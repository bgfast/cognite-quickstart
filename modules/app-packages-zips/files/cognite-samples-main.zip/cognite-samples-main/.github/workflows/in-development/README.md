## Introduction

Welcome to the **Field Engineering Demo Library** repository! This repository is designed to provide a common library of Cognite Data Fusion (CDF) demo modules that can be used, improved, and tailored to support different use cases and industries. Deployment from this environment does not require coding experience. The foundation of this demo environment is the **Valhall dataset** from Open Industrial Data. Additional data sources may be added as separate modules to extend or enhance the demos.

### Overview & Key Terms

- **Github Actions:** You can deploy to CDF through the Github UI using actions configured in the `Actions` tab in this repository.  You are not required to set up CDF toolkit on your own.

- **Github Environments:** All secrets and environmental variables are managed through the Github UI using a Github feature called Environments. You can access Github Environments in the `Settings` tab in this repository and then selecting `Environments`. Instructions on creating your environment are provided in the [Deployment Walkthrough](#deployment-walkthrough) section below.

- **Modules:** Each demo is organized into a "module." A module is a bundle of CDF resources, such as data models, time series, files, and Streamlit apps. While modules are not entirely self-contained, the number of inter-module dependencies should be minimized and documented. Each module should include its own `README.md` file with instructions and details.

- **Industry Models:** A key feature of this repository is the inclusion of **industry models**, located under the `cog-demo/modules/industry_models` folder. These models use the Valhall dataset as a base but modify asset and time series names to simulate demos for different industries, such as energy, chemicals, or biotech. This approach maintains compatibility with existing CDF artifacts created for the Valhall demo while offering industry-specific flexibility.

### Getting Started

To set up and deploy this demo environment, you will need to be an administrator in GitHub and have the appropriate permissions to enable deployment from a GitHub Action. 

### Toolkit Documentation

If you are interested in learning more about toolkit and developing your own modules, visit the [Toolkit section](https://docs.cognite.com/cdf/deploy/cdf_toolkit/) on Cognite Docs for additional information. The [YAML reference library](https://docs.cognite.com/cdf/deploy/cdf_toolkit/references/resource_library) is particularly helpful to understand how YAML files are configured for each CDF artifact type, which will enable you to create your own modules. 


## Deployment Walkthrough
### Pre-requisites
These pre-requisites assume you are using Azure.
1. If you need to create a CDF environment (organization + project), follow the steps outlined [here](https://cognitedata.atlassian.net/wiki/spaces/AUTH/pages/3375923233/CDF+Project+and+Organization+Management) to create an internal environment. If you already have one, you can skip this step.
2. In Entra ID, create an App Registration or use a Cognite internal application registration. Generate a secret and take note of both client ID and secret.
![alt text](images/my_organization.png "CDF app registration")
3. Add that App Registration to the CDF admin group for your organization, or manually create a group in CDF that gives the App Registration permissions comparable to the default `oidc-admin-group`. If using a Cognite internal application registration, you must create a new temp admin group (groups and projects full capabilities) and assign that app registration to the new group.
![alt text](images/admin.png "Admin")
4. Cognite Functions is not activated by default for a first time CDF deployment. If Cognite Functions is not activated before you try to deploy from GitHub, the deployment will fail. Go into the CDF web UI and access the Cognite Functions page to activate it. If this is a new CDF with no permissions added, you will need to manually add permissions for your user account so it has "read/write" for functions so you can access the page. You must wait for Cognite Functions to finish activating before running the GitHub action. Cognite Functions activation takes an hour or so.
5. Change the Data Modeling status of your CDF to "DATA_MODELING_ONLY" by submitting a ticket [here](https://cognitedata.atlassian.net/servicedesk/customer/portal/44/create/636). You can continue before this has been completed, but you will need to have this completed before you upload your 3D model.
6. A Github Environment with variables and secrets must be created in this repository for your CDF:
   - In this repository, go to GitHub: `Settings > Environments`.
   - Familiarize yourself with an example, like `demo`.
   - Create your environment using the **same name** as your CDF project.
   - Add your environment variables and secrets

###### Environment Secrets
- FUNCTION_CLIENT_SECRET
- IDP_CLIENT_SECRET
- TRANSFORMATION_CLIENT_SECRET

###### Environment Variables 
required environment variables with examples, on the left for CDF app registrations and on the right for Entra ID app registrations:

- CDF_CLUSTER
- CDF_PROJECT
- FUNCTION_CLIENT_ID
- IDP_CLIENT_ID
- IDP_SCOPES (None or https://<cluster>.cognitedata.com/.default)
- IDP_TENANT_ID
- IDP_TOKEN_URL (https://auth.cognite.com/oauth2/token or https://login.microsoftonline.com/**tenantID**/oauth2/v2.0/token)
- LOGIN_FLOW  (client_credentials)
- PROVIDER  (cdf or entra_id)
- TRANSFORMATION_CLIENT_ID

![alt text](images/secrets_image.png "Secrets")
![alt text](images/variable_image.png "variables")


### Deployment Steps

1. **Prepare Deployment YAML File**  
   - You can use a programming IDE (like VS Code) or the GitHub UI to create your own deployment YAML file. The steps are similar.
   - Navigate to the `cog-demos` folder.  
   - Download `config.demo.yaml` to use as a template, and start customizing the parameters as needed for your environment. You will customize the modules in the next step.\
   - The `config.demo.yaml` contains all modules for a basic Valhall deployment. Add additional modules if desired.
   - Name the file `config.<Your_CDF_Project>.yaml`
   - Create your own branch and check your YAML deployment file into GitHub.
   - Create a pull request and merge the branch back into `main`.

2. **Run the Deployment**  
   - Create your own branch and check your YAML deployment file into GitHub.
   - Create a pull request and merge the branch back into `main`.

2. **Run the Deployment**  
   - Go to the GitHub Actions tab.  
   - Select the deployment action `Deploy CDF Modules` and specify the branch (if not `main`) and the environment name corresponding to your YAML deployment file.
   - The first deployment could fail, but permissions will be created. Run the deployment a second time. If it still fails, try locally to run `poetry run cdf auth init` to set up your environment (we will fix that soon hopefully)

![alt text](images/run_workflow.png "Secrets")


### Summary video
https://github.com/user-attachments/assets/078ec3ca-ed2b-4d32-bf5d-d6998fff1993

### Post-Deployment Steps for First Time Deployment
1. In your CDF's Data Management workspace, go to Configure > 3D, create a scene and link it to your location and attach and upload the Valhall 3D model [downloaded from here](https://drive.google.com/drive/folders/1JQdDRdlCzwn8IpFl1TPHQfgnGqrVDvx2?usp=sharing). After the model is uploaded, publish the model. NOTE: If your CDF is not set to "DATA_MODELING_ONLY", your 3D model will not be uploaded correctly. Ensure your CDF is set to "DATA_MODELING_ONLY" per the pre-requisites.



## Local run

1. Clone the repository

2. Follow the prerequisites above 

In your terminal: 

3. install dependencies using poetry.lock `poetry install --no-root`

4. Run `poetry run cdf auth init` to set up your environment. Alternatively, you can edit .env file with the right details based on [.env template CDF authentication](.env_tmpl.cdf) or [.env template Entra authentication](.env_tmpl.entra) and run `poetry run cdf auth init` afterwards. Have a look at the [.env template CDF authentication](.env_tmpl.cdf) or [.env template Entra authentication](.env_tmpl.entra) files, since they set up additional environment variables that are used to run [local scripts](scripts) (datapoints replication and wipe of CDF project) and run functions locally.

![alt text](images/auth_init.png "auth init command")

In Fusion:

5. Check that the app registration for toolkit belongs to the newly created toolkit group, if not add it manually, temp admin group can be deleted. If you used the app registration from Entra ID, you can skip this step, verify the groupID is linked to the newly created toolkit group. 

![alt text](images/toolkit_app.png "Toolkit app registration")

6. Create your config in [cog-demos](cog-demos), config-<your environment>.yaml, for example copy and rename [config.demo.yaml](cog-demos/config.demo.yaml). 

In your terminal: 

7. Build the templates `poetry run cdf build --env=<your environment>` (replace <your environment> with your environment)

8. Deploy the templates `poetry run cdf deploy --env=<your environment>` (replace <your environment> with your environment)

9. Run `poetry run cdf run workflow --external-id=wf_population_valhall` (if not successful, you might have to run the workflow manually from the UI, you need to enable it un unleash first)

Alternatively, you can run the [script](full_deploy.sh), for example like `./full_deploy.sh <your environment>` to deploy everything. Adapt the script if necessary to remove some compononents, like workflows you are not deploying.


## Additional scripts

- [run workflow in CDF](scripts/run_workflow.py) to run a workflow in CDF.
Run with `poetry run run_workflow` OR `poetry run run_workflow --external_id <external_id> [--confirm]`

- [replication script - DM project](scripts/replication.py) to run locally. this will replicate datapoints from publicdata (CDM) to your own project.
Run with `poetry run replication` OR `poetry run replication --start_time <start_time> --days_offset <days_offset> (--start_over) (--confirm)`

- [run 3D contextualization in CDF](scripts/three_d_contextualization.py) to run 3D contextualization in CDF.
Run with `poetry run three_d_contextualization` OR `poetry run three_d_contextualization --start_time <start_time> --days_offset <days_offset> (--start_over) (--confirm)`

- [wipe data in CDF - DM project](scripts/wipe_cdf_dm.py) to run locally. this will delete all data in CDF. Open a selection window and asks for confirmation
Run with `poetry run wipe`

## FAQ

### What is a module?
A module is a bundle of CDF resources, such as data models, time series, files, and Streamlits. A general practice is to create a module for each use case. While some dependencies between modules may exist, it is a good idea to use modules to minimize these dependencies.

### What is an industry model?
An industry model is a module under the `cog-demo/modules/industry_model` folder that applies industry-specific asset and time series names to the Valhall dataset. All external IDs remain the same, so this should make it interoperable with many CDF artifacts that were created against Valhall demo.

### Where do I go for help?
Ask for help in the `#uat-and-demo-projects` channel or reach out to @gaetan-h


## Very quick deploy
You can create GitHub environments, including variables and secrets, using the GitHub CLI 

- Install gh: If you haven't already, install the GitHub CLI from https://cli.github.com/, eg `brew install gh`

- Authenticate: Log in to your GitHub account using `gh auth login`

- Run the [script](create_environment.sh) to create the environment, variables and secrets based on the .env file, environment name is CDF_PROJECT

- The script will then create the toolkit app registration and add it to the toolkit group

- The script will then trigger the workflow to deploy all the workflow modules

```
./create_environment.sh
```

Prequisites:
- Have requested the CDF project
- Have created an admin group in CDF (only required full capabilities on groups and projects) and added the toolkit app registration to it (this group can be deleted after the toolkit group has been created)
- Have setup the .env file with the right details based on [.env template CDF authentication](.env_tmpl.cdf) or [.env template Entra authentication](.env_tmpl.entra)