# 🎨 Automated Worktree Color Management

This repository includes an automated system for managing color-coded worktrees in VS Code/Cursor. The system can handle 1-10 worktrees and automatically assigns unique colors based on worktree names and branch types.

## 🚀 Quick Start

### Option 1: Set up current worktree only
```bash
python scripts/setup-worktree-colors.py
```

### Option 2: Set up all worktrees at once
```bash
python scripts/setup-all-worktrees.py
```

### Option 3: Add to your shell profile for automatic setup
Add this to your `~/.zshrc` or `~/.bashrc`:
```bash
# Auto-setup worktree colors when entering a repository
worktree_colors() {
    if [[ -f "scripts/setup-worktree-colors.py" ]]; then
        python scripts/setup-worktree-colors.py
    fi
}

# Run on directory change
chpwd_functions=(${chpwd_functions[@]} "worktree_colors")
```

## 🎨 Color Palette

The system uses a 10-color palette with intelligent assignment:

| Color | Hex | Purpose |
|-------|-----|---------|
| 🟢 Green | `#4caf50` | Main/Production |
| 🔵 Blue | `#2196f3` | Testing/Staging |
| 🔴 Red | `#ff6b6b` | Feature Development |
| 🟠 Orange | `#ff9800` | Experimental |
| 🟣 Purple | `#9c27b0` | Hotfix/Urgent |
| 🟡 Teal | `#009688` | Research/POC |
| 🔷 Pink | `#e91e63` | UI/UX Work |
| 🔹 Indigo | `#3f51b5` | Backend/API |
| 🟤 Brown | `#795548` | Documentation |
| ⚫ Gray | `#607d8b` | Maintenance |

## 🧠 How It Works

The system uses multiple strategies to assign colors:

1. **Worktree Order**: Sorts worktrees alphabetically and assigns colors in order
2. **Branch Type Detection**: Recognizes common branch patterns:
   - `main`/`master` → Green
   - `feature/*` → Red
   - `hotfix/*` → Purple
   - `test/*`/`staging` → Blue
   - etc.
3. **Name Pattern Recognition**: Analyzes worktree names for keywords
4. **Hash Fallback**: Uses consistent hashing for unique cases

## 📁 What Gets Created

Each worktree gets a `.vscode/settings.json` file with:
- **Colored title bar** and status bar
- **Custom window title** showing purpose
- **Metadata comments** with generation info

Example generated settings:
```json
{
    "window.title": "FEATURE DEVELOPMENT - ${activeEditorShort}${separator}${rootName}",
    "workbench.colorCustomizations": {
        "titleBar.activeBackground": "#ff6b6b",
        "titleBar.activeForeground": "#ffffff",
        "statusBar.background": "#ff6b6b"
    },
    "// Worktree Info": {
        "name": "cognite-samples-3",
        "branch": "feature/organize-pid-modules",
        "color": "Red",
        "purpose": "Feature Development"
    }
}
```

## 🔧 Advanced Usage

### Custom Color Assignment
To override the automatic assignment, you can:
1. Edit the `BRANCH_TYPE_COLORS` dictionary in `setup-worktree-colors.py`
2. Add custom patterns to `get_worktree_purpose()` function
3. Manually edit the generated `.vscode/settings.json` files

### Git Hooks Integration
Add to `.git/hooks/post-checkout`:
```bash
#!/bin/bash
# Auto-setup colors after branch checkout
if [[ -f "scripts/setup-worktree-colors.py" ]]; then
    python scripts/setup-worktree-colors.py
fi
```

### CI/CD Integration
Add to your development setup scripts:
```bash
# In your onboarding script
python scripts/setup-all-worktrees.py
```

## 🛠️ Troubleshooting

### Colors not showing?
1. Restart VS Code/Cursor
2. Check if `.vscode/settings.json` was created
3. Verify you're in a Git repository

### Script not found?
```bash
# Make sure scripts are executable
chmod +x scripts/setup-worktree-colors.py
chmod +x scripts/setup-all-worktrees.py
```

### Wrong colors assigned?
The system is deterministic - same worktree names and branches will always get the same colors. If you want different colors, you can:
1. Rename your worktrees
2. Edit the generated settings manually
3. Modify the color assignment logic

## 📋 Requirements

- Python 3.6+
- Git with worktree support
- VS Code or Cursor

## 🔗 Integration with Terminal

This works seamlessly with your existing terminal prompt setup:
```bash
# Your existing prompt still works
PS1='%F{cyan}%n@%m%f:%F{yellow}%~%f%F{green}$(show_git_worktree)%f$ '
```

The `whereami` command also continues to work as before.

## 📈 Benefits

✅ **Automatic**: No manual color configuration needed  
✅ **Consistent**: Same worktree = same color every time  
✅ **Scalable**: Handles 1-10 worktrees automatically  
✅ **Intelligent**: Recognizes branch patterns and purposes  
✅ **Maintainable**: All logic in version-controlled scripts  
✅ **Portable**: Works on any machine with the repository 