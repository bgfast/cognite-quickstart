# CDF Development Tasks

## ✅ Completed Tasks

### Task 1: Add one-click streamlit to source control in admin folder
- **Status**: ✅ **COMPLETED**
- **Details**: 
  - Created `cog-demos/modules/admin/admin-streamlit/` structure
  - Downloaded streamlit from CDF using `scripts/download_streamlit_from_cdf.py`
  - Fixed `gtoken_space.space.yaml` with proper space definition
  - Successfully deployed and tested locally and via GitHub Actions

### Task 2: Refactor YAML for REST calls (after Kevin meeting)
- **Status**: ⏳ **PENDING** (waiting for Kevin meeting)

### Task 3: Circle back with Thomas for deployment
- **Status**: ⏳ **PENDING**

### Task 4: Refactor one-click to accept .env file input
- **Status**: ✅ **COMPLETED**
- **Details**: Created comprehensive environment switching system with `cdfenv.sh`
  - Cross-platform support (Mac, Linux, Windows PowerShell, Git Bash)
  - Interactive numbered selection
  - Direct switching by name or partial match
  - Uses `~/envs` folder for `.env.cluster.tenant.project` files

### Task 5: Deploy to existing CDF using temporary GitHub token with Azure KeyVault
- **Status**: ⏳ **PENDING**

### Task 6: Share framework with Fredrik, Gaetan, Jan Helge, Jan Inge
- **Status**: ⏳ **PENDING**

### Additional Completed Work:
- **Trader Dashboard Standardization**: Fixed array issues and standardized "My Book of Business" naming across all 7 trader dashboards
- **Download Script Enhancement**: Created comprehensive streamlit download tool with conflict resolution, toolkit compatibility, and bulk download features
- **Cleanup System**: Simplified to use CDF toolkit's native `cdf clean` command instead of custom scripts
- **Git Workflow**: Proper branch management and pull request workflow established

---

## 🆕 New Feature Tasks

### Task 7: Deployment Audit Logging
- **Status**: 🔄 **NEEDS DISCUSSION**
- **Objective**: Log to a Data Model every time toolkit deploys to CDF for audit trail
- **Discussion Points**:
  - Which Data Model to use? (Create new `deployment_audit` or use existing?)
  - Information to capture: timestamp, user, modules, environment, success/failure, commit hash
  - Implementation approach: toolkit plugin/hook vs GitHub Actions workflow modification
  - Should we log both deployments and `cdf clean` operations?
  - Scope: admin-streamlit specific or general solution for all deployments?

### Task 8: Enhanced GitHub Action Titles
- **Status**: ✅ **COMPLETED**
- **Objective**: Add CDF project name to GitHub Action title for easy identification
- **Implementation**: 
  - **Workflow Run Name**: `DYNAMIC DEPLOYMENT - [project-name]`
  - **Job Name**: `Deploy [project-name]`
  - **Format**: Uses `[project-name]` format for clear identification
  - **Dynamic**: Project name extracted from `inputs.environment` parameter
  - **Module Display**: New first step shows detailed module list instead of cramming into title
- **Before**: `Deploy to [project] - Module List`
- **After**: `DYNAMIC DEPLOYMENT - [project]` + dedicated module display step
- **Benefits**: 
  - Easier identification of deployments in GitHub Actions UI
  - Project name prominently displayed in both run name and job name
  - Consistent formatting with square brackets
  - Clean titles without long module lists cluttering the UI
  - Detailed module information clearly displayed in first step
- **Testing Required**: 
  - Run a GitHub Action deployment to verify the new titles display correctly
  - Confirm project name appears in both workflow run name and job name
  - Validate new "Display Deployment Configuration" step shows module list properly
  - Ensure titles are clean without long module lists

### Task 9: Clean Button in Admin Streamlit
- **Status**: 🧪 **READY FOR TESTING**
- **Objective**: Add clean button functionality to admin streamlit for removing deployed modules
- **Implementation Details**:
  - **UI Design**: Added 🧹 Clean buttons next to each 🚀 Deploy button in 2-column layout
  - **Confirmation Dialog**: Two-step confirmation process with module list preview
  - **Workflow Integration**: Enhanced GitHub Actions workflow with clean operation support
  - **Safety Features**: 
    - Confirmation dialog showing exact modules to be cleaned
    - Cancel option to abort operation
    - Dry-run mode support for testing
  - **User Experience**: 
    - Clean buttons disabled when deploy buttons are disabled (same validation)
    - Real-time progress tracking via GitHub Actions
    - Success/error feedback with direct links to workflow runs
- **Technical Implementation**:
  - Added `trigger_clean_workflow()` function to call GitHub Actions
  - Enhanced workflow with `action` input parameter (deploy/clean)
  - Conditional workflow steps based on action type
  - Uses CDF toolkit's native `cdf clean` command
  - Proper environment variable handling for authentication
- **Files Modified**:
  - `cog-demos/modules/admin/admin-streamlit/streamlit/stapp-admin-streamlit/main.py`
  - `.github/workflows/dynamic_deployment.yaml`
- **Testing Notes**: Ready for user testing to confirm clean operations work correctly

### Task 10: Streamlit Version Indicator
- **Status**: 🔄 **NEEDS DESIGN DISCUSSION**
- **Objective**: Display version information in streamlit interface
- **Discussion Points**:
  - **Version source**: Git commit hash, semantic version, build timestamp, or combination?
  - **Display location options**:
    - Sidebar info panel
    - Footer of main page
    - About/Info modal dialog
    - Header subtitle
  - Interactive features: clickable for more details (commit message, deploy time)?
  - Show both "deployed version" and "latest available version"?
  - Standardize across all streamlits in project?

### Task 11: Deployment Validation Testing
- **Status**: 🔄 **NEEDS TECHNICAL DISCUSSION**
- **Objective**: Unit test validation via API calls to confirm streamlit deployment success
- **Discussion Points**:
  - **Validation scope**:
    - Streamlit app exists and accessible?
    - Functionality works (CDF connectivity)?
    - All dependent resources properly deployed?
  - **Execution timing**:
    - Part of GitHub Actions post-deployment?
    - Separate scheduled health checks?
    - On-demand via admin interface?
  - **Test methods**:
    - Direct CDF API calls for streamlit status?
    - HTTP requests to streamlit endpoints?
    - Browser automation for UI testing?
  - **Reusability**: Pattern for all streamlits vs admin-specific?

### Task 12: Multi-Tenant Azure Group Management
- **Status**: 📦 **BACKLOG**

### Task 13: Module List Paste Functionality in Admin Streamlit
- **Status**: 🔄 **NEEDS DESIGN DISCUSSION**
- **Objective**: Add ability to paste a list of modules into admin-streamlit for bulk selection
- **Discussion Points**:
  - **Input format**: Support comma-separated, line-separated, or both?
  - **UI placement**: Text area above existing module checkboxes or separate tab/section?
  - **Validation**: How to handle invalid module names or paths?
  - **Integration**: Should it replace checkbox selection or work alongside it?
  - **Parsing logic**: Handle different formats (with/without "modules/" prefix)?
  - **User experience**: Clear button to reset, preview of parsed modules?
- **Use Cases**:
  - Bulk deployment of predefined module sets
  - Copy/paste from documentation or other sources
  - Faster selection for power users
  - Integration with external tooling

### Task 14: UI Testing of Streamlit in SaaS Deployment
- **Status**: 🚧 **PHASE 1 COMPLETED** ✅ **PHASE 2 READY**
- **Objective**: Implement comprehensive automated testing for streamlit applications deployed in CDF SaaS environment

### Task 15: CDF Group Access Comparison Streamlit
- **Status**: ✅ **CORE FUNCTIONALITY COMPLETED** ⚠️ **POLISH ISSUES REMAIN**
- **Objective**: Create comprehensive tool for comparing group access permissions between two CDF environments
- **Location**: `cog-demos/modules/admin/admin-streamlit/streamlit/stapp-cdf-group-compare/`
- **Completed Features**:
  - ✅ Side-by-side group comparison between two CDF environments
  - ✅ Human-readable capability names (150+ technical-to-readable mappings)
  - ✅ Missing group detection with complete capability analysis
  - ✅ Group mapping interface for cross-environment name mismatches
  - ✅ Individual & bulk capability addition (preview mode)
  - ✅ Dual operation modes (Local mode with auto .env loading + SaaS mode with file upload)
  - ✅ Auto-detection of CDF project names and cluster info
  - ✅ Comprehensive error handling and debugging capabilities
  - ✅ Documentation and startup scripts
- **Open Issues & Tasks**:
  - 🔴 **HIGH PRIORITY**:
    1. **DataFrame Serialization Errors**: `ArrowTypeError: Expected bytes, got a 'int' object` for column 'bgfast' - repeated serialization failures (non-blocking but generates log spam)
    2. **Group Mapping Dropdown Loading**: Dropdowns not consistently populating with group names (debug info added, needs root cause analysis)
  - 🟡 **MEDIUM PRIORITY**:
    3. **Text Visibility Issues**: "White text on white background in page menu and radio button options" - needs custom Streamlit theming/CSS
    4. **Real CDF SDK Integration**: Currently preview/placeholder mode - needs actual implementation of `add_capability_to_group()` function with proper API calls, error handling, rollback, confirmation dialogs
  - 🟢 **LOW PRIORITY**:
    5. **Performance Optimization**: Multiple sequential CDF API calls for group mapping - needs caching, connection pooling, parallel requests
    6. **Enhanced Error Handling**: Basic error messages - needs specific error codes, retry mechanisms, better connection status reporting
- **Next Steps**: Fix DataFrame serialization and group mapping loading issues for production-ready stability
- **Progress Update**:
  - ✅ **Phase 1 COMPLETED**: Fixed demo scripts with robust path resolution
    - **Implementation**: Multiple path attempts (local, container, relative paths) with comprehensive fallback
    - **Coverage**: All 7 trader dashboards now have working demo functionality
    - **Details**: Industry-specific embedded demo scripts, graceful error handling, extensive logging
    - **Files Modified**: All trader dashboard `main.py` files with robust `load_demo_script()` function
    - **Result**: Demo scripts now work reliably in both local development and SaaS deployment environments
  - 🆕 **Phase 2 READY**: Comprehensive trader dashboard testing system
- **Architecture Phases**:
  1. ✅ **Phase 1**: Fix demo scripts with robust path resolution **COMPLETED**
  2. 🆕 **Phase 2**: Trader Dashboard Automated Testing **READY TO START**
  3. **Phase 3**: Comprehensive UI testing framework
  4. **Phase 4**: Advanced testing (performance, visual regression)
- **Phase 2 Requirements** (Trader Dashboard Testing):
  - **Automated Test Suite**: Script to test all 7 trader dashboards systematically
  - **Live CDF Testing**: Run tests against actual CDF SaaS environment (not local)
  - **Functionality Validation**: Test core features like data loading, filtering, visualization
  - **Local vs SaaS Comparison**: Document differences in behavior between local and SaaS deployment
  - **Reporting**: Generate test results with pass/fail status and detailed error information
- **Trader Dashboards to Test**:
  1. `trader-dashboard-bulk-chemicals`
  2. `trader-dashboard-food-beverage` 
  3. `trader-dashboard-metals-mining`
  4. `trader-dashboard-petrochem`
  5. `trader-dashboard-pulp-paper`
  6. `trader-dashboard-refinery`
  7. `trader-dashboard-utilities`
- **Test Categories**:
  - **Deployment Test**: Verify streamlit deploys successfully to CDF SaaS
  - **Connectivity Test**: Confirm CDF API connections work properly
  - **Data Loading Test**: Validate that demo data loads correctly
  - **UI Functionality Test**: Test filtering, search, and interactive elements
  - **Performance Test**: Measure load times and responsiveness
  - **Error Handling Test**: Verify graceful handling of missing data/permissions
- **Implementation Options**:
  - **Python Test Suite**: Automated script using requests/selenium for UI testing
  - **GitHub Actions Integration**: Run tests as part of CI/CD pipeline
  - **Admin Streamlit Integration**: Add test dashboard tab to admin interface
  - **Standalone Testing Tool**: Separate testing application
- **Success Criteria**:
  - All trader dashboards deploy successfully to CDF SaaS
  - Core functionality works in SaaS environment (✅ demo scripts now working)
  - Automated test suite provides reliable validation
  - Local vs SaaS differences are well documented
  - Easy to add new tests for future dashboard changes
- **Discussion Points** (for future phases):
  - **Testing Framework**: Selenium, Playwright, or Streamlit-specific testing tools?
  - **Test Scope**: 
    - Functional testing (buttons, forms, navigation)
    - Visual regression testing
    - Performance testing (load times, responsiveness)
    - Cross-browser compatibility
  - **Test Environment**: 
    - Testing against live SaaS deployments vs staging environment
    - Authentication handling for CDF SaaS
    - Test data management and cleanup
  - **CI/CD Integration**: 
    - Run tests after deployment in GitHub Actions?
    - Test failure handling and rollback procedures
    - Reporting and notification of test results
- **Technical Considerations**:
  - SaaS-specific challenges (authentication, network access)
  - Test isolation and parallel execution
  - Screenshot/video capture for debugging
  - Integration with existing deployment pipeline

### Task 15: Data Lake Streaming Integration
- **Status**: 🔄 **NEEDS INTEGRATION PLANNING**
- **Objective**: Integrate custom streaming pipeline for large file transfers from data lake CDF to destination CDF
- **Background**: 
  - Existing Python code that connects to a "data lake" CDF (source)
  - Streams large files (PDFs, point clouds, 3D files) to destination CDF
  - Uses custom GitHub runner for handling very large file transfers
  - Proven solution for large-scale data migration/synchronization
- **Integration Requirements**:
  - **Code Integration**: Incorporate existing streaming code into project structure
  - **GitHub Runner Setup**: Document and standardize custom runner configuration
  - **Configuration Management**: Integrate with existing CDF environment switching (`cdfenv.sh`)
  - **Deployment Pipeline**: Add streaming operations to admin streamlit or standalone interface
  - **Monitoring & Logging**: Add progress tracking and error handling for large transfers
- **Technical Considerations**:
  - **File Type Support**: PDFs, point clouds (.las, .laz, .xyz?), 3D files (.obj, .gltf, .ifc?)
  - **Transfer Optimization**: Chunking, resume capability, parallel transfers
  - **Authentication**: CDF authentication for both source and destination
  - **Storage Efficiency**: Deduplication, compression, delta syncing
  - **Error Handling**: Network interruption recovery, partial transfer cleanup
- **Implementation Options**:
  - **Standalone Tool**: Separate CLI/script for data lake operations
  - **Admin Integration**: Add data lake tab to admin streamlit
  - **GitHub Actions**: Scheduled or triggered data synchronization workflows
  - **API Service**: REST API for on-demand streaming operations
- **Use Cases**:
  - **Initial Data Migration**: Bulk transfer from legacy systems
  - **Ongoing Synchronization**: Regular updates from data lake to operational CDF
  - **Backup & Archive**: Streaming data to archive CDF instances
  - **Cross-Project Sharing**: Moving large datasets between CDF projects
- **Success Criteria**:
  - Reliable transfer of large files (>GB) without timeouts
  - Progress monitoring and resumable transfers
  - Integration with existing deployment and environment management
  - Documented setup process for custom GitHub runners
  - Error handling and automatic retry mechanisms

### Task 16: GitHub-Free SaaS Deployment
- **Status**: 🔄 **ARCHITECTURE REDESIGN NEEDED**
- **Objective**: Remove GitHub dependency by installing Cognite Toolkit directly in SaaS instance for direct deployment
- **Background**: 
  - Current deployment relies on GitHub Actions and custom runners
  - GitHub adds complexity, latency, and external dependencies
  - SaaS instances should be self-contained for deployment operations
  - Need ability to deploy to any CDF environment directly from SaaS
- **Core Requirements**:
  - **Toolkit Installation**: Install Cognite Toolkit directly in SaaS container/environment
  - **Direct Deployment**: Deploy modules/configurations without GitHub intermediary
  - **Environment Agnostic**: Deploy to any CDF instance (dev, test, prod, customer environments)
  - **Self-Contained**: All deployment capabilities within SaaS instance
  - **Configuration Management**: Manage deployment configs without GitHub repo dependency
- **Technical Challenges**:
  - **Container Persistence**: Toolkit installation and config storage in ephemeral containers
  - **Authentication**: Direct CDF authentication without GitHub secrets
  - **Config Storage**: Alternative to GitHub for storing deployment configurations
  - **Version Control**: Track deployments without Git history
  - **Security**: Secure credential management in SaaS environment
  - **Networking**: Direct CDF API access from SaaS containers
- **Implementation Approaches**:
  - **Embedded Toolkit**: Bundle Cognite Toolkit in SaaS container image
  - **Dynamic Installation**: Install toolkit on-demand in running containers
  - **Config Database**: Store deployment configs in CDF or external database
  - **API-Based**: Use CDF APIs directly instead of toolkit CLI
  - **Hybrid**: Keep essential configs in SaaS, sync minimal data with external systems
- **Architecture Options**:
  - **Streamlit Integration**: Add deployment interface to admin streamlit
  - **REST API Service**: Standalone deployment service within SaaS
  - **CLI Interface**: Command-line toolkit access from SaaS environment
  - **Web Interface**: Custom deployment dashboard
- **Benefits**:
  - **Reduced Latency**: Direct deployment without GitHub Actions queue
  - **Simplified Workflow**: No external dependencies or runner setup
  - **Real-time Deployment**: Immediate deployment from SaaS interface
  - **Cost Reduction**: No GitHub runner costs or complexity
  - **Offline Capability**: Deploy without internet connectivity to GitHub
- **Use Cases**:
  - **Rapid Prototyping**: Quick deployment of new modules/configs
  - **Customer Demos**: Deploy to customer environments during demos
  - **Emergency Fixes**: Immediate deployment without CI/CD pipeline
  - **Multi-Environment**: Deploy same config to multiple CDF instances
  - **Offline Deployments**: Air-gapped or restricted network environments
- **Success Criteria**:
  - SaaS instance can deploy modules without GitHub dependency
  - Deploy to any CDF environment with proper credentials
  - Maintain deployment history and rollback capability
  - Secure credential and configuration management
  - Performance comparable to or better than GitHub Actions

### Task 17: GitHub-Free Large File Streaming
- **Status**: 🔄 **ALTERNATIVE ARCHITECTURE NEEDED**
- **Objective**: Implement large file streaming (PDFs, point clouds, 3D files) without GitHub custom runners
- **Background**: 
  - Current streaming solution relies on custom GitHub runners for large file handling
  - Need alternative that works directly from SaaS or local environments
  - Remove GitHub infrastructure dependency for data transfer operations
  - Enable streaming in air-gapped or restricted environments
- **Core Requirements**:
  - **Direct CDF-to-CDF Streaming**: Stream large files between CDF instances without GitHub
  - **Large File Support**: Handle multi-GB files (point clouds, 3D models, large PDFs)
  - **Resume Capability**: Handle network interruptions and resume transfers
  - **Progress Monitoring**: Real-time transfer progress and status
  - **Authentication**: Direct CDF authentication for source and destination
- **Technical Approaches**:
  - **SaaS-Based Streaming**: Stream directly from SaaS container environment
  - **Local Client**: Streaming client that runs on local machines/servers
  - **CDF Functions**: Use CDF Functions for server-side streaming
  - **Cloud Storage Bridge**: Use cloud storage as intermediary (S3, Azure Blob)
  - **Direct HTTP Streaming**: Chunked transfer directly between CDF instances
- **Implementation Options**:
  - **Streamlit Interface**: Add streaming controls to admin streamlit
  - **CLI Tool**: Standalone command-line streaming utility
  - **REST API**: Streaming service with REST endpoints
  - **Background Service**: Long-running streaming daemon
  - **Batch Processing**: Queue-based batch streaming system
- **Technical Challenges**:
  - **Memory Management**: Stream large files without loading entirely in memory
  - **Network Resilience**: Handle timeouts, retries, and connection drops
  - **Concurrent Transfers**: Multiple file streaming with bandwidth management
  - **File Integrity**: Checksums and validation for transferred files
  - **Metadata Preservation**: Maintain file metadata and CDF relationships
- **Architecture Considerations**:
  - **Chunked Transfer**: Stream files in chunks to handle size limits
  - **Parallel Processing**: Multiple concurrent streams for throughput
  - **Queue Management**: Prioritize and schedule large file transfers
  - **Storage Optimization**: Temporary storage and cleanup strategies
  - **Monitoring**: Logging, metrics, and alerting for transfer operations
- **Use Cases**:
  - **Data Migration**: Move large datasets between CDF environments
  - **Backup Operations**: Stream files to archive/backup CDF instances
  - **Cross-Region Sync**: Synchronize large files across geographic regions
  - **Customer Data Transfer**: Move customer data without GitHub dependencies
  - **Offline Scenarios**: Air-gapped or restricted network environments
- **Success Criteria**:
  - Stream multi-GB files reliably without GitHub infrastructure
  - Resume interrupted transfers automatically
  - Monitor transfer progress in real-time
  - Handle concurrent transfers efficiently
  - Maintain file integrity and metadata

### Task 18: Custom GitHub Action for Large File Streaming
- **Status**: 🔄 **GITHUB ACTION DEVELOPMENT**
- **Objective**: Create specialized GitHub Action exclusively for large file streaming between CDF instances
- **Background**: 
  - Current custom runners are complex and resource-intensive
  - Need purpose-built GitHub Action for streaming use case
  - Simplify deployment while maintaining GitHub integration
  - Reusable action for multiple projects and workflows
- **Core Requirements**:
  - **Purpose-Built Action**: GitHub Action specifically designed for CDF file streaming
  - **Large File Optimization**: Optimized for multi-GB file transfers
  - **Configurable**: Support different source/destination CDF configurations
  - **Resumable**: Handle network interruptions and resume transfers
  - **Efficient**: Minimal resource usage compared to custom runners
- **Action Features**:
  - **Input Parameters**: Source CDF, destination CDF, file filters, transfer options
  - **Authentication**: Support for CDF service principals and tokens
  - **File Selection**: Flexible file filtering (by type, size, date, metadata)
  - **Transfer Options**: Parallel transfers, chunk size, retry logic
  - **Progress Reporting**: Transfer status and progress in GitHub logs
  - **Error Handling**: Comprehensive error reporting and recovery
- **Technical Implementation**:
  - **Container-Based**: Lightweight container with streaming utilities
  - **Python SDK**: Use CDF Python SDK for API interactions
  - **Streaming Logic**: Efficient chunked transfer implementation
  - **State Management**: Track transfer state for resumability
  - **Resource Management**: Optimize memory and network usage
- **Configuration Options**:
  - **Source Configuration**: CDF cluster, project, authentication
  - **Destination Configuration**: Target CDF cluster, project, credentials
  - **File Filters**: File types, size ranges, date ranges, metadata filters
  - **Transfer Settings**: Chunk size, parallel streams, timeout values
  - **Retry Policy**: Retry attempts, backoff strategy, failure handling
- **Integration Points**:
  - **Workflow Triggers**: Scheduled, manual, or event-triggered transfers
  - **Environment Variables**: Secure credential management
  - **Output Variables**: Transfer results for downstream actions
  - **Artifact Storage**: Optional local file caching or staging
  - **Notification**: Integration with GitHub notifications or external systems
- **Advantages Over Custom Runners**:
  - **Simplified Setup**: No custom runner infrastructure required
  - **Cost Effective**: Use standard GitHub Actions compute
  - **Maintainable**: Standard GitHub Action lifecycle and updates
  - **Portable**: Reusable across different repositories and projects
  - **Secure**: Leverage GitHub's security model and secret management
- **Use Cases**:
  - **Scheduled Sync**: Regular data synchronization between CDF instances
  - **Deployment Workflows**: Stream files as part of deployment pipelines
  - **Backup Automation**: Automated backup of large files to archive CDF
  - **Multi-Environment**: Stream files across dev/test/prod environments
  - **Customer Onboarding**: Automated data transfer for new customers
- **Success Criteria**:
  - GitHub Action handles multi-GB files reliably
  - Simpler setup than custom GitHub runners
  - Reusable across multiple projects
  - Comprehensive logging and error reporting
  - Efficient resource utilization within GitHub Actions limits

---

## 🔧 Technical Infrastructure Tasks

### Environment Management
- **Status**: ✅ **COMPLETED**
- **Details**: `cdfenv.sh` function for switching between CDF environments
- **Features**: Interactive selection, partial matching, cross-platform compatibility

### Download Script System
- **Status**: ✅ **COMPLETED**
- **Details**: `scripts/download_streamlit_from_cdf.py` with comprehensive features
- **Features**: Conflict resolution, toolkit compatibility, bulk download, subfolder organization

### Cleanup System
- **Status**: ✅ **COMPLETED**
- **Details**: Uses CDF toolkit's native `cdf clean` command
- **Features**: Dry-run capability, selective cleanup, dependency handling

---

## 📊 Priority & Implementation Order

### ✅ Recently Completed
1. **Task 2**: Refactor YAML for REST calls (Kevin meeting completed)
2. **Task 8**: Enhanced GitHub Action Titles (clean titles with project names + detailed module display step)
3. **Task 14 Phase 1**: Demo Script Fixes (robust path resolution across all trader dashboards)

### Lower Priority (Research Phase)
1. **Task 3**: Circle back with Thomas for deployment
2. **Task 5**: Deploy using Azure KeyVault integration
3. **Task 6**: Framework sharing with team
4. **Task 7**: Deployment Audit Logging (needs architectural discussion first)
5. **Task 9**: Clean Button in Admin Streamlit (ready for user testing)
6. **Task 10**: Streamlit Version Indicator
7. **Task 11**: Deployment Validation Testing
8. **Task 13**: Module List Paste Functionality in Admin Streamlit
9. **Task 14 Phase 2**: Trader Dashboard Automated Testing
10. **Task 15**: Data Lake Streaming Integration
11. **Task 16**: GitHub-Free SaaS Deployment
12. **Task 17**: GitHub-Free Large File Streaming
13. **Task 18**: Custom GitHub Action for Large File Streaming

### 📦 Backlog
- **Task 12**: Multi-Tenant Azure Group Management (comprehensive Streamlit app with full workflow - moved to backlog)

---

## 🤝 Discussion Topics

### Architecture Decisions Needed
1. **Audit Logging Data Model**: Should we create a shared `deployment_audit` space that all projects can use?
2. **Version Management**: How to standardize version indicators across all streamlits?
3. **Validation Framework**: Should deployment validation be a reusable pattern?

### User Experience Considerations
1. **Safety vs Usability**: Balance for clean button (prevent accidents vs ease of use)
2. **Information Display**: Right balance of version info vs UI clutter
3. **Access Control**: Who should have access to destructive operations?

### Technical Implementation
1. **Toolkit Integration**: Best way to hook into deployment pipeline for logging
2. **Cross-Platform**: Ensure all solutions work across different environments
3. **Performance**: Impact of validation and logging on deployment speed

---

## 📝 Notes

- All tasks should maintain compatibility with existing `cdfenv.sh` environment switching
- Consider reusability across different CDF projects and streamlits
- Maintain security best practices, especially for destructive operations
- Document all new features for team sharing (Task 6)

---

**Last Updated**: December 2024
**Next Review**: All tasks moved to lower priority for future planning with new streaming and deployment tasks added
