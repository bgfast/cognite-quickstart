#!/usr/bin/env python3
"""
Multi-Tenant Azure Group Management Streamlit App

This app provides a user-friendly interface for:
1. Resolving CDF Group IDs to Azure AD Object IDs
2. Finding which Azure tenant contains those groups
3. Comparing user permissions across tenants
4. Interactive group management and user addition

Workflow: CDF Group IDs → Azure AD Object IDs → Find Tenant → Compare Users → Interactive Addition
"""

import streamlit as st
import pandas as pd
import requests
import json
import os
import time
import asyncio
from typing import Dict, List, Tuple, Optional, AsyncGenerator
from datetime import datetime

# Page config
st.set_page_config(
    page_title="Multi-Tenant Group Management",
    page_icon="👥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .step-header {
        font-size: 1.5rem;
        color: #ff7f0e;
        margin: 1rem 0;
        padding: 0.5rem;
        background-color: #f0f2f6;
        border-radius: 0.5rem;
    }
    .success-box {
        padding: 1rem;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 0.5rem;
        color: #155724;
    }
    .warning-box {
        padding: 1rem;
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        border-radius: 0.5rem;
        color: #856404;
    }
    .error-box {
        padding: 1rem;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        border-radius: 0.5rem;
        color: #721c24;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'workflow_step' not in st.session_state:
    st.session_state.workflow_step = 1
if 'cdf_group_ids' not in st.session_state:
    st.session_state.cdf_group_ids = []
if 'azure_groups' not in st.session_state:
    st.session_state.azure_groups = {}
if 'found_tenant' not in st.session_state:
    st.session_state.found_tenant = None
if 'user_comparison' not in st.session_state:
    st.session_state.user_comparison = {}
if 'selected_groups' not in st.session_state:
    st.session_state.selected_groups = []

class AzureGroupManager:
    """Handles Azure AD group operations"""
    
    def __init__(self):
        self.token = None
        self.tenant_id = None
    
    def get_cdf_client(self, project: str, cluster: str):
        """Get CDF client for group resolution"""
        # This would normally use the CDF SDK
        # For now, return a mock client structure
        return {
            'project': project,
            'cluster': cluster,
            'base_url': f"https://{cluster}.cognitedata.com"
        }
    
    async def resolve_cdf_groups_to_azure(self, cdf_group_ids: List[int], cdf_client) -> AsyncGenerator[Tuple[int, int, Dict], None]:
        """Resolve CDF group IDs to Azure AD Object IDs"""
        results = {}
        
        for i, group_id in enumerate(cdf_group_ids):
            # Simulate API call to CDF to get group details including sourceId
            # In real implementation, this would be:
            # group = cdf_client.iam.groups.retrieve(id=group_id)
            # azure_object_id = group.source_id
            
            # Mock data for demonstration
            mock_azure_ids = {
                1687685586523441: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                2125067782830863: "b2c3d4e5-f6g7-8901-bcde-f23456789012",
                2363699696206645: "c3d4e5f6-g7h8-9012-cdef-345678901234",
                2740053181763316: "d4e5f6g7-h8i9-0123-def0-456789012345",
                2955717714680570: "e5f6g7h8-i9j0-1234-ef01-567890123456"
            }
            
            if group_id in mock_azure_ids:
                results[group_id] = {
                    'azure_object_id': mock_azure_ids[group_id],
                    'cdf_name': f'CDF Group {group_id}',
                    'status': 'resolved'
                }
            else:
                results[group_id] = {
                    'azure_object_id': None,
                    'cdf_name': f'CDF Group {group_id}',
                    'status': 'not_found'
                }
            
            # Simulate progress
            yield i + 1, len(cdf_group_ids), results
            await asyncio.sleep(0.5)  # Simulate API delay
    
    def get_azure_token(self, tenant_id: str) -> Optional[str]:
        """Get Azure access token for specific tenant"""
        try:
            # Try environment variables first
            client_id = os.getenv('IDP_CLIENT_ID')
            client_secret = os.getenv('IDP_CLIENT_SECRET')
            
            if all([tenant_id, client_id, client_secret]):
                token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
                data = {
                    'grant_type': 'client_credentials',
                    'client_id': client_id,
                    'client_secret': client_secret,
                    'scope': 'https://graph.microsoft.com/.default'
                }
                
                response = requests.post(token_url, data=data)
                if response.status_code == 200:
                    return response.json()['access_token']
            
            return None
        except Exception as e:
            st.error(f"Failed to get Azure token: {e}")
            return None
    
    def find_groups_in_tenant(self, azure_object_ids: List[str], tenant_id: str) -> Dict:
        """Find which groups exist in a specific tenant"""
        token = self.get_azure_token(tenant_id)
        if not token:
            return {'error': 'Authentication failed'}
        
        results = {}
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        for object_id in azure_object_ids:
            try:
                url = f"https://graph.microsoft.com/v1.0/groups/{object_id}"
                response = requests.get(url, headers=headers)
                
                if response.status_code == 200:
                    group_data = response.json()
                    results[object_id] = {
                        'found': True,
                        'name': group_data.get('displayName', 'Unknown'),
                        'description': group_data.get('description', ''),
                        'tenant': tenant_id
                    }
                else:
                    results[object_id] = {'found': False, 'tenant': tenant_id}
            except Exception as e:
                results[object_id] = {'found': False, 'error': str(e), 'tenant': tenant_id}
        
        return results
    
    def get_user_groups(self, user_email: str, tenant_id: str) -> List[Dict]:
        """Get all groups for a specific user"""
        token = self.get_azure_token(tenant_id)
        if not token:
            return []
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        try:
            # Get user by email
            user_url = f"https://graph.microsoft.com/v1.0/users/{user_email}"
            user_response = requests.get(user_url, headers=headers)
            
            if user_response.status_code != 200:
                return []
            
            user_id = user_response.json()['id']
            
            # Get user's group memberships
            groups_url = f"https://graph.microsoft.com/v1.0/users/{user_id}/memberOf"
            groups_response = requests.get(groups_url, headers=headers)
            
            if groups_response.status_code == 200:
                groups_data = groups_response.json()
                return [
                    {
                        'id': group['id'],
                        'name': group.get('displayName', 'Unknown'),
                        'description': group.get('description', '')
                    }
                    for group in groups_data.get('value', [])
                    if group.get('@odata.type') == '#microsoft.graph.group'
                ]
            
            return []
        except Exception as e:
            st.error(f"Error getting user groups: {e}")
            return []
    
    def add_user_to_group(self, user_email: str, group_id: str, tenant_id: str) -> bool:
        """Add user to a specific group"""
        token = self.get_azure_token(tenant_id)
        if not token:
            return False
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        try:
            # Get user ID
            user_url = f"https://graph.microsoft.com/v1.0/users/{user_email}"
            user_response = requests.get(user_url, headers=headers)
            
            if user_response.status_code != 200:
                return False
            
            user_id = user_response.json()['id']
            
            # Add user to group
            add_url = f"https://graph.microsoft.com/v1.0/groups/{group_id}/members/$ref"
            add_data = {
                "@odata.id": f"https://graph.microsoft.com/v1.0/directoryObjects/{user_id}"
            }
            
            add_response = requests.post(add_url, headers=headers, json=add_data)
            return add_response.status_code in [200, 204]
        
        except Exception as e:
            st.error(f"Error adding user to group: {e}")
            return False

# Initialize the manager
azure_mgr = AzureGroupManager()

# Main app
def main():
    st.markdown('<h1 class="main-header">👥 Multi-Tenant Azure Group Management</h1>', unsafe_allow_html=True)
    
    # Sidebar navigation
    st.sidebar.title("🔄 Workflow Progress")
    
    steps = [
        "📝 Input CDF Group IDs",
        "🔄 Resolve to Azure IDs", 
        "🔍 Find Tenant",
        "👥 Compare Users",
        "✅ Select Groups",
        "🚀 Execute Changes"
    ]
    
    for i, step in enumerate(steps, 1):
        if i == st.session_state.workflow_step:
            st.sidebar.markdown(f"**➡️ {step}**")
        elif i < st.session_state.workflow_step:
            st.sidebar.markdown(f"✅ {step}")
        else:
            st.sidebar.markdown(f"⏳ {step}")
    
    # Step routing
    if st.session_state.workflow_step == 1:
        step1_input_cdf_groups()
    elif st.session_state.workflow_step == 2:
        step2_resolve_azure_ids()
    elif st.session_state.workflow_step == 3:
        step3_find_tenant()
    elif st.session_state.workflow_step == 4:
        step4_compare_users()
    elif st.session_state.workflow_step == 5:
        step5_select_groups()
    elif st.session_state.workflow_step == 6:
        step6_execute_changes()

def step1_input_cdf_groups():
    st.markdown('<div class="step-header">📝 Step 1: Input CDF Group IDs</div>', unsafe_allow_html=True)
    
    st.write("Enter the CDF internal group IDs that you want to resolve to Azure AD groups.")
    
    # Default IDs from downstream-demo
    default_ids = "1687685586523441,2125067782830863,2363699696206645,2740053181763316,2955717714680570,4792782465222491,5746417205616430,5925952929457569,8933733449918875"
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        input_method = st.radio(
            "Input method:",
            ["Manual Entry", "JSON Input", "File Upload"],
            horizontal=True
        )
        
        if input_method == "Manual Entry":
            group_ids_input = st.text_area(
                "CDF Group IDs (comma-separated):",
                value=default_ids,
                height=100,
                help="Enter CDF internal group IDs separated by commas"
            )
        elif input_method == "JSON Input":
            st.write("**Structured JSON Input Format:**")
            st.code('''
{
    "subject": "fv-uPtTvVMOSDGgZcbSyfQ",
    "projects": [
        {
            "projectUrlName": "downstream-demo",
            "groups": [1687685586523441, 2125067782830863, ...]
        }
    ]
}
            ''', language="json")
            
            json_input = st.text_area(
                "Paste JSON data:",
                height=200,
                help="Paste the complete JSON structure with subject and projects"
            )
            
            group_ids_input = ""
            selected_projects = []
            
            if json_input:
                try:
                    data = json.loads(json_input)
                    if 'projects' in data:
                        st.session_state.subject = data.get('subject', '')
                        
                        # Let user select which projects to process
                        st.write("**Select Projects to Process:**")
                        all_group_ids = []
                        
                        for project in data['projects']:
                            project_name = project.get('projectUrlName', 'Unknown')
                            group_count = len(project.get('groups', []))
                            
                            selected = st.checkbox(
                                f"{project_name} ({group_count} groups)",
                                key=f"project_{project_name}",
                                value=True
                            )
                            
                            if selected:
                                selected_projects.append(project_name)
                                all_group_ids.extend(project.get('groups', []))
                        
                        if all_group_ids:
                            group_ids_input = ','.join(map(str, all_group_ids))
                            st.session_state.selected_projects = selected_projects
                            
                            st.success(f"Parsed {len(all_group_ids)} group IDs from {len(selected_projects)} projects")
                    else:
                        st.error("Invalid JSON format: 'projects' key not found")
                except json.JSONDecodeError as e:
                    st.error(f"Invalid JSON format: {e}")
        else:
            uploaded_file = st.file_uploader(
                "Upload file with CDF Group IDs",
                type=['txt', 'csv', 'json'],
                help="Upload a text, CSV, or JSON file containing CDF Group IDs"
            )
            group_ids_input = ""
            if uploaded_file:
                content = uploaded_file.read().decode('utf-8')
                
                if uploaded_file.name.endswith('.json'):
                    try:
                        data = json.loads(content)
                        if 'projects' in data:
                            all_group_ids = []
                            for project in data['projects']:
                                all_group_ids.extend(project.get('groups', []))
                            group_ids_input = ','.join(map(str, all_group_ids))
                        else:
                            st.error("Invalid JSON format: 'projects' key not found")
                    except json.JSONDecodeError as e:
                        st.error(f"Invalid JSON format: {e}")
                else:
                group_ids_input = content.replace('\n', ',').replace(' ', '')
    
    with col2:
        st.markdown("**CDF Environment:**")
        cdf_project = st.text_input("CDF Project:", value="downstream-demo")
        cdf_cluster = st.text_input("CDF Cluster:", value="az-eastus-1")
    
    if st.button("🔄 Parse and Validate IDs", type="primary"):
        if group_ids_input:
            try:
                # Parse and validate IDs
                ids = [int(id_str.strip()) for id_str in group_ids_input.split(',') if id_str.strip()]
                
                if ids:
                    st.session_state.cdf_group_ids = ids
                    st.session_state.cdf_project = cdf_project
                    st.session_state.cdf_cluster = cdf_cluster
                    
                    st.markdown('<div class="success-box">', unsafe_allow_html=True)
                    st.write(f"✅ Successfully parsed {len(ids)} CDF Group IDs:")
                    
                    # Display in a nice table
                    df = pd.DataFrame({
                        'CDF Group ID': ids,
                        'Status': ['Ready for resolution'] * len(ids)
                    })
                    st.dataframe(df, use_container_width=True)
                    st.markdown('</div>', unsafe_allow_html=True)
                    
                    if st.button("➡️ Continue to Resolution"):
                        st.session_state.workflow_step = 2
                        st.rerun()
                else:
                    st.error("No valid CDF Group IDs found in input")
            except ValueError as e:
                st.error(f"Invalid format: {e}")
        else:
            st.error("Please enter CDF Group IDs")

def step2_resolve_azure_ids():
    st.markdown('<div class="step-header">🔄 Step 2: Resolve CDF Groups to Azure AD Object IDs</div>', unsafe_allow_html=True)
    
    st.write(f"Resolving {len(st.session_state.cdf_group_ids)} CDF Group IDs to Azure AD Object IDs...")
    
    if st.button("🔄 Start Resolution Process", type="primary"):
        # Create placeholder for progress
        progress_bar = st.progress(0)
        status_text = st.empty()
        results_container = st.empty()
        
        # Mock the resolution process
        resolved_groups = {}
        
        # Mock Azure Object IDs for demonstration
        mock_azure_ids = {
            1687685586523441: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            2125067782830863: "b2c3d4e5-f6g7-8901-bcde-f23456789012",
            2363699696206645: "c3d4e5f6-g7h8-9012-cdef-345678901234",
            2740053181763316: "d4e5f6g7-h8i9-0123-def0-456789012345",
            2955717714680570: "e5f6g7h8-i9j0-1234-ef01-567890123456",
            4792782465222491: "f6g7h8i9-j0k1-2345-f012-678901234567",
            5746417205616430: "g7h8i9j0-k1l2-3456-0123-789012345678",
            5925952929457569: "h8i9j0k1-l2m3-4567-1234-890123456789",
            8933733449918875: "i9j0k1l2-m3n4-5678-2345-901234567890"
        }
        
        for i, group_id in enumerate(st.session_state.cdf_group_ids):
            progress = (i + 1) / len(st.session_state.cdf_group_ids)
            progress_bar.progress(progress)
            status_text.text(f"Resolving group {i+1}/{len(st.session_state.cdf_group_ids)}: {group_id}")
            
            if group_id in mock_azure_ids:
                resolved_groups[group_id] = {
                    'azure_object_id': mock_azure_ids[group_id],
                    'cdf_name': f'CDF Group {group_id}',
                    'status': 'resolved'
                }
            else:
                resolved_groups[group_id] = {
                    'azure_object_id': None,
                    'cdf_name': f'CDF Group {group_id}',
                    'status': 'not_found'
                }
            
            time.sleep(0.3)  # Simulate API delay
        
        progress_bar.progress(1.0)
        status_text.text("✅ Resolution complete!")
        
        # Store results
        st.session_state.azure_groups = resolved_groups
        
        # Display results
        results_data = []
        for cdf_id, data in resolved_groups.items():
            results_data.append({
                'CDF Group ID': cdf_id,
                'Azure Object ID': data['azure_object_id'] or 'Not Found',
                'Status': '✅ Resolved' if data['status'] == 'resolved' else '❌ Not Found'
            })
        
        results_df = pd.DataFrame(results_data)
        results_container.dataframe(results_df, use_container_width=True)
        
        resolved_count = sum(1 for data in resolved_groups.values() if data['status'] == 'resolved')
        
        if resolved_count > 0:
            st.markdown('<div class="success-box">', unsafe_allow_html=True)
            st.write(f"✅ Successfully resolved {resolved_count}/{len(st.session_state.cdf_group_ids)} groups to Azure AD Object IDs")
            st.markdown('</div>', unsafe_allow_html=True)
            
            if st.button("➡️ Continue to Tenant Discovery"):
                st.session_state.workflow_step = 3
                st.rerun()
        else:
            st.markdown('<div class="error-box">', unsafe_allow_html=True)
            st.write("❌ No groups could be resolved. Please check your CDF connection and group IDs.")
            st.markdown('</div>', unsafe_allow_html=True)

def step3_find_tenant():
    st.markdown('<div class="step-header">🔍 Step 3: Find Azure Tenant</div>', unsafe_allow_html=True)
    
    st.write("Searching across your accessible Azure tenants to find which contains the resolved Azure AD groups...")
    
    # Get resolved Azure Object IDs
    azure_object_ids = [
        data['azure_object_id'] 
        for data in st.session_state.azure_groups.values() 
        if data['status'] == 'resolved'
    ]
    
    if not azure_object_ids:
        st.error("No Azure Object IDs to search for. Please go back and resolve CDF groups first.")
        return
    
    st.write(f"Searching for {len(azure_object_ids)} Azure AD groups...")
    
    # Tenant configuration
    st.subheader("🏢 Configure Tenant Search")
    
    col1, col2 = st.columns(2)
    
    with col1:
        search_method = st.radio(
            "Search method:",
            ["Known Tenants", "Auto-Discovery"],
            help="Choose how to search for the groups across tenants"
        )
    
    with col2:
        if search_method == "Known Tenants":
            tenant_input = st.text_area(
                "Tenant IDs (one per line):",
                value="a8339f73-21ce-4a7a-abcc-021514bea883\n16b3c013-d300-468d-ac64-7eda0820b6d3",
                help="Enter Azure AD Tenant IDs to search"
            )
        else:
            st.info("Auto-discovery will attempt to find tenants using available credentials")
    
    if st.button("🔍 Start Tenant Search", type="primary"):
        if search_method == "Known Tenants" and tenant_input:
            tenant_ids = [tid.strip() for tid in tenant_input.split('\n') if tid.strip()]
        else:
            # Mock tenant discovery
            tenant_ids = ["a8339f73-21ce-4a7a-abcc-021514bea883"]
        
        search_progress = st.progress(0)
        search_status = st.empty()
        
        found_groups = {}
        
        for i, tenant_id in enumerate(tenant_ids):
            search_progress.progress((i + 1) / len(tenant_ids))
            search_status.text(f"Searching tenant {i+1}/{len(tenant_ids)}: {tenant_id}")
            
            # Mock search results - simulate finding groups in first tenant
            if i == 0:  # Find groups in first tenant
                for obj_id in azure_object_ids[:5]:  # Find first 5 groups
                    found_groups[obj_id] = {
                        'found': True,
                        'tenant': tenant_id,
                        'name': f'Demo Group {obj_id[:8]}...',
                        'description': 'Mock group for demonstration'
                    }
            
            time.sleep(0.5)
        
        search_progress.progress(1.0)
        search_status.text("✅ Tenant search complete!")
        
        if found_groups:
            st.session_state.found_tenant = list(found_groups.values())[0]['tenant']
            st.session_state.tenant_groups = found_groups
            
            st.markdown('<div class="success-box">', unsafe_allow_html=True)
            st.write(f"✅ Found {len(found_groups)} groups in tenant: `{st.session_state.found_tenant}`")
            
            # Display found groups
            found_data = []
            for obj_id, data in found_groups.items():
                found_data.append({
                    'Azure Object ID': obj_id,
                    'Group Name': data['name'],
                    'Description': data['description'],
                    'Tenant': data['tenant']
                })
            
            found_df = pd.DataFrame(found_data)
            st.dataframe(found_df, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)
            
            if st.button("➡️ Continue to User Comparison"):
                st.session_state.workflow_step = 4
                st.rerun()
        else:
            st.markdown('<div class="error-box">', unsafe_allow_html=True)
            st.write("❌ No groups found in any of the searched tenants.")
            st.write("Please verify your tenant IDs and ensure you have appropriate permissions.")
            st.markdown('</div>', unsafe_allow_html=True)

def step4_compare_users():
    st.markdown('<div class="step-header">👥 Step 4: Compare User Permissions</div>', unsafe_allow_html=True)
    
    st.write(f"Compare group memberships between two users in tenant: `{st.session_state.found_tenant}`")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("👤 User A (Has Access)")
        user_a = st.text_input(
            "User A Email:",
            value="user.a@company.com",
            help="Email of user who currently has access"
        )
    
    with col2:
        st.subheader("👤 User B (Needs Access)")
        user_b = st.text_input(
            "User B Email:",
            value="user.b@company.com",
            help="Email of user who needs access"
        )
    
    if st.button("🔄 Compare User Permissions", type="primary"):
        if user_a and user_b:
            comparison_progress = st.progress(0)
            comparison_status = st.empty()
            
            # Mock user group retrieval
            comparison_status.text(f"Getting groups for {user_a}...")
            comparison_progress.progress(0.3)
            time.sleep(1)
            
            # Mock User A groups (has access to target groups)
            target_group_ids = list(st.session_state.tenant_groups.keys())
            user_a_groups = []
            
            # Add target groups to User A
            for i, group_id in enumerate(target_group_ids[:3]):  # User A has first 3 target groups
                user_a_groups.append({
                    'id': group_id,
                    'name': f'CDF Group {i+1}',
                    'description': f'Target group {i+1} description'
                })
            
            # Add some other groups
            user_a_groups.extend([
                {'id': 'other-group-1', 'name': 'Other Group 1', 'description': 'Unrelated group'},
                {'id': 'other-group-2', 'name': 'Other Group 2', 'description': 'Another unrelated group'}
            ])
            
            comparison_status.text(f"Getting groups for {user_b}...")
            comparison_progress.progress(0.7)
            time.sleep(1)
            
            # Mock User B groups (missing some target groups)
            user_b_groups = [
                {'id': target_group_ids[0], 'name': 'CDF Group 1', 'description': 'Target group 1 description'},  # Has one target group
                {'id': 'other-group-3', 'name': 'Other Group 3', 'description': 'Unrelated group'},
            ]
            
            comparison_progress.progress(1.0)
            comparison_status.text("✅ User comparison complete!")
            
            # Store comparison results
            st.session_state.user_a = user_a
            st.session_state.user_b = user_b
            st.session_state.user_a_groups = user_a_groups
            st.session_state.user_b_groups = user_b_groups
            
            # Analyze differences
            user_a_group_ids = {g['id'] for g in user_a_groups}
            user_b_group_ids = {g['id'] for g in user_b_groups}
            target_group_ids_set = set(st.session_state.tenant_groups.keys())
            
            # Groups User A has that User B doesn't (in target groups)
            missing_groups = []
            for group_id in target_group_ids_set:
                if group_id in user_a_group_ids and group_id not in user_b_group_ids:
                    group_info = next((g for g in user_a_groups if g['id'] == group_id), None)
                    if group_info:
                        missing_groups.append(group_info)
            
            st.session_state.missing_groups = missing_groups
            
            # Display comparison
            st.subheader("📊 Permission Comparison")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("User A Groups", len(user_a_groups))
                st.write("**Groups:**")
                for group in user_a_groups:
                    emoji = "🎯" if group['id'] in target_group_ids_set else "📁"
                    st.write(f"{emoji} {group['name']}")
            
            with col2:
                st.metric("User B Groups", len(user_b_groups))
                st.write("**Groups:**")
                for group in user_b_groups:
                    emoji = "🎯" if group['id'] in target_group_ids_set else "📁"
                    st.write(f"{emoji} {group['name']}")
            
            with col3:
                st.metric("Missing Groups", len(missing_groups), delta=f"-{len(missing_groups)}")
                st.write("**User B Missing:**")
                for group in missing_groups:
                    st.write(f"❌ {group['name']}")
            
            if missing_groups:
                st.markdown('<div class="warning-box">', unsafe_allow_html=True)
                st.write(f"⚠️ User B is missing {len(missing_groups)} groups that User A has access to.")
                st.markdown('</div>', unsafe_allow_html=True)
                
                if st.button("➡️ Continue to Group Selection"):
                    st.session_state.workflow_step = 5
                    st.rerun()
            else:
                st.markdown('<div class="success-box">', unsafe_allow_html=True)
                st.write("✅ User B already has access to all the same target groups as User A!")
                st.markdown('</div>', unsafe_allow_html=True)
        else:
            st.error("Please enter both user email addresses")

def step5_select_groups():
    st.markdown('<div class="step-header">✅ Step 5: Select Groups to Add</div>', unsafe_allow_html=True)
    
    st.write(f"Select which groups to add **{st.session_state.user_b}** to:")
    
    missing_groups = st.session_state.missing_groups
    
    if not missing_groups:
        st.info("No missing groups found. User B already has appropriate access.")
        return
    
    st.subheader("🎯 Missing Groups")
    
    selected_groups = []
    
    for i, group in enumerate(missing_groups):
        col1, col2 = st.columns([1, 4])
        
        with col1:
            selected = st.checkbox(
                "Add",
                key=f"group_{i}",
                value=True  # Default to selected
            )
        
        with col2:
            st.write(f"**{group['name']}**")
            st.write(f"📝 {group['description']}")
            st.write(f"🆔 `{group['id']}`")
            st.write("---")
        
        if selected:
            selected_groups.append(group)
    
    st.session_state.selected_groups = selected_groups
    
    if selected_groups:
        st.subheader("📋 Summary")
        st.write(f"You have selected **{len(selected_groups)}** groups to add {st.session_state.user_b} to:")
        
        for group in selected_groups:
            st.write(f"✅ {group['name']}")
        
        st.markdown('<div class="warning-box">', unsafe_allow_html=True)
        st.write("⚠️ **Important:** This will modify Azure AD group memberships. Please review carefully before proceeding.")
        st.markdown('</div>', unsafe_allow_html=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔄 Dry Run (Preview Only)", type="secondary"):
                st.info("Dry run mode - no changes will be made")
                preview_changes()
        
        with col2:
            if st.button("🚀 Execute Changes", type="primary"):
                st.session_state.workflow_step = 6
                st.rerun()
    else:
        st.info("No groups selected. Please select at least one group to continue.")

def preview_changes():
    """Show a preview of what changes would be made"""
    st.subheader("🔍 Dry Run Preview")
    
    preview_data = []
    for group in st.session_state.selected_groups:
        preview_data.append({
            'Action': 'Add User to Group',
            'User': st.session_state.user_b,
            'Group': group['name'],
            'Group ID': group['id'],
            'Status': 'Would be added'
        })
    
    preview_df = pd.DataFrame(preview_data)
    st.dataframe(preview_df, use_container_width=True)

def step6_execute_changes():
    st.markdown('<div class="step-header">🚀 Step 6: Execute Changes</div>', unsafe_allow_html=True)
    
    st.write(f"Adding **{st.session_state.user_b}** to **{len(st.session_state.selected_groups)}** groups...")
    
    if st.button("🚀 Confirm and Execute", type="primary"):
        execution_progress = st.progress(0)
        execution_status = st.empty()
        results_container = st.container()
        
        results = []
        
        for i, group in enumerate(st.session_state.selected_groups):
            progress = (i + 1) / len(st.session_state.selected_groups)
            execution_progress.progress(progress)
            execution_status.text(f"Adding to group {i+1}/{len(st.session_state.selected_groups)}: {group['name']}")
            
            # Mock the group addition (in real app, this would call Azure AD API)
            time.sleep(1)  # Simulate API call
            
            # Mock success (90% success rate for demo)
            import random
            success = random.random() > 0.1
            
            results.append({
                'Group': group['name'],
                'Group ID': group['id'],
                'Status': '✅ Success' if success else '❌ Failed',
                'Details': 'User added successfully' if success else 'Permission denied'
            })
            
            # Show real-time results
            with results_container:
                results_df = pd.DataFrame(results)
                st.dataframe(results_df, use_container_width=True)
        
        execution_progress.progress(1.0)
        execution_status.text("✅ Execution complete!")
        
        # Final summary
        successful = sum(1 for r in results if '✅' in r['Status'])
        failed = len(results) - successful
        
        if successful > 0:
            st.markdown('<div class="success-box">', unsafe_allow_html=True)
            st.write(f"✅ Successfully added {st.session_state.user_b} to {successful} groups!")
            st.markdown('</div>', unsafe_allow_html=True)
        
        if failed > 0:
            st.markdown('<div class="error-box">', unsafe_allow_html=True)
            st.write(f"❌ Failed to add to {failed} groups. Please check permissions and try again.")
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Audit log
        st.subheader("📋 Audit Log")
        audit_data = {
            'Timestamp': datetime.now().isoformat(),
            'Operator': 'Current User',  # In real app, get from auth
            'Action': 'Add User to Groups',
            'Target User': st.session_state.user_b,
            'Source User': st.session_state.user_a,
            'Tenant': st.session_state.found_tenant,
            'Groups Modified': len(st.session_state.selected_groups),
            'Successful': successful,
            'Failed': failed
        }
        
        st.json(audit_data)
        
        # Reset workflow
        if st.button("🔄 Start New Workflow"):
            for key in ['workflow_step', 'cdf_group_ids', 'azure_groups', 'found_tenant', 'user_comparison', 'selected_groups']:
                if key in st.session_state:
                    del st.session_state[key]
            st.rerun()

if __name__ == "__main__":
    main() 