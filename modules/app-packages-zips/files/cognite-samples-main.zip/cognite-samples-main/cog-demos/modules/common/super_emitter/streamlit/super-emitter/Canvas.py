from cognite.client import CogniteClient
from cognite.client.data_classes.data_modeling import NodeOrEdgeData, NodeApply, EdgeApply, ViewId, ContainerId
from cognite.client.data_classes.filters import Filter
import datetime, uuid

# Settings
canvas_space_canvas = "cdf_industrial_canvas"
canvas_space_instance = "IndustrialCanvasInstanceSpace"
canvas_container_canvas = "Canvas"
canvas_container_instance = "ContainerReference"

def get_time(timestamp:int=None):
    # Current time
    if timestamp:
        now = datetime.datetime.fromtimestamp(timestamp/1000)
    else:
        now = datetime.datetime.now(datetime.timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

def get_user_id(client:CogniteClient):
    # Your user ID
    if client:
        return client.iam.user_profiles.me().user_identifier
    else:
        return None

def generate_id():
    return str(uuid.uuid4())

def generate_properties(item:dict, node_id:str, offset_x:int=0, offset_y:int=0):
    '''
    item = {
      # Mandatory
      type = resource type
      id = resource id
      
      # Optional Common
      label = user defined name of object
      x = upper left coordinate of object
      y = upper left coordinate of object
      width = widht of object
      height = height of object
      
      # Optional specfic
      resource_sub_id = 3D revision ID
      initial_asset_id = 3D target asset ID
      start_timestamp = Time series start time (seconds since 1970)
      end_timestamp = Time series start time (seconds since 1970)
    }
    '''
    # Mandatory
    property_type:str = item['type']
    resource_id:int = item['id']
    
    # Optional
    label:str = "No label defined" if not "label" in item else item['label']
    x:int = offset_x if not "x" in item else item['x']
    y:int = offset_y if not "y" in item else item['y']
    width:int = 0 if not "width" in item else item['width']
    height:int = 0 if not "height" in item else item['height']
    resource_sub_id:int = 0 if not "resource_sub_id" in item else item['resource_sub_id']
    initial_asset_id:int = 0 if not "initial_asset_id" in item else item['initial_asset_id']
    start_timestamp:int = 0 if not "start_timestamp" in item else item['start_timestamp']
    end_timestamp:int = 0 if not "end_timestamp" in item else item['end_timestamp']
    
    property = {
            'id': node_id,
            'containerReferenceType': property_type,
            'label': label,
            'x': x,
            'y': y,
        }
    
    match property_type:
        case "event":
             property.update({
                'width': width if width != 0 else 600,
                'height': height if height != 0 else 500,
                'resourceId': resource_id,
                'properties': {
                    'zIndex': 0
                }
             })
        case "asset":
             property.update({
                "width": width if width != 0 else 600,
                "height": height if height != 0 else 356,
                "resourceId": resource_id,
                "properties": {
                    "unscaledWidth": 600,
                    "unscaledHeight": 356,
                    "zIndex": 0
                }
            })
        case "timeseries":
             property.update({
                "width": width if width != 0 else 700,
                "height": height if height != 0 else 400,
                "resourceId": resource_id,
                "properties": {
                    "startDate": get_time(start_timestamp),
                    "endDate": get_time(end_timestamp),
                    "zIndex": 0
                }
            })        
        case "file":
            property.update({
                "maxWidth": width if width != 0 else 1200,
                "maxHeight": height if height != 0 else 1200,
                'width': width if width != 0 else 1200,
                'height': height if height != 0 else 1200,
                "resourceId": resource_id,
                "properties": {
                    "page": 1,
                    "zIndex": 0
                }
            })
        case "threeD":
            property.update({
                'width': width if width != 0 else 600,
                'height': height if height != 0 else 400,
                "resourceId": resource_id,
                "resourceSubId": resource_sub_id,
                "properties": {
                    "initialAssetId" : initial_asset_id,
                    "zIndex": 0
                }
            })        
        case _:
            print(f"Input type {type} not found")
            pass
    
    return property
        

def create_canvas(name:str, client:CogniteClient):
    # The Canvas node
    canvas_id = generate_id()
    canvas = NodeApply(
        space=canvas_space_instance,
        external_id=canvas_id,
        sources=[
            NodeOrEdgeData(
                source=ContainerId(canvas_space_canvas, canvas_container_canvas),
                properties={
                    'name': name,
                    'visibility': "private",
                    'updatedAt': get_time(),
                    'createdBy': get_user_id(client),
                    'updatedBy': get_user_id(client)
                }
            )
        ]
    )
    return canvas, canvas_id

def create_objects(canvas_id:str, inputs = []):
    nodes = []
    edges = []
    offset_x = 0
    offset_y = 0
    prev_height = 0
    offsets = {}
    
    # print(f"Canvas ID: {canvas_id}")
    for index, item in enumerate(inputs):
        if item['type'] not in offsets:
            for key in offsets:
                offset_y = max(offset_y, offsets[key]['y'] + prev_height)

            offsets[item['type']] = {'x': 0, 'y': offset_y}
    
        offset_x = offsets[item['type']]['x'] 
        offset_y = offsets[item['type']]['y']
        
        node_id = generate_id()
        properties = generate_properties(item, node_id, offset_x, offset_y)
        if not properties:
            continue
            
        print(str(offsets))
        
        offsets[item['type']]['x'] = offset_x + properties['width'] + 20
        prev_height = properties['height'] + 20
        
        n = NodeApply(
            space=canvas_space_instance,
            external_id=f"{canvas_id}_{node_id}",
            sources=[
                NodeOrEdgeData(
                    source=ContainerId(canvas_space_canvas, canvas_container_instance),
                    properties=properties
                )
            ]
        )
        nodes.append(n)
        # print(n.dump())
        
        edge_id = str(uuid.uuid4())
        e = EdgeApply(
            space=canvas_space_instance,
            external_id=f"{canvas_id}_{canvas_id}_{node_id}",
            type=(canvas_space_canvas, "referencesContainerReference"),
            start_node=(canvas_space_instance, canvas_id),
            end_node=(canvas_space_instance, f"{canvas_id}_{node_id}"),
        )
        edges.append(e)        
        # print(e.dump())
        
    return nodes, edges

def generate(name:str, inputs, client:CogniteClient):
    canvas, canvas_id = create_canvas(name=name, client=client)
    nodes, edges = create_objects(canvas_id=canvas_id, inputs=inputs) 
    client.data_modeling.instances.apply([canvas] + nodes, edges)
    return canvas_id