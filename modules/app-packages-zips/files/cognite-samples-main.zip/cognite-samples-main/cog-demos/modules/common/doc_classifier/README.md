Name: Document Classifier
Description: This demo is designed to read different types of documents (P&IDs, manuals, assembly diagrams, etc), classify the documents, and pull out metadata from the documents like drawing number and title. You can then add this information as CDF metadata to each document to make it easier to find the information you're looking for (this is manual for now). There is a separate demo of Doc Parsing included, with a data model and corresponding PDF that you can parse to show the power of generative AI in CDF.
Type: Streamlit


**Author:** Kevin Caputo

**Description:** This demo is designed to read different types of documents (P&IDs, manuals, assembly diagrams, etc), classify the documents, and pull out metadata from the documents like drawing number and title. You can then add this information as CDF metadata to each document to make it easier to find the information you're looking for (this is manual for now). There is a separate demo of Doc Parsing included, with a data model and corresponding PDF that you can parse to show the power of generative AI in CDF.

**Demo Notes:** The prompt provides some hints to give a more reliable result and lists the options for classification (for consistency). Try tweaking the prompt in the Streamlit if you are not getting the results you want. 
