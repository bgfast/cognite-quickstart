from handler import handle
from cognite.client import CogniteClient, ClientConfig
from cognite.client.credentials import OAuthClientCredentials
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
# This value will depend on the cluster your CDF project-publicdata runs on
cluster = os.getenv("CDF_CLUSTER")
base_url = f"https://{cluster}.cognitedata.com"
tenant_id = os.getenv("IDP_TENANT_ID")
client_id = os.getenv("IDP_CLIENT_ID")
client_secret = os.getenv("IDP_CLIENT_SECRET")
project_name = os.getenv("CDF_PROJECT")

provider = os.getenv("PROVIDER")
# Checking based on the provider (CDF) or EntraID, we need to set the token_url and scopes
if provider == "cdf":
    token_url = "https://auth.cognite.com/oauth2/token"
    scopes = None
else:
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    scopes = [f"{base_url}/.default"]

client = CogniteClient(
    ClientConfig(
        client_name=project_name,
        base_url=base_url,
        project=project_name,
        credentials=OAuthClientCredentials(
            token_url=token_url,
            client_id=client_id,
            client_secret=client_secret,
            scopes=scopes,
        ),
    )
)

data = {
    "file_space": "valhall-files",
    "asset_space": "valhall-assets",
    "file_names": [
        "25578-P-4110006-001.pdf",
        "25578-P-4110010-001.pdf",
        "25578-P-4110119-001.pdf",
        "ME-P-0003-001.pdf",
        "ME-P-0004-001.pdf",
        "ME-P-0151-001.pdf",
        "ME-P-0152-001.pdf",
        "ME-P-0153-001.pdf",
        "ME-P-0156-001.pdf",
        "ME-P-0156-002.pdf",
        "ME-P-0160-001.pdf",
    ],
}
handle(data, client)
