# Multi-Tenant Azure Group Management

A comprehensive Streamlit application for managing Azure AD group memberships across multiple tenants, with integration to CDF (Cognite Data Fusion) group resolution.

## 🎯 Purpose

This tool solves the complex workflow of:
1. Taking CDF internal group IDs and resolving them to Azure AD Object IDs
2. Finding which Azure tenant contains those specific groups
3. Comparing user permissions between two users across tenants
4. Interactively adding missing group memberships to synchronize access

## 🔄 Complete Workflow

```
CDF Group IDs → Azure AD Object IDs → Find Tenant → Compare Users → Interactive Addition
```

### Step-by-Step Process

1. **Input CDF Group IDs**: Multiple input methods including JSON format support
2. **Resolve Azure IDs**: Maps CDF internal IDs to Azure AD Object IDs via CDF API
3. **Tenant Discovery**: Scans multiple Azure tenants to locate the groups
4. **User Comparison**: Compares group memberships between User A (has access) and User B (needs access)
5. **Gap Analysis**: Visual report showing missing group memberships
6. **Interactive Addition**: Selective group addition with confirmation prompts
7. **Audit Logging**: Complete audit trail of all changes made

## 📝 Input Formats

### 1. Manual Entry
Simple comma-separated list of CDF Group IDs:
```
1687685586523441,2125067782830863,2363699696206645
```

### 2. JSON Input (Structured Format)
Supports the complete project structure format:
```json
{
    "subject": "fv-uPtTvVMOSDGgZcbSyfQ",
    "projects": [
        {
            "projectUrlName": "downstream-demo",
            "groups": [
                1687685586523441,
                2125067782830863,
                2363699696206645,
                2740053181763316,
                2955717714680570
            ]
        },
        {
            "projectUrlName": "z-kevin",
            "groups": [
                2488862794691652,
                4159070442904688,
                4234241350184666
            ]
        }
    ]
}
```

### 3. File Upload
Supports uploading:
- `.txt` files with comma-separated IDs
- `.csv` files with group IDs
- `.json` files with the structured format above

## 🔧 Features

### Input Processing
- ✅ Multiple input methods (manual, JSON, file upload)
- ✅ Project selection from multi-project JSON
- ✅ Input validation and parsing
- ✅ Real-time group count display

### Resolution & Discovery
- ✅ CDF-to-Azure ID resolution with progress tracking
- ✅ Multi-tenant search with authentication
- ✅ Group existence verification across tenants
- ✅ Detailed status reporting

### User Comparison
- ✅ Side-by-side permission comparison
- ✅ Visual metrics (group counts, missing groups)
- ✅ Target group highlighting
- ✅ Gap analysis reporting

### Interactive Management
- ✅ Selective group addition with checkboxes
- ✅ Dry-run preview mode
- ✅ Confirmation dialogs for safety
- ✅ Real-time execution progress
- ✅ Success/failure tracking

### Safety & Auditing
- ✅ Dry-run mode for testing
- ✅ Confirmation prompts before changes
- ✅ Comprehensive audit logging
- ✅ Error handling and reporting

## 🚀 Usage

### Prerequisites
1. **Azure AD Permissions**: Requires appropriate permissions to:
   - Read group information across tenants
   - Add users to groups
   - Access Microsoft Graph API

2. **Environment Variables**:
   ```bash
   IDP_CLIENT_ID=your-azure-client-id
   IDP_CLIENT_SECRET=your-azure-client-secret
   ```

3. **CDF Access**: Valid CDF credentials for group resolution

### Running the Application

1. **Navigate to the app directory**:
   ```bash
   cd cog-demos/modules/common/in-development-streamlits/multi-tenant-group-mgmt/streamlit/stapp-multi-tenant-group-mgmt
   ```

2. **Install dependencies**:
   ```bash
   pip install streamlit pandas requests
   ```

3. **Run the Streamlit app**:
   ```bash
   streamlit run app.py
   ```

### Step-by-Step Usage

1. **Step 1: Input Group IDs**
   - Choose your input method (Manual, JSON, or File Upload)
   - For JSON input, paste your structured data and select projects to process
   - Configure CDF environment settings (project and cluster)
   - Click "Parse and Validate IDs"

2. **Step 2: Resolve Azure IDs**
   - Click "Start Resolution Process"
   - Monitor progress as CDF Group IDs are mapped to Azure AD Object IDs
   - Review the resolution results table

3. **Step 3: Find Tenant**
   - Configure tenant search (Known Tenants or Auto-Discovery)
   - Enter tenant IDs to search
   - Click "Start Tenant Search"
   - Review which groups were found in which tenant

4. **Step 4: Compare Users**
   - Enter User A email (user who has access)
   - Enter User B email (user who needs access)
   - Click "Compare User Permissions"
   - Review the side-by-side comparison and missing groups

5. **Step 5: Select Groups**
   - Review the missing groups list
   - Select which groups to add User B to
   - Use "Dry Run" to preview changes without making them
   - Click "Execute Changes" when ready

6. **Step 6: Execute Changes**
   - Confirm the changes you want to make
   - Monitor real-time progress as users are added to groups
   - Review the final audit log

## 🔒 Security Considerations

- **Principle of Least Privilege**: Only request necessary Azure AD permissions
- **Audit Trail**: All changes are logged with timestamps and user information
- **Confirmation Required**: Multiple confirmation steps before making changes
- **Dry-Run Mode**: Test changes before executing them
- **Error Handling**: Graceful handling of permission errors and API failures

## 🏗️ Architecture

### Components
- **AzureGroupManager**: Handles all Azure AD operations
- **CDF Integration**: Resolves CDF group IDs to Azure Object IDs
- **Multi-Step Workflow**: Guided process with progress tracking
- **Session State Management**: Maintains workflow state across steps

### API Integrations
- **Microsoft Graph API**: For Azure AD group operations
- **CDF SDK**: For group ID resolution
- **Multi-Tenant Support**: Handles authentication across different tenants

## 📊 Example Use Cases

1. **Onboarding New Users**: Compare a new user's access to an existing user and add missing groups
2. **Access Auditing**: Review and synchronize permissions across projects
3. **Bulk Permission Updates**: Process multiple projects and groups efficiently
4. **Cross-Tenant Management**: Handle groups across different Azure tenants

## 🐛 Troubleshooting

### Common Issues

1. **Authentication Failures**
   - Verify `IDP_CLIENT_ID` and `IDP_CLIENT_SECRET` environment variables
   - Check Azure AD application permissions
   - Ensure tenant IDs are correct

2. **Group Not Found**
   - Verify CDF Group IDs are correct
   - Check if groups exist in the specified tenant
   - Confirm CDF project and cluster settings

3. **Permission Denied**
   - Verify Azure AD application has required permissions
   - Check if user has rights to modify group memberships
   - Review tenant-specific permission requirements

## 🔄 Future Enhancements

- **Batch Processing**: Handle larger datasets more efficiently
- **Role-Based Access**: Implement user-specific access controls
- **Notification System**: Email notifications for completed operations
- **Enhanced Reporting**: More detailed analytics and reporting features
- **API Integration**: REST API for programmatic access

## 📁 File Structure

```
multi-tenant-group-mgmt/
├── README.md                           # This documentation
└── streamlit/
    └── stapp-multi-tenant-group-mgmt/
        └── app.py                      # Main Streamlit application
```

## 🤝 Contributing

When making changes to this application:
1. Test thoroughly with dry-run mode first
2. Update documentation for any new features
3. Follow the existing code style and structure
4. Add appropriate error handling and logging
5. Test with multiple tenant configurations 