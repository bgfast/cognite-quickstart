import streamlit as st
import json
from cognite.client import CogniteClient
# Temporarily comment out config import to debug
# from config import *
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from data_modeling import View
from cognite_ai import Completions
import dm_helper

# Initialize CogniteClient
client = CogniteClient()

st.set_page_config(page_title="Form to Asset Extractor", page_icon="🔍", layout="wide")

# --- UI Layout ---
with st.container():
        st.markdown(
            f"""
            <div style="display: flex; justify-content: center;">
                <img src="https://mms.businesswire.com/media/20250519865188/en/2474150/5/cognite-tagline-horizontal_6.jpg?download=1&_gl=1*16caelh*_gcl_au*MTg1MTcxMzU0MS4xNzU0NTg2MzAy*_ga*MTEyNzQ1NDMxMy4xNzU0NTg2MzAz*_ga_ZQWF70T3FK*czE3NTQ1ODYzMDIkbzEkZzAkdDE3NTQ1ODYzMDIkajYwJGwwJGgw" width=300>
            </div>
            """,
            unsafe_allow_html=True
        )
st.markdown("<h1 style='text-align: center;'>Docs2Data Auto-Analyzer</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center; font-style: italic; font-size: 18px; margin-top: -20px;'>Powered by Cognite's Industrial Knowledge Graph</p>", unsafe_allow_html=True)
st.markdown("---")

# --- Session State Initialization ---
for key in ['ai_results', 'selected_file_name', 'selected_page_number']:
    if key not in st.session_state:
        st.session_state[key] = None

# --- Data Loading Functions ---
@st.cache_data
def get_datasets_list(_client):
    """Get list of datasets from CDF, filtered for configured prefix."""
    datasets = _client.data_sets.list(limit=None)
    return [ds for ds in datasets if ds.external_id]

@st.cache_data
def get_files_list(_client, dataset_id):
    """Get list of files from a specific dataset."""
    return [file for file in _client.files.list(data_set_ids=[dataset_id], limit=1000) if file.name]
 # Input Section

st.header("4. Forms to Assets")
# --- Dataset and File Selection ---
with st.spinner("Loading datasets from CDF..."):
    datasets = get_datasets_list(client)

if not datasets:
    st.error("No datasets found in CDF. Please create a dataset and upload some files first.")
    st.stop()

dataset_options = {f"{ds.name or ds.external_id} ({ds.external_id})": ds for ds in datasets}
default_ds_key = list(dataset_options.keys())[0]
selected_dataset_key = st.selectbox("Select Dataset", options=list(dataset_options.keys()), index=list(dataset_options.keys()).index(default_ds_key))
selected_dataset = dataset_options[selected_dataset_key]

with st.spinner("Loading files..."):
    files = get_files_list(client, selected_dataset.id)

if not files:
    st.error(f"No files found in dataset '{selected_dataset.external_id}'.")
    st.stop()

file_options = {file.name: file for file in files}
selected_file_key = st.selectbox("Select File", options=list(file_options.keys()))
selected_file = file_options[selected_file_key]

# --- Page Selection and Instructions ---
page_number = st.number_input("Page Number to Analyze", min_value=1, max_value=100, value=6)

default_instructions = """You are an expert in analyzing ASME U-1 form images. Extract ONLY the specified properties from the form and respond in valid JSON format. If a property is not visible or does not exist, use null.

RESPOND ONLY IN THIS EXACT JSON FORMAT:
{
  "U1Form": {
    "nationalBoardNumber": null,
    "mfrRepresentative": null,
    "authorizedInspector": null,
    "reportDate": null,
    "manufacturedAndCertifiedBy": null,
    "manufacturedFor": null,
    "locationOfInstallation": null,
    "asmeCode": null,
    "drawingNumber": null,
    "yearBuilt": null,
    "codeCaseNumber": null,
    "specialService": null
  },
  "U1Vessel": {
    "type": null,
    "vesselType": null,
    "manufacturerSerialNumber": null,
    "numberOfCourses": null,
    "overallLength": null,
    "mawpInternal": null,
    "mawpExternal": null,
    "mawpInternalTemp": null,
    "mawpExternalTemp": null,
    "minDesignMetalTemp": null,
    "minDesignMetalTempAt": null,
    "impactTest": null,
    "impactTestedComponents": null,
    "testPressure": null,
    "proofTest": null,
    "testTemp": null
  },
  "U1Shell": [
    {
      "courseNumber": null,
      "courseDiameter": null,
      "courseLength": null,
      "courseMaterialSpec": null,
      "courseThicknessNom": null,
      "courseThicknessCorr": null,
      "longJointType": null,
      "longJointEff": null,
      "circumJointType": null,
      "circumJointEff": null,
      "heatTreatmentTemp": null,
      "heatTreatmentTime": null
    }
  ],
  "U1Flange": [
    {
      "number": null,
      "type": null,
      "id": null,
      "od": null,
      "thickness": null,
      "minHubThickness": null,
      "material": null,
      "howAttached": null,
      "location": null,
      "boltingNumAndSize": null,
      "boltingMaterial": null,
      "washer": null,
      "washerMaterial": null
    }
  ],
  "U1Heads": [
    {
      "location": null,
      "minThickness": null,
      "corr": null,
      "crownRadius": null,
      "knuckleRadius": null,
      "ellipticalRatio": null,
      "conicalApexAngle": null,
      "hemisphericalRadius": null,
      "flatDiameter": null,
      "sideToPressure": null,
      "type": null,
      "categoryAJoint": null
    }
  ],
  "U1Jacket": {
    "type": null,
    "dimensions": null,
    "closure": null
  }
}

Extract all visible values from the form. Use exact text as shown. For dates, use the format shown on the form. For multiple shells/heads/flanges, create separate objects in their respective arrays."""

instructions = st.text_area("AI Instructions", value=default_instructions, height=150)

# --- Main Action Button ---
analyze_col1, analyze_col2, analyze_col3 = st.columns([1, 1, 1])
with analyze_col2:
    interrogate_clicked = st.button("✨ Interrogate", type="primary", use_container_width=True)

if interrogate_clicked:
    with st.spinner(f"Analyzing page {page_number}..."):
        try:
            # Use Completions class instead of Interogate
            completions = Completions(
                client=client,
                system_prompt=instructions,
                user_content="Please analyze this image."
            )
            
            result = completions.call_endpoint_with_file(
                file_id=selected_file.id,
                start_page=page_number,
                end_page=page_number
            )
            
            st.session_state.ai_results = result
            st.session_state.selected_file_name = selected_file.name
            st.session_state.selected_page_number = page_number
        except Exception as e:
            st.error(f"Error during analysis: {e}")

# --- Results and Commit Section ---
if st.session_state.ai_results:
    st.markdown("---")
    try:
        start_idx, end_idx = st.session_state.ai_results.find('{'), st.session_state.ai_results.rfind('}') + 1
        if start_idx == -1 or end_idx <= start_idx:
            raise json.JSONDecodeError("No valid JSON object found in AI response.", st.session_state.ai_results, 0)
        
        parsed_json = json.loads(st.session_state.ai_results[start_idx:end_idx])
        
        with st.expander("📋 Extracted Data Preview", expanded=True):
            st.json(parsed_json)

        if st.button("💾 Commit to Knowledge Graph", type="secondary", use_container_width=True):
            with st.spinner("Saving U1 form data..."):
                try:
                    asset_prefix = st.session_state.selected_file_name
                    try:
                        d2d_view = View(client, space="d2d2", external_id="D2DDoc")
                        instance_id = f"doc-{st.session_state.selected_file_name}"
                        props = d2d_view.get_instance(external_id=instance_id, space="d2d2")
                        if props and props.get("assetsList"):
                            asset_prefix = props["assetsList"][0]
                            st.info(f"Retrieved asset from document: {asset_prefix}")
                    except Exception as e:
                        st.warning(f"Could not look up asset name, using filename as fallback: {e}")

                    save_results = dm_helper.save_u1_form_data(
                        client=client,
                        u1_json_data=parsed_json,
                        asset_prefix=asset_prefix,
                        file_name=st.session_state.selected_file_name
                    )

                    if save_results.get("success"):
                        st.success(f"Successfully saved {save_results['components_saved']} components.")
                        with st.expander("Save Details"):
                            for detail in save_results.get("details", []):
                                st.write(f"  - {detail['component']}: {detail['status'].capitalize()} ({detail.get('external_id', detail.get('error'))})")
                    else:
                        st.error(f"Failed to save components. Saved: {save_results['components_saved']}, Failed: {save_results['components_failed']}.")
                        st.json(save_results)

                except Exception as e:
                    st.error(f"Error during save: {e}")

    except json.JSONDecodeError as e:
        st.error(f"Could not parse JSON from AI response: {e}")
        st.code(st.session_state.ai_results, language="text")
