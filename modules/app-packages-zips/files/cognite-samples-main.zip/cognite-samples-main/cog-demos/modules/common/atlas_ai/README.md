# Atlas AI Data Models

## Overview
The Atlas AI module creates the foundational data models and infrastructure required for Atlas AI functionality in Cognite Data Fusion. This module is completely self-contained and requires no configuration variables.

## What This Module Does
- **Creates Atlas AI data models** for managing AI agent information
- **Sets up a dedicated space** called `cognite-atlas-ai`
- **Defines AI Agent containers** with properties like name, description, goals, instructions, etc.
- **Creates access groups** for Atlas AI functionality

## Module Components

### 1. **Space**
- **Name**: `cognite-atlas-ai`
- **Purpose**: Dedicated space for Atlas AI data models

### 2. **Data Model**
- **External ID**: `CogniteAtlasAI`
- **Version**: `v1`
- **Space**: `cognite-atlas-ai`

### 3. **Container**
- **External ID**: `AIAgent`
- **Purpose**: Stores AI agent information
- **Properties**:
  - `name`: Agent name
  - `description`: Agent description
  - `isPublished`: Publication status
  - `ownerId`: Agent owner ID
  - `goal`: Agent goal
  - `instructions`: Agent instructions
  - `model`: AI model used
  - `tools`: Tools available to agent
  - `exampleQuestions`: Example questions for the agent

### 4. **View**
- **External ID**: `AIAgent`
- **Purpose**: Provides access to AI agent data
- **Version**: `v1`

### 5. **Access Group**
- **Name**: `gp_atlas_ai_default`
- **Members**: `allUserAccounts`
- **Capabilities**:
  - **Data Models ACL**: READ access to `cognite-atlas-ai` space
  - **Data Model Instances ACL**: READ/WRITE access to `cognite-atlas-ai` space

## Configuration Requirements

### ✅ **No Variables Required!**
This module is **completely self-contained** and doesn't use any template variables (`{{variable}}`). It's designed to be plug-and-play.

### **Deployment**
- **No configuration needed** - deploy as-is
- **No environment variables required**
- **No template substitutions needed**

## Usage
Once deployed, this module provides the foundational data models for Atlas AI functionality, allowing users to:
- Create and manage AI agents
- Store agent configurations
- Define agent goals and instructions
- Configure agent tools and capabilities

## Verification System

### **Automated Verification**
The Atlas AI module includes an automated verification system that validates successful deployment by checking all required components via CDF API calls.

**Location**: `modules/common/atlas_ai/verify/verify.py`

### **What It Verifies**
The verification script automatically checks for:

1. **Space**: `cognite-atlas-ai` - Dedicated space for Atlas AI data models
2. **Data Model**: `CogniteAtlasAI` - Main data model for Atlas AI functionality  
3. **Container**: `AIAgent` - Container storing AI agent information with 9 properties
4. **View**: `AIAgent` - View providing access to AI agent data

### **How to Run Verification**

**Individual Module Verification:**
```bash
cd cog-demos
python modules/common/atlas_ai/verify/verify.py
```

**Test Harness (All Modules):**
```bash
cd cog-demos
python ../scripts/test_harness.py --config config.all.yaml
```

### **Verification Output**
```
🔍 ATLAS_AI VERIFICATION
========================================
✅ Space: Space found
✅ Data Model: Data Model found
✅ Container: Container found (checked 66 containers)
✅ View: View found (checked 48 views)

📋 Atlas AI verification PASSED
```

### **Integration with Deployment**
The verification system is designed to run automatically after each successful deployment to ensure all Atlas AI components are properly deployed and accessible.

**Key Features:**
- **Pagination Handling**: Automatically handles large result sets (checks all containers/views)
- **Detailed Logging**: Shows exactly how many items were checked
- **Error Handling**: Provides clear error messages if verification fails
- **Exit Codes**: Returns proper exit codes for automated integration

## Type
Atlas AI