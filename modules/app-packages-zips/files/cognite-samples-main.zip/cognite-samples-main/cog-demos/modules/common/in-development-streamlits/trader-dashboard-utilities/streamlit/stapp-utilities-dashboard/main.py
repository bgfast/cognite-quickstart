import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import random
import numpy as np
import os
import logging

# --- Demo Script Functionality ---
def load_demo_script():
    """Load the demo script from the markdown file with robust path resolution and fallback."""
    
    # Embedded fallback content for when file can't be loaded
    fallback_content = """
# ⚡ Utilities Power Generation Trading Dashboard - Demo Script
**Duration: 8-10 minutes | Business Value Story**

---

## 👥 **PERSONAS**

**🎯 RACHEL TORRES** - Senior Power Trader  
*14 years experience at GridMax Energy, manages $180M power trading portfolio*  
*Specializes in electricity, natural gas, and renewable energy certificate trading*  
*Known for her expertise in grid operations and real-time market dynamics*  
*Currently under pressure to improve trading margins by 25% amid volatile renewable generation*

**⚙️ MICHAEL CHEN** - Generation Operations Manager  
*17 years experience, oversees 25 power plants across 7 grid regions*  
*Former power systems engineer with expertise in grid stability and dispatch optimization*  
*Responsible for $90M in annual generation optimization initiatives*  
*Leading digital transformation to improve grid-to-market coordination*

---

## 🌅 **SETTING THE SCENE**
*It's 5:45 AM on a Monday morning at GridMax Energy's Chicago trading floor. Rachel is monitoring day-ahead power markets that are showing extreme volatility due to weather forecasts, while natural gas prices are spiking on pipeline constraints. Michael is at the central dispatch center coordinating multiple power plants across ERCOT, PJM, and CAISO markets. Rachel has significant exposure to electricity delivery commitments during peak demand periods.*

---

## 🎬 **SCENE 1: The Crisis Unfolds (0:00 - 2:00)**

**RACHEL** *(surrounded by multiple screens showing power prices, load forecasts, and weather data)*  
"Michael, we have a perfect storm developing. Day-ahead power prices in ERCOT just hit $85/MWh on extreme heat forecasts, natural gas spiked $2.50 on pipeline maintenance, and I've got major utilities expecting 2,500 MWh of firm power delivery during tomorrow's peak hours. Wind generation forecasts are dropping fast."

**MICHAEL** *(video call from dispatch center, with generation status boards visible in background)*  
"I saw the weather alerts. What's our exposure looking like across the different markets?"

**RACHEL** *(analyzing position screens)*  
"We're short 1,800 MWh in ERCOT at an average of $68/MWh, but real-time prices could hit $150+ during peak. I need to know our generation capacity and fuel availability across all our plants, especially our peaking units."

---

## 📊 **SCENE 2: Dashboard Deep Dive (2:00 - 5:00)**

**MICHAEL**  
"Let me show you our real-time generation status using our integrated operations dashboard..."

### **Key Dashboard Interactions:**

1. **Enterprise-Wide Generation Overview**
   - Navigate to Enterprise-Wide view  
   - Point out: 25 facilities across 7 grid regions
   - Total capacity: 18,500 MW, current generation: 14,200 MW
   - Available peaking capacity: 3,800 MW (enough to cover shortfall)

2. **Regional Focus - ERCOT**
   - Switch to Region-Wide filter for ERCOT
   - Highlight: 4 gas plants, 2 wind farms showing optimal status
   - Combined ERCOT generation: 4,200 MW current, 5,800 MW max capacity

3. **Equipment & Fuel Status Analysis**
   - Click on South Texas Gas Plant (1,200 MW capacity)
   - Fuel availability: 72 hours at full load
   - Equipment status: All turbines optimal, ready for dispatch

4. **Real-time Market Integration**
   - Show electricity price trends vs. generation cost curves
   - Natural gas consumption rates and cost impact analysis
   - Renewable generation forecasts and variability factors

---

## 💡 **SCENE 3: Strategic Decision Making (5:00 - 8:00)**

**RACHEL**  
"Perfect visibility! I can see we have the capacity, but what about fuel costs? These gas prices are killing our margins."

**MICHAEL**  
"Our South Texas plant has locked-in gas contracts at $4.20/MMBtu through next month. Even with transport, we're looking at $42/MWh variable costs. With power at $85 and potentially $150, we're profitable across all scenarios."

**RACHEL**  
"Excellent. Here's my strategy:
- **Immediate**: Commit to 1,800 MWh delivery using our ERCOT gas plants
- **Opportunistic**: Offer additional 1,000 MWh at $95/MWh for peak hours
- **Risk Management**: Keep 500 MW spinning reserve for grid stability payments"

### **Business Impact Demonstrated:**

**Before Dashboard:**
- 45+ minutes coordinating across dispatch centers
- Conservative bidding due to uncertainty
- Missed high-value trading opportunities
- Manual fuel cost calculations

**With Dashboard:**
- Real-time generation and fuel visibility (3 minutes)
- Confident bidding on peak power
- Optimized plant dispatch decisions
- **Result**: Additional $125K profit opportunity per day

---

## 🎯 **SCENE 4: Grid Integration Excellence (8:00 - 10:00)**

**RACHEL**  
"Michael, this real-time coordination is transformative. While other traders are guessing about their generation capability, we're making data-driven dispatch decisions that maximize both grid value and trading profits."

**MICHAEL**  
"Exactly. And from the grid operations side, I can optimize our plant dispatch based on your forward commitments, manage our renewable intermittency, and ensure we're capturing every ancillary service payment opportunity."

### **Quantified Business Value:**
- **Trading Margin Improvement**: 25% increase ($45M annual impact)
- **Decision Speed**: 20x faster (45 min → 3 min)
- **Peak Revenue Capture**: $3.2M additional monthly during high-price events
- **Fuel Cost Optimization**: $2.1M saved annually through better dispatch
- **Grid Services Revenue**: $1.8M additional from ancillary services

---

## 🔧 **Key Features Demonstrated:**

✅ **Real-time Generation Monitoring**  
✅ **Multi-market Price Integration**  
✅ **Fuel Cost & Availability Tracking**  
✅ **Renewable Generation Forecasting**  
✅ **Grid Stability & Ancillary Services**  
✅ **Peak Demand Response Optimization**  
✅ **Cross-regional Portfolio Management**

---

## 📈 **ROI Summary:**
- **Implementation Cost**: $980K
- **Annual Benefit**: $52.1M
- **Payback Period**: 6.9 days
- **3-Year NPV**: $147M

---

*This dashboard transforms power trading from reactive to proactive, enabling real-time grid optimization that maximizes both market profits and system reliability.*
"""
    
    try:
        # Get the directory of the current script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Multiple path attempts for different deployment scenarios
        possible_paths = [
            # Local development path (original)
            os.path.join(os.path.dirname(os.path.dirname(current_dir)), "DEMO_SCRIPT.md"),
            # Container deployment paths
            os.path.join("/app", "DEMO_SCRIPT.md"),
            os.path.join("/app", "trader-dashboard-utilities", "DEMO_SCRIPT.md"),
            # Relative to current directory
            os.path.join(current_dir, "DEMO_SCRIPT.md"),
            os.path.join(current_dir, "..", "..", "DEMO_SCRIPT.md"),
            # Working directory
            "DEMO_SCRIPT.md",
            "./DEMO_SCRIPT.md"
        ]
        
        # Try each path
        for path in possible_paths:
            try:
                if os.path.exists(path):
                    with open(path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():  # Ensure file is not empty
                            return content
            except Exception as path_error:
                # Log individual path failures but continue trying
                logging.warning(f"Failed to load demo script from {path}: {path_error}")
                continue
        
        # If no file found, return fallback content
        logging.info("Demo script file not found in any expected location, using embedded fallback content")
        return fallback_content
        
    except Exception as e:
        # Final fallback with error info
        logging.error(f"Error in load_demo_script: {str(e)}")
        return f"""
# Demo Script Loading Error

**Error Details:** {str(e)}

**Fallback Content:**

{fallback_content}
"""

# Page configuration
st.set_page_config(layout="wide", page_title="Utilities Power Generation Trading Dashboard", page_icon="⚡")

st.title("⚡ Utilities Power Generation Trading Dashboard - Real-Time Grid Insights")

# Prominent disclaimer
st.markdown(
    """
    <div style="background-color:#fff3cd; padding: 10px; border-left: 5px solid #ffc107; margin-bottom: 20px;">
        <h4 style="color:#856404; margin-top: 0;">⚠️ IMPORTANT: This is a Mockup Demo</h4>
        <p style="color:#856404; margin-bottom: 0;">
            This dashboard uses **simulated data** to illustrate potential functionalities for energy trading operations. 
            It is a **mockup, not a Proof-of-Concept (POC)**, and does not connect to live grid or plant systems. 
            Its purpose is to facilitate discussion and gather feedback on desired features and data presentation.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

st.write("Dashboard is loading...")

# --- Global Definitions for Power Generation Data Simulation ---
regions = ["ERCOT", "PJM", "CAISO", "NYISO", "SPP", "MISO", "ISO-NE"]
fuel_types = ["Natural Gas", "Coal", "Nuclear", "Hydro", "Wind", "Solar", "Biomass"]
commodities = ["Electricity (MWh)", "Natural Gas (MMBtu)", "Coal (tons)"]
equipment_types = ["Gas Turbine", "Steam Turbine", "Generator", "Boiler", "Transformer", "Reactor", "Cooling Tower", "Wind Turbine"]
status_options = ["Optimal", "Reduced Output", "Planned Maintenance", "Forced Outage", "Shutdown"]
incident_causes = ["Equipment Failure", "Fuel Supply Issue", "Weather Impact", "Grid Constraint", "Scheduled Maintenance", "Environmental Limit"]
outlook_options = ["Improving", "Stable", "Declining", "Under Review", "Recovering"]

# Trader's Book of Business (market hubs and regions)
trader_books = {
    "Trader A (ERCOT Hub)": {"Markets": ["ERCOT"], "FuelTypes": ["Natural Gas", "Wind", "Solar"]},
    "Trader B (PJM West)": {"Markets": ["PJM"], "FuelTypes": ["Natural Gas", "Coal", "Nuclear"]},
    "Trader C (CAISO SP15)": {"Markets": ["CAISO"], "FuelTypes": ["Natural Gas", "Hydro", "Solar"]},
    "Trader D (Multi-Region)": {"Markets": regions, "FuelTypes": fuel_types}
}

def get_hardcoded_plant_data(num_plants=25):
    """
    Generates hard-coded data for 25 power generation plants across different fuel types and regions.
    Simulates various operational states for energy trading scenarios.
    """
    plants_template = [
        {"name": "South Texas Gas Plant", "region": "ERCOT", "fuel_type": "Natural Gas", "capacity_mw": 1200},
        {"name": "West Texas Wind Farm", "region": "ERCOT", "fuel_type": "Wind", "capacity_mw": 800},
        {"name": "East Texas Coal Plant", "region": "ERCOT", "fuel_type": "Coal", "capacity_mw": 1500},
        {"name": "Hill Country Solar", "region": "ERCOT", "fuel_type": "Solar", "capacity_mw": 600},
        {"name": "Pennsylvania Nuclear", "region": "PJM", "fuel_type": "Nuclear", "capacity_mw": 2200},
        {"name": "Ohio Valley Coal", "region": "PJM", "fuel_type": "Coal", "capacity_mw": 1800},
        {"name": "Marcellus Gas Plant", "region": "PJM", "fuel_type": "Natural Gas", "capacity_mw": 1000},
        {"name": "Appalachian Hydro", "region": "PJM", "fuel_type": "Hydro", "capacity_mw": 400},
        {"name": "Central Valley Gas", "region": "CAISO", "fuel_type": "Natural Gas", "capacity_mw": 900},
        {"name": "Sierra Nevada Hydro", "region": "CAISO", "fuel_type": "Hydro", "capacity_mw": 1200},
        {"name": "Mojave Solar", "region": "CAISO", "fuel_type": "Solar", "capacity_mw": 700},
        {"name": "Tehachapi Wind", "region": "CAISO", "fuel_type": "Wind", "capacity_mw": 500},
        {"name": "Upstate Nuclear", "region": "NYISO", "fuel_type": "Nuclear", "capacity_mw": 1900},
        {"name": "Hudson Valley Gas", "region": "NYISO", "fuel_type": "Natural Gas", "capacity_mw": 800},
        {"name": "Finger Lakes Hydro", "region": "NYISO", "fuel_type": "Hydro", "capacity_mw": 300},
        {"name": "Kansas Wind Complex", "region": "SPP", "fuel_type": "Wind", "capacity_mw": 1100},
        {"name": "Oklahoma Gas Plant", "region": "SPP", "fuel_type": "Natural Gas", "capacity_mw": 1300},
        {"name": "Arkansas Coal Plant", "region": "SPP", "fuel_type": "Coal", "capacity_mw": 1600},
        {"name": "Illinois Nuclear", "region": "MISO", "fuel_type": "Nuclear", "capacity_mw": 2000},
        {"name": "Minnesota Wind Farm", "region": "MISO", "fuel_type": "Wind", "capacity_mw": 900},
        {"name": "Indiana Coal Plant", "region": "MISO", "fuel_type": "Coal", "capacity_mw": 1400},
        {"name": "Wisconsin Hydro", "region": "MISO", "fuel_type": "Hydro", "capacity_mw": 350},
        {"name": "Maine Wind Farm", "region": "ISO-NE", "fuel_type": "Wind", "capacity_mw": 600},
        {"name": "Connecticut Gas Plant", "region": "ISO-NE", "fuel_type": "Natural Gas", "capacity_mw": 750},
        {"name": "Vermont Hydro", "region": "ISO-NE", "fuel_type": "Hydro", "capacity_mw": 250},
    ]
    
    num_plants_to_create = min(num_plants, len(plants_template))
    selected_plants = random.sample(plants_template, k=num_plants_to_create)
    
    all_plants_data = []
    
    for i, plant_info in enumerate(selected_plants):
        plant_name = plant_info["name"]
        plant_id = f"plant_{i+1}"
        region = plant_info["region"]
        fuel_type = plant_info["fuel_type"]
        capacity_mw = plant_info["capacity_mw"]
        
        status = random.choices(status_options, weights=[0.60, 0.20, 0.10, 0.07, 0.03], k=1)[0]
        
        # Assign trader books based on region and fuel type
        assigned_trader_books = []
        for trader, details in trader_books.items():
            if region in details["Markets"] and fuel_type in details["FuelTypes"]:
                assigned_trader_books.append(trader)
        
        if not assigned_trader_books:
            assigned_trader_books = ["Trader D (Multi-Region)"]
        
        # Randomize to 1-2 traders max
        if len(assigned_trader_books) > 2:
            assigned_trader_books = random.sample(assigned_trader_books, k=random.randint(1, 2))
        
        current_plant = {
            "PlantID": plant_id,
            "PlantName": plant_name,
            "Region": region,
            "FuelType": fuel_type,
            "CapacityMW": capacity_mw,
            "OverallStatus": status,
            "LastUpdated": datetime.now() - timedelta(minutes=random.randint(5, 60)),
            "TraderBooks": assigned_trader_books,
        }
        
        # Calculate current generation based on status
        base_generation = capacity_mw * random.uniform(0.7, 0.95)  # Normal capacity factor
        generation_factor = 1.0
        
        if status == "Reduced Output":
            generation_factor = random.uniform(0.4, 0.7)
        elif status == "Planned Maintenance":
            generation_factor = random.uniform(0.2, 0.5)
        elif status == "Forced Outage":
            generation_factor = random.uniform(0.0, 0.2)
        elif status == "Shutdown":
            generation_factor = 0.0
        
        current_generation = base_generation * generation_factor
        planned_generation = base_generation
        
        current_plant["CurrentGeneration_MW"] = current_generation
        current_plant["PlannedGeneration_MW"] = planned_generation
        current_plant["GenerationDeviation_Pct"] = ((current_generation - planned_generation) / planned_generation) * 100 if planned_generation > 0 else 0
        
        # Fuel consumption and costs
        if fuel_type == "Natural Gas":
            heat_rate = random.uniform(7000, 9000)  # BTU/kWh
            fuel_consumption = current_generation * heat_rate / 1000  # MMBtu/hr
            fuel_price = random.uniform(3.0, 6.0)  # $/MMBtu
        elif fuel_type == "Coal":
            heat_rate = random.uniform(9000, 11000)  # BTU/kWh
            fuel_consumption = current_generation * heat_rate / 2000 / 1000  # tons/hr (assuming 20 MMBtu/ton)
            fuel_price = random.uniform(40, 80)  # $/ton
        else:
            fuel_consumption = 0  # Renewables, nuclear, hydro
            fuel_price = 0
        
        current_plant["FuelConsumption_Rate"] = fuel_consumption
        current_plant["FuelPrice"] = fuel_price
        current_plant["VariableCost_MWh"] = (fuel_consumption * fuel_price) / current_generation if current_generation > 0 else 0
        
        # Equipment status simulation
        equipment_status = []
        num_equipment = random.randint(4, 8)
        
        for eq_idx in range(num_equipment):
            eq_type = random.choice(equipment_types)
            eq_name = f"{eq_type} {eq_idx+1}"
            eq_status_options_eq = ["Optimal", "Reduced Capacity", "Maintenance", "Fault", "Offline"]
            eq_status = random.choices(eq_status_options_eq, weights=[0.75, 0.12, 0.08, 0.03, 0.02], k=1)[0]
            
            generation_impact_mw = 0
            estimated_duration_hours = 0
            
            if eq_status in ["Reduced Capacity", "Fault", "Offline"]:
                if eq_status == "Reduced Capacity":
                    impact_factor = random.uniform(0.05, 0.20)
                    generation_impact_mw = capacity_mw * impact_factor
                    estimated_duration_hours = random.randint(4, 24)
                elif eq_status == "Fault":
                    impact_factor = random.uniform(0.20, 0.50)
                    generation_impact_mw = capacity_mw * impact_factor
                    estimated_duration_hours = random.randint(12, 72)
                elif eq_status == "Offline":
                    impact_factor = random.uniform(0.50, 1.0)
                    generation_impact_mw = capacity_mw * impact_factor
                    estimated_duration_hours = random.randint(24, 168)
            
            equipment_status.append({
                "EquipmentID": f"eq_{plant_id}_{eq_idx}",
                "Name": eq_name,
                "Type": eq_type,
                "Status": eq_status,
                "GenerationImpact_MW": round(generation_impact_mw, 1),
                "EstimatedDuration_Hours": estimated_duration_hours
            })
        
        current_plant["Equipment"] = equipment_status
        
        # Incidents and operator notes
        incidents = []
        if status != "Optimal":
            incident_type = "Forced Outage" if status in ["Forced Outage", "Shutdown"] else "Planned Maintenance" if status == "Planned Maintenance" else "Performance Issue"
            
            incident_duration = 0
            if status in ["Forced Outage", "Shutdown"]:
                incident_duration = random.randint(24, 168)
            elif status == "Planned Maintenance":
                incident_duration = random.randint(48, 336)
            elif status == "Reduced Output":
                incident_duration = random.randint(6, 48)
            
            operator_note = f"Experiencing {incident_type} due to {random.choice(incident_causes)}. Operations team actively addressing."
            if incident_duration > 0:
                operator_note += f" Estimated restoration in {incident_duration} hours."
            
            incidents.append({
                "Timestamp": datetime.now() - timedelta(hours=random.randint(1, 24)),
                "Type": incident_type,
                "RootCause": random.choice(incident_causes),
                "ImpactDescription": f"Reduced generation by {abs(current_plant['GenerationDeviation_Pct']):.1f}%",
                "Outlook": random.choice(outlook_options),
                "EstimatedDuration_Hours": incident_duration,
                "OperatorNotes": operator_note,
                "Source": "Operations"
            })
        
        current_plant["Incidents"] = incidents
        all_plants_data.append(current_plant)
    
    # Override specific plants for demo consistency
    # ERCOT Gas Plant - Major outage scenario
    ercot_gas = next((item for item in all_plants_data if item["PlantName"] == "South Texas Gas Plant"), None)
    if ercot_gas:
        ercot_gas["OverallStatus"] = "Forced Outage"
        ercot_gas["CurrentGeneration_MW"] = 150.0
        ercot_gas["PlannedGeneration_MW"] = 1100.0
        ercot_gas["GenerationDeviation_Pct"] = -86.4
        ercot_gas["TraderBooks"] = ["Trader A (ERCOT Hub)", "Trader D (Multi-Region)"]
        
        ercot_gas["Incidents"] = [{
            "Timestamp": datetime.now() - timedelta(hours=8),
            "Type": "Forced Outage",
            "RootCause": "Equipment Failure",
            "ImpactDescription": "Gas Turbine 1 trip caused plant shutdown. Only backup generator online.",
            "Outlook": "Under Review",
            "EstimatedDuration_Hours": 72,
            "OperatorNotes": "Major gas turbine failure. Replacement parts being expedited. Estimated 3-day outage affecting 950 MW capacity.",
            "Source": "Operations"
        }]
    
    # PJM Coal Plant - Planned maintenance
    pjm_coal = next((item for item in all_plants_data if item["PlantName"] == "Ohio Valley Coal"), None)
    if pjm_coal:
        pjm_coal["OverallStatus"] = "Planned Maintenance"
        pjm_coal["CurrentGeneration_MW"] = 720.0
        pjm_coal["PlannedGeneration_MW"] = 1650.0
        pjm_coal["GenerationDeviation_Pct"] = -56.4
        pjm_coal["TraderBooks"] = ["Trader B (PJM West)", "Trader D (Multi-Region)"]
        
        pjm_coal["Incidents"] = [{
            "Timestamp": datetime.now() - timedelta(hours=24),
            "Type": "Planned Maintenance",
            "RootCause": "Scheduled Maintenance",
            "ImpactDescription": "Unit 2 offline for boiler inspection. Unit 1 at reduced load.",
            "Outlook": "Stable",
            "EstimatedDuration_Hours": 120,
            "OperatorNotes": "Scheduled 5-day maintenance outage. Unit 1 operating at 40% to maintain grid stability.",
            "Source": "Operations"
        }]
    
    return pd.DataFrame(all_plants_data)

@st.cache_data(ttl=30)
def get_plant_data():
    """Retrieves the hard-coded power plant data."""
    return get_hardcoded_plant_data()

@st.cache_data(ttl=10)
def get_equipment_details(selected_plant_data):
    """Retrieves equipment details from the provided plant data."""
    if selected_plant_data is None or not isinstance(selected_plant_data, pd.Series):
        return pd.DataFrame()
    return pd.DataFrame(selected_plant_data["Equipment"])

@st.cache_data(ttl=10)
def get_incidents(selected_plant_data):
    """Retrieves incidents and operator notes from the provided plant data."""
    if selected_plant_data is None or not isinstance(selected_plant_data, pd.Series):
        return pd.DataFrame()
    return pd.DataFrame(selected_plant_data["Incidents"])

@st.cache_data(ttl=30)
def get_commodity_data(filtered_plants_df):
    """Aggregates commodity data across the filtered set of plants."""
    data = []
    for commodity in commodities:
        if commodity == "Electricity (MWh)":
            current = filtered_plants_df["CurrentGeneration_MW"].sum()
            planned = filtered_plants_df["PlannedGeneration_MW"].sum()
            shortfall = max(0, planned - current)
            data.append({
                "Commodity": commodity,
                "Current Generation (MW)": round(current, 1),
                "Planned Generation (MW)": round(planned, 1),
                "Shortfall (MW)": round(shortfall, 1),
                "Deviation (%)": round(((current - planned) / planned) * 100, 1) if planned > 0 else 0
            })
        elif commodity == "Natural Gas (MMBtu)":
            gas_plants = filtered_plants_df[filtered_plants_df["FuelType"] == "Natural Gas"]
            consumption = gas_plants["FuelConsumption_Rate"].sum()
            avg_price = gas_plants["FuelPrice"].mean() if len(gas_plants) > 0 else 0
            data.append({
                "Commodity": commodity,
                "Current Consumption (MMBtu/hr)": round(consumption, 1),
                "Average Price ($/MMBtu)": round(avg_price, 2),
                "Daily Cost ($)": round(consumption * avg_price * 24, 0),
                "Status": "Normal" if consumption > 0 else "No Consumption"
            })
        elif commodity == "Coal (tons)":
            coal_plants = filtered_plants_df[filtered_plants_df["FuelType"] == "Coal"]
            consumption = coal_plants["FuelConsumption_Rate"].sum()
            avg_price = coal_plants["FuelPrice"].mean() if len(coal_plants) > 0 else 0
            data.append({
                "Commodity": commodity,
                "Current Consumption (tons/hr)": round(consumption, 1),
                "Average Price ($/ton)": round(avg_price, 2),
                "Daily Cost ($)": round(consumption * avg_price * 24, 0),
                "Status": "Normal" if consumption > 0 else "No Consumption"
            })
    
    return pd.DataFrame(data)

@st.cache_data(ttl=30)
def get_generation_trends(plant_id, region):
    """
    Generates historical generation data for a specific plant or region,
    including month-to-date, 30-day forecast, and 30-day rolling average.
    """
    today = datetime.now().date()
    start_date = today - timedelta(days=60)
    end_date = today + timedelta(days=30)
    
    dates = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]
    
    df_plants = get_plant_data()
    
    if plant_id:
        plant_row = df_plants[df_plants["PlantID"] == plant_id].iloc[0]
        base_generation = plant_row["PlannedGeneration_MW"]
        plant_name = plant_row["PlantName"]
    else:
        # Regional aggregation
        region_plants = df_plants[df_plants["Region"] == region]
        base_generation = region_plants["PlannedGeneration_MW"].sum()
        plant_name = f"{region} Region"
    
    generation_data_points = []
    
    for date in dates:
        if date <= today:  # Historical data
            daily_gen = base_generation * random.uniform(0.85, 1.05)
            
            # Simulate weather and operational impacts
            if random.random() < 0.1:  # 10% chance of significant event
                daily_gen *= random.uniform(0.3, 0.8)
            
            generation_data_points.append({
                "Date": date,
                "Generation (MW)": daily_gen,
                "Planned Generation (MW)": base_generation,
                "Type": "Actual"
            })
        else:  # Forecast data
            forecast_gen = base_generation * random.uniform(0.90, 1.02)
            
            # Seasonal adjustments for renewables
            if plant_id:
                if plant_row["FuelType"] in ["Solar", "Wind"]:
                    seasonal_factor = 0.8 + 0.4 * random.random()  # Higher variability
                    forecast_gen *= seasonal_factor
            
            generation_data_points.append({
                "Date": date,
                "Forecast (MW)": forecast_gen,
                "Planned Generation (MW)": base_generation,
                "Type": "Forecast"
            })
    
    df_combined = pd.DataFrame(generation_data_points)
    df_combined["Date"] = pd.to_datetime(df_combined["Date"])
    df_combined.set_index("Date", inplace=True)
    
    # Calculate 30-day rolling average for historical data
    historical_mask = df_combined.index.date <= today
    df_combined.loc[historical_mask, "30-Day Rolling Avg (MW)"] = \
        df_combined.loc[historical_mask, "Generation (MW)"].rolling(window=30, min_periods=1).mean()
    
    # Fill NaN values for plotting
    df_combined.loc[df_combined['Type'] == 'Forecast', 'Generation (MW)'] = np.nan
    df_combined.loc[df_combined['Type'] == 'Actual', 'Forecast (MW)'] = np.nan
    
    # Calculate Month-to-Date generation
    first_day_of_month = today.replace(day=1)
    mtd_df = df_combined.loc[(df_combined.index.date >= first_day_of_month) & (df_combined.index.date <= today)]
    mtd_generation = mtd_df["Generation (MW)"].sum()
    
    df_combined.reset_index(inplace=True)
    
    return df_combined, mtd_generation, plant_name

# --- Streamlit UI Components ---

# --- Sidebar Navigation ---
st.sidebar.header("Navigation")

# Add tabs for main dashboard and demo script
page = st.sidebar.radio("Select Page:", ["Dashboard", "Demo Script"])

if page == "Demo Script":
    st.title("⚡ Utilities Power Generation Trading Dashboard - Demo Script")
    st.markdown("---")
    
    demo_content = load_demo_script()
    st.markdown(demo_content)
    
    st.markdown("---")
    st.caption("Return to the Dashboard using the sidebar navigation.")
    st.stop()  # Stop execution here for demo script page

# --- Filtering Options (Enterprise, Region, Trader's Book) ---
st.sidebar.header("View Filters")

view_mode = st.sidebar.radio(
    "Select View Mode:",
    ("Enterprise Wide", "Region Wide", "My Book of Business")
)

df_plants = get_plant_data()
filtered_plants_df = df_plants.copy()
selected_region = None
selected_trader_book = None

if view_mode == "Region Wide":
    regions_available = sorted(df_plants["Region"].unique().tolist())
    selected_region = st.sidebar.selectbox("Select Region:", regions_available)
    filtered_plants_df = filtered_plants_df[filtered_plants_df["Region"] == selected_region]
elif view_mode == "My Book of Business":
    # Flatten trader books and get unique values
    all_trader_books = []
    for _, row in df_plants.iterrows():
        all_trader_books.extend(row["TraderBooks"])
    unique_trader_books = sorted(list(set(all_trader_books)))
    
    selected_trader_book = st.sidebar.selectbox("Select Trader Book:", unique_trader_books)
    
    # Filter plants that include this trader book
    mask = df_plants["TraderBooks"].apply(lambda x: selected_trader_book in x)
    filtered_plants_df = filtered_plants_df[mask]

# Additional filters
st.sidebar.subheader("Additional Filters")
fuel_filter = st.sidebar.multiselect(
    "Filter by Fuel Type:",
    options=sorted(df_plants["FuelType"].unique()),
    default=sorted(df_plants["FuelType"].unique())
)

status_filter = st.sidebar.multiselect(
    "Filter by Status:",
    options=status_options,
    default=status_options
)

# Apply additional filters
filtered_plants_df = filtered_plants_df[
    (filtered_plants_df["FuelType"].isin(fuel_filter)) &
    (filtered_plants_df["OverallStatus"].isin(status_filter))
]

# --- Main Dashboard Layout ---

# Summary metrics row
col1, col2, col3, col4 = st.columns(4)

total_capacity = filtered_plants_df["CapacityMW"].sum()
total_current = filtered_plants_df["CurrentGeneration_MW"].sum()
total_planned = filtered_plants_df["PlannedGeneration_MW"].sum()
capacity_factor = (total_current / total_capacity) * 100 if total_capacity > 0 else 0

with col1:
    st.metric(
        "Total Capacity", 
        f"{total_capacity:,.0f} MW",
        help="Total installed capacity of filtered plants"
    )

with col2:
    st.metric(
        "Current Generation", 
        f"{total_current:,.0f} MW",
        delta=f"{total_current - total_planned:,.0f} MW vs Plan"
    )

with col3:
    st.metric(
        "Capacity Factor", 
        f"{capacity_factor:.1f}%",
        help="Current generation as % of total capacity"
    )

with col4:
    outage_count = len(filtered_plants_df[filtered_plants_df["OverallStatus"].isin(["Forced Outage", "Shutdown"])])
    st.metric(
        "Plants with Outages", 
        f"{outage_count}",
        delta=f"{len(filtered_plants_df)} total plants"
    )

st.markdown("---")

# Real-time Generation Alerts
st.subheader("🚨 Real-Time Generation Alerts")

# Identify plants with significant deviations
alert_plants = filtered_plants_df[
    (filtered_plants_df["GenerationDeviation_Pct"] < -20) | 
    (filtered_plants_df["OverallStatus"].isin(["Forced Outage", "Shutdown"]))
].copy()

if len(alert_plants) > 0:
    for _, plant in alert_plants.iterrows():
        deviation = plant["GenerationDeviation_Pct"]
        
        if plant["OverallStatus"] in ["Forced Outage", "Shutdown"]:
            alert_type = "🔴 CRITICAL"
            color = "red"
        elif deviation < -50:
            alert_type = "🟠 HIGH"
            color = "orange"
        else:
            alert_type = "🟡 MEDIUM"
            color = "gold"
        
        shortfall_mw = plant["PlannedGeneration_MW"] - plant["CurrentGeneration_MW"]
        shortfall_mwh_24h = shortfall_mw * 24
        
        st.markdown(
            f"""
            <div style="border-left: 5px solid {color}; padding: 10px; margin: 10px 0; background-color: #f8f9fa;">
                <strong>{alert_type}: {plant['PlantName']}</strong> ({plant['Region']}, {plant['FuelType']})<br/>
                <strong>Impact:</strong> {deviation:.1f}% below plan ({shortfall_mw:.0f} MW shortfall)<br/>
                <strong>24-Hour Shortfall:</strong> {shortfall_mwh_24h:,.0f} MWh<br/>
                <strong>Status:</strong> {plant['OverallStatus']} | <strong>Last Updated:</strong> {plant['LastUpdated'].strftime('%H:%M')}
            </div>
            """,
            unsafe_allow_html=True
        )
else:
    st.info("✅ No significant generation alerts at this time.")

st.markdown("---")

# Impact Analysis
st.subheader("📊 Quantified Impact Analysis")

col1, col2 = st.columns(2)

with col1:
    st.write("**Generation Shortfall Analysis**")
    commodity_data = get_commodity_data(filtered_plants_df)
    electricity_data = commodity_data[commodity_data["Commodity"] == "Electricity (MWh)"].iloc[0]
    
    shortfall_mw = electricity_data["Shortfall (MW)"]
    shortfall_24h = shortfall_mw * 24
    shortfall_7d = shortfall_mw * 24 * 7
    
    if shortfall_mw > 0:
        st.error(f"**Current Shortfall:** {shortfall_mw:.0f} MW")
        st.write(f"• **Next 24 hours:** {shortfall_24h:,.0f} MWh to buy")
        st.write(f"• **Next 7 days:** {shortfall_7d:,.0f} MWh to buy")
        
        # Estimate cost impact (assuming $50/MWh average price)
        estimated_cost_24h = shortfall_24h * 50
        st.write(f"• **Estimated cost impact (24h):** ${estimated_cost_24h:,.0f}")
    else:
        st.success("✅ No generation shortfall - meeting planned output")

with col2:
    st.write("**Trader Recommendations**")
    if shortfall_mw > 50:
        st.write("🔴 **IMMEDIATE ACTION REQUIRED**")
        
        # Calculate specific trading recommendations
        hourly_shortfall = shortfall_mw
        daily_shortfall_mwh = hourly_shortfall * 24
        peak_hours_shortfall = hourly_shortfall * 16  # Peak hours (6am-10pm)
        off_peak_shortfall = hourly_shortfall * 8    # Off-peak hours
        
        st.write(f"**Immediate Purchases Needed:**")
        st.write(f"• **Next Hour:** {hourly_shortfall:.0f} MW")
        st.write(f"• **Peak Hours (6am-10pm):** {peak_hours_shortfall:,.0f} MWh")
        st.write(f"• **Off-Peak Hours:** {off_peak_shortfall:,.0f} MWh")
        
        # Price impact estimates
        peak_price_estimate = 75  # $/MWh
        off_peak_price_estimate = 45  # $/MWh
        emergency_premium = 1.5
        
        peak_cost = peak_hours_shortfall * peak_price_estimate * emergency_premium
        off_peak_cost = off_peak_shortfall * off_peak_price_estimate * emergency_premium
        total_cost = peak_cost + off_peak_cost
        
        st.write(f"**Estimated Costs (with emergency premium):**")
        st.write(f"• Peak Hours: ${peak_cost:,.0f}")
        st.write(f"• Off-Peak: ${off_peak_cost:,.0f}")
        st.write(f"• **Total Daily Cost: ${total_cost:,.0f}**")
        
        st.write("**Actions:**")
        st.write("• Contact market operations for emergency purchases")
        st.write("• Activate demand response programs")
        st.write("• Check neighboring region availability")
        st.write("• Consider curtailing interruptible loads")
        
    elif shortfall_mw > 0:
        st.write("🟡 **MONITOR CLOSELY**")
        
        hourly_shortfall = shortfall_mw
        daily_shortfall_mwh = hourly_shortfall * 24
        
        st.write(f"**Potential Purchases:**")
        st.write(f"• **Hourly:** {hourly_shortfall:.0f} MW")
        st.write(f"• **Daily:** {daily_shortfall_mwh:,.0f} MWh")
        
        # Normal market pricing
        avg_price = 55  # $/MWh
        estimated_cost = daily_shortfall_mwh * avg_price
        
        st.write(f"**Estimated Cost: ${estimated_cost:,.0f}/day**")
        st.write("**Actions:**")
        st.write("• Prepare for potential market purchases")
        st.write("• Monitor weather and demand forecasts")
        st.write("• Review unit commitment schedule")
        st.write("• Check bilateral contract availability")
        
    else:
        st.write("✅ **NORMAL OPERATIONS**")
        
        # Calculate excess capacity for sales opportunities
        excess_mw = total_current - total_planned
        if excess_mw > 10:
            excess_daily_mwh = excess_mw * 24
            potential_revenue = excess_daily_mwh * 50  # Conservative price
            
            st.write(f"**Sales Opportunities:**")
            st.write(f"• **Excess Generation:** {excess_mw:.0f} MW")
            st.write(f"• **Daily Excess:** {excess_daily_mwh:,.0f} MWh")
            st.write(f"• **Potential Revenue:** ${potential_revenue:,.0f}/day")
            st.write("**Actions:**")
            st.write("• Market excess generation in day-ahead")
            st.write("• Consider real-time sales opportunities")
            st.write("• Review long-term contract positions")
        else:
            st.write("**Actions:**")
            st.write("• Continue standard monitoring")
            st.write("• Optimize unit dispatch for cost efficiency")
            st.write("• Monitor for arbitrage opportunities")

st.markdown("---")

# Top 5 Equipment Impact
st.subheader("🔧 Top 5 Equipment Impact")

# Collect all equipment from filtered plants
all_equipment = []
for _, plant in filtered_plants_df.iterrows():
    for eq in plant["Equipment"]:
        eq_copy = eq.copy()
        eq_copy["PlantName"] = plant["PlantName"]
        eq_copy["Region"] = plant["Region"]
        eq_copy["FuelType"] = plant["FuelType"]
        all_equipment.append(eq_copy)

equipment_df = pd.DataFrame(all_equipment)

if len(equipment_df) > 0:
    # Filter for equipment with issues
    problem_equipment = equipment_df[
        (equipment_df["Status"] != "Optimal") & 
        (equipment_df["GenerationImpact_MW"] > 0)
    ].copy()
    
    if len(problem_equipment) > 0:
        # Sort by impact and take top 5
        top_equipment = problem_equipment.nlargest(5, "GenerationImpact_MW")
        
        for _, eq in top_equipment.iterrows():
            status_color = {
                "Reduced Capacity": "orange",
                "Maintenance": "blue", 
                "Fault": "red",
                "Offline": "darkred"
            }.get(eq["Status"], "gray")
            
            st.markdown(
                f"""
                <div style="border-left: 5px solid {status_color}; padding: 10px; margin: 5px 0; background-color: #f8f9fa;">
                    <strong>{eq['Name']}</strong> at {eq['PlantName']} ({eq['Region']})<br/>
                    <strong>Status:</strong> {eq['Status']} | <strong>Impact:</strong> {eq['GenerationImpact_MW']:.1f} MW loss<br/>
                    <strong>Estimated Duration:</strong> {eq['EstimatedDuration_Hours']} hours | <strong>Type:</strong> {eq['Type']}
                </div>
                """,
                unsafe_allow_html=True
            )
    else:
        st.info("✅ No equipment issues impacting generation at this time.")
else:
    st.info("No equipment data available for current filter selection.")

st.markdown("---")

# Generation Analytics
st.subheader("📈 Generation Analytics")

# Plant/Region selection for detailed analysis
analysis_col1, analysis_col2 = st.columns(2)

with analysis_col1:
    analysis_type = st.radio("Analysis Type:", ["Individual Plant", "Regional Aggregate"])

with analysis_col2:
    if analysis_type == "Individual Plant":
        plant_options = filtered_plants_df["PlantName"].tolist()
        if plant_options:
            selected_plant_name = st.selectbox("Select Plant:", plant_options)
            selected_plant_data = filtered_plants_df[filtered_plants_df["PlantName"] == selected_plant_name].iloc[0]
            plant_id = selected_plant_data["PlantID"]
            region = selected_plant_data["Region"]
        else:
            st.warning("No plants available for selected filters")
            plant_id = None
            region = None
    else:
        if selected_region:
            region = selected_region
            plant_id = None
        else:
            regions_available = filtered_plants_df["Region"].unique().tolist()
            if regions_available:
                region = st.selectbox("Select Region:", regions_available)
                plant_id = None
            else:
                st.warning("No regions available for selected filters")
                region = None
                plant_id = None

if plant_id or region:
    trends_df, mtd_generation, analysis_name = get_generation_trends(plant_id, region)
    
    # Generation trends chart
    fig_trends = go.Figure()
    
    # Historical generation
    historical_data = trends_df[trends_df["Type"] == "Actual"]
    fig_trends.add_trace(go.Scatter(
        x=historical_data["Date"],
        y=historical_data["Generation (MW)"],
        mode='lines',
        name='Actual Generation',
        line=dict(color='blue', width=2)
    ))
    
    # Forecast generation
    forecast_data = trends_df[trends_df["Type"] == "Forecast"]
    fig_trends.add_trace(go.Scatter(
        x=forecast_data["Date"],
        y=forecast_data["Forecast (MW)"],
        mode='lines',
        name='Forecast',
        line=dict(color='orange', width=2, dash='dash')
    ))
    
    # 30-day rolling average
    historical_avg = trends_df[trends_df["Type"] == "Actual"]
    fig_trends.add_trace(go.Scatter(
        x=historical_avg["Date"],
        y=historical_avg["30-Day Rolling Avg (MW)"],
        mode='lines',
        name='30-Day Rolling Avg',
        line=dict(color='green', width=1, dash='dot')
    ))
    
    # Planned generation line
    fig_trends.add_trace(go.Scatter(
        x=trends_df["Date"],
        y=trends_df["Planned Generation (MW)"],
        mode='lines',
        name='Planned Generation',
        line=dict(color='red', width=1, dash='dashdot')
    ))
    
    fig_trends.update_layout(
        title=f"Generation Trends: {analysis_name}",
        xaxis_title="Date",
        yaxis_title="Generation (MW)",
        hovermode='x unified',
        height=500
    )
    
    st.plotly_chart(fig_trends, use_container_width=True)
    
    # Summary metrics
    metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
    
    with metrics_col1:
        st.metric("Month-to-Date Generation", f"{mtd_generation:,.0f} MWh")
    
    with metrics_col2:
        avg_30day = historical_avg["30-Day Rolling Avg (MW)"].iloc[-1] if len(historical_avg) > 0 else 0
        st.metric("30-Day Average", f"{avg_30day:,.0f} MW")
    
    with metrics_col3:
        forecast_avg = forecast_data["Forecast (MW)"].mean() if len(forecast_data) > 0 else 0
        st.metric("30-Day Forecast Avg", f"{forecast_avg:,.0f} MW")

st.markdown("---")

# Operations Intelligence
st.subheader("🎯 Operations Intelligence")

ops_col1, ops_col2 = st.columns(2)

with ops_col1:
    st.write("**Recent Incident Log**")
    
    # Collect all incidents from filtered plants
    all_incidents = []
    for _, plant in filtered_plants_df.iterrows():
        for incident in plant["Incidents"]:
            incident_copy = incident.copy()
            incident_copy["PlantName"] = plant["PlantName"]
            incident_copy["Region"] = plant["Region"]
            all_incidents.append(incident_copy)
    
    if all_incidents:
        incidents_df = pd.DataFrame(all_incidents)
        incidents_df = incidents_df.sort_values("Timestamp", ascending=False)
        
        for _, incident in incidents_df.head(5).iterrows():
            timestamp_str = incident["Timestamp"].strftime("%m/%d %H:%M")
            st.markdown(
                f"""
                <div style="border: 1px solid #ddd; padding: 8px; margin: 5px 0; border-radius: 5px; background-color: #f9f9f9;">
                    <strong>{timestamp_str}</strong> - {incident['PlantName']}<br/>
                    <strong>Type:</strong> {incident['Type']} | <strong>Cause:</strong> {incident['RootCause']}<br/>
                    <strong>Impact:</strong> {incident['ImpactDescription']}<br/>
                    <em>"{incident['OperatorNotes']}"</em>
                </div>
                """,
                unsafe_allow_html=True
            )
    else:
        st.info("No recent incidents for filtered plants.")

with ops_col2:
    st.write("**Operations Inquiry Form**")
    
    with st.form("ops_inquiry"):
        inquiry_plant = st.selectbox("Plant:", [""] + filtered_plants_df["PlantName"].tolist())
        inquiry_type = st.selectbox("Inquiry Type:", [
            "Generation Forecast Update",
            "Maintenance Schedule Change", 
            "Fuel Supply Status",
            "Equipment Status Check",
            "Emergency Contact",
            "Other"
        ])
        inquiry_priority = st.selectbox("Priority:", ["Low", "Medium", "High", "Critical"])
        inquiry_details = st.text_area("Details:", placeholder="Describe your inquiry...")
        
        submitted = st.form_submit_button("Submit Inquiry")
        
        if submitted and inquiry_plant and inquiry_details:
            st.success(f"✅ Inquiry submitted for {inquiry_plant} - Priority: {inquiry_priority}")
            st.info("Operations team will respond within 30 minutes for High/Critical priority items.")

# Plant Performance Summary Table
st.subheader("📋 Plant Performance Summary")

if len(filtered_plants_df) > 0:
    # Create summary table
    summary_df = filtered_plants_df[[
        "PlantName", "Region", "FuelType", "OverallStatus", 
        "CapacityMW", "CurrentGeneration_MW", "PlannedGeneration_MW", 
        "GenerationDeviation_Pct"
    ]].copy()
    
    # Format the dataframe for display
    summary_df["Capacity (MW)"] = summary_df["CapacityMW"].round(0).astype(int)
    summary_df["Current (MW)"] = summary_df["CurrentGeneration_MW"].round(0).astype(int)
    summary_df["Planned (MW)"] = summary_df["PlannedGeneration_MW"].round(0).astype(int)
    summary_df["Deviation (%)"] = summary_df["GenerationDeviation_Pct"].round(1)
    
    # Select columns for display
    display_df = summary_df[[
        "PlantName", "Region", "FuelType", "OverallStatus",
        "Capacity (MW)", "Current (MW)", "Planned (MW)", "Deviation (%)"
    ]]
    
    # Color coding function for status
    def color_status(val):
        if val in ["Forced Outage", "Shutdown"]:
            return 'background-color: #ffebee'
        elif val in ["Reduced Output"]:
            return 'background-color: #fff3e0'
        elif val == "Planned Maintenance":
            return 'background-color: #e3f2fd'
        else:
            return 'background-color: #e8f5e8'
    
    def color_deviation(val):
        if val < -20:
            return 'background-color: #ffebee; color: red; font-weight: bold'
        elif val < -10:
            return 'background-color: #fff3e0; color: orange'
        elif val < 0:
            return 'color: #ff9800'
        else:
            return 'color: green'
    
    # Apply styling
    styled_df = display_df.style.map(color_status, subset=['OverallStatus']).map(color_deviation, subset=['Deviation (%)'])
    
    st.dataframe(styled_df, use_container_width=True, height=400)
else:
    st.info("No plants match the current filter criteria.")

# Footer
st.markdown("---")
st.markdown(
    """
    <div style="text-align: center; color: #666; font-size: 0.9em;">
        <p>Utilities Power Generation Trading Dashboard | Real-time grid insights for energy trading decisions</p>
        <p><em>This is a demonstration with simulated data - Not connected to live systems</em></p>
    </div>
    """,
    unsafe_allow_html=True
) 