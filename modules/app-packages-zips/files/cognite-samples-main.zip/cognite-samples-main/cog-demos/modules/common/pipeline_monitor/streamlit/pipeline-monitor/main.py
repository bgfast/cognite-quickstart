import streamlit as st
from cognite.client import CogniteClient
from cognite.client.data_classes.data_modeling import ViewId
import folium
from folium import plugins
from library import get_lines, get_work_order_count, pump_popup

def get_pump_stations():
    """Retrieve pump stations from the data model with their coordinates."""
    client = CogniteClient()
    
    # Define the PumpStation view
    pump_station_view = ViewId(space="verdantix-demo", external_id="PumpStation", version="v2")
    
    try:
        # Get all pump station instances
        pump_stations = client.data_modeling.instances.list(
            sources=[pump_station_view],
            space="valhall-assets",
            limit=None
        )
        
        markers = {}
        for station in pump_stations:
            # Get properties from the PumpStation view
            station_props = station.properties.get(pump_station_view, {})
            
            # Extract coordinates
            latitude = station_props.get("latitude")
            longitude = station_props.get("longitude")
            name = station_props.get("name", station.external_id)
            
            if latitude is not None and longitude is not None:
                markers[name] = {
                    "coordinates": [longitude, latitude],  # folium expects [lon, lat]
                    "asset": station.external_id
                }
        
        return markers
    
    except Exception as e:
        st.error(f"Error retrieving pump stations: {e}")
        return {}

kml_url = "https://hub.arcgis.com/api/v3/datasets/e36c4585bb7d4f6d988853a16f5ecd26_0/downloads/data?format=kml&spatialRefId=4326&where=1%3D1"

st.title("Pump Station Status")

options = ["🚦 Current Status", "💼 Open Work Orders"]

st.write("Hit cmd-click or ctrl+click when opening links to open in a new tab")

layer = st.radio(
    label="",
    options=options,
)

# Create map
pipe_map = folium.Map(location=[65.31299392820134, -148.2802451266079], zoom_start=4)

# Load pipe coordinates and draw them
coordinates = get_lines(kml_url)

for c in coordinates:
    folium.PolyLine(
        locations=c,
        color="#00FF00",
        weight=5,
        tooltip="TAPS",
    ).add_to(pipe_map)

# Load pump station coordinates from data model
markers = get_pump_stations()

if not markers:
    st.warning("No pump stations found in the data model.")
else:
    if layer == options[1]:
        #kw = {"prefix": "fa", "color": "green", "icon": "arrow-up"}
        kw = {"prefix": "fa", "color": "green", "icon": "toolbox"}
        #kw = {"color": "green"}
        for name, data in markers.items():
            number = get_work_order_count(markers[name]["asset"])
            folium.Marker(
                markers[name]["coordinates"][::-1], 
                tooltip=name,
        #        icon=folium.Icon(**kw),
                icon=folium.DivIcon(
                    html=f"""
                        <div style="font-size: 12pt; color: black; background-color: white; 
                            border-radius: 50%; width: 24px; height: 24px;
                            text-align: center; line-height: 24px;">
                            {number}
                        </div>
                        """
                    ),
                popup=pump_popup(name, markers[name]["asset"]),
            ).add_to(pipe_map)
    else:
        for name, data in markers.items():
            canvas = False
            if "8" in name:
                kw = {"prefix": "fa", "color": "red", "icon": "toolbox"}
                canvas = True          
            else:
                kw = {"prefix": "fa", "color": "green", "icon": "toolbox"}
            folium.Marker(
                markers[name]["coordinates"][::-1], 
                tooltip=name,
                icon=folium.Icon(**kw),
                popup=pump_popup(name, markers[name]["asset"], canvas),
            ).add_to(pipe_map)      

st.components.v1.html(folium.Figure().add_child(pipe_map).render(), height=750)