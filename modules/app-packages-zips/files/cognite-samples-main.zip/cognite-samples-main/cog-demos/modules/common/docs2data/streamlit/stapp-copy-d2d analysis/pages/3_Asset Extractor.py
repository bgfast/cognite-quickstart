import streamlit as st
import pandas as pd
import io
from typing import List, Dict, Any
from cognite.client import CogniteClient
from cognite.client.data_classes.data_sets import DataSet
from cognite.client.data_classes.files import FileMetadata
from cognite.client.data_classes.contextualization import (
    FileReference, 
    DiagramDetectConfig, 
    ConnectionFlags, 
    DirectionWeights
)
from cognite.client.data_classes import filters
from cognite.client.data_classes.documents import DocumentProperty
from PIL import Image
import plotly.graph_objects as go

class AssetTagExtractor:
    def __init__(self, client: CogniteClient):
        self.client = client
        # Set API subversion for diagram detection
        self.client.config.api_subversion = "20230101-beta"
    
    def get_datasets(self) -> List[DataSet]:
        """Get all available datasets"""
        datasets = self.client.data_sets.list(limit=None)
        return sorted(datasets, key=lambda d: d.name.lower())
    
    def get_files_in_dataset(self, dataset_id: int) -> List[FileMetadata]:
        """Get all files in a specific dataset"""
        files = self.client.files.list(data_set_ids=[dataset_id], limit=None)
        return sorted(files, key=lambda f: f.name.lower())
    
    def create_asset_tag_patterns(self) -> List[Dict[str, str]]:
        """
        Create patterns to match asset tags like:
        17D-E107, 35F-105, 12D123, 72-F003
        """
        patterns = [
            # Pattern: NN[A]-[A]NNN (like 17D-E107, 35F-105)
            {'sample': '00A-A000'},
            {'sample': '0A-A000'},

            # Pattern: NNANNN (like 12D123)
            {'sample': '00A000'},
            
            # Pattern: NN-ANNN (like 72-F003)
            {'sample': '00-A000'},
            
            # Additional common patterns
            {'sample': '0A-A000'},
            {'sample': '0A-000'},
            {'sample': '0A000'}
        ]
        return patterns
    
    def get_page_count(self, file_id: int) -> int:
        """Get the number of pages in a document"""
        try:
            doc_filter = filters.Equals(DocumentProperty.id, file_id)
            documents = self.client.documents.list(filter=doc_filter)
            if documents and documents[0]:
                return documents[0].page_count
            return 1
        except Exception:
            return 1
    
    def extract_asset_tags(self, file_id: int, page_count: int = None) -> List[Dict[str, Any]]:
        """
        Extract asset tags from a file using diagram detection
        """
        if not page_count:
            page_count = self.get_page_count(file_id)
        
        # Create patterns for asset tag matching
        entities = self.create_asset_tag_patterns()
        
        # Configure diagram detection
        config = DiagramDetectConfig(
            remove_leading_zeros=False,  # Keep leading zeros in asset tags
            read_embedded_text=True,     # Read text from document
            connection_flags=ConnectionFlags(
                no_text_inbetween=True,
                natural_reading_order=False,  # Allow vertical text
            ),
            direction_weights=DirectionWeights(left=2, right=1, up=1, down=3),
        )
        
        results = []
        step = 40  # Process pages in chunks
        
        try:
            for i in range(1, page_count + 1, step):
                first_page = i
                last_page = min(page_count, i + step - 1)
                
                file_ref = FileReference(
                    file_id=file_id, 
                    first_page=first_page, 
                    last_page=last_page
                )
                
                # Run diagram detection synchronously
                detect_job = self.client.diagrams.detect(
                    entities=entities,
                    pattern_mode=True,
                    file_references=file_ref,
                    configuration=config
                )
                
                # Get result synchronously
                result = detect_job.result
                results.append(result)
                
        except Exception as e:
            st.error(f"Error during asset tag extraction: {str(e)}")
            return []
        
        return results
    
    def render_preview_with_annotations(self, file_id: int, annotations: List[Dict[str, Any]], page_number: int = 1):
        """Render file preview with detected asset tags highlighted for a specific page"""
        try:
            # Get document
            doc_filter = filters.Equals(DocumentProperty.id, file_id)
            documents = self.client.documents.list(filter=doc_filter)
            if not documents:
                st.error("Document not found")
                return
            
            document = documents[0]
            
            # Download selected page as PNG
            png_bytes = self.client.documents.previews.download_page_as_png_bytes(
                id=document.id, page_number=page_number
            )
            
            # Load image
            img = Image.open(io.BytesIO(png_bytes))
            w, h = img.size
            
            # Create Plotly figure
            fig = go.Figure()
            fig.add_layout_image(
                dict(source=img, xref="x", yref="y", x=0, y=h, sizex=w, sizey=h, layer="below")
            )
            fig.update_xaxes(visible=False, range=[0, w])
            fig.update_yaxes(visible=False, range=[0, h], scaleanchor="x")
            
            # Add annotation boxes and hover points for the selected page only
            if annotations:
                shapes = []
                centers_x, centers_y, hover_texts = [], [], []
                
                for result in annotations:
                    if result and result.get("items"):
                        for item in result["items"]:
                            for ann in item.get("annotations", []):
                                ann_page = ann.get("region", {}).get("page", 1)
                                if ann_page != page_number:
                                    continue  # Skip annotations not on selected page
                                
                                text = ann["text"]
                                
                                # Get coordinates from region vertices
                                if "region" in ann and "vertices" in ann["region"]:
                                    vertices = ann["region"]["vertices"]
                                    x_coords = [v["x"] for v in vertices]
                                    y_coords = [v["y"] for v in vertices]
                                    
                                    x_min, x_max = min(x_coords), max(x_coords)
                                    y_min, y_max = min(y_coords), max(y_coords)
                                    
                                    # Convert to pixel coordinates
                                    x0 = x_min * w
                                    x1 = x_max * w
                                    y0 = h - y_max * h  # Flip Y coordinate
                                    y1 = h - y_min * h
                                    
                                    # Add rectangle shape
                                    shapes.append({
                                        "type": "rect",
                                        "x0": x0, "y0": y0,
                                        "x1": x1, "y1": y1,
                                        "line": {"color": "red", "width": 2},
                                        "fillcolor": "rgba(255,0,0,0.1)"
                                    })
                                    
                                    # Add hover point
                                    centers_x.append((x0 + x1) / 2)
                                    centers_y.append((y0 + y1) / 2)
                                    hover_texts.append(f"Asset Tag: {text}")
                
                # Apply shapes and hover points to figure
                fig.update_layout(shapes=shapes)
                
                if centers_x:
                    fig.add_trace(go.Scattergl(
                        x=centers_x, y=centers_y,
                        mode="markers",
                        marker={"size": 8, "color": "red", "opacity": 0.7},
                        hoverinfo="text",
                        hovertext=hover_texts,
                        showlegend=False,
                        name="Asset Tags"
                    ))
            
            # Display the chart
            st.plotly_chart(fig, use_container_width=True)
            
        except Exception as e:
            st.error(f"Error rendering preview: {str(e)}")


def main():
    
    st.set_page_config(
        page_title="Asset Tag Extractor",
        page_icon="🏷️",
        layout="wide"
    )
    with st.container():
        st.markdown(
            f"""
            <div style="display: flex; justify-content: center;">
                <img src="https://mms.businesswire.com/media/20250519865188/en/2474150/5/cognite-tagline-horizontal_6.jpg?download=1&_gl=1*16caelh*_gcl_au*MTg1MTcxMzU0MS4xNzU0NTg2MzAy*_ga*MTEyNzQ1NDMxMy4xNzU0NTg2MzAz*_ga_ZQWF70T3FK*czE3NTQ1ODYzMDIkbzEkZzAkdDE3NTQ1ODYzMDIkajYwJGwwJGgw" width=300>
            </div>
            """,
            unsafe_allow_html=True
        )
    st.markdown("<h1 style='text-align: center;'>Docs2Data Auto-Analyzer</h1>", unsafe_allow_html=True)
    st.markdown("<p style='margin-top: -20px; font-style: italic; font-size: 18px; text-align: center;'>Powered by Cognite's Industrial Knowledge Graph</p>", unsafe_allow_html=True)
    st.markdown("---")
    # Initialize session state
    if 'annotations' not in st.session_state:
        st.session_state['annotations'] = None
    if 'page_count' not in st.session_state:
        st.session_state['page_count'] = None
    
    st.header("3. Asset Tag Extractor")
    
    # Initialize client
    try:
        client = CogniteClient()
        extractor = AssetTagExtractor(client)
    except Exception as e:
        st.error(f"Failed to connect to Cognite: {str(e)}")
        return
    
    # Step 1: Dataset Selection
    datasets = extractor.get_datasets()
    
    if not datasets:
        st.warning("No datasets found")
        return
    
    selected_dataset = st.selectbox(
        "Choose a dataset:",
        datasets,
        format_func=lambda d: f"{d.name}",
        key="dataset_selector"
    )
    
    if not selected_dataset:
        st.info("Please select a dataset to continue")
        return
    
    # Step 2: File Selection
    with st.spinner("Loading files..."):
        files = extractor.get_files_in_dataset(selected_dataset.id)
    
    if not files:
        st.warning(f"No files found in dataset '{selected_dataset.name}'")
        return
    
    selected_file = st.selectbox(
        "Choose a file:",
        files,
        format_func=lambda f: f"{f.name} ({f.mime_type})",
        key="file_selector"
    )
    
    if not selected_file:
        st.info("Please select a file to continue")
        return
    
    # Step 3: Extract Asset Tags
    #st.header("3. Extract Asset Tags")
    
    if st.session_state['annotations'] is None:
        analyze_col1, analyze_col2, analyze_col3 = st.columns([1, 1, 1])
        with analyze_col2:
            extract_clicked = st.button("🔍 Extract Asset Tags", type="primary", use_container_width=True)
        
        if extract_clicked:
            with st.spinner("Extracting asset tags..."):
                # Get page count first
                page_count = extractor.get_page_count(selected_file.id)
                st.info(f"Document has {page_count} page(s)")
                
                # Extract asset tags
                annotations = extractor.extract_asset_tags(selected_file.id, page_count)
                
                # Store in session state
                st.session_state['annotations'] = annotations
                st.session_state['page_count'] = page_count
                
                st.rerun()  # Force rerun to display results
    else:
        # Use stored values
        annotations = st.session_state['annotations']
        page_count = st.session_state['page_count']
        
        if annotations:
            # Parse and display results
            asset_tags = []
            for result in annotations:
                if result and result.get("items"):
                    for item in result["items"]:
                        for ann in item.get("annotations", []):
                            asset_tags.append({
                                "Asset Tag": ann["text"],
                                "Confidence": round(ann.get("confidence", 0), 3),
                                "Page": ann.get("region", {}).get("page", 1)
                            })
            
            if asset_tags:
                st.success(f"Found {len(asset_tags)} asset tags!")
                
                # Display results table
                df = pd.DataFrame(asset_tags)
                st.dataframe(df, use_container_width=True)
                
                # Page selector for preview
                preview_page = st.number_input(
                    "Select page for preview",
                    min_value=1,
                    max_value=page_count,
                    value=1,
                    step=1
                )
                
                # Display preview with annotations
                st.subheader(f"Document Preview (Page {preview_page}) with Detected Tags:")
                extractor.render_preview_with_annotations(selected_file.id, annotations, preview_page)
                
                # Show raw results in expandable section
                with st.expander("View Raw Detection Results"):
                    st.json(annotations)
                
            else:
                st.warning("No asset tags found matching the specified patterns")
        else:
            st.error("Failed to extract asset tags")
        
        # Reset button
        if st.button("Reset and Extract Again"):
            st.session_state['annotations'] = None
            st.session_state['page_count'] = None
            st.rerun()


if __name__ == "__main__":
    main()
