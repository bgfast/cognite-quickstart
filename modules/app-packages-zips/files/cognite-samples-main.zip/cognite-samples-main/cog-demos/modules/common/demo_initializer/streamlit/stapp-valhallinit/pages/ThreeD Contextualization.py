import streamlit as st
from cognite.client import CogniteClient
from cognite.client.exceptions import CogniteAPIError
import json

# Function to get 3D models
def get_3d_models(client):
    try:
        # Get all 3D models
        models = client.three_d.models.list()
        # Filter out models that have a dataset_id (keep only those where dataset_id is None)
        filtered_models = [model for model in models if model.data_set_id is None]
        return filtered_models
    except CogniteAPIError as e:
        st.error(f"Error fetching 3D models: {str(e)}")
        return []

# Function to get latest revision for a model
def get_latest_revision(client, model_id):
    try:
        # Remove sort parameter and get all revisions
        revisions = client.three_d.revisions.list(model_id=model_id, published=True, limit=100)  # Adjust limit as needed
        if not revisions:
            return None
        # Sort revisions manually by created_time
        sorted_revisions = sorted(revisions, key=lambda x: x.created_time, reverse=True)
        return sorted_revisions[0]  # Return the most recent revision
    except CogniteAPIError as e:
        st.error(f"Error fetching revisions: {str(e)}")
        return None

# Function to call the Cognite Function
def call_three_d_annotations_valhall(client, data):
    try:
        # Replace 'three_d_annotations_valhall' with your actual function name if different
        function_call = client.functions.call(
            external_id="3d_annotations_valhall",  # Function name in CDF
            data=data
        )
        return function_call
    except CogniteAPIError as e:
        st.error(f"Error calling function: {str(e)}")
        return None
# Main Streamlit app
def main():
    st.title("Execute 3D Annotation Function")
    
    # Initialize client
    try:
        client = CogniteClient()
    except Exception as e:
        st.error(f"Failed to initialize Cognite client: {str(e)}")
        return

    # Get 3D models
    models = get_3d_models(client)
    
    if not models:
        st.warning("No 3D models found or error occurred")
        return

    # Create model selection dropdown
    model_names = [model.name for model in models if model.name]
    selected_model_name = st.selectbox("Select a 3D Model", model_names)
    
    # Get selected model details
    selected_model = next((m for m in models if m.name == selected_model_name), None)
    
    if selected_model:
        
        # Get and display latest revision
        latest_revision = get_latest_revision(client, selected_model.id)
        
        if latest_revision:
             
            # Prepare data for annotation function
            annotation_data = {
                "model_id": str(selected_model.id),
                "revision_id": str(latest_revision.id),
                "asset_space": "valhall-assets",
                "three_d_space": "valhall-three_d"
            }
            
            # Show data preview
            st.subheader("Annotation Data Preview")
            st.json(annotation_data)
            
            if st.button("Run 3D Annotations"):
                with st.spinner("Processing annotations..."):
                    function_call = call_three_d_annotations_valhall(client, annotation_data)
                    if function_call:
                        # Wait for function to complete (optional)
                        function_call.wait_for_completion()
                        st.success("Annotation processing completed!")
                        st.write("Function Call ID:", function_call.id)
                        st.write("Status:", function_call.status)
                        # If you want to display the response
                        if function_call.status == "Completed":
                            result = function_call.get_response()
                            st.write("Result:")
                            st.json(result)
                    else:
                        st.error("Function call failed")
        else:
            st.warning("No published revisions found for this model")
    else:
        st.error("Selected model not found")

if __name__ == "__main__":
    # Streamlit app configuration
    st.set_page_config(
        page_title="3D Model Annotation App",
        page_icon="📊",
        layout="wide"
    )
    main()