from cognite.client import CogniteClient
from cognite.client.data_classes.data_modeling import ViewId
import streamlit as st
import io
import requests
import xml.etree.ElementTree as ET
import folium
from folium import plugins

def parse_coordinates(coordinates_text):
    # Split by spaces to get individual coordinate groups
    coordinate_groups = coordinates_text.strip().split()
    
    # Convert each group into a tuple of floats (longitude, latitude)
    coordinates_list = [
        tuple(map(float, group.split(',')))[::-1]
        for group in coordinate_groups
    ]
    
    return coordinates_list

@st.cache_data
def get_lines(url):
    response = requests.get(url)
    response.raise_for_status()
    file_bytes = response.content
    kml_file = io.BytesIO(file_bytes)
    tree = ET.parse(kml_file)
    root = tree.getroot()
    namespace = {"kml": "http://www.opengis.net/kml/2.2"}
    points = []
    # Loop through each Placemark element
    #for placemark in root.findall(".//Placemark"):
    for coordinates in root.findall(".//kml:LineString/kml:coordinates", namespaces=namespace):
        # Extract coordinates from the coordinates element
        coordinates_text = coordinates.text.strip() if coordinates is not None else "No coordinates"
        points.append(parse_coordinates(coordinates_text))
    
    return points

@st.cache_data
def get_work_order_count(ext_id: str):
    client = CogniteClient()
    
    # Use data modeling API with MaintenanceOrder view
    view_id = ViewId(space="verdantix-demo", external_id="MaintenanceOrder", version="feecb9633c537c")
    
    # Query maintenance orders that reference the given asset external ID
    # The "assets" property is a list, so we need to check if our asset is in that list
    try:
        maintenance_orders = client.data_modeling.instances.list(
            sources=[view_id],
            space="verdantix-demo",
            filter={
                "containsAny": {
                    "property": ["verdantix-demo", "MaintenanceOrder/feecb9633c537c", "assets"],
                    "values": [{"space": "valhall-assets", "externalId": ext_id}]
                }
            },
            limit=None
        )
        return len(maintenance_orders)
    except Exception as e:
        # Log the error and return 0
        st.warning(f"Could not retrieve work orders for asset {ext_id}: {e}")
        return 0

@st.cache_data
def get_search_url(ext_id: str):
    client = CogniteClient()
    
    # Get the project name and cluster dynamically from the client configuration
    project_name = client.config.project
    cluster = client.config.base_url.replace("https://", "").replace("/", "")
    
    # Define the PumpStation view
    pump_station_view = ViewId(space="verdantix-demo", external_id="PumpStation", version="v2")
    
    return f"https://cog-demos.fusion.cognite.com/{project_name}/search/asset/verdantix-demo/v2/PumpStation/valhall-assets/{ext_id}?cluster={cluster}&workspace=industrial-tools"

@st.cache_data
def pump_popup(name: str, ext_id: str, canvas: bool=False):
    wo_count = get_work_order_count(ext_id)
    
    # Get dynamic project name and cluster
    client = CogniteClient()
    project_name = client.config.project
    cluster = client.config.base_url.replace("https://", "").replace("/", "")
    
    url = f"https://cog-demos.fusion.cognite.com/{project_name}/industrial-canvas/canvas?canvasId=dce69302-ccb5-49f0-92c1-86f3675fb121&cluster={cluster}&workspace=industrial-tools"
    canvas_anchor = "<a href='" + url + "'>Open relevant data</a>" if canvas else ""
    return folium.Popup(
                "<b>Location:</b><br>" + name + "<br>"
                "<b>Open work orders:</b><br>" + str(wo_count) + "<br>"
                "<b><a href='" + get_search_url(ext_id) + "'>Open asset</a></b><br>"
                "<b>" + canvas_anchor + "</b>",
                max_width=450,
          )