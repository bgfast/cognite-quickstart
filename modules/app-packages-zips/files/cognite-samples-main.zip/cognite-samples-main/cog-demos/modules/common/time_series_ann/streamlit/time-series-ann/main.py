import streamlit as st
from cognite.client import CogniteClient
import pandas as pd
import altair as alt
from datetime import datetime, timedelta

# Initialize the CogniteClient
client = CogniteClient()

# constants
domain = "cog-demos"
project = client.config.project
base_url = client.config.base_url

# Streamlit UI
st.title("Timeseries Annotation Widget")

# Function to search assets dynamically
def search_assets(query):
    if query:
        return client.assets.search(query=query, limit=10)
    return []

# Create an input field and update selectbox based on query
search_query = st.text_input("Search for an Asset", "")

# Always display asset and time series selectors side by side
col1, col2 = st.columns(2)

# Dynamically search for assets based on user input
assets = search_assets(search_query)

# Prepare asset and time series dropdowns, even if empty
asset_options = {}
selected_asset_name = ""
selected_asset_id = None
time_series_options = {}
selected_time_series_name = ""
selected_time_series_id = None

if assets:
    asset_options = {asset.name: asset.id for asset in assets}

# Asset selection dropdown
with col1:
    selected_asset_name = st.selectbox("Select an Asset", list(asset_options.keys()) if asset_options else ["No assets found"])
    if selected_asset_name in asset_options:
        selected_asset_id = asset_options[selected_asset_name]

# Time series selection dropdown
with col2:
    if selected_asset_id:
        time_series = client.time_series.list(asset_ids=[selected_asset_id], limit=10)
        if time_series:
            time_series_options = {ts.name: ts.id for ts in time_series}
    selected_time_series_name = st.selectbox("Select a Time Series", list(time_series_options.keys()) if time_series_options else ["No time series available"])
    if selected_time_series_name in time_series_options:
        selected_time_series_id = time_series_options[selected_time_series_name]

# Default date range for the chart (today for both start and end)
default_date = datetime.now().date()
start_date_selected = default_date
end_date_selected = default_date

# Time window selection with sliders
st.markdown("---")
if selected_time_series_id:
    # Retrieve the time series data
    datapoints = client.time_series.data.retrieve(id=selected_time_series_id, granularity="1d", aggregates=["average"])

    # Convert to pandas DataFrame
    df = datapoints.to_pandas()

    if not df.empty:
        df.rename(columns={df.keys()[0]: selected_time_series_name}, inplace=True)

        # Get the earliest and latest timestamps from the data
        min_time = df.index.min().to_pydatetime().date()
        max_time = df.index.max().to_pydatetime().date()

        st.markdown("#### Select Start and End Date")

        start_date_selected = st.slider("Start Date", min_value=min_time, max_value=max_time, value=min_time)

        end_date_selected = st.slider("End Date", min_value=min_time, max_value=max_time, value=max_time)

        # Ensure end date is not earlier than start date
        if end_date_selected < start_date_selected:
            st.error("End Date cannot be earlier than Start Date. Please adjust the date range.")
            end_date_selected = start_date_selected

        # Convert selected dates to datetime objects
        start_time_selected = datetime.combine(start_date_selected, datetime.min.time())
        end_time_selected = datetime.combine(end_date_selected, datetime.min.time())

        # Plot the time series with Altair
        escaped_time_series_name = selected_time_series_name.replace(":", "\\:")

        base_chart = alt.Chart(df.reset_index()).mark_line().encode(
            x='index:T',  # Use 'index' (timestamp) from the DataFrame
            y=f'{escaped_time_series_name}:Q'  # Escape the colon in the column name
        )

        # Create vertical lines for start and end times
        start_line = alt.Chart(pd.DataFrame({'time': [start_time_selected]})).mark_rule(color='green').encode(
            x='time:T'
        )
        end_line = alt.Chart(pd.DataFrame({'time': [end_time_selected]})).mark_rule(color='red').encode(
            x='time:T'
        )

        # Create a filled area between start and end times
        filled_area = alt.Chart(pd.DataFrame({
            'start': [start_time_selected],
            'end': [end_time_selected]
        })).mark_rect(color='lightgrey', opacity=0.5).encode(
            x='start:T',
            x2='end:T'
        )

        # Combine the time series plot with the vertical lines and add interactivity
        final_chart = (base_chart + start_line + end_line + filled_area).interactive()

        # Render the combined chart
        st.altair_chart(final_chart, use_container_width=True)
    else:
        st.write("No data available for the selected time series.")

# --- Event Creation Section (Always Visible) ---
st.markdown("---")
st.subheader("Time series Annotation")

# Collect additional event information
event_description = st.text_area("Event Description", "")

col5, col6 = st.columns(2)

with col5:
    event_type = st.text_input("Event Type", "")
with col6:
    event_subtype = st.text_input("Event Subtype", "")
metadata = st.text_area("Metadata (key=value format, one per line)", "")

# Parse metadata input into a dictionary
metadata_dict = {}
if metadata:
    metadata_lines = metadata.split("\n")
    for line in metadata_lines:
        if "=" in line:
            key, value = line.split("=", 1)
            metadata_dict[key.strip()] = value.strip()

# Create the event payload
def create_event():
    event = {
        "description": event_description,
        "startTime": int(start_time_selected.timestamp() * 1000) if selected_time_series_id else None,  # Corrected to startTime
        "endTime": int(end_time_selected.timestamp() * 1000) if selected_time_series_id else None,  # Corrected to endTime
        "type": event_type,
        "subtype": event_subtype,
        "source": "manual entry",
        "assetIds": [selected_asset_id] if selected_asset_id else None,
        "metadata": metadata_dict
    }
    return client.events.create(event)

# Save Event Button
if st.button("Save Event"):
    if event_description and event_type and selected_asset_id and selected_time_series_id:
        response = create_event()
        event_id = response.id
        st.success(f"Event created successfully with ID: {event_id}")

        # Provide a link to the created event
        event_link = f"https://{domain}.fusion.cognite.com/{project}/explore/search/asset?cluster={base_url}&journey=asset-{selected_asset_id}%7Eevent-{event_id}-event&workspace=data-management"
        st.markdown(f"[View Event]({event_link})")
    else:
        st.error("Please provide all necessary information to create an event.")
