# ⛽ Oil Refinery Trading Dashboard - Demo Script
**Duration: 8-10 minutes | Expanded Business Value Story**

---

## 👥 **PERSONAS**

**🎯 CARLOS MARTINEZ** - Senior Refined Products Trader  
*16 years experience at RefineCorp Global, manages $250M refined products portfolio*  
*Specializes in gasoline, diesel, and jet fuel trading across North American markets*  
*Known for his expertise in crack spread optimization and seasonal demand patterns*  
*Currently under pressure to improve refining margins by 22% amid volatile crude costs*

**⚙️ JENNIFER WONG** - Refinery Operations Manager  
*13 years experience, oversees 5 refinery complexes across Texas, Louisiana, and California*  
*Former process engineer with expertise in crude distillation and catalytic cracking*  
*Responsible for $60M in annual refinery optimization initiatives*  
*Leading digital initiatives to improve crude-to-products yield optimization*

---

## 🌅 **SETTING THE SCENE**
*It's 7:15 AM on a Thursday morning at RefineCorp's Denver trading center. Carlos is monitoring refined product futures that opened higher on inventory concerns, while Brent crude is volatile due to OPEC production uncertainties. Jennifer is at the central operations center coordinating multiple Gulf Coast and West Coast refineries. Carlos has significant exposure to gasoline and diesel contracts with delivery commitments to major fuel distributors.*

---

## 🎬 **SCENE 1: The Crisis Unfolds (0:00 - 2:00)**

**CARLOS** *(monitoring multiple screens with product curves, crack spreads, and inventory reports)*  
"Jennifer, we've got a serious margin squeeze developing. Brent crude spiked $3.50 overnight on supply concerns, but gasoline futures are only up $2.20. My crack spreads are getting crushed, and I've got major distributors expecting 40,000 barrels of gasoline and 25,000 barrels of diesel over the next two weeks."

**JENNIFER** *(video call from refinery control room, with process unit displays in background)*  
"I saw the crude price jump on my morning alerts. What's your current exposure?"

**CARLOS** *(rapidly switching between trading positions)*  
"We're long crude and short products - basically betting on strong refining margins. But if crude costs keep climbing faster than product prices, and we can't maximize our yields, we're looking at potentially $3 million in margin compression. I need to know RIGHT NOW - are our crude units running at maximum throughput? Any coker problems? Any catalyst issues affecting yields?"

**JENNIFER** *(reviewing multiple refinery status screens)*  
"Carlos, here's the challenge - I got a 6 AM call from our Texas City refinery about crude distillation unit issues. Our Long Beach facility mentioned something about catalytic cracker catalyst deactivation. The Baton Rouge refinery had a delayed restart from maintenance, but I'm still getting updated timing from the unit supervisors."

**CARLOS** *(voice escalating with market urgency)*  
"Jennifer, this information lag is killing our profitability! While you're collecting status reports from five different refineries, gasoline crack spreads are moving 10 cents per gallon. Every minute of uncertainty about our production capacity could cost us hundreds of thousands. If our yields are compromised, I need to start adjusting my product positions NOW, but I don't know by how much!"

**JENNIFER** *(looking overwhelmed)*  
"I completely understand the urgency, Carlos. By the time I coordinate with each refinery manager, review their shift reports, and calculate our actual product yields, the trading window has closed. But I think we might have a breakthrough solution that could transform how we coordinate refinery operations with your trading strategies..."

**CARLOS**  
"With crude this volatile and margins this tight, I'm desperate for anything that gives us better coordination. Show me what you've got."

---

## 🎬 **SCENE 2: The Game-Changing Solution (2:00 - 3:30)**

**JENNIFER** *(screen sharing the refinery dashboard)*  
"Carlos, I want to introduce our new Oil Refinery Trading Dashboard. We've been piloting this for two months, and it's specifically engineered to bridge the gap between complex refinery operations and your fast-paced product trading decisions."

**CARLOS** *(skeptically)*  
"Jennifer, I've seen countless refinery dashboards. They typically show me pretty process diagrams of yesterday's yields when I need to make real-time decisions on volatile product markets. What makes this one different?"

**JENNIFER** *(highlighting real-time alerts)*  
"Look at this critical alert section - instead of me making sequential calls to five refineries, everything aggregates in real-time. See this red alert? Crude Distillation Unit 2 at Texas City reduced throughput 34 minutes ago due to heat exchanger fouling. The system automatically calculated this reduces our gasoline production by 2,800 barrels per day."

**CARLOS** *(leaning in)*  
"That's more current than anything I typically receive. But Carlos the trader doesn't care about heat exchanger fouling - I care about whether I can meet my product delivery commitments and how much gasoline I need to source from other suppliers."

**JENNIFER** *(clicking to Quantified Impact Analysis)*  
"This is the game-changer, Carlos. The system doesn't just report equipment problems - it automatically translates refinery disruptions into trading recommendations. Look at this analysis: based on current operational issues across all our refineries, we're going to be short 15,000 barrels of gasoline and 8,000 barrels of diesel over the next two weeks."

**CARLOS** *(eyes lighting up)*  
"Wait, it's calculating my product shortfall automatically? Instead of me trying to estimate yields from scattered refinery reports?"

**JENNIFER**  
"Exactly! And here's the trading recommendation: 'BUY 15,000 BBL GASOLINE, BUY 8,000 BBL DIESEL.' The system is providing precise trading guidance based on real refinery capacity. No more yield guesswork."

**CARLOS** *(pointing at screen)*  
"This could revolutionize our operations! But how do I trust these calculations? What if the system overestimates our shortfall?"

**JENNIFER**  
"Excellent question. Let me show you the underlying data and our validation methodology..."

---

## 🎬 **SCENE 3: Deep Dive - Proving the Value (3:30 - 5:30)**

**JENNIFER** *(scrolling to equipment monitoring)*  
"Here's how we ensure accuracy. This equipment monitoring section shows the top 5 operational issues across all refineries. Each critical unit has real-time sensors feeding data to the system. See this catalytic cracker at Long Beach? It's been operating at 80% capacity for 4 hours due to catalyst deactivation, with an estimated 8-hour regeneration cycle. The system calculates this reduces our gasoline yield by 1,200 barrels per day."

**CARLOS** *(studying the detailed interface)*  
"This operational transparency is incredible. Instead of waiting for your 9 AM production briefing, I can see yield impacts the moment they develop. But what about market context? I need to understand how current production compares to seasonal patterns and planned maintenance."

**JENNIFER** *(switching to Production Analytics)*  
"That's exactly what this forecasting section addresses. Here's our 30-day production forecast with seasonal demand patterns and planned turnaround schedules. You can see we typically experience 25% yield reduction in October due to major maintenance across our Gulf Coast refineries."

**CARLOS** *(examining trend analysis)*  
"The month-to-date versus rolling average comparison is brilliant! I can immediately spot when we're deviating from normal production patterns. This shows we're currently 15% below our 30-day gasoline yield average - that's actionable intelligence I can use to adjust my crack spread positions."

**JENNIFER** *(navigating to inquiry system)*  
"And here's something that will improve our communication efficiency. Instead of urgent calls interrupting refinery operations, you can submit structured inquiries with priority levels and receive tracked responses."

**CARLOS** *(testing the inquiry interface)*  
"So if I need exact timing on that Texas City crude unit repair, I can submit a high-priority inquiry and get documented responses instead of playing phone tag with multiple refinery supervisors?"

**JENNIFER**  
"Exactly! It builds an institutional knowledge base. When similar equipment issues arise, we can reference previous incidents and response patterns. It systematizes our crisis communication protocols."

**CARLOS** *(leaning back)*  
"Jennifer, I'm starting to see how this transforms our entire trading operation. Let me explain what this means from a margin optimization perspective..."

---

## 🎬 **SCENE 4: The Business Case - Real ROI Stories (5:30 - 7:30)**

**CARLOS** *(standing, gesturing toward market displays)*  
"Jennifer, let me quantify this with a real example. Remember the diesel shortage crisis ten weeks ago? Our Baton Rouge refinery had that unexpected hydrocracker shutdown, and it took us 5 hours to understand the full yield impact. By the time I realized we were going to be short 12,000 barrels on our diesel commitments, ultra-low sulfur diesel prices had already spiked 18 cents. We ended up paying $2.1 million more than necessary to source replacement barrels."

**JENNIFER** *(nodding with recognition)*  
"I remember that crisis. I was coordinating with three different unit operators, trying to calculate exact yield losses while managing the shutdown sequence and restart planning..."

**CARLOS**  
"With this dashboard, I would have seen that hydrocracker problem within minutes, not hours. The system would have immediately calculated our diesel shortfall and recommended covering positions. I could have secured diesel at pre-spike prices. That's over $2 million in avoided losses from one incident."

**JENNIFER**  
"And from my operational perspective, instead of spending 2-3 hours every morning aggregating yield reports, calculating product balances, and briefing your trading team, I can focus on optimizing actual refinery performance. The dashboard automates all that data compilation and analysis."

**CARLOS** *(pointing to customization options)*  
"I love how I can tailor views for my specific trading portfolio. See this? I can focus exclusively on gasoline, diesel, and jet fuel without getting overwhelmed by information about products I don't actively trade. It's like having a personalized command center for refined product markets."

**JENNIFER**  
"Plus, the incident tracking helps us identify recurring operational problems. Look at this historical data - Heat Exchanger Bank C at Texas City has fouled six times in three months. That pattern indicates we need different crude blending or cleaning protocols, not just reactive maintenance."

**CARLOS** *(getting excited)*  
"Jennifer, this completely transforms our competitive advantage. While our competitors are still making trading decisions based on yesterday's yield reports, we're operating with real-time refinery intelligence. The quantified impact analysis - having the system calculate exactly how many barrels of each product to buy or sell - that's like having an algorithmic assistant for physical oil trading."

**JENNIFER**  
"And think about the cascading benefits. Better trading decisions improve our refining margins, which provides more capital for yield optimization projects, which reduces operational variability, which improves our production predictability..."

**CARLOS**  
"It creates a virtuous cycle! But here's what really excites me - we're shifting from reactive crisis management to proactive market positioning. Instead of scrambling to cover product shortfalls after they happen, we can anticipate yield constraints and position ourselves advantageously in the market."

**JENNIFER**  
"Exactly. We've compressed our information cycle from hours to minutes, eliminated miscommunication between refinery operations and trading, and most importantly, we're making faster, better-informed decisions than our competition."

---

## 🎯 **KEY BUSINESS BENEFITS HIGHLIGHTED**

### **💰 Financial Impact**
- **Avoided Losses**: $2.1M+ per incident through faster reaction times
- **Optimized Product Sourcing**: Real-time buy/sell recommendations based on refinery yields
- **Improved Crack Spreads**: Immediate visibility enables superior margin management

### **⏱️ Operational Efficiency**
- **Time Savings**: 2-3 hours daily reporting → Real-time dashboard visibility
- **Faster Decisions**: Hours → Minutes for critical trading decisions
- **Systematic Communication**: Structured inquiries replace urgent operational interruptions

### **📊 Strategic Advantages**
- **Proactive Trading**: Shift from reactive to predictive decision-making
- **Risk Mitigation**: Early warning system for yield disruptions
- **Data-Driven Insights**: Historical patterns inform future capacity planning

---

## 🎪 **DEMO FLOW SUMMARY**

1. **Problem Setup** - Traditional challenges in refinery trading/operations coordination
2. **Solution Introduction** - Dashboard overview and core capabilities  
3. **Feature Deep-dive** - Real-time alerts, impact analysis, yield forecasting
4. **ROI Demonstration** - Concrete examples of cost avoidance and margin improvement
5. **Strategic Value** - Transformation from reactive to proactive operations

## 🎬 **SCENE 5: The Strategic Vision (7:30 - 8:30)**

**CARLOS** *(looking thoughtful)*  
"Jennifer, this isn't just about optimizing our current refining margins. This is about fundamentally changing our business model. With this real-time yield intelligence, we could offer customers guaranteed product delivery contracts with much higher confidence. We could even develop premium pricing for 'yield-guaranteed' supply agreements."

**JENNIFER**  
"That's a compelling strategic vision. Our fuel distributors are constantly asking for more predictable product supply. If we can demonstrate real-time visibility into our refinery yields and proactive disruption management..."

**CARLOS**  
"Exactly! And from a risk management perspective, this dashboard gives me the data I need to optimize our crack spread positions. Instead of over-hedging because I'm uncertain about refinery yields, I can maintain more precise positions and improve overall profitability."

**JENNIFER** *(checking mobile notifications)*  
"Speaking of which, I just received notification that our Long Beach catalytic cracker catalyst regeneration completed ahead of schedule. Without this system, you wouldn't have known that for hours."

**CARLOS** *(smiling)*  
"And now I can immediately adjust my afternoon gasoline positions! Jennifer, we need to roll this out to the entire refined products trading desk. When can we schedule training for my team?"

**JENNIFER**  
"I'll work with IT to provision access for your entire trading team by next week. And Carlos, thank you for helping me understand how operational visibility creates trading advantages I hadn't fully appreciated."

**CARLOS**  
"That's what true partnership looks like, Jennifer. Refinery operations and products trading working together with the right technology - that's how we maintain our competitive edge and deliver superior value to our customers."

---

## 📈 **EPILOGUE: Six Months Later**

*Six months after implementing the Oil Refinery Trading Dashboard, RefineCorp Global has:*

- **Reduced average response time** to yield disruptions from 3 hours to 12 minutes
- **Avoided $14.2M in losses** through proactive position management during refinery outages  
- **Improved refining margins by 22%** through better operations-trading coordination
- **Increased customer satisfaction scores by 30%** due to more reliable product deliveries
- **Reduced unplanned downtime by 18%** through better equipment monitoring and predictive maintenance
- **Established premium pricing** for guaranteed delivery contracts, generating $18M in additional annual revenue

*Carlos's trading team now consistently outperforms competitors by leveraging real-time refinery intelligence, while Jennifer's operations team has transformed from a cost center to a strategic profit driver.* 