# In-Development Streamlits Module Collection

This module contains a collection of trading dashboard streamlit applications that are currently in development.

## Overview

This parent module enables deployment of all streamlit applications contained in its subdirectories by referencing the single module path: `modules/common/in-development-streamlits`

## Included Streamlits

### 1. Petrochem Dashboard (`petrochem-dashboard/`)
- **Purpose**: Trading dashboard for petrochemical operations
- **Products**: Ethylene, Propylene, Butadiene, Benzene, Xylene, Polyethylene, Polypropylene
- **Trader Focus**: Automotive, Packaging, Construction, General
- **Streamlit ID**: `stapp-petrochem-dashboard`

### 2. Refinery Dashboard (`refinery-dashboard/`)
- **Purpose**: Trading dashboard for oil refinery operations  
- **Products**: Gasoline, Diesel, Jet Fuel, Heavy Fuel Oil, Naphtha, LPG, Lubricants
- **Trader Focus**: Transportation, Industrial, Marine/Aviation, General
- **Streamlit ID**: `stapp-refinery-dashboard`

### 3. Food & Beverage Dashboard (`food-beverage-dashboard/`)
- **Purpose**: Trading dashboard for food and beverage processing operations
- **Products**: Refined Sugar, Ethanol, Skim Milk Powder, Corn Starch, Wheat Flour, Soybean Oil
- **Trader Focus**: Food Processing, Beverage, Commodity Trading
- **Streamlit ID**: `stapp-food-beverage-dashboard`

### 4. Utilities Power Generation Dashboard (`utilities-dashboard/`)
- **Purpose**: Trading dashboard for power generation and utilities operations
- **Products**: Electricity (MWh), Natural Gas (MMBtu), Coal (tons)
- **Power Sources**: Natural Gas, Coal, Nuclear, Hydro, Wind, Solar, Biomass
- **Trader Focus**: Power Trading, Grid Operations, Energy Markets
- **Streamlit ID**: `stapp-utilities-dashboard`

### 5. Bulk Chemicals Dashboard (`bulk-chemicals-dashboard/`)
- **Purpose**: Trading dashboard for bulk chemical manufacturing operations
- **Products**: Ammonia, Methanol, Caustic Soda (NaOH), Sulfuric Acid, Urea
- **Trader Focus**: Nitrogen Products, Methanol, Caustics, Global Chemicals
- **Streamlit ID**: `stapp-bulk-chemicals-dashboard`

### 6. Pulp & Paper Mills Dashboard (`pulp-paper-dashboard/`)
- **Purpose**: Trading dashboard for pulp mills and paper manufacturing operations
- **Products**: Bleached Softwood Kraft (BSK) Pulp, Unbleached Kraft Paper, Newsprint, Coated Paperboard, Tissue Paper
- **Equipment**: Digesters, Paper Machines, De-inking Lines, Bleaching Towers, Recovery Boilers, Pulp Dryers
- **Trader Focus**: Kraft Pulp, Newsprint, Tissue, Multi-Product, Global Kraft
- **Streamlit ID**: `stapp-pulp-paper-dashboard`

### 7. Metals & Mining Dashboard (`metals-mining-dashboard/`)
- **Purpose**: Trading dashboard for smelters, refineries, mines, and steel mills
- **Products**: Copper (refined), Aluminum (primary), Nickel, Zinc, Iron Ore, Steel (Hot Rolled Coil)
- **Facilities**: Smelters, Refineries, Mines, Steel Mills, Processing Plants
- **Equipment**: Blast Furnaces, Smelters, Crushers, Rolling Mills, Flotation Cells, Electrolytic Cells
- **Trader Focus**: Base Metals, Steel & Iron, Aluminum, Precious Metals, Global Metals
- **Streamlit ID**: `stapp-metals-mining-dashboard`

## Usage

To deploy all streamlits in this collection, use the module path:
```
modules/common/in-development-streamlits
```

This will automatically deploy all streamlit applications contained in the subdirectories.

## Development Status

These applications are currently in development and serve as proof-of-concept dashboards for gathering feedback on features and data presentation. 