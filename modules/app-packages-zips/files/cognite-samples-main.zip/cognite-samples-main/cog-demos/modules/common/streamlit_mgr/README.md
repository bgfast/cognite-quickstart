# Streamlit Manager
This Streamlit app lets you send Streamlit applications directly from Cognite Data Fusion (CDF) to the `cognitedata/cognite-samples` GitHub repository. It simplifies the process of turning your Streamlits into toolkit modules—no knowledge of toolkit module structures required. The app converts your Streamlit code into `.py` and `.yaml` files, which you can then load into your preferred IDE and manage using GitHub as a version control system.
Type: Streamlit

## Features
- **Read Existing Modules**: Scans the `cog-demos/modules/` directory in the specified branch to list existing modules.
- **Update or Create Modules**: Choose an existing module to update or create a new one by entering a custom path (e.g., `common/mymodule`).
- **Field Validation**: Includes validation to ensure all required fields (app, branch, module, commit message) are valid before publishing.

## Usage
1. **Launch the App**: Deploy this Streamlit in your CDF environment (see deployment instructions in the root README).
2. **Select a Streamlit App**: Choose a Streamlit from CDF using the "Select Streamlit Application" dropdown.
3. **Enter Your GitHub PAT**: Provide a Personal Access Token (PAT) with repository write access under "GitHub Personal Access Token (PAT)".
4. **Specify a Branch**: Input an existing branch name (e.g., `my-branch`) under "Existing Branch Name". Wait up to 10 seconds for module options to load.
5. **Choose or Create a Module**: Select an existing module from the dropdown or pick "Create New..." and enter a new module name.
6. **Add a Commit Message**: Write a brief commit message describing your changes.
7. **Publish to GitHub**: Click "Publish to GitHub" to push your Streamlit as `.py` and `.yaml` files to the `cognitedata/cognite-samples` repo.

## Notes
- **GitHub PAT**: Required for authentication. Generate one with `repo` scope in your GitHub settings.
- **Branch Management**: Create and manage branches via the GitHub web UI at [https://github.com/cognitedata/cognite-samples/branches](https://github.com/cognitedata/cognite-samples/branches). The `main` branch is protected and cannot be used directly. Streamlit Manager will not create branches for you.
- **Target Repository**: Fixed to `cognitedata/cognite-samples` (this repository).
- **Deployment**: To redeploy this Streamlit Manager to your CDF environment, follow the instructions in the root README of this repository on deploying one module.

### Screenshot:
<img width="547" alt="Screenshot 2025-01-10 145344" src="https://github.com/user-attachments/assets/f33dde3c-5015-4862-a37e-e9bb5217c862"/>
