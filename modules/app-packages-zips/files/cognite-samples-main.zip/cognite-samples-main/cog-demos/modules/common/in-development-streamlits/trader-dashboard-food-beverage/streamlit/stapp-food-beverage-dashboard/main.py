import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import random
import os
import logging

# --- Demo Script Functionality ---
def load_demo_script():
    """Load the demo script from the markdown file with robust path resolution and fallback."""
    
    # Embedded fallback content for when file can't be loaded
    fallback_content = """
# 🌾 Food & Beverage Trading Dashboard - Demo Script
**Duration: 8-10 minutes | Business Value Story**

---

## 👥 **PERSONAS**

**🎯 SARAH CHEN** - Senior Commodity Trader  
*15 years experience at AgriCorp Global, manages $200M commodity portfolio*  
*Specializes in refined sugar, ethanol, and corn starch trading*  
*Known for her analytical approach and risk management expertise*  
*Currently under pressure to improve trading margins by 15% this year*

**⚙️ MARCUS RODRIGUEZ** - Operations Manager  
*12 years experience, oversees 6 processing facilities across North America*  
*Former plant engineer who understands both technical operations and business impact*  
*Responsible for $50M in annual production efficiency improvements*  
*Champion of digital transformation initiatives*

---

## 🌅 **SETTING THE SCENE**
*It's 7:45 AM on a Tuesday morning. Sarah is in her Chicago trading floor office, surrounded by multiple monitors showing commodity prices, weather patterns, and market news. Marcus is joining virtually from the control room at their largest processing facility in Iowa. The refined sugar market has been volatile due to weather concerns in Brazil, and Sarah's team is managing significant exposure.*

---

## 🎬 **SCENE 1: The Crisis Unfolds (0:00 - 2:00)**

**SARAH** *(frantically switching between screens, coffee cup in hand)*  
"Marcus, we have a serious situation developing. Brazilian sugar futures just spiked 8% overnight due to drought concerns, and my London counterpart is telling me European buyers are scrambling for supply. I've got three major food manufacturers expecting delivery of 15,000 metric tons of refined sugar over the next two weeks."

**MARCUS** *(video call from plant control room, machinery humming in background)*  
"I saw the market alerts this morning. What's your exposure looking like?"

**SARAH** *(pulling up trading positions)*  
"We're long 12,000 MT refined sugar at an average of $520/MT, but spot prices just hit $560. I need to know our production capacity and raw sugar inventory - can we fulfill these contracts and potentially capitalize on the price spike?"

---

## 📊 **SCENE 2: Dashboard Deep Dive (2:00 - 5:00)**

**MARCUS**  
"Let me show you our real-time processing operations using our integrated dashboard..."

### **Key Dashboard Interactions:**

1. **Enterprise-Wide Processing Overview**
   - Navigate to Enterprise-Wide view
   - Point out: 6 facilities, 8,500 MT/day total capacity
   - Current production: 7,200 MT/day (85% utilization)
   - Product mix: 60% refined sugar, 25% ethanol, 15% corn starch

2. **Regional Focus - North America**
   - Switch to Region-Wide filter
   - Highlight: Iowa and Illinois facilities optimal for sugar processing
   - Combined sugar capacity: 3,200 MT/day, currently at 2,400 MT/day

3. **Raw Material Inventory Analysis**
   - Click on Iowa Processing Center
   - Raw sugar inventory: 18-day supply at current consumption
   - Quality specs: meets all food-grade requirements
   - Logistics: 3 incoming rail shipments scheduled this week

4. **Production Optimization Potential**
   - Show capacity to shift from ethanol to sugar production
   - Ethanol margins: $45/MT vs. sugar margins now $85/MT
   - Can increase sugar output by 800 MT/day within 48 hours

---

## 💡 **SCENE 3: Strategic Decision Making (5:00 - 8:00)**

**SARAH**  
"Perfect visibility! I can see we can not only fulfill our contracts but also capitalize on this price move. Can we really shift 800 MT/day from ethanol to sugar that quickly?"

**MARCUS**  
"Absolutely. Our Iowa facility has flexible processing lines. We can adjust the fermentation process and redirect feedstock. The only consideration is we have an ethanol contract, but the penalty is only $15/MT - well worth it given current sugar margins."

**SARAH**  
"Excellent strategic opportunity:
- **Immediate**: Confirm 12,000 MT delivery using current production
- **Opportunistic**: Offer additional 6,000 MT at $545/MT for premium capture
- **Optimization**: Shift 800 MT/day capacity to sugar for next 2 weeks"

### **Business Impact Demonstrated:**

**Before Dashboard:**
- Phone calls to each facility (45+ minutes)
- Conservative capacity assumptions
- Missed market opportunities
- Manual inventory tracking

**With Dashboard:**
- Real-time production and inventory visibility (3 minutes)
- Confident trading decisions
- Optimized product mix based on margins
- **Result**: Additional $780K profit opportunity over 2 weeks

---

## 🎯 **SCENE 4: Agricultural Excellence (8:00 - 10:00)**

**SARAH**  
"Marcus, this integration is game-changing. While other traders are operating blind on production capacity, we're making data-driven decisions that optimize our entire agricultural value chain."

**MARCUS**  
"Exactly. From the operations side, I can optimize our production scheduling based on your forward positions, manage our raw material purchasing around market volatility, and ensure we're maximizing every ton of throughput."

### **Quantified Business Value:**
- **Trading Margin Improvement**: 15% increase ($30M annual impact)
- **Decision Speed**: 15x faster (45 min → 3 min)
- **Product Mix Optimization**: $1.2M additional monthly revenue
- **Inventory Optimization**: $600K working capital improvement
- **Market Opportunity Capture**: 95% vs. 60% industry average

---

## 🔧 **Key Features Demonstrated:**

✅ **Real-time Processing Operations**  
✅ **Multi-product Portfolio Management**  
✅ **Raw Material Inventory Tracking**  
✅ **Production Flexibility Analysis**  
✅ **Margin Optimization Tools**  
✅ **Market Price Integration**  
✅ **Supply Chain Coordination**

---

## 📈 **ROI Summary:**
- **Implementation Cost**: $850K
- **Annual Benefit**: $31.8M
- **Payback Period**: 9.8 days
- **3-Year NPV**: $88M

---

*This dashboard transforms food & beverage trading from reactive to proactive, enabling integrated agricultural processing that maximizes margins while ensuring reliable supply chain execution.*
"""
    
    try:
        # Get the directory of the current script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Multiple path attempts for different deployment scenarios
        possible_paths = [
            # Local development path (original)
            os.path.join(os.path.dirname(os.path.dirname(current_dir)), "DEMO_SCRIPT.md"),
            # Container deployment paths
            os.path.join("/app", "DEMO_SCRIPT.md"),
            os.path.join("/app", "trader-dashboard-food-beverage", "DEMO_SCRIPT.md"),
            # Relative to current directory
            os.path.join(current_dir, "DEMO_SCRIPT.md"),
            os.path.join(current_dir, "..", "..", "DEMO_SCRIPT.md"),
            # Working directory
            "DEMO_SCRIPT.md",
            "./DEMO_SCRIPT.md"
        ]
        
        # Try each path
        for path in possible_paths:
            try:
                if os.path.exists(path):
                    with open(path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():  # Ensure file is not empty
                            return content
            except Exception as path_error:
                # Log individual path failures but continue trying
                logging.warning(f"Failed to load demo script from {path}: {path_error}")
                continue
        
        # If no file found, return fallback content
        logging.info("Demo script file not found in any expected location, using embedded fallback content")
        return fallback_content
        
    except Exception as e:
        # Final fallback with error info
        logging.error(f"Error in load_demo_script: {str(e)}")
        return f"""
# Demo Script Loading Error

**Error Details:** {str(e)}

**Fallback Content:**

{fallback_content}
"""

# Set page config
st.set_page_config(
    page_title="Food & Beverage Trading Dashboard",
    page_icon="🌾",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Add custom CSS
st.markdown("""
<style>
    .main-header { 
        font-size: 2.5rem; 
        font-weight: bold; 
        color: #2E7D32; 
        text-align: center; 
        margin-bottom: 1rem;
    }
    .metric-card {
        background: linear-gradient(90deg, #E8F5E8 0%, #C8E6C9 100%);
        padding: 1rem;
        border-radius: 10px;
        border-left: 5px solid #4CAF50;
        margin: 0.5rem 0;
    }
    .alert-critical { background-color: #ffebee; border-left: 5px solid #f44336; padding: 1rem; margin: 0.5rem 0; }
    .alert-warning { background-color: #fff8e1; border-left: 5px solid #ff9800; padding: 1rem; margin: 0.5rem 0; }
    .alert-normal { background-color: #e8f5e8; border-left: 5px solid #4caf50; padding: 1rem; margin: 0.5rem 0; }
    .equipment-status {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.5rem;
        margin: 0.2rem 0;
        border-radius: 5px;
    }
    .status-online { background-color: #c8e6c9; }
    .status-offline { background-color: #ffcdd2; }
    .status-maintenance { background-color: #ffe0b2; }
</style>
""", unsafe_allow_html=True)

# Generate mock data
@st.cache_data
def generate_mock_data():
    """Generate comprehensive mock data for food & beverage processing"""
    
    # Products to track
    products = [
        "Refined Sugar", "Ethanol", "Skim Milk Powder", 
        "Corn Starch", "Wheat Flour", "Soybean Oil"
    ]
    
    # Processing plants
    plants = [
        "Midwest Sugar Refinery", "Gulf Coast Ethanol Plant", "Great Lakes Dairy Complex",
        "Iowa Corn Processing", "Kansas Wheat Mills", "Mississippi Valley Soy Plant",
        "California Food Hub", "Texas Processing Center", "Illinois Ag Complex"
    ]
    
    # Equipment types
    equipment_types = [
        "Centrifuge", "Evaporator", "Fermentation Tank", "Dryer", "Mill", 
        "Separator", "Heat Exchanger", "Storage Tank", "Packaging Line", "Conveyor System"
    ]
    
    # Trader categories
    trader_categories = ["Food Service", "Industrial Processing", "Export Markets", "Retail Distribution"]
    
    # Generate plant data
    plant_data = []
    for plant in plants:
        for product in products[:3]:  # Each plant produces 3 products
            planned_capacity = random.randint(800, 2000)
            actual_production = planned_capacity * random.uniform(0.65, 1.05)
            deviation = ((actual_production - planned_capacity) / planned_capacity) * 100
            
            plant_data.append({
                'plant': plant,
                'product': product,
                'planned_capacity': planned_capacity,
                'actual_production': int(actual_production),
                'deviation_percent': round(deviation, 1),
                'region': random.choice(['North America', 'Europe', 'Asia-Pacific']),
                'trader_book': random.choice(trader_categories),
                'status': 'Critical' if deviation < -20 else 'Warning' if deviation < -10 else 'Normal'
            })
    
    # Generate equipment data
    equipment_data = []
    for plant in plants:
        for i in range(5):  # Top 5 equipment per plant
            equipment = f"{random.choice(equipment_types)} {chr(65+i)}"
            is_online = random.choice([True, True, True, False])  # 75% online
            impact = random.randint(50, 300) if not is_online else 0
            duration = random.randint(4, 48) if not is_online else 0
            
            equipment_data.append({
                'plant': plant,
                'equipment': equipment,
                'status': 'Online' if is_online else random.choice(['Offline', 'Maintenance']),
                'production_impact': impact,
                'estimated_duration': duration
            })
    
    # Generate time series data
    dates = pd.date_range(start=datetime.now() - timedelta(days=60), 
                         end=datetime.now() + timedelta(days=30), freq='D')
    
    time_series_data = []
    for plant in plants[:3]:  # Focus on 3 plants for detailed analytics
        for product in products[:2]:  # 2 products per plant
            base_production = random.randint(400, 800)
            for date in dates:
                # Add seasonal variation and noise
                seasonal_factor = 1 + 0.1 * np.sin(2 * np.pi * date.dayofyear / 365)
                noise = random.uniform(0.85, 1.15)
                production = int(base_production * seasonal_factor * noise)
                
                time_series_data.append({
                    'date': date,
                    'plant': plant,
                    'product': product,
                    'production': production,
                    'is_forecast': date > datetime.now()
                })
    
    # Generate incident logs
    incidents = []
    incident_types = [
        "Equipment Failure", "Scheduled Maintenance", "Supply Chain Delay", 
        "Quality Issue", "Power Outage", "Weather Impact"
    ]
    
    for i in range(15):
        incident_date = datetime.now() - timedelta(days=random.randint(0, 30))
        incidents.append({
            'date': incident_date.strftime('%Y-%m-%d %H:%M'),
            'plant': random.choice(plants),
            'type': random.choice(incident_types),
            'description': f"Issue with {random.choice(equipment_types)} affecting {random.choice(products)} production",
            'impact': f"{random.randint(50, 500)} tons/day reduction",
            'status': random.choice(['Resolved', 'In Progress', 'Scheduled'])
        })
    
    return {
        'plant_data': pd.DataFrame(plant_data),
        'equipment_data': pd.DataFrame(equipment_data),
        'time_series_data': pd.DataFrame(time_series_data),
        'incidents': incidents,
        'products': products,
        'plants': plants
    }

# Load data
data = generate_mock_data()

# Main title
st.markdown('<h1 class="main-header">🌾 Food & Beverage Trading Dashboard</h1>', unsafe_allow_html=True)
st.markdown("**Large-Scale Processing Operations | Real-Time Production Intelligence**")

# Sidebar filters
st.sidebar.header("Navigation")

# Add tabs for main dashboard and demo script
page = st.sidebar.radio("Select Page:", ["Dashboard", "Demo Script"])

if page == "Demo Script":
    st.title("🥤 Food & Beverage Trading Dashboard - Demo Script")
    st.markdown("---")
    
    demo_content = load_demo_script()
    st.markdown(demo_content)
    
    st.markdown("---")
    st.caption("Return to the Dashboard using the sidebar navigation.")
    st.stop()  # Stop execution here for demo script page

st.sidebar.header("🔍 Filters & Options")

view_option = st.sidebar.selectbox(
    "View Scope",
    ["Enterprise-Wide", "Region-Wide", "My Book of Business"]
)

if view_option == "Region-Wide":
    selected_region = st.sidebar.selectbox(
        "Select Region",
        data['plant_data']['region'].unique()
    )
    filtered_data = data['plant_data'][data['plant_data']['region'] == selected_region]
elif view_option == "My Book of Business":
    selected_book = st.sidebar.selectbox(
        "Select Trader Book",
        data['plant_data']['trader_book'].unique()
    )
    filtered_data = data['plant_data'][data['plant_data']['trader_book'] == selected_book]
else:
    filtered_data = data['plant_data']

selected_products = st.sidebar.multiselect(
    "Focus Products",
    data['products'],
    default=data['products'][:3]
)

# Real-time Production Alerts
st.header("🚨 Real-Time Production Alerts")

col1, col2, col3 = st.columns(3)

critical_issues = filtered_data[filtered_data['status'] == 'Critical']
warning_issues = filtered_data[filtered_data['status'] == 'Warning']
normal_operations = filtered_data[filtered_data['status'] == 'Normal']

with col1:
    st.markdown(f"""
    <div class="alert-critical">
        <h3>🔴 Critical Issues: {len(critical_issues)}</h3>
        <p>Production >20% below plan</p>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown(f"""
    <div class="alert-warning">
        <h3>🟡 Warnings: {len(warning_issues)}</h3>
        <p>Production 10-20% below plan</p>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown(f"""
    <div class="alert-normal">
        <h3>🟢 Normal Operations: {len(normal_operations)}</h3>
        <p>On or above plan</p>
    </div>
    """, unsafe_allow_html=True)

# Quantified Impact Analysis
st.header("📊 Quantified Impact Analysis")

col1, col2 = st.columns(2)

with col1:
    st.subheader("Production Shortfall by Product")
    
    shortfall_data = []
    for product in selected_products:
        product_data = filtered_data[filtered_data['product'] == product]
        total_shortfall = product_data[product_data['deviation_percent'] < 0]['actual_production'].sum() - \
                         product_data[product_data['deviation_percent'] < 0]['planned_capacity'].sum()
        
        if total_shortfall < 0:
            shortfall_data.append({
                'Product': product,
                'Shortfall (MT)': abs(int(total_shortfall)),
                'Est. Duration (days)': random.randint(5, 30),
                'Buy/Sell Recommendation': f"BUY {abs(int(total_shortfall))} MT"
            })
    
    if shortfall_data:
        shortfall_df = pd.DataFrame(shortfall_data)
        st.dataframe(shortfall_df, use_container_width=True)
    else:
        st.info("No significant shortfalls detected in selected scope.")

with col2:
    st.subheader("Weekly Impact Forecast")
    
    impact_weeks = ['This Week', 'Next Week', 'Week +2', 'Week +3']
    impact_values = [random.randint(500, 2000) for _ in range(4)]
    
    fig_impact = px.bar(
        x=impact_weeks, 
        y=impact_values,
        title="Projected Production Impact (MT)",
        color=impact_values,
        color_continuous_scale="Reds"
    )
    fig_impact.update_layout(height=300, showlegend=False)
    st.plotly_chart(fig_impact, use_container_width=True)

# Top 5 Equipment Impact
st.header("⚙️ Top 5 Equipment Issues")

equipment_issues = data['equipment_data'][data['equipment_data']['status'] != 'Online'].head(5)

if not equipment_issues.empty:
    for _, equipment in equipment_issues.iterrows():
        status_class = "status-offline" if equipment['status'] == 'Offline' else "status-maintenance"
        
        st.markdown(f"""
        <div class="equipment-status {status_class}">
            <div>
                <strong>{equipment['plant']} - {equipment['equipment']}</strong><br>
                <small>Impact: -{equipment['production_impact']} tons/day | Duration: {equipment['estimated_duration']} hours</small>
            </div>
            <div>
                <span style="padding: 5px 10px; border-radius: 15px; background: {'#f44336' if equipment['status'] == 'Offline' else '#ff9800'}; color: white; font-size: 12px;">
                    {equipment['status']}
                </span>
            </div>
        </div>
        """, unsafe_allow_html=True)
else:
    st.success("🎉 All equipment operating normally!")

# Production Analytics
st.header("📈 Production Analytics")

analytics_plant = st.selectbox("Select Plant for Detailed Analytics", data['plants'][:3])

ts_data = data['time_series_data'][data['time_series_data']['plant'] == analytics_plant]

if not ts_data.empty:
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Month-to-Date vs 30-Day Rolling Average")
        
        current_month = ts_data[
            (ts_data['date'] >= datetime.now().replace(day=1)) & 
            (ts_data['date'] <= datetime.now())
        ]
        
        rolling_30 = ts_data[
            (ts_data['date'] >= datetime.now() - timedelta(days=30)) & 
            (ts_data['date'] <= datetime.now())
        ]
        
        mtd_avg = current_month['production'].mean()
        rolling_avg = rolling_30['production'].mean()
        
        fig_comparison = go.Figure()
        fig_comparison.add_trace(go.Bar(
            x=['Month-to-Date', '30-Day Rolling'],
            y=[mtd_avg, rolling_avg],
            marker_color=['#2E7D32', '#1976D2']
        ))
        fig_comparison.update_layout(
            title="Average Daily Production (MT)",
            height=300
        )
        st.plotly_chart(fig_comparison, use_container_width=True)
    
    with col2:
        st.subheader("Production Trend & Forecast")
        
        fig_trend = px.line(
            ts_data, 
            x='date', 
            y='production', 
            color='product',
            title="Historical & Forecasted Production"
        )
        
        # Add vertical line for current date
        try:
            current_date = pd.Timestamp.now()
            fig_trend.add_vline(
                x=current_date, 
                line_dash="dash", 
                line_color="red",
                annotation_text="Today"
            )
        except Exception:
            # If vline fails, add a simple annotation instead
            fig_trend.add_annotation(
                x=pd.Timestamp.now(),
                y=ts_data['production'].max() * 0.9,
                text="Today",
                showarrow=True,
                arrowhead=2,
                arrowcolor="red",
                font=dict(color="red")
            )
        
        fig_trend.update_layout(height=300)
        st.plotly_chart(fig_trend, use_container_width=True)

# Supervisor Notes & Incident Logs
st.header("📝 Operations Intelligence")

col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("Recent Incident Log")
    
    incidents_df = pd.DataFrame(data['incidents'])
    st.dataframe(
        incidents_df[['date', 'plant', 'type', 'description', 'impact', 'status']],
        use_container_width=True,
        height=300
    )

with col2:
    st.subheader("Operations Inquiry")
    
    with st.form("ops_inquiry"):
        inquiry_plant = st.selectbox("Plant", data['plants'])
        inquiry_type = st.selectbox("Inquiry Type", [
            "Production Status", "Equipment Issue", "Supply Chain", 
            "Quality Concern", "Capacity Planning", "Other"
        ])
        inquiry_priority = st.selectbox("Priority", ["Low", "Medium", "High", "Critical"])
        inquiry_details = st.text_area("Details", height=100)
        
        if st.form_submit_button("Submit Inquiry"):
            st.success("✅ Inquiry submitted to operations team!")
            st.info(f"Reference ID: FB-{random.randint(1000, 9999)}")

# Performance Summary
st.header("📊 Performance Summary")

col1, col2, col3, col4 = st.columns(4)

total_production = filtered_data['actual_production'].sum()
total_capacity = filtered_data['planned_capacity'].sum()
utilization = (total_production / total_capacity) * 100
critical_plants = len(filtered_data[filtered_data['status'] == 'Critical'])

with col1:
    st.markdown(f"""
    <div class="metric-card">
        <h3>{total_production:,} MT</h3>
        <p>Total Production</p>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown(f"""
    <div class="metric-card">
        <h3>{utilization:.1f}%</h3>
        <p>Capacity Utilization</p>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown(f"""
    <div class="metric-card">
        <h3>{critical_plants}</h3>
        <p>Plants Needing Attention</p>
    </div>
    """, unsafe_allow_html=True)

with col4:
    efficiency_score = random.randint(75, 95)
    st.markdown(f"""
    <div class="metric-card">
        <h3>{efficiency_score}%</h3>
        <p>Overall Efficiency</p>
    </div>
    """, unsafe_allow_html=True)

# Footer
st.markdown("---")
st.markdown(
    "**Food & Beverage Trading Dashboard** | "
    "Powered by Cognite Industrial Canvas | "
    f"Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | "
    "🌾 Optimizing Global Food Processing Operations"
)

 