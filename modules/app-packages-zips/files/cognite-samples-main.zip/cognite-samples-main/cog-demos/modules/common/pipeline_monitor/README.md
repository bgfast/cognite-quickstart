# Pipeline Monitor

## Overview
The Pipeline Monitor module provides a comprehensive dashboard for monitoring pipeline operations and pump stations in Cognite Data Fusion. This module includes a Streamlit application for visualizing pipeline data and work order management.

## What This Module Does
- **Creates a Streamlit application** for pipeline monitoring and visualization
- **Displays pump stations** along pipeline routes on interactive maps
- **Shows work order counts** for each station in real-time
- **Provides operational insights** for midstream customers
- **Enables data-driven decision making** for pipeline operations

## Module Components

### 1. **Streamlit Application**
- **Name**: Pipeline Monitor
- **External ID**: `pipeline-monitor`
- **Entrypoint**: `main.py`
- **Purpose**: Interactive pipeline monitoring dashboard

### 2. **Application Files**
- **Main Application**: `main.py` - Core Streamlit application logic
- **Helper Module**: `FileHelper.py` - Utility functions for file operations
- **Requirements**: `requirements.txt` - Python dependencies
- **Configuration**: `PipelineMonitor.Streamlit.yaml` - Streamlit app configuration

### 3. **Dependencies**
- `streamlit` - Web application framework
- `cognite-sdk` - CDF client library
- `pandas` - Data manipulation
- `plotly` - Interactive visualizations
- `requests` - HTTP requests

## Configuration Requirements

### ✅ **No Variables Required!**
This module is **completely self-contained** and doesn't use any template variables (`{{variable}}`). It's designed to be plug-and-play.

### **Deployment**
- **No configuration needed** - deploy as-is
- **No environment variables required**
- **No template substitutions needed**

## Usage
Once deployed, this module provides:
- Interactive pipeline maps with pump station locations
- Real-time work order counts per station
- Operational dashboards for midstream operations
- Data visualization tools for pipeline monitoring

## Verification System

### **Automated Verification**
The Pipeline Monitor module includes an automated verification system that validates successful deployment by checking the Streamlit application deployment status via CDF API calls.

**Location**: `modules/common/pipeline_monitor/verify/verify.py`

### **What It Verifies**
The verification script automatically checks for:

1. **CDF Connection**: Validates authentication and connection to CDF
2. **Streamlit Apps Available**: Confirms Streamlit apps are accessible in CDF
3. **Pipeline Monitor App**: Verifies the specific "Pipeline Monitor" app is deployed and accessible

### **How to Run Verification**

**Individual Module Verification:**
```bash
cd cog-demos
python modules/common/pipeline_monitor/verify/verify.py
```

**Test Harness (All Modules):**
```bash
cd cog-demos
python ../scripts/test_harness.py --config config.all.yaml
```

### **Verification Output**
```
🔍 PIPELINE_MONITOR VERIFICATION
==================================================
✅ CDF Connection: Connected to CDF as user@example.com
✅ Streamlit Apps Available: Found 23 Streamlit app(s) in CDF
✅ Pipeline Monitor App: Found Pipeline Monitor app: 'Pipeline Monitor' (ID: 1234567890123456)

📋 Pipeline Monitor verification PASSED
```

### **Integration with Deployment**
The verification system is designed to run automatically after each successful deployment to ensure the Pipeline Monitor Streamlit application is properly deployed and accessible.

**Key Features:**
- **External ID Matching**: Uses the correct external ID (`pipeline-monitor`) for reliable detection
- **Name Validation**: Ensures the app name matches "Pipeline Monitor"
- **Detailed Logging**: Shows exactly what was found and verified
- **Error Handling**: Provides clear error messages if verification fails
- **Exit Codes**: Returns proper exit codes for automated integration

## Author
**Torgrim Aas**

## Demo Notes
There are two hardcoded URLs in the library.py file. You will need to update those once you deploy to your environment.

## Screenshot
<img width="437" alt="Screenshot 2025-01-10 145344" src="https://github.com/user-attachments/assets/f45d639d-8dd2-4dea-8eea-3b0bce2636fc" />

## Type
Pipeline Monitor
