"""
Simple AI Analysis Library for Document Processing
"""
from cognite.client import CogniteClient
from cognite_ai import Completions
from config import *

def _get_completion_instance(client: CogniteClient, prompt_external_id: str) -> Completions:
    """Helper to get a configured Completions instance."""
    completion = Completions(client)
    completion.get_prompts_from_dm(
        view_space=PROMPTS_SPACE,
        view_external_id="Prompt",
        instance_external_id=prompt_external_id,
        instance_space=PROMPTS_SPACE,
        mapping={"system_prompt": "prompt", "user_content": "user_content"}
    )
    return completion

def analyze_page_content(client: CogniteClient, page_content: str, page_number: int, content_segment_types: list, previous_page_summary: str, file_name: str) -> dict:
    """Analyze a single page to determine content type and if it continues previous content."""
    try:
        completion = _get_completion_instance(client, "analyze_page_content")
        
        segment_types_list = "\n".join([f"- {seg_type}" for seg_type in content_segment_types])
        previous_context = f"Previous page summary: {previous_page_summary}" if previous_page_summary else "This is the first page being analyzed."
        
        completion.substitute_params({
            "{segment_types_list}": segment_types_list,
            "{file_name}": file_name,
            "{page_number}": str(page_number),
            "{context_text}": previous_context,
            "{content_sample}": page_content
        })
        
        result = completion.call_endpoint(clean_json=True)
        result["page_number"] = page_number
        return result
        
    except Exception as e:
        return {"content_type": "Unknown", "is_continuation": False, "page_summary": f"Analysis failed: {e}", "page_number": page_number, "error": str(e)}

def quick_analyze_page(client: CogniteClient, page_content: str, page_number: int, file_name: str) -> dict:
    """Analyze a single page to find document information."""
    try:
        completion = _get_completion_instance(client, "summarize_page_with_ai")
        
        content_sample = page_content[:3000] + "..." if len(page_content) > 3000 else page_content
        
        completion.substitute_params({
            "{file_name}": file_name,
            "{page_number}": str(page_number),
            "{content_sample}": content_sample
        })
        
        result = completion.call_endpoint(clean_json=True)
        result["page_number"] = page_number
        return result

    except Exception as e:
        return {"document_title": "Not found", "date": "Not found", "equipment_unit": "Not found", "equipment_tag": "Not found", "page_summary": f"Analysis failed: {e}", "key_elements": [], "page_number": page_number, "error": str(e)}

def quick_classify_document(client: CogniteClient, page_results: list, file_name: str) -> dict:
    """Look at all the page results and determine overall document information."""
    try:
        completion = _get_completion_instance(client, "classify_overall_document")
        
        page_info_list = []
        for result in page_results:
            if "error" in result:
                page_text = f"Page {result.get('page_number', '?')}: Error - {result['error']}"
            else:
                page_text = f"""Page {result.get('page_number', '?')}:
- Title: {result.get('document_title', 'Not found')}
- Date: {result.get('date', 'Not found')}
- Equipment Unit: {result.get('equipment_unit', 'Not found')}
- Equipment Tag: {result.get('equipment_tag', 'Not found')}
- Summary: {result.get('page_summary', 'No summary')}
- Key Elements: {', '.join(result.get('key_elements', []))}"""
            page_info_list.append(page_text)
        
        completion.substitute_params({
            "{file_name}": file_name,
            "{len_page_results}": str(len(page_results)),
            "{page_info_text}": "\n".join(page_info_list)
        })
        
        return completion.call_endpoint(clean_json=True)

    except Exception as e:
        return {"document_title": "Not determined", "equipment_unit": "Not determined", "equipment_tag": "Not determined", "document_type": "Not determined", "confidence_level": "Low", "reasoning": f"Classification failed: {e}", "key_indicators": [], "error": str(e)}

def classify_non_pdf_file_with_ai(client: CogniteClient, document_content: str, content_segment_types: list, file_name: str) -> dict:
    """Classify non-PDF file content using AI to extract key document information."""
    try:
        system_prompt = f"""You are an expert document analyst specializing in industrial and engineering documents. 
Your task is to analyze document content and classify it based on the text content provided.
Available content segment types to consider:
'{"\n".join([f"- {seg_type}" for seg_type in content_segment_types])}'

Instructions:
1. Carefully analyze the full document content to determine the document type, title, equipment information, and other key details
2. Look for equipment tags (alphanumeric identifiers like 3D140, 72F003, 4E124, etc.)
3. Identify equipment units or systems (like Unit 72F, Platform A, Alky Unit, etc.)
4. Determine the document type based on content, format, and purpose
5. Extract the most likely document title from headers, titles, or content context
6. Assess your confidence level based on the clarity and availability of information
Provide your response as valid JSON only, with no additional text or markdown formatting.

Equipment tags:
- These generally follow a defined format. Examples are 3D140, 72F003, 4E124. 
- The equipment tag is generally a number, followed by a letter, followed by a 3 digit number. 
- Equipment tags may be represented with different hyphenation, such as 3D-140 42-F003, and 4-E124. Remove all separators from your response. 
- If you do not find an equipment tag matching this, it is OK to return another format of equipment tag. In this case, leave the separators as-is.
- If an equipment tag appears in the filename, it should be assumed that this is the equipment tag to return."""

        user_content = f"""Please analyze the following document and provide classification information:
File Name: {file_name}
Document Content:
{document_content}

Analyze this document content and provide a JSON response with the following structure:
{{
    "document_title": "Most likely full document title based on all available information",
    "equipment_unit": "Most likely equipment unit/system identifier (e.g., '72F', 'Platform A', etc.)",
    "equipment_tag": "Most likely primary equipment tag/ID (e.g., 3D140, 72F003, 4E124, etc.)",
    "document_type": "Type of document (e.g., 'P&ID', 'Inspection Report', 'Data Sheet', 'Manual', etc.)",
    "confidence_level": "High/Medium/Low - your confidence in these determinations",
    "reasoning": "Brief explanation of how you determined these values",
    "key_indicators": ["list", "of", "key", "evidence", "that", "led", "to", "classification"]
}}"""
        
        completion = Completions(client, system_prompt=system_prompt, user_content=user_content)
        return completion.call_endpoint(clean_json=True)

    except Exception as e:
        return {"document_title": "Not determined", "equipment_unit": "Not determined", "equipment_tag": "Not determined", "document_type": "Not determined", "confidence_level": "Low", "reasoning": f"Analysis failed: {e}", "key_indicators": [], "error": str(e)}

def enhanced_determine_content_boundaries(client: CogniteClient, page_analyses: list, content_segment_types: list, file_name: str) -> dict:
    """Determine final content segment boundaries and classify overall package."""
    try:
        completion = _get_completion_instance(client, "enhanced_determine_content_boundaries")
        
        page_summaries = []
        for analysis in page_analyses:
            if 'error' in analysis:
                page_summaries.append(f"Page {analysis['page_number']}: Error - {analysis['error']}")
            else:
                continuation = "Continuation" if analysis.get('is_continuation', False) else "New segment"
                page_summaries.append(f"Page {analysis['page_number']}: {analysis.get('content_type', 'Unknown')} - {continuation} - {analysis.get('page_summary', 'No summary')}")
        
        completion.substitute_params({
            "{file_name}": file_name,
            "{len(page_analyses)}": str(len(page_analyses)),
            "{page_summaries}": "\n".join(page_summaries)
        })
        
        return completion.call_endpoint(clean_json=True)
        
    except Exception as e:
        return {"content_segments": [], "total_segments": 0, "overall_package_classification": "Not determined", "analysis_notes": f"Analysis failed: {e}", "error": str(e)}

def extract_segment_parameters(client: CogniteClient, segment_content: str, content_type: str, schema: dict, file_name: str, segment_id: int, segment_title: str, schema_name: str) -> dict:
    """Extract schema parameters from a content segment using AI."""
    try:
        completion = _get_completion_instance(client, "extract_segment_parameters")
        
        schema_properties = schema.get('properties', {})
        fields_list = "\n".join([f"- {field_name} ({field_type})" for field_name, field_type in schema_properties.items()])
        
        completion.substitute_params({
            "{schema.get('description', 'No description')}": schema.get('description', 'No description'),
            "{content_type}": content_type,
            "{fields_list}": fields_list,
            "{file_name}": file_name,
            "{segment_title}": segment_title,
            "{schema_description}": schema.get('description', 'No description'),
            "{segment_content}": segment_content
        })
        
        result = completion.call_endpoint(clean_json=True)
        result.update({'segment_id': segment_id, 'content_type': content_type, 'schema_name': schema_name})
        return result
        
    except Exception as e:
        return {"extracted_parameters": {}, "extraction_notes": f"Parameter extraction failed: {e}", "confidence_level": "Low", "fields_found": [], "fields_not_found": [], "segment_id": segment_id, "content_type": content_type, "schema_name": schema_name, "error": str(e)}

def determine_content_segments_with_ai(client: CogniteClient, segment_content: str, content_segment_types: list) -> dict:
    """Determine content segment type from content using AI with hardcoded prompt."""
    try:
        system_prompt = f"""You are an expert document analyst specializing in industrial and engineering documents. 
Your task is to analyze document content and classify it as a single content segment.
Available content segment types to consider:
'{"\n".join([f"- {seg_type}" for seg_type in content_segment_types])}'

Instructions:
1. Analyze the provided content as a single document/segment
2. Determine the most appropriate content type from the available options
3. Use "Other (Unclassified)" when content doesn't fit standard types, and provide specific ad-hoc classification
4. Provide a descriptive title and summary for the document
5. Classify the overall document package (same as the single segment classification)
Provide your response as valid JSON only, with no additional text or markdown formatting."""

        user_content = f"""Please analyze the following document content and classify it as a single content segment:
Document Content:
{segment_content}

Analyze this content and provide a JSON response with the following structure:
{{
    "content_segments": [
        {{
            "document_title": "Title or description of this document",
            "start_page": 1,
            "end_page": 1,
            "content_type": "One of the available content segment types",
            "summary": "Summary of the content in this document",
            "ad_hoc_classification": "Only for Other (Unclassified) - provide specific classification"
        }}
    ],
    "total_segments": 1,
    "overall_package_classification": "Classification of the entire document (same as the single segment)",
    "overall_package_ad_hoc_classification": "Only for Other (Unclassified) packages - provide specific classification",
    "package_classification_reasoning": "Explanation of why this classification was chosen",
    "analysis_notes": "Any observations about the document content and structure"
}}"""
        
        completion = Completions(client, system_prompt=system_prompt, user_content=user_content)
        return completion.call_endpoint(clean_json=True)

    except Exception as e:
        return {"content_segments": [], "total_segments": 0, "overall_package_classification": "Not determined", "overall_package_ad_hoc_classification": "", "package_classification_reasoning": f"Analysis failed: {e}", "analysis_notes": "Content segmentation analysis failed", "error": str(e)}
