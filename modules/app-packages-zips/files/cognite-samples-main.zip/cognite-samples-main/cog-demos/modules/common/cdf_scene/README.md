# CDF scene data model
CDF scene data model
Type: 3D