import streamlit as st
from cognite.client import CogniteClient
import base64
import json
from cognite.client.data_classes import filters
from cognite.client.data_classes.documents import DocumentProperty

st.title("Document Categorization using Cognite AI")
client = CogniteClient()

@st.cache_data
def get_files():
    # Retrieve all files and filter for .pdf and .tif extensions
    all_files = client.files.list(limit=-1)
    return [f for f in all_files if f.name.lower().endswith(('.pdf', '.tif'))]

def get_doc_url(file_id):
    return f"https://cog-caputo.fusion.cognite.com/kevin-sandbox/explore/search?cluster=bluefield.cognitedata.com&journey=file-{file_id}&workspace=data-management&full-page=true"

def count_tokens_approximate(prompt):
    # Break into smaller pieces: words and subwords
    tokens = []
    for word in prompt.split():
        tokens.extend([word[i:i+5] for i in range(0, len(word), 5)])
    return len(tokens)

def get_document_data_urls(files):
    data_urls = []
    for f in files:
        document = client.documents.list(filter=filters.Equals(DocumentProperty.id, f.id))[0]
        binary_content = client.documents.retrieve_content(id=document.id)
        page_contents = [
            client.documents.previews.download_page_as_png_bytes(
                id=document.id, page_number=page
            ) for page in range(1, min(document.page_count + 1, 10))
        ]
        # Format as data URL
        data_urls += [
            f"data:image/png;base64,{base64.b64encode(content).decode('utf-8')}"
            for content in page_contents
        ]
    return data_urls

def analyze_files(files, prompt):
    contents = []
    if files:
        prompt += f"\nAdditional data that might help is coming here:"
    for f in files:
        content = client.documents.retrieve_content(id=f.id).decode('utf-8')
        prompt += content[:65536]

    data_urls = get_document_data_urls(files)

    message = {
        "messages": [
            {
                "role": "user",
                "content": [
                    { "type": "text", "text": prompt },
                    *[
                        { "type": "image_url", "imageUrl": { "url": data_url }}
                        for data_url in data_urls
                    ]
                ]
            }
        ],
        "model": "azure/gpt-4o"
    }

    st.write(f"Estimated tokens: {count_tokens_approximate(json.dumps(message))}")
    response = client.post(
        url=f"/api/v1/projects/{client.config.project}/ai/chat/completions",
        json=message
    )
    return response.json().get('choices', [{}])[0].get('message', {}).get('content', "Unexpected response format")

# Fetch all files
files = get_files()

# Display a dropdown of files for selection
if files:
    selected_file = st.selectbox("Select a file", options=files, format_func=lambda f: f.name)

    user_prompt = """Analyze the provided drawing from a refinery and extract the following information, if available:

* Document ID: The unique identifier of the document (may be called DWG No, Drawing Number, etc)
* Document Title: The title or name of the document (typically in the lower right of the drawing near the drawing number).
* Document Classification: Categorize the document (select only from: P&ID, Assembly Drawing, Component Drawing, General Arrangement Drawing, Manual).
* Vendor: Identify the vendor or company associated with the document (e.g., Flowserve, General Electric, Texas Compressor, Wood Group).
Only respond back with a valid JSON object that has the following keys: documentID, documentTitle, documentClassification, vendor
    Do not return ```json"""

    if selected_file:
        #prompt = st.text_area("Query the Drawing", value=user_prompt, height=400)
        if st.button("✨Categorize"):
            llm_output = analyze_files(files=[selected_file], prompt=user_prompt)
            try:
                st.write(json.loads(llm_output))
            except json.JSONDecodeError:
                st.write(llm_output)
else:
    st.write("No files found.")
