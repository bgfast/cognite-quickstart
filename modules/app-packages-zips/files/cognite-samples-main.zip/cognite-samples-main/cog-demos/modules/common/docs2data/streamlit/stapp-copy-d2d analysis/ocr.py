from cognite.client import CogniteClient
from cognite.client.data_classes.contextualization import FileReference
from typing import Dict, List, Any, Optional
import statistics

class OCR:
    """Wrapper for OCR operations on files in Cognite Data Fusion using internal file IDs."""

    def __init__(self, client: CogniteClient, internal_id: int):
        """
        Initialize OCR handler.

        Args:
            client (CogniteClient): Cognite client instance.
            internal_id (int): Internal ID of the file.
        """
        self.client = client
        self.internal_id = internal_id
        self.file_id = internal_id
        self._ocr_results: Dict[int, Dict[str, Any]] = {}
        # No need to call _get_id() since we already have the internal ID



    def run_ocr(self, start_page: int = 1, end_page: Optional[int] = None, page_count: Optional[int] = None, entities: Optional[List[dict]] = None, ignore_completion: bool = False, one_page: bool = False):
        """
        Trigger OCR detection on file pages.

        Args:
            start_page (int): Starting page (default 1).
            end_page (Optional[int]): Ending page.
            page_count (Optional[int]): Total pages if no end_page.
            entities (Optional[List[dict]]): Entities for filtering. e.g. [{'sample':'00A-A000'}, {'sample':'0A-A000']
            ignore_completion (bool): Don't wait for job completion.
            one_page (bool): Process single page (unused currently).
        """
        if end_page is None and page_count is None:
            raise ValueError("Either end_page or page_count must be provided")

        effective_end = end_page if end_page is not None else page_count
        if effective_end <= 0:
            raise ValueError("End page or page count must be positive")

        if start_page > effective_end:
            raise ValueError("start_page must be <= effective end")

        start = start_page
        step = 50  # Max pages per job
        for i in range(start, effective_end + 1, step):
            first = i
            last = min(effective_end, i + step - 1)

            fr = FileReference(file_id=self.file_id, first_page=first, last_page=last)

            detect_params = {
                "search_field": "token",
                "partial_match": True,
                "file_references": [fr]
            }
            if entities is not None:
                detect_params["entities"] = entities
            else:
                detect_params["entities"] = [{"token": "A"}, {"token": "1"}]  # Default broad entities

            detect_job = self.client.diagrams.detect(**detect_params)

            if not ignore_completion:
                detect_job.result  # Wait for completion
                # After triggering, retrieve the OCR results for the range
                self._retrieve_ocr(start_page, end_page)

    def _retrieve_ocr(self, start_page: Optional[int] = None, end_page: Optional[int] = None) -> bool:
        """
        Retrieve OCR results for pages.

        This is usually called after run_ocr (and internally by it), but if ignore_completion=True in run_ocr, you may need to call this manually after jobs complete.

        Args:
            start_page (Optional[int]): Start page.
            end_page (Optional[int]): End page.

        Returns:
            bool: Success status. Prints a warning if not all requested pages are returned.
        """
        import warnings

        start = start_page or 1
        limit = (end_page - start + 1) if end_page else 25  # Default batch size

        payload = {
            "startPage": start,
            "limit": limit,
            "fileId": self.file_id
        }

        try:
            response = self.client.post(
                f"/api/v1/projects/{self.client.config.project}/context/diagram/ocr",
                json=payload
            )
            if response.status_code != 200:
                return False

            items = response.json().get('items', [])
            for i, item in enumerate(items):
                page_num = start + i
                self._ocr_results[page_num] = item

            expected_count = limit
            received_count = len(items)
            if received_count < expected_count:
                missing_start = start + received_count
                missing_end = start + limit - 1
                # If only a few pages missing, list them, else show range
                missing_pages = list(range(missing_start, missing_end + 1))
                if len(missing_pages) <= 10:
                    missing_str = ", ".join(str(p) for p in missing_pages)
                else:
                    missing_str = f"{missing_start}-{missing_end}"
                warnings.warn(
                    f"OCR results missing for {expected_count - received_count} page(s): {missing_str}. "
                    "This usually means OCR has not been run for these pages. Run the run_ocr method to trigger OCR."
                )
            return True
        except Exception:
            warnings.warn(
                    f"OCR has failed for file ID {self.file_id}"
                )
            return False


    def get_text(self, start_page: Optional[int] = None, end_page: Optional[int] = None) -> str:
        """
        Extract text from OCR pages, automatically retrieving OCR data if needed.

        Args:
            start_page (Optional[int]): Start page.
            end_page (Optional[int]): End page.

        Returns:
            str: Combined text from pages.
        """
        # Determine actual range
        if not self._ocr_results:
            # If no OCR results at all, default to page 1
            start = start_page or 1
            end = end_page or start
        else:
            start = start_page or min(self._ocr_results.keys())
            end = end_page or max(self._ocr_results.keys())

        # Check if we have all pages in the range
        missing_pages = []
        for page in range(start, end + 1):
            if page not in self._ocr_results:
                missing_pages.append(page)
        
        # If pages are missing, retrieve them
        if missing_pages:
            retrieve_start = min(missing_pages)
            retrieve_end = max(missing_pages)
            success = self._retrieve_ocr(retrieve_start, retrieve_end)
            if not success:
                raise RuntimeError(f"Failed to retrieve OCR data for pages {retrieve_start}-{retrieve_end}")

        # Extract text from all pages in range
        text_parts = []
        for page in range(start, end + 1):
            if page not in self._ocr_results:
                raise RuntimeError(f"Page {page} still not available after OCR retrieval")
            annotations = self._ocr_results[page].get('annotations', [])
            page_text = ' '.join(ann.get('text', '') for ann in annotations if ann.get('text'))
            text_parts.append(page_text)
        
        return ' '.join(text_parts)

    def get_annotations(self, start_page: Optional[int] = None, end_page: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get raw OCR annotations for pages, automatically retrieving OCR data if needed.

        Args:
            start_page (Optional[int]): Start page.
            end_page (Optional[int]): End page.

        Returns:
            List[Dict[str, Any]]: List of annotations.
        """
        # Determine actual range
        if not self._ocr_results:
            # If no OCR results at all, default to page 1
            start = start_page or 1
            end = end_page or start
        else:
            start = start_page or min(self._ocr_results.keys())
            end = end_page or max(self._ocr_results.keys())

        # Check if we have all pages in the range
        missing_pages = []
        for page in range(start, end + 1):
            if page not in self._ocr_results:
                missing_pages.append(page)
        
        # If pages are missing, retrieve them
        if missing_pages:
            retrieve_start = min(missing_pages)
            retrieve_end = max(missing_pages)
            success = self._retrieve_ocr(retrieve_start, retrieve_end)
            if not success:
                raise RuntimeError(f"Failed to retrieve OCR data for pages {retrieve_start}-{retrieve_end}")

        # Get annotations from all pages in range
        annotations = []
        for page in range(start, end + 1):
            if page not in self._ocr_results:
                raise RuntimeError(f"Page {page} still not available after OCR retrieval")
            annotations.extend(self._ocr_results[page].get('annotations', []))
        
        return annotations

    def calculate_confidence(self, start_page: Optional[int] = None, end_page: Optional[int] = None) -> float:
        """
        Calculate average OCR confidence for pages, automatically retrieving OCR data if needed.

        Args:
            start_page (Optional[int]): Start page.
            end_page (Optional[int]): End page.

        Returns:
            float: Average confidence (0.0 to 1.0).
        """
        # Determine actual range
        if not self._ocr_results:
            # If no OCR results at all, default to page 1
            start = start_page or 1
            end = end_page or start
        else:
            start = start_page or min(self._ocr_results.keys())
            end = end_page or max(self._ocr_results.keys())

        # Check if we have all pages in the range
        missing_pages = []
        for page in range(start, end + 1):
            if page not in self._ocr_results:
                missing_pages.append(page)
        
        # If pages are missing, retrieve them
        if missing_pages:
            retrieve_start = min(missing_pages)
            retrieve_end = max(missing_pages)
            success = self._retrieve_ocr(retrieve_start, retrieve_end)
            if not success:
                raise RuntimeError(f"Failed to retrieve OCR data for pages {retrieve_start}-{retrieve_end}")

        # Calculate confidence from all pages in range
        confidences = []
        for page in range(start, end + 1):
            if page not in self._ocr_results:
                raise RuntimeError(f"Page {page} still not available after OCR retrieval")
            annotations = self._ocr_results[page].get('annotations', [])
            confidences.extend(float(ann.get('confidence', 0)) for ann in annotations if ann.get('confidence') is not None)
        
        if not confidences:
            return 0.0
        return statistics.mean(confidences)
