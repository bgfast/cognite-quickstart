import pandas as pd
import time
from datetime import datetime, timedelta
import plotly.express as px
import streamlit as st
from cognite.client.data_classes import filters
from cognite.client.data_classes.assets import AssetProperty
import os
import pytz
from cognite.client.utils import ZoneInfo


class SuperEmitterClient:

    def __init__(self, client, date_input, time_input, lookback_days, lookforward_days, search_query):
        # arguments
        """
        lookback_days and lookforward_days are used for time series queries. 
        
        """
        self.client = client
        self.date_input = date_input
        self.time_input = time_input
        self.lookback_days = lookback_days
        self.lookforward_days = lookforward_days
        self.search_query = search_query

        # formatting inputs

        self.alert_dt = datetime.combine(date_input, time_input)
        self.alert_timestamp = int(datetime.combine(date_input, time_input).timestamp()) * 1000
        
        # time range windows for events
        self.EBS_DELTA = 86400 * 1000 * 547 # 18 months
        self.WORKORDER_DELTA = 86400 * 1000 * lookback_days # same range as the timeseries lookback
        self.DEFAULT_DELTA = 86400 * 1000 * 30

        # time range windows for time series and events with same time series window
        self.local_tz = "US/Central"
        self.TS_START = datetime.fromtimestamp(self.alert_timestamp/1000, tz=ZoneInfo(self.local_tz)) - timedelta(days=self.lookback_days)
        self.TS_END = datetime.fromtimestamp(self.alert_timestamp/1000, tz=ZoneInfo(self.local_tz)) + timedelta(days=self.lookforward_days)
   

        self.LOOKBACK_MS = 86400 * 1000 * lookback_days
        self.LOOKFORWARD_MS = 86400 * 1000 * lookforward_days

        # Canvas needs timestamp, cannot take datetime input
        
        self.TS_START_CANVAS = self.alert_timestamp - self.LOOKBACK_MS
        self.TS_END_CANVAS = self.alert_timestamp + self.LOOKFORWARD_MS

        self.EVENT_RANGES = {"EBS_Signal" : {"start" : self.alert_timestamp - self.EBS_DELTA, "end" : self.alert_timestamp + self.EBS_DELTA},
                             "Work Order" : {"start" : self.alert_timestamp - self.LOOKBACK_MS, "end" : self.alert_timestamp + self.LOOKFORWARD_MS},
                             "default" : {"start" : self.alert_timestamp - self.LOOKBACK_MS, "end" : self.alert_timestamp + self.LOOKFORWARD_MS}}


    
        # data placeholders
        #new Code 

        temp_pad_asset = self.client.assets.retrieve(external_id=search_query)
        if not temp_pad_asset:
            try:  
                temp_pad_asset = self.client.assets.retrieve(id=int(search_query))
            except ValueError:
                pass
#        if not temp_pad_asset:
#            temp_al = self.client.assets.search(query = (search_query), limit = 1)
#            temp_pad_asset = temp_al[0].external_id
#            temp_pad_asset = self.client.assets.retrieve(external_id=temp_pad_id)

        #self.pad_asset = self.client.assets.retrieve(external_id=search_query)
        self.pad_asset = temp_pad_asset
        self.se_img = self.get_image_file()
        self.ebs_flare = None
        self.ebs_tank = None
        self.ebs_treater = None
        self.ops = None
        self.wos = None
        self.trucking_events = None
        self.am_events = None
        self.flare_temp_timeseries = None
        self.flare_rate_timeseries = None
        self.tank_timeseries = None
        self.combustor_timeseries = None
    
    def get_image_file(self):
        
        # sample file with hardcoded image. Needs to be updated to get actual images when available.

        se_img = self.client.files.retrieve(id=2149925934253372)
        return se_img
    
    def download_image_file(self):
        
        # sample file with hardcoded image. Needs to be updated to get actual images when available.
        se_img = self.client.files.retrieve_download_urls(id=2149925934253372)
        return list(se_img.values())[0]
    
    """
     FUNCTIONS FOR GETTING EVENTS. THE FUNCTION YOU WILL CHOOSE DEPENDS ON THE NATURE OF THE EVENTS.
     FOR EXAMPLE, ALL WELLVIEW JOB EVENTS ARE NEEDED EVEN THOUGH THERE ARE MULTIPLE TYPES--IN THIS
     CASE, IT MAKES MORE SENSE TO GET THEM BY DATASET.

     FOR SOMETHING LIKE PLANNING OPTIMIZER, THERE ARE MULTIPLE DIFFERENT TYPES TO RETRIEVE.
     """

    def adjust_event_times(self, df):
            df['start_time'] = df['start_time'].dt.tz_localize('UTC')
            df['start_time'] = df['start_time'].dt.tz_convert(self.local_tz)

            if "end_time" in df.columns:
                df['end_time'] = df['end_time'].dt.tz_localize('UTC')
                df['end_time'] = df['end_time'].dt.tz_convert(self.local_tz)
                df.sort_values(by='end_time', ascending=False, inplace=True)
            else:
                df.sort_values(by='start_time', ascending=False, inplace=True)
            return df

    def get_event_data_by_type(self, event_type, event_subtype, metadata_input=None):

        # This function gives an easy way to get events based on a type.

        start = self.EVENT_RANGES.get(event_type, self.EVENT_RANGES.get("default")).get("start")
        end = self.EVENT_RANGES.get(event_type, self.EVENT_RANGES.get("default")).get("end")


        event_data = self.client.events.list(asset_subtree_external_ids=[self.pad_asset.external_id], 
                                        type=event_type,
                                        subtype=event_subtype,
                                        metadata=metadata_input,
                                        limit=None,
                                        start_time={"min" : start,
                                                    "max" : end}).to_pandas(expand_metadata=True)

        if event_data.empty:
            return event_data
        else:
            event_data = self.adjust_event_times(event_data)

        return event_data

    def get_multiple_type_events(self, event_types, event_subtypes, metadata_input=None):
        
        # This function gives an easy way to get events based on multiple types or subtypes.

        if isinstance(event_types, list):
            start = self.EVENT_RANGES.get("default").get("start")
            end = self.EVENT_RANGES.get("default").get("end")
        else:
            start = self.EVENT_RANGES.get(event_types, self.EVENT_RANGES.get("default")).get("start")
            end = self.EVENT_RANGES.get(event_types, self.EVENT_RANGES.get("default")).get("end")

        if isinstance(event_types, list) and isinstance(event_subtypes, list):
            df_list = []
            
            for event_type in event_types:
                for event_subtype in event_subtypes: 
                    temp_res = self.client.events.list(asset_subtree_external_ids=[self.pad_asset.external_id], 
                                                        type=event_type,
                                                        subtype=event_subtype,
                                                        metadata=metadata_input,
                                                        limit=None,
                                                        start_time={"min": start, "max": end}).to_pandas(expand_metadata=True)
                    df_list.append(temp_res)
                    
            event_data = pd.concat(temp_data_list)

        elif isinstance(event_types, list):
            temp_data_list = [self.client.events.list(asset_subtree_external_ids=[self.pad_asset.external_id], 
                                                      type=sub,
                                                      subtype=event_subtypes,
                                                      metadata=metadata_input,
                                                      limit=None,
                                                      start_time={"min": start, "max": end}).to_pandas(expand_metadata=True)
                             for sub in event_types]

            event_data = pd.concat(temp_data_list)

        elif isinstance(event_subtypes, list):
            temp_data_list = [self.client.events.list(asset_subtree_external_ids=[self.pad_asset.external_id], 
                                                      type=event_types,
                                                      subtype=sub,
                                                      metadata=metadata_input,
                                                      limit=None,
                                                      start_time={"min": start, "max": end}).to_pandas(expand_metadata=True)
                             for sub in event_subtypes]

            event_data = pd.concat(temp_data_list)

        if event_data.empty:
            return event_data
        else:
            event_data = self.adjust_event_times(event_data)
        return event_data

    def get_event_data_by_dataset(self, dataset_ext_id):
        
        # This function retrieves events based on a dataset.

        start = self.EVENT_RANGES.get("default").get("start")
        end = self.EVENT_RANGES.get("default").get("end")
        
        event_data = self.client.events.list(asset_subtree_external_ids=[self.pad_asset.external_id], 
                                        data_set_external_ids=[dataset_ext_id],
                                        limit=None,
                                        start_time={"min" : start,
                                                    "max" : end}).to_pandas(expand_metadata=True)
        if event_data.empty:
            return event_data
        else:
            event_data = self.adjust_event_times(event_data)
    
        return event_data

    def get_timeseries_data(self):
        
        """
         Function to get time series data. Right now, it finds time series based on strings
         within the name. In the future, it might be better to use what is in the PI mapping
         sequence so it is consistent across use cases. This is a more aggresive approach
         to try and get all needed PI tags. 
        """

        all_timeseries = self.client.time_series.list(asset_subtree_external_ids=[self.pad_asset.external_id], 
                                                      data_set_external_ids=['Flare-DS'], 
                                                      limit=None).dump()
        self.flare_temp_timeseries = [ts for ts in all_timeseries if "FLARE" in ts['name'] and "temperature" in ts['name']]
        self.flare_rate_timeseries = [ts for ts in all_timeseries if "FLARE" in ts['name'] and "rate" in ts['name']]
        self.treater_temp_timeseries =  [ts for ts in all_timeseries if "Treater" in ts['name'] and "Temperature" in ts['name']]
        self.tank_timeseries = [ts for ts in all_timeseries if "TANK-pressure" in ts['name']]
        self.combustor_timeseries = [ts for ts in all_timeseries if "INCINERATOR" in ts['name']]
        self.vapor_recovery_timeseries = [ts for ts in all_timeseries if "VAPOR RECOVERY" in ts['name']]

    def get_relevant_data(self):

        # Main function to retrieve all necessary data for the SuperEmitter client. 

        self.get_timeseries_data()
        #self.ebs_flare = self.get_multiple_type_events(event_types="EBS_Signal", event_subtypes=["Flare Temp", "Flare Temp 1", "Flare Temp 2"], metadata_input={"ProgressStatus" : "Completed"})
        self.ebs_flare = self.get_multiple_type_events(event_types="EBS_Signal", event_subtypes=["Flare Temp", "Flare Temp 1", "Flare Temp 2"])
        self.ebs_tank = self.get_event_data_by_type(event_type="EBS_Signal", event_subtype="Tank Pressure", metadata_input={"ProgressStatus" : "Completed"})
        self.ebs_treater = self.get_event_data_by_type(event_type="EBS_Signal", event_subtype="Treater Temperature", metadata_input={"ProgressStatus" : "Completed"})
        self.wos = self.get_event_data_by_type(event_type="Work Order", event_subtype=None, metadata_input=None)
        self.trucking_events = self.get_event_data_by_type(event_type="tank unload", event_subtype=None, metadata_input=None)
        self.am_events = self.get_multiple_type_events(event_types=["BKN_AM", "BKN_AM_COMP"], event_subtypes=None, metadata_input=None)
        self.ops = self.get_event_data_by_dataset(dataset_ext_id='wellview_job')
        self.soofie = self.get_event_data_by_dataset(dataset_ext_id="soofie")
    
    def find_equipment_assets(self, search_param):
        
        # This function is used to query equipment based on a prefix, the `search_param`

        equip_type_filter = filters.Prefix(AssetProperty.name, search_param)
        equip_dataset_id = self.client.data_sets.retrieve(external_id='Flare-DS').id
    
        equipment_filter = filters.Equals(AssetProperty.data_set_id, equip_dataset_id)

        equipment_assets =  self.client.assets.list(asset_subtree_external_ids=[self.pad_asset.external_id],
                                                    advanced_filter=filters.And(equip_type_filter, equipment_filter),
                                                    limit=None)
        return equipment_assets
    

    # def find_specific_equipment_info(self, search_param):

    

    def equip_check(self, search_param):

        # This function returns a "Y" for "yes" if equipment is found based on the search 
        # parameter provided and a "N" for "no" otherwise. 

        equip_found = self.find_equipment_assets(search_param)
        if equip_found:
            return "Y"
        else:
            return "N"

    def generate_pad_equipment(self):
        equip_data = {"Location" : self.pad_asset.name,
                      "Facility Type" : 'HT',#self.pad_asset.metadata["Separation"], 
                      "Pit Flare" : self.equip_check("INCINERATOR:"), 
                      "HP Piloted Flare" : self.equip_check("FLARE:HP"), 
                      "LP Piloted Flare" : self.equip_check("FLARE:LP"), 
                      "Dual Tip Flare" : self.equip_check("FLARE:DUAL TIP"), 
                      "HT" : "Y", #if self.pad_asset.metadata["Separation"]=="HT" else "N", 
                      "VHT" : "N", #if self.pad_asset.metadata["Separation"]=="VHT" else "N", 
                      "Combustor" : self.equip_check("INCINERATOR:"), 
                      "Tanks" : self.equip_check("TANK"), 
                      "VRU" : self.equip_check("VAPOR RECOVERY UNIT"), 
                      "Pig L/R" : "Y" if any([self.equip_check("PIG LAUNCHER")=="Y", self.equip_check("PIG RECEIVER")=="Y"]) else "N"
                    }
        return pd.DataFrame(equip_data, index=[1])


    def rename_pi_df(self, df):

        # This function renames the PI time series to remove the unecessary information from the very long tag name

        column_count = {}
        new_columns = []
        
        for col in df.columns:
            base_name = col.split(".")[-1]
            if base_name not in column_count:
                column_count[base_name] = 1
                new_columns.append(base_name)
            else:
                column_count[base_name] += 1
                new_columns.append(f"{base_name}-{column_count[base_name]}")

        COLUMN_MAPPING = {col_old: col_new for col_old, col_new in zip(df.columns, new_columns)}
        df.rename(columns=COLUMN_MAPPING, inplace=True)
        
        return df


    def generate_timeseries_display(self, ts_list, title, unit):
        
        # This function generates the plotly graph.
        
        ts_ext_ids = [ts["externalId"] for ts in ts_list]
        ts_data = self.client.time_series.data.retrieve_dataframe_in_tz(external_id=ts_ext_ids, 
                                                start=self.TS_START, 
                                                end=self.TS_END)

        # ts_data = self.client.time_series.data.retrieve(external_id=ts_ext_ids,
        #                                         start=self.TS_START,
        #                                         end=self.TS_END).to_pandas()

        if not ts_data.empty:
            ts_data = self.rename_pi_df(ts_data)
            
            # Define a color sequence excluding red
            safe_colors = [color for color in px.colors.qualitative.Safe if color != "red"]

            fig = px.line(ts_data, 
                        title=title,
                        labels={"index": "Date/Time", "value": unit},
                        color_discrete_sequence=safe_colors)  # Exclude red from the color sequence

            fig.add_vline(x=self.alert_dt, line=dict(color="red", width=2))
            fig.add_annotation(x=self.alert_dt + pd.Timedelta(days=2.5), yref="paper", y=0.95, 
                            text="Diagnostic Event",
                            showarrow=False,
                            font=dict(color="red", size=12),
                            align="left")
            fig.update_layout(
                legend=dict(
                    x=0.5,
                    y=-0.3,  # Adjust this value to move the legend up or down relative to the x-axis
                    xanchor="center",
                    yanchor="top",
                    orientation="h"  # Horizontal orientation
            )
        )
            st.plotly_chart(fig, use_container_width=True)
