"""
Simple Data Model Helper Library
Easy-to-understand functions for working with CDF data models.
"""
import re
from cognite.client.data_classes.data_modeling import DirectRelationReference
# Temporarily comment out config import to debug
# from config import *
from data_modeling import View


def prepare_document_properties(analysis_results):
    """
    Convert analysis results into properties for the data model.
    """
    selected_file = analysis_results['selected_file']
    overall_classification = analysis_results['overall_classification']
    classification_result = analysis_results['classification']
    
    properties = {
        'name': selected_file.name,
        'description': f"{selected_file.name}",
        'pageCount': classification_result['page_count'],
        'fileType': classification_result['file_extension'].lstrip('.').upper(),
        'docTitle': overall_classification.get('document_title', 'Not determined'),
        'equipmentUnit': overall_classification.get('equipment_unit', 'Not determined'),
        'assetsList': [overall_classification.get('equipment_tag')] if overall_classification.get('equipment_tag') and overall_classification.get('equipment_tag') != 'Not determined' else [],
        'docClassification': overall_classification.get('document_type', 'Not determined'),
        'ocrConfidence': round(analysis_results.get('ocr_confidence', 0.0), 2),
        'llmConfidence': analysis_results.get('llm_confidence', 'Unknown')
    }
    
    try:
        properties['sourceFile'] = DirectRelationReference(external_id=selected_file.name, space="d2d2")
    except Exception:
        pass
    
    return properties


def save_document_to_model(client, analysis_results, space_name="d2d2", view_name="D2DDoc"):
    """
    Complete workflow to save analysis results to the data model using the View class.
    """
    try:
        properties = prepare_document_properties(analysis_results)
        instance_id = f"doc-{analysis_results['selected_file'].name}"
        view = View(client, space_name, view_name)
        view.upsert_instance(external_id=instance_id, properties=properties, space=space_name)
        return {"success": True, "instance_id": instance_id}
    except Exception as e:
        return {"error": f"Save failed: {str(e)}", "success": False}


def get_content_segment_types_from_cdf(client, space_name="d2d2", prefix="D2DContentSegment"):
    """Get content segment types by listing views that start with the prefix."""
    try:
        all_views = client.data_modeling.views.list(space=space_name, limit=-1)
        segment_types = [
            re.sub(r'([A-Z])', r' \1', view.external_id.replace(prefix, "")).strip()
            for view in all_views if view.external_id.startswith(prefix) and view.external_id != prefix
        ]
        return sorted(filter(None, segment_types))
    except Exception as e:
        return {"error": f"Failed to get content segment types: {str(e)}", "success": False}


def get_dynamic_schema_for_content_type(client, content_type, space_name="d2d2"):
    """Get schema properties dynamically from CDF data model views using the View class."""
    try:
        clean_type = content_type.replace(" ", "").replace("(", "").replace(")", "")
        view_external_id = "D2DContentSegment" if clean_type in ["Other", "OtherUnclassified"] else f"D2DContentSegment{clean_type}"
        
        view = View(client, space_name, view_external_id)
        
        EXCLUDED_PROPERTIES = {'name', 'tags', 'aliases', 'assets', 'containedIn', 'startPage', 'endPage', 'parent', 'children', 'llmConfidence'}
        properties = {prop: "string" for prop in view.get_properties() if prop not in EXCLUDED_PROPERTIES}
        
        return {"properties": properties, "description": f"Dynamic schema for {content_type}", "success": True}
    except Exception as e:
        return {"properties": {}, "description": f"Dynamic schema for {content_type}", "error": str(e)}


def save_segments_to_model(client, segment_extractions, selected_file, space_name="d2d2"):
    """Save multiple content segments to their appropriate data model views using the View class."""
    results = {"success": True, "segments_saved": 0, "segments_failed": 0, "details": []}
    clean_filename = selected_file.name.replace(".", "_").replace(" ", "_")
    
    for segment in segment_extractions:
        try:
            segment_id = segment.get('segment_id', 0)
            content_type = segment.get('content_type', 'Other')
            pages = segment.get('pages', f'{segment_id}-{segment_id}')
            clean_type = content_type.replace(" ", "").replace("(", "").replace(")", "")
            view_name = "D2DContentSegment" if clean_type in ["Other", "OtherUnclassified"] else f"D2DContentSegment{clean_type}"
            segment_external_id = f"{clean_filename}_{pages}_{clean_type}"
            
            properties = {
                'name': segment.get('segment_title', f'Segment {segment_id}'),
                'description': f"Content segment from {selected_file.name}",
                'startPage': int(pages.split('-')[0]) if '-' in pages else segment_id,
                'endPage': int(pages.split('-')[1]) if '-' in pages else segment_id,
                'documentTitle': segment.get('segment_title', f'Segment {segment_id}'),
                'containedIn': DirectRelationReference(external_id=f"doc-{selected_file.name}", space=space_name),
                **segment.get('extracted_parameters', {})
            }

            view = View(client, space_name, view_name)
            view.upsert_instance(external_id=segment_external_id, properties=properties, space=space_name)
            
            results["segments_saved"] += 1
            results["details"].append({"segment_id": segment_id, "status": "saved", "external_id": segment_external_id, "view_name": view_name})
        except Exception as e:
            results["segments_failed"] += 1
            results["details"].append({"segment_id": segment.get('segment_id', 'unknown'), "status": "failed", "error": str(e)})

    if results["segments_failed"] > 0:
        results["success"] = False
    return results

U1_COMPONENT_CONFIG = [
    # (view_name, id_suffix, component_type, is_list)
    ("U1Form", "", "form", False),
    ("U1Vessel", "-vessel", "vessel", False),
    ("U1Jacket", "-jacket", "jacket", False),
    ("U1Shell", "-shell", "shell", True),
    ("U1Flange", "-flange", "flange", True),
    ("U1Heads", "-head", "head", True),
]

def save_u1_form_data(client, u1_json_data, asset_prefix, file_name):
    """
    Parse U1 form JSON structure and save each component to the data model.
    """
    results = {"success": True, "components_saved": 0, "components_failed": 0, "details": []}
    space_name = "d2d-formu1"
    vessel_external_id = f"U1-{asset_prefix}-vessel"
    view_cache = {}

    for view_name, id_suffix, component_type, is_list in U1_COMPONENT_CONFIG:
        if view_name not in u1_json_data:
            continue

        component_items = u1_json_data[view_name] if is_list else [u1_json_data[view_name]]
        if not isinstance(component_items, list) or not component_items:
            continue
        
        try:
            if view_name not in view_cache:
                view_cache[view_name] = View(client, space_name, view_name)
            view = view_cache[view_name]

            for i, item_data in enumerate(component_items, 1):
                if not item_data or not any(v is not None for v in item_data.values()):
                    continue
                
                ext_id_suffix = f"{id_suffix}-{i}" if is_list else id_suffix
                external_id = f"U1-{asset_prefix}{ext_id_suffix}"
                component_label = f"{view_name}-{i}" if is_list else view_name

                props = item_data.copy()
                props.update({
                    "name": external_id.replace("U1-", "", 1),
                    "description": component_type,
                    "sourceId": file_name if view_name != "U1Form" else None,
                    "parent": {"space": space_name, "externalId": vessel_external_id} if view_name not in ["U1Form", "U1Vessel"] else None,
                })
                # Filter out None values from props
                props = {k: v for k, v in props.items() if v is not None}
                
                view.upsert_instance(external_id=external_id, properties=props, space=space_name)
                results["components_saved"] += 1
                results["details"].append({"component": component_label, "status": "saved", "external_id": external_id})

        except Exception as e:
            results["components_failed"] += len(component_items)
            error_msg = f"Failed to process {view_name}: {e}"
            results["details"].append({"component": view_name, "status": "failed", "error": error_msg})

    if results["components_failed"] > 0:
        results["success"] = False
        
    return results
