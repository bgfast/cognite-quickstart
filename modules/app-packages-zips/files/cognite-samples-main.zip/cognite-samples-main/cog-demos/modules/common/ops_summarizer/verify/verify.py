#!/usr/bin/env python3
"""
Ops Summarizer Module Verification

This module verifies that the Ops Summarizer Streamlit app has been successfully deployed
by checking for the Streamlit app in CDF using the same approach as download_streamlit_from_cdf.py.
"""

import os
import sys
from typing import Dict, Any, List, Optional
from cognite.client import CogniteClient, ClientConfig
from cognite.client.credentials import OAuthClientCredentials


def get_cognite_client() -> CogniteClient:
    """Create and return a configured CogniteClient using environment variables."""
    # Check for required environment variables
    required_vars = ['CDF_PROJECT', 'CDF_CLUSTER', 'IDP_CLIENT_ID', 'IDP_CLIENT_SECRET', 'IDP_TENANT_ID']
    missing_vars = [var for var in required_vars if not os.getenv(var)]
    
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
    
    # Create OAuth credentials
    credentials = OAuthClientCredentials(
        token_url=os.getenv('IDP_TOKEN_URL', f"https://login.microsoftonline.com/{os.getenv('IDP_TENANT_ID')}/oauth2/v2.0/token"),
        client_id=os.getenv('IDP_CLIENT_ID', ''),
        client_secret=os.getenv('IDP_CLIENT_SECRET', ''),
        scopes=os.getenv('IDP_SCOPES', f"https://{os.getenv('CDF_CLUSTER')}.cognitedata.com/.default").split(),
    )
    
    # Create client config
    config = ClientConfig(
        client_name="ops-summarizer-verification",
        project=os.getenv('CDF_PROJECT', ''),
        credentials=credentials,
        base_url=os.getenv('CDF_URL', f"https://{os.getenv('CDF_CLUSTER')}.cognitedata.com"),
    )
    
    return CogniteClient(config)


def get_streamlit_apps() -> List[Dict[str, Any]]:
    """Get all available Streamlit apps from CDF."""
    try:
        client = get_cognite_client()
        # Streamlit apps are stored as -source.json files in the /streamlit-apps/ directory
        # Use limit=None to get all results, not just the first page
        apps = client.files.list(directory_prefix="/streamlit-apps/", limit=None)
        
        # Find -source.json files
        streamlit_apps = []
        for file in apps:
            if file.name and file.name.endswith("-source.json"):
                # Extract app name by removing -source.json suffix
                app_name = file.name[:-12]  # Remove "-source.json"
                streamlit_apps.append({
                    "name": app_name,
                    "external_id": file.external_id,
                    "file_id": file.id,
                    "file": file
                })
        
        return streamlit_apps
    except Exception as e:
        print(f"Error fetching Streamlit apps: {e}")
        return []


def find_ops_summarizer_app() -> Optional[Dict[str, Any]]:
    """Find the Ops Summarizer Streamlit app by name."""
    apps = get_streamlit_apps()
    
    if not apps:
        return None
    
    # Look for the external ID from the Streamlit YAML config: "ops-summarizer"
    target_external_id = "ops-summarizer"
    target_names = ["Ops Summarizer", "ops-summarizer", "ops_summarizer"]
    
    # First try to match by external_id (most reliable)
    for app in apps:
        if app.get("external_id") == target_external_id:
            # Only return if the name also matches "Ops Summarizer"
            if app["name"] == "Ops Summarizer":
                return app
    
    # Then try exact name matches (more reliable in this case)
    for app in apps:
        if app["name"] in target_names:
            return app
    
    # Try case-insensitive exact match
    for app in apps:
        app_name_lower = app["name"].lower()
        for target in target_names:
            if app_name_lower == target.lower():
                return app
    
    # Try partial matches (more flexible)
    for app in apps:
        app_name_lower = app["name"].lower()
        if "ops" in app_name_lower and "summarizer" in app_name_lower:
            return app
        if "ops" in app_name_lower and "summar" in app_name_lower:
            return app
    
    return None


def verify_module() -> Dict[str, Any]:
    """Main verification function."""
    results = {
        'module_name': 'ops_summarizer',
        'success': False,
        'checks': [],
        'summary': ''
    }
    
    try:
        # Test CDF connection
        client = get_cognite_client()
        user_info = client.iam.user_profiles.me()
        
        results['checks'].append({
            'name': 'CDF Connection',
            'success': True,
            'message': f"Connected to CDF as {user_info.email}"
        })
        
        # Check for Streamlit apps in general
        all_apps = get_streamlit_apps()
        results['checks'].append({
            'name': 'Streamlit Apps Available',
            'success': len(all_apps) > 0,
            'message': f"Found {len(all_apps)} Streamlit app(s) in CDF"
        })
        
        # Look for the specific Ops Summarizer app
        ops_app = find_ops_summarizer_app()
        app_found = ops_app is not None
        
        if app_found:
            results['checks'].append({
                'name': 'Ops Summarizer App',
                'success': True,
                'message': f"Found Ops Summarizer app: '{ops_app['name']}' (ID: {ops_app['file_id']})"
            })
        else:
            results['checks'].append({
                'name': 'Ops Summarizer App',
                'success': False,
                'message': "Ops Summarizer app not found in deployed CDF Streamlit apps. The app is visible in the UI but needs to be published/deployed to appear in the CDF files system."
            })
            
            # Show available apps for debugging
            if all_apps:
                available_names = [app['name'] for app in all_apps]
                results['checks'].append({
                    'name': 'Available Apps',
                    'success': False,
                    'message': f"Found {len(available_names)} deployed apps. The 'Ops Summarizer' app needs to be published from the Streamlit UI to appear in this list."
                })
        
        # Core success depends on finding the Ops Summarizer app
        results['success'] = app_found
        results['summary'] = f"Ops Summarizer verification {'PASSED' if app_found else 'FAILED'}"
        
    except Exception as e:
        results['checks'].append({
            'name': 'Connection',
            'success': False,
            'message': f"Error: {e}"
        })
        results['summary'] = "Ops Summarizer verification FAILED"
    
    return results


if __name__ == "__main__":
    result = verify_module()
    print(f"🔍 {result['module_name'].upper()} VERIFICATION")
    print("=" * 50)
    
    for check in result['checks']:
        status = "✅" if check['success'] else "❌"
        print(f"{status} {check['name']}: {check['message']}")
    
    print(f"\n📋 {result['summary']}")
    sys.exit(0 if result['success'] else 1)
