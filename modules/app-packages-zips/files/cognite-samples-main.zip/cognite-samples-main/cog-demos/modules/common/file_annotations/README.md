Name: File annotations
Description: Function to create file annotations
Type: Contextualization