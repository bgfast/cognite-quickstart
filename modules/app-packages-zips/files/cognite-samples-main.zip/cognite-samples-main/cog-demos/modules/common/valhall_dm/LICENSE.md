# License for the Asset Performance Management (APM) data set

Please see [Terms of Use](./Open%20Industrial%20Data%20-%20Terms%20of%20Use.pdf) for the APM data set.

The Valhall compressor operational states Jupyter Notebook is licensed under Apache-2.
