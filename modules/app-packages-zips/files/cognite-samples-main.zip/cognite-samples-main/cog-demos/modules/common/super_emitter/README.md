# Super Emitter

## Overview
The Super Emitter module provides a comprehensive dashboard for monitoring and analyzing emission data in Cognite Data Fusion. This module includes a Streamlit application for emission tracking, visualization, and reporting.

## What This Module Does
- **Creates a Streamlit application** for emission monitoring and analysis
- **Provides emission tracking tools** for environmental compliance
- **Enables data visualization** for emission trends and patterns
- **Supports environmental reporting** and compliance monitoring
- **Facilitates emission data analysis** for operational insights

## Module Components

### 1. **Streamlit Application**
- **Name**: Super Emitter
- **External ID**: `super-emitter`
- **Entrypoint**: `main.py`
- **Purpose**: Interactive emission monitoring dashboard

### 2. **Application Files**
- **Main Application**: `main.py` - Core Streamlit application logic
- **Canvas Module**: `Canvas.py` - Canvas and visualization components
- **File Utils**: `FileUtils.py` - File handling utilities
- **Library Module**: `MyLibrary.py` - Core library functions
- **Super Emitter Core**: `SuperEmitter.py` - Main emission tracking logic
- **Requirements**: `requirements.txt` - Python dependencies
- **Configuration**: `super_emitter.Streamlit.yaml` - Streamlit app configuration

### 3. **Dependencies**
- `streamlit` - Web application framework
- `cognite-sdk` - CDF client library
- `pandas` - Data manipulation
- `plotly` - Interactive visualizations
- `requests` - HTTP requests

## Configuration Requirements

### ✅ **No Variables Required!**
This module is **completely self-contained** and doesn't use any template variables (`{{variable}}`). It's designed to be plug-and-play.

### **Deployment**
- **No configuration needed** - deploy as-is
- **No environment variables required**
- **No template substitutions needed**

## Usage
Once deployed, this module provides:
- Interactive emission monitoring dashboards
- Environmental compliance tracking tools
- Emission trend analysis and visualization
- Real-time emission data monitoring
- Customizable reporting capabilities

## Verification System

### **Automated Verification**
The Super Emitter module includes an automated verification system that validates successful deployment by checking the Streamlit application deployment status via CDF API calls.

**Location**: `modules/common/super_emitter/verify/verify.py`

### **What It Verifies**
The verification script automatically checks for:

1. **CDF Connection**: Validates authentication and connection to CDF
2. **Streamlit Apps Available**: Confirms Streamlit apps are accessible in CDF
3. **Super Emitter App**: Verifies the specific "Super Emitter" app is deployed and accessible

### **How to Run Verification**

**Individual Module Verification:**
```bash
cd cog-demos
python modules/common/super_emitter/verify/verify.py
```

**Test Harness (All Modules):**
```bash
cd cog-demos
python ../scripts/test_harness.py --config config.all.yaml
```

### **Verification Output**
```
🔍 SUPER_EMITTER VERIFICATION
==================================================
✅ CDF Connection: Connected to CDF as user@example.com
✅ Streamlit Apps Available: Found 23 Streamlit app(s) in CDF
✅ Super Emitter App: Found Super Emitter app: 'Super Emitter' (ID: 1234567890123456)

📋 Super Emitter verification PASSED
```

### **Integration with Deployment**
The verification system is designed to run automatically after each successful deployment to ensure the Super Emitter Streamlit application is properly deployed and accessible.

**Key Features:**
- **External ID Matching**: Uses the correct external ID (`super-emitter`) for reliable detection
- **Name Validation**: Ensures the app name matches "Super Emitter"
- **Detailed Logging**: Shows exactly what was found and verified
- **Error Handling**: Provides clear error messages if verification fails
- **Exit Codes**: Returns proper exit codes for automated integration

## Type
Super Emitter