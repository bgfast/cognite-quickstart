import streamlit as st
from cognite.client import CogniteClient
from cognite.client.exceptions import CogniteAPIError
import time

# Initialize Cognite Client
def initialize_client():
    client = CogniteClient()
    return client

# Execute Cognite Workflow
def execute_workflow(client, workflow_name, workflow_version):
    try:
        # Execute the workflow
        execution = client.workflows.executions.run(
            workflow_external_id=workflow_name,
            version=workflow_version
        )
        return execution
    except CogniteAPIError as e:
        st.error(f"Error executing workflow: {str(e)}")
        return None

# Main Streamlit app
def main():
    st.title("Workflow Executor")
    
    try:
        client = initialize_client()
    except Exception as e:
        st.error(f"Failed to initialize Cognite client: {str(e)}")
        return

    # Configuration - replace these with your actual workflow details
    WORKFLOW_NAME = "wf_initialize_valhall"  # Replace with your workflow's external ID
    WORKFLOW_VERSION = "1"  # Replace with your workflow version

    st.write(f"Ready to execute workflow: {WORKFLOW_NAME} (version: {WORKFLOW_VERSION})")

    # Execute button
    if st.button("Execute Workflow"):
        with st.spinner("Executing workflow..."):
            execution = execute_workflow(client, WORKFLOW_NAME, WORKFLOW_VERSION)
            if execution:
                st.success("Workflow execution started!")
                st.write("Execution ID:", execution.id)
                st.write("Status:", execution.status)
                # Optionally wait for completion
                with st.spinner("Waiting for completion..."):
                    execution = client.workflows.executions.retrieve(execution.id)
                    while execution.status in ["running", "scheduled"]:
                        time.sleep(2)  # Poll every 2 seconds
                        execution = client.workflows.executions.retrieve(execution.id)
                    st.write("Final Status:", execution.status)
                    if execution.status == "completed":
                        st.write("Workflow completed successfully!")
                    elif execution.status == "failed":
                        st.error(f"Workflow failed: {execution.failure_reason}")
            else:
                st.error("Failed to start workflow execution")

if __name__ == "__main__":
    st.set_page_config(
        page_title="Workflow Executor",
        page_icon="⚙️",
        layout="wide"
    )
    main()