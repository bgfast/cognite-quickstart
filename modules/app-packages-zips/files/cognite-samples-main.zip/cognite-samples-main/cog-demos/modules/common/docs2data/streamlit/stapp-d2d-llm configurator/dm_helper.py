from typing import Dict, Any, List, Optional
from cognite.client import CogniteClient
from cognite.client.data_classes.data_modeling.instances import NodeApply, NodeOrEdgeData
from cognite.client.data_classes.data_modeling import ViewId

def populate_instance_properties(
    client: CogniteClient,
    properties_dict: Dict[str, Any],
    instance_external_id: str,
    view_external_id: str,
    view_version: str,
    space: str
) -> bool:
    """Populate instance properties. Returns True if successful."""
    view_id = ViewId(space=space, external_id=view_external_id, version=view_version)
    node_apply = NodeApply(
        space=space,
        external_id=instance_external_id,
        sources=[NodeOrEdgeData(source=view_id, properties=properties_dict)]
    )
    client.data_modeling.instances.apply([node_apply])
    return True

def get_instance_properties(
    client: CogniteClient,
    view_external_id: str,
    view_version: str,
    space: str,
    instance_external_id: str
) -> Optional[Dict[str, Any]]:
    """Get instance properties. Returns properties dict or None if not found."""
    view_id = ViewId(space=space, external_id=view_external_id, version=view_version)
    result = client.data_modeling.instances.retrieve(
        nodes=[(space, instance_external_id)],
        sources=[view_id]
    )
    if not result.nodes:
        return None
    
    instance = result.nodes[0]
    props = {}
    if hasattr(instance, "properties") and instance.properties:
        for v in instance.properties.values():
            if isinstance(v, dict):
                props.update(v)
            else:
                props = dict(instance.properties)
                break
    return props

def get_latest_view(client: CogniteClient, view_external_id: str, space: str) -> Optional[str]:
    """Get latest view version. Returns version string or None if not found."""
    views = [v for v in client.data_modeling.views.list(space=space, limit=None) if v.external_id == view_external_id]
    if not views:
        return None
    latest = max(views, key=lambda v: (v.created_time, v.last_updated_time))
    return latest.version

def get_instances(client: CogniteClient, view: str, view_version: str, view_space: str, instance_space: str) -> List[Any]:
    """Get all instances for a specific view."""
    view_id = ViewId(space=view_space, external_id=view, version=view_version)
    instances = client.data_modeling.instances.list(
        sources=[view_id],
        space=instance_space,
        limit=None
    )
    print(f"Debug: instances type = {type(instances)}")
    return list(instances)