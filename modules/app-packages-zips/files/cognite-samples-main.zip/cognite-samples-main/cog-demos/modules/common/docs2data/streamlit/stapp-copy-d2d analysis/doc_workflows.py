"""
Document Classes for D2D Analysis Utility

Encapsulates document-type-specific logic for different file types (PDF, Word, Excel, Email).
Each document type handles its own extraction, classification, and analysis workflows.
"""

import sys
import os
import io
import mimetypes
import re
import unicodedata
from pathlib import Path
from ocr import OCR


class Document:
    """Base class for all document types in the D2D Analysis Utility."""
    
    def __init__(self, client, file_metadata):
        """
        Initialize document with client and file metadata.
        
        Args:
            client: CogniteClient instance
            file_metadata: FileMetadata object from CDF
        """
        self.client = client
        self.file_metadata = file_metadata
        self.file_id = int(file_metadata.id)
        self.filename = file_metadata.name
        self.external_id = file_metadata.external_id
    
    @classmethod
    def create(cls, client, file_metadata):
        """
        Factory method to create appropriate document subclass based on file extension.
        
        Args:
            client: CogniteClient instance
            file_metadata: FileMetadata object from CDF
            
        Returns:
            Document subclass instance
        """
        if not file_metadata.name:
            return UnsupportedDocument(client, file_metadata)
            
        extension = Path(file_metadata.name).suffix.lower()
        
        if extension == '.pdf':
            return PDFDocument(client, file_metadata)
        elif extension in ['.doc', '.docx']:
            return WordDocument(client, file_metadata)
        elif extension in ['.xls', '.xlsx']:
            return ExcelDocument(client, file_metadata)
        elif extension == '.msg':
            return EmailDocument(client, file_metadata)
        else:
            return UnsupportedDocument(client, file_metadata)
    
    def get_basic_info(self):
        """
        Get basic file classification information.
        
        Returns:
            dict: File classification details
        """
        try:
            filename = self.filename or "unknown_file"
            file_extension = Path(filename).suffix.lower()
            
            # Basic file types
            file_types = {
                '.pdf': 'PDF Document',
                '.doc': 'Word Document (Legacy)',
                '.docx': 'Word Document',
                '.xls': 'Excel Spreadsheet (Legacy)',
                '.xlsx': 'Excel Spreadsheet',
                '.ppt': 'PowerPoint Presentation (Legacy)',
                '.pptx': 'PowerPoint Presentation',
                '.msg': 'Outlook Email Message',
                '.eml': 'Email Message',
                '.png': 'PNG Image',
                '.jpg': 'JPEG Image',
                '.jpeg': 'JPEG Image',
                '.tiff': 'TIFF Image',
                '.tif': 'TIFF Image',
                '.bmp': 'Bitmap Image',
                '.csv': 'CSV Data File',
                '.txt': 'Text File',
                '.xml': 'XML Document',
                '.json': 'JSON Data File'
            }
            
            # Determine file type
            if file_extension in file_types:
                file_type = file_types[file_extension]
            else:
                file_type = "Unknown/Unsupported"
            
            # Get MIME type
            mime_type, _ = mimetypes.guess_type(filename)
            mime_type = mime_type or "application/octet-stream"
            
            # Get page count for PDFs
            page_count = 0
            if file_extension == '.pdf':
                try:
                    import pypdf
                    file_content = self.client.files.download_bytes(self.file_metadata.id)
                    pdf_reader = pypdf.PdfReader(io.BytesIO(file_content))
                    page_count = len(pdf_reader.pages)
                except Exception:
                    # If fails, default to 1 page
                    page_count = 1
            else:
                page_count = 1
            
            # Determine processing capabilities
            can_process_ocr = file_extension in ['.pdf', '.png', '.jpg', '.jpeg', '.tiff', '.tif']
            can_process_text = file_extension in ['.pdf', '.doc', '.docx', '.txt']
            
            return {
                "file_type": file_type,
                "file_extension": file_extension,
                "mime_type": mime_type,
                "page_count": page_count,
                "can_process_ocr": can_process_ocr,
                "can_process_text": can_process_text,
                "error_message": None,
                "success": True
            }
            
        except Exception as e:
            return {
                "file_type": "Unknown",
                "file_extension": "",
                "mime_type": "application/octet-stream",
                "page_count": 0,
                "can_process_ocr": False,
                "can_process_text": False,
                "error_message": str(e),
                "success": False
            }
    
    def extract_text(self, **kwargs):
        raise NotImplementedError("Subclasses must implement extract_text method")
    
    def get_content_segment_types(self):
        raise NotImplementedError("Subclasses must implement get_content_segment_types method")
    
    def analyze_for_classification(self, **kwargs):
        raise NotImplementedError("Subclasses must implement analyze_for_classification method")
    
    def analyze_for_content_segments(self, **kwargs):
        raise NotImplementedError("Subclasses must implement analyze_for_content_segments method")
    
    def extract_segment_content(self, start_page, end_page):
        raise NotImplementedError("Subclasses must implement extract_segment_content method")
    
    def is_supported(self):
        """Check if this document type is supported."""
        return True
    
    @staticmethod
    def _clean_extracted_text(raw_text):
        """
        Clean and format text extracted from documents.
        Handles common issues like bytes, unicode characters, excess whitespace.
        
        Args:
            raw_text: Raw text content (could be bytes or string)
            
        Returns:
            str: Cleaned and formatted text
        """
        if not raw_text:
            return ""
        
        # Handle bytes objects
        if isinstance(raw_text, bytes):
            try:
                # Try UTF-8 first
                text = raw_text.decode('utf-8')
            except UnicodeDecodeError:
                try:
                    # Fallback to latin-1
                    text = raw_text.decode('latin-1')
                except UnicodeDecodeError:
                    # Last resort - ignore errors
                    text = raw_text.decode('utf-8', errors='ignore')
        else:
            text = str(raw_text)
        
        # Remove byte string prefixes if they exist
        if text.startswith("b'") and text.endswith("'"):
            text = text[2:-1]
        
        # Fix common unicode issues
        unicode_fixes = {
            '\\xe2\\x80\\x98': "'",  # Left single quotation mark
            '\\xe2\\x80\\x99': "'",  # Right single quotation mark
            '\\xe2\\x80\\x9c': '"',  # Left double quotation mark
            '\\xe2\\x80\\x9d': '"',  # Right double quotation mark
            '\\xe2\\x80\\xa6': '...',  # Horizontal ellipsis
            '\\xe2\\x80\\x93': '-',  # En dash
            '\\xe2\\x80\\x94': '--', # Em dash
            '\\xa0': ' ',          # Non-breaking space
            '\\r\\n': '\\n',         # Windows line endings
            '\\r': '\\n',           # Mac line endings
        }
        
        for bad_char, good_char in unicode_fixes.items():
            text = text.replace(bad_char, good_char)
        
        # Normalize unicode characters
        text = unicodedata.normalize('NFKD', text)
        
        # Clean up whitespace
        # Replace multiple consecutive spaces with single space
        text = re.sub(r' +', ' ', text)
        
        # Replace multiple consecutive newlines with double newline
        text = re.sub(r'\\n\\s*\\n\\s*\\n+', '\\n\\n', text)
        
        # Remove leading/trailing whitespace from each line
        lines = text.split('\\n')
        lines = [line.strip() for line in lines]
        text = '\\n'.join(lines)
        
        # Remove excessive blank lines at start and end
        text = text.strip()
        
        return text


class PDFDocument(Document):
    """PDF document handler using OCR for text extraction."""
    
    def __init__(self, client, file_metadata):
        super().__init__(client, file_metadata)
        self.ocr_instance = None
    
    def extract_text(self, start_page=1, end_page=None):
        """
        Extract text from PDF using OCR.
        
        Args:
            start_page (int): Starting page (default 1)
            end_page (int): Ending page (optional)
            
        Returns:
            str: Extracted text content
        """
        if not self.ocr_instance:
            self.ocr_instance = OCR(self.client, self.file_id)
        
        try:
            extracted_text = self.ocr_instance.get_text(start_page, end_page)
            if not extracted_text or not extracted_text.strip():
                print(f"No text extracted from OCR for file ID {self.file_id}, pages {start_page}-{end_page}")
                return None
            return extracted_text
        except RuntimeError as e:
            print(f"OCR extraction failed for file ID {self.file_id}, pages {start_page}-{end_page}: {str(e)}")
            return None
    
    def get_confidence(self, start_page=1, end_page=None):
        """
        Get OCR confidence for specified page range.
        
        Args:
            start_page (int): Starting page
            end_page (int): Ending page
            
        Returns:
            float: OCR confidence score
        """
        if self.ocr_instance:
            return self.ocr_instance.calculate_confidence(start_page, end_page)
        return None
    
    def get_content_segment_types(self):
        """Get PDF-specific content segment types."""
        return [
            "Technical Drawing",
            "Piping Diagram", 
            "Equipment Specification",
            "Inspection Report",
            "Test Results",
            "Safety Procedure",
            "Operating Procedure",
            "Maintenance Record",
            "Design Document",
            "Engineering Analysis"
        ]
    
    def analyze_for_classification(self, num_pages=3):
        """
        Complete PDF classification workflow.
        
        Args:
            num_pages (int): Number of pages to analyze
            
        Returns:
            dict: Classification analysis results
        """
        from LLM_workflows import quick_analyze_page, quick_classify_document
        
        results = {"selected_file": self.file_metadata}
        
        # Step 1: File Classification
        classification = self.get_basic_info()
        if not classification.get("success"):
            return {"error": f"File classification failed: {classification.get('error_message')}"}
        results['classification'] = classification
        
        # Step 2: OCR Analysis
        text_content = self.extract_text(1, num_pages)
        if not text_content:
            return {"error": "Failed to extract text from PDF"}
        
        # Process each page for summaries
        page_summaries = []
        for page_num in range(1, num_pages + 1):
            page_content = self.extract_text(page_num, page_num)
            if page_content:
                summary = quick_analyze_page(self.client, page_content, page_num, self.filename)
                if 'error' not in summary:
                    page_summaries.append(summary)
        
        if not page_summaries:
            return {"error": "No valid page summaries generated"}
        
        results['page_summaries'] = page_summaries
        
        # Step 3: Overall Classification
        overall_classification = quick_classify_document(self.client, page_summaries, self.filename)
        if 'error' in overall_classification:
            return {"error": f"Overall classification failed: {overall_classification['error']}"}
        
        results['overall_classification'] = overall_classification
        results['ocr_confidence'] = self.get_confidence(1, num_pages)
        results['llm_confidence'] = overall_classification.get('confidence_level', 'Unknown')
        
        return results
    
    def analyze_for_content_segments(self, max_pages=30):
        """
        Complete PDF content segment analysis.
        
        Args:
            max_pages (int): Maximum pages to analyze
            
        Returns:
            dict: Content segment analysis results
        """
        from LLM_workflows import analyze_page_content, enhanced_determine_content_boundaries
        from dm_helper import get_content_segment_types_from_cdf
        
        results = {
            "selected_file": self.file_metadata,
            "max_pages": max_pages,
            "success": False
        }
        
        # Get content segment types from CDF
        content_segment_types = get_content_segment_types_from_cdf(self.client)
        if isinstance(content_segment_types, dict) and "error" in content_segment_types:
            return results
        results["content_segment_types"] = content_segment_types
        
        # Initialize OCR instance
        if not self.ocr_instance:
            self.ocr_instance = OCR(self.client, self.file_id)
        
        # Analyze each page
        page_analyses = []
        previous_page_summary = None
        
        for page_number in range(1, max_pages + 1):
            page_content = self.ocr_instance.get_text(page_number, page_number)
            
            if page_content and page_content.strip():
                analysis = analyze_page_content(
                    self.client, page_content, page_number, content_segment_types, 
                    previous_page_summary, self.filename
                )
                
                if analysis:
                    page_analyses.append(analysis)
                    previous_page_summary = analysis.get('page_summary')
                else:
                    page_analyses.append({
                        "page_number": page_number,
                        "error": "Page analysis failed"
                    })
        
        results["page_analyses"] = page_analyses
        
        # Determine content boundaries
        boundary_result = enhanced_determine_content_boundaries(
            self.client, page_analyses, content_segment_types, self.filename
        )
        
        if not boundary_result or "error" in boundary_result:
            return results
        
        content_segments = boundary_result.get("content_segments", [])
        overall_classification = boundary_result.get("overall_package_classification", "Not determined")
        
        results.update({
            "content_segments": content_segments,
            "overall_package_classification": overall_classification,
            "boundary_analysis": boundary_result,
            "success": True
        })
        
        return results
    
    def extract_segment_content(self, start_page, end_page):
        """Extract content for PDF segment."""
        if not self.ocr_instance:
            self.ocr_instance = OCR(self.client, self.file_id)
        
        return self.ocr_instance.get_text(start_page, end_page)


class WordDocument(Document):
    """Word document handler using Documents API."""
    
    def extract_text(self):
        """Extract text from Word document."""
        try:
            # Use CDF Documents API to retrieve content directly
            raw_text = self.client.documents.retrieve_content(self.file_id)
            
            # Clean and format the text
            cleaned_text = self._clean_extracted_text(raw_text)
            
            return cleaned_text
            
        except Exception as e:
            print(f"Failed to extract text from Word document using Documents API: {e}")
            print("Note: This might mean the Documents API is not available in your CDF version")
            print("or the file is not supported by the Documents API")
            return None
    
    def get_content_segment_types(self):
        """Get Word-specific content segment types."""
        return [
            "Inspection Report",
            "Technical Specification", 
            "Operating Procedure",
            "Maintenance Record",
            "Test Report",
            "Design Document",
            "Safety Document",
            "Compliance Document",
            "Engineering Analysis",
            "Data Sheet"
        ]
    
    def analyze_for_classification(self):
        """Complete Word document classification workflow."""
        from LLM_workflows import classify_non_pdf_file_with_ai
        
        results = {"selected_file": self.file_metadata}
        
        # Step 1: File Classification
        classification = self.get_basic_info()
        if classification.get("error_message"):
            return {"error": f"File classification failed: {classification['error_message']}"}
        results['classification'] = classification
        
        # Step 2: Text Extraction
        cleaned_text = self.extract_text()
        if not cleaned_text:
            return {"error": "Failed to extract text from Word document"}
        
        # Step 3: AI Classification
        overall_classification = classify_non_pdf_file_with_ai(
            client=self.client,
            document_content=cleaned_text,
            content_segment_types=self.get_content_segment_types(),
            file_name=self.filename
        )
        
        if 'error' in overall_classification:
            return {"error": f"AI classification failed: {overall_classification['error']}"}
        
        results['overall_classification'] = overall_classification
        results['ocr_confidence'] = 1.0  # Direct text extraction, no OCR uncertainty
        results['llm_confidence'] = overall_classification.get('confidence_level', 'Unknown')
        
        return results
    
    def analyze_for_content_segments(self, max_pages=None):
        """Complete Word content segment analysis."""
        from LLM_workflows import determine_content_segments_with_ai
        from dm_helper import get_content_segment_types_from_cdf
        
        results = {"selected_file": self.file_metadata, "success": False}
        
        # Get content segment types from CDF
        content_segment_types = get_content_segment_types_from_cdf(self.client)
        if isinstance(content_segment_types, dict) and "error" in content_segment_types:
            return results
        results["content_segment_types"] = content_segment_types
        
        # Extract text content
        cleaned_text = self.extract_text()
        if not cleaned_text:
            return results
        results["document_content"] = cleaned_text
        
        # AI Content Segmentation
        boundary_result = determine_content_segments_with_ai(
            client=self.client,
            segment_content=cleaned_text,
            content_segment_types=content_segment_types
        )
        
        if not boundary_result or "error" in boundary_result:
            return results
        
        content_segments = boundary_result.get("content_segments", [])
        overall_classification = boundary_result.get("overall_package_classification", "Not determined")
        
        results.update({
            "content_segments": content_segments,
            "overall_package_classification": overall_classification,
            "boundary_analysis": boundary_result,
            "success": True
        })
        
        return results
    
    def extract_segment_content(self, start_page, end_page):
        """For Word docs, return full content (no page-based segments)."""
        return self.extract_text()


class ExcelDocument(Document):
    """Excel document handler using Documents API."""
    
    def extract_text(self):
        """Extract text from Excel document."""
        try:
            # Use Documents API for Excel files
            text_content = self.client.documents.retrieve_content(self.file_id)
            
            if text_content:
                return self._clean_extracted_text(text_content)
            
            return None
            
        except Exception as e:
            print(f"Failed to extract text from Excel document: {e}")
            return None
    
    def get_content_segment_types(self):
        """Get Excel-specific content segment types."""
        return [
            "Data Sheet",
            "Inspection Record",
            "Test Results", 
            "Equipment Log",
            "Maintenance Record",
            "Calculation Sheet",
            "Measurement Data",
            "Performance Data",
            "Inventory List",
            "Technical Specification"
        ]
    
    def analyze_for_classification(self):
        """Complete Excel document classification workflow."""
        from LLM_workflows import classify_non_pdf_file_with_ai
        
        results = {"selected_file": self.file_metadata}
        
        # Step 1: File Classification
        classification = self.get_basic_info()
        if classification.get("error_message"):
            return {"error": f"File classification failed: {classification['error_message']}"}
        results['classification'] = classification
        
        # Step 2: Data Extraction
        cleaned_text = self.extract_text()
        if not cleaned_text:
            return {"error": "Failed to extract data from Excel document"}
        
        # Step 3: AI Classification
        overall_classification = classify_non_pdf_file_with_ai(
            client=self.client,
            document_content=cleaned_text,
            content_segment_types=self.get_content_segment_types(),
            file_name=self.filename
        )
        
        if 'error' in overall_classification:
            return {"error": f"AI classification failed: {overall_classification['error']}"}
        
        results['overall_classification'] = overall_classification
        results['ocr_confidence'] = 1.0  # Direct text extraction, no OCR uncertainty
        results['llm_confidence'] = overall_classification.get('confidence_level', 'Unknown')
        
        return results
    
    def analyze_for_content_segments(self, max_pages=None):
        """Complete Excel content segment analysis."""
        from LLM_workflows import determine_content_segments_with_ai
        from dm_helper import get_content_segment_types_from_cdf
        
        results = {"selected_file": self.file_metadata, "success": False}
        
        # Get content segment types from CDF
        content_segment_types = get_content_segment_types_from_cdf(self.client)
        if isinstance(content_segment_types, dict) and "error" in content_segment_types:
            return results
        results["content_segment_types"] = content_segment_types
        
        # Extract data content
        cleaned_text = self.extract_text()
        if not cleaned_text:
            return results
        results["document_content"] = cleaned_text
        
        # AI Content Segmentation
        boundary_result = determine_content_segments_with_ai(
            client=self.client,
            segment_content=cleaned_text,
            content_segment_types=content_segment_types
        )
        
        if not boundary_result or "error" in boundary_result:
            return results
        
        content_segments = boundary_result.get("content_segments", [])
        overall_classification = boundary_result.get("overall_package_classification", "Not determined")
        
        results.update({
            "content_segments": content_segments,
            "overall_package_classification": overall_classification,
            "boundary_analysis": boundary_result,
            "success": True
        })
        
        return results
    
    def extract_segment_content(self, start_page, end_page):
        """For Excel docs, return full content (no page-based segments)."""
        return self.extract_text()


class EmailDocument(Document):
    """Email/MSG document handler using Documents API."""
    
    def extract_text(self):
        """Extract text from email document."""
        try:
            # Use Documents API for MSG files
            text_content = self.client.documents.retrieve_content(self.file_id)
            
            if text_content:
                return self._clean_extracted_text(text_content)
            
            return None
            
        except Exception as e:
            print(f"Failed to extract text from MSG document: {e}")
            return None
    
    def get_content_segment_types(self):
        """Get Email-specific content segment types."""
        return [
            "Email Communication",
            "Technical Discussion",
            "Project Communication",
            "Incident Report Email",
            "Maintenance Communication",
            "Equipment Discussion",
            "Safety Alert",
            "Operational Update",
            "Status Report",
            "Approval Request"
        ]
    
    def analyze_for_classification(self):
        """Complete email document classification workflow."""
        from LLM_workflows import classify_non_pdf_file_with_ai
        
        results = {"selected_file": self.file_metadata}
        
        # Step 1: File Classification
        classification = self.get_basic_info()
        if classification.get("error_message"):
            return {"error": f"File classification failed: {classification['error_message']}"}
        results['classification'] = classification
        
        # Step 2: Email Content Extraction
        cleaned_text = self.extract_text()
        if not cleaned_text:
            return {"error": "Failed to extract content from MSG document"}
        
        # Step 3: AI Classification
        overall_classification = classify_non_pdf_file_with_ai(
            client=self.client,
            document_content=cleaned_text,
            content_segment_types=self.get_content_segment_types(),
            file_name=self.filename
        )
        
        if 'error' in overall_classification:
            return {"error": f"AI classification failed: {overall_classification['error']}"}
        
        results['overall_classification'] = overall_classification
        results['ocr_confidence'] = 1.0  # Direct text extraction, no OCR uncertainty
        results['llm_confidence'] = overall_classification.get('confidence_level', 'Unknown')
        
        return results
    
    def analyze_for_content_segments(self, max_pages=None):
        """Complete email content segment analysis."""
        from LLM_workflows import determine_content_segments_with_ai
        from dm_helper import get_content_segment_types_from_cdf
        
        results = {"selected_file": self.file_metadata, "success": False}
        
        # Get content segment types from CDF
        content_segment_types = get_content_segment_types_from_cdf(self.client)
        if isinstance(content_segment_types, dict) and "error" in content_segment_types:
            return results
        results["content_segment_types"] = content_segment_types
        
        # Extract email content
        cleaned_text = self.extract_text()
        if not cleaned_text:
            return results
        results["document_content"] = cleaned_text
        
        # AI Content Segmentation
        boundary_result = determine_content_segments_with_ai(
            client=self.client,
            segment_content=cleaned_text,
            content_segment_types=content_segment_types
        )
        
        if not boundary_result or "error" in boundary_result:
            return results
        
        content_segments = boundary_result.get("content_segments", [])
        overall_classification = boundary_result.get("overall_package_classification", "Not determined")
        
        results.update({
            "content_segments": content_segments,
            "overall_package_classification": overall_classification,
            "boundary_analysis": boundary_result,
            "success": True
        })
        
        return results
    
    def extract_segment_content(self, start_page, end_page):
        """For email docs, return full content (no page-based segments)."""
        return self.extract_text()


class UnsupportedDocument(Document):
    """Handler for unsupported document types."""
    
    def extract_text(self, **kwargs):
        """Unsupported documents cannot extract text."""
        return None
    
    def get_content_segment_types(self):
        """No content segment types for unsupported documents."""
        return []
    
    def analyze_for_classification(self, **kwargs):
        """Cannot analyze unsupported documents."""
        return {"error": f"Unsupported file type: {self.filename}"}
    
    def analyze_for_content_segments(self, **kwargs):
        """Cannot analyze unsupported documents."""
        return {"selected_file": self.file_metadata, "success": False, "error": f"Unsupported file type: {self.filename}"}
    
    def extract_segment_content(self, start_page, end_page):
        """Cannot extract from unsupported documents."""
        return None
    
    def is_supported(self):
        """Unsupported documents return False."""
        return False
