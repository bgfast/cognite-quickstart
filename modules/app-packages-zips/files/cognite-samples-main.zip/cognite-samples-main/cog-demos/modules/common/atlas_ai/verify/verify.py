#!/usr/bin/env python3
"""
Atlas AI Module Verification
"""

import os
import sys
from typing import Dict, Any
from cognite.client import CogniteClient
from cognite.client.config import ClientConfig
from cognite.client.credentials import OAuthClientCredentials


def get_cdf_client() -> CogniteClient:
    """Initialize CDF client."""
    project = os.getenv('CDF_PROJECT')
    cluster = os.getenv('CDF_CLUSTER')
    client_id = os.getenv('IDP_CLIENT_ID')
    client_secret = os.getenv('IDP_CLIENT_SECRET')
    token_url = os.getenv('IDP_TOKEN_URL')
    scopes = os.getenv('IDP_SCOPES', '').split(',')
    
    credentials = OAuthClientCredentials(
        token_url=token_url,
        client_id=client_id,
        client_secret=client_secret,
        scopes=scopes
    )
    
    config = ClientConfig(
        client_name="atlas-ai-verification",
        project=project,
        base_url=f"https://{cluster}.cognitedata.com",
        credentials=credentials
    )
    
    return CogniteClient(config)


def verify_module() -> Dict[str, Any]:
    """Main verification function."""
    results = {
        'module_name': 'atlas_ai',
        'success': False,
        'checks': [],
        'summary': ''
    }
    
    try:
        client = get_cdf_client()
        user_info = client.iam.user_profiles.me()
        
        # Test space
        spaces = client.data_modeling.spaces.list()
        space_found = any(space.space == "cognite-atlas-ai" for space in spaces)
        results['checks'].append({
            'name': 'Space',
            'success': space_found,
            'message': f"Space {'found' if space_found else 'not found'}"
        })
        
        # Test data model
        data_models = client.data_modeling.data_models.list()
        dm_found = any(dm.external_id == "CogniteAtlasAI" for dm in data_models)
        results['checks'].append({
            'name': 'Data Model',
            'success': dm_found,
            'message': f"Data Model {'found' if dm_found else 'not found'}"
        })
        
        # Test container (with pagination to avoid limit issues)
        containers = client.data_modeling.containers.list(limit=1000)
        container_found = any(c.external_id == "AIAgent" and c.space == "cognite-atlas-ai" for c in containers)
        results['checks'].append({
            'name': 'Container',
            'success': container_found,
            'message': f"Container {'found' if container_found else 'not found'} (checked {len(containers)} containers)"
        })
        
        # Test view (with pagination to avoid limit issues)
        views = client.data_modeling.views.list(limit=1000)
        view_found = any(v.external_id == "AIAgent" and v.space == "cognite-atlas-ai" for v in views)
        results['checks'].append({
            'name': 'View',
            'success': view_found,
            'message': f"View {'found' if view_found else 'not found'} (checked {len(views)} views)"
        })
        
        # Core components must be present (space, data model, container, view)
        # Note: Access group check removed as it's not critical for functionality
        core_success = space_found and dm_found and container_found and view_found
        results['success'] = core_success
        results['summary'] = f"Atlas AI verification {'PASSED' if core_success else 'FAILED'}"
        
    except Exception as e:
        results['checks'].append({
            'name': 'Connection',
            'success': False,
            'message': f"Error: {e}"
        })
        results['summary'] = "Atlas AI verification FAILED"
    
    return results


if __name__ == "__main__":
    result = verify_module()
    print(f"🔍 {result['module_name'].upper()} VERIFICATION")
    print("=" * 40)
    
    for check in result['checks']:
        status = "✅" if check['success'] else "❌"
        print(f"{status} {check['name']}: {check['message']}")
    
    print(f"\n📋 {result['summary']}")
    sys.exit(0 if result['success'] else 1)
