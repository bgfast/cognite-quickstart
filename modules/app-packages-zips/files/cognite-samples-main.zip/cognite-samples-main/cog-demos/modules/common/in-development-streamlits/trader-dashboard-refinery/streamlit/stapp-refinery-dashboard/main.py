import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
import random
import numpy as np
import os
import logging

# --- Demo Script Functionality ---
def load_demo_script():
    """Load the demo script from the markdown file with robust path resolution and fallback."""
    
    # Embedded fallback content for when file can't be loaded
    fallback_content = """
# ⛽ Oil Refinery Trading Dashboard - Demo Script
**Duration: 8-10 minutes | Business Value Story**

---

## 👥 **PERSONAS**

**🎯 CARLOS MARTINEZ** - Senior Refined Products Trader  
*16 years experience at RefineCorp Global, manages $250M refined products portfolio*  
*Specializes in gasoline, diesel, and jet fuel trading across North American markets*  
*Known for his expertise in crack spread optimization and seasonal demand patterns*  
*Currently under pressure to improve refining margins by 22% amid volatile crude costs*

**⚙️ JENNIFER WONG** - Refinery Operations Manager  
*13 years experience, oversees 5 refinery complexes across Texas, Louisiana, and California*  
*Former process engineer with expertise in crude distillation and catalytic cracking*  
*Responsible for $60M in annual refinery optimization initiatives*  
*Leading digital initiatives to improve crude-to-products yield optimization*

---

## 🌅 **SETTING THE SCENE**
*It's 7:15 AM on a Thursday morning at RefineCorp's Denver trading center. Carlos is monitoring refined product futures that opened higher on inventory concerns, while Brent crude is volatile due to OPEC production uncertainties. Jennifer is at the central operations center coordinating multiple Gulf Coast and West Coast refineries. Carlos has significant exposure to gasoline and diesel contracts with delivery commitments to major fuel distributors.*

---

## 🎬 **SCENE 1: The Crisis Unfolds (0:00 - 2:00)**

**CARLOS** *(monitoring multiple screens with product curves, crack spreads, and inventory reports)*  
"Jennifer, we've got a serious margin squeeze developing. Brent crude spiked $3.50 overnight on supply concerns, but gasoline futures are only up $2.20. My crack spreads are getting crushed, and I've got major distributors expecting 40,000 barrels of gasoline and 25,000 barrels of diesel over the next two weeks."

**JENNIFER** *(video call from operations center, with refinery unit displays in background)*  
"I saw the crude move. What are your current crack spreads looking like?"

**CARLOS** *(analyzing trading screens)*  
"RBOB gasoline cracks dropped from $28/barrel to $24.70, and ULSD diesel cracks are down to $31.20 from $34.50 yesterday. I need to know our refinery yields and production flexibility - can we shift our product slate to maximize diesel output?"

---

## 📊 **SCENE 2: Dashboard Deep Dive (2:00 - 5:00)**

**JENNIFER**  
"Let me show you our real-time refinery operations using our integrated dashboard..."

### **Key Dashboard Interactions:**

1. **Enterprise-Wide Refinery Overview**
   - Navigate to Enterprise-Wide view
   - Point out: 5 refineries, 310,000 bpd total crude capacity
   - Current throughput: 285,000 bpd (92% utilization)
   - Product yield breakdown: 45% gasoline, 25% diesel, 15% jet fuel, 15% other

2. **Regional Focus - Gulf Coast**
   - Switch to Region-Wide filter
   - Highlight: Texas Coast and Louisiana refineries
   - Combined capacity: 185,000 bpd, optimal for diesel maximization

3. **Unit Operations Analysis**
   - Click on Texas Coast Refinery showing optimal status
   - Catalytic cracker running at 95% capacity
   - Diesel yield potential: can increase from 25% to 32% with unit adjustments

4. **Crude Slate & Yield Optimization**
   - Show crude oil quality vs. product yields
   - Heavy crude processing advantages for diesel production
   - Inventory: 12-day crude supply, 8-day product inventory

---

## 💡 **SCENE 3: Strategic Decision Making (5:00 - 8:00)**

**CARLOS**  
"Perfect! I can see we have the flexibility. If we can boost diesel yields to 32%, that's an extra 7,000 barrels per day. With current crack spreads, that's worth $220K more per day."

**JENNIFER**  
"Absolutely. We can optimize our FCC unit parameters and adjust our crude slate toward heavier grades. The Louisiana refinery is particularly well-suited for this - we can implement the changes within 48 hours."

**CARLOS**  
"Excellent strategic positioning:
- **Immediate**: Reduce gasoline production commitments by 8,000 bpd
- **Optimize**: Increase diesel output to capture $31/barrel cracks
- **Hedge**: Lock in crude purchases for heavy grade feedstock"

### **Business Impact Demonstrated:**

**Before Dashboard:**
- Phone calls to each refinery (60+ minutes)
- Conservative yield assumptions
- Missed optimization opportunities
- Reactive trading strategies

**With Dashboard:**
- Real-time yield and unit visibility (4 minutes)
- Proactive product slate optimization
- Data-driven crude purchasing decisions
- **Result**: Additional $1.54M profit opportunity over 2 weeks

---

## 🎯 **SCENE 4: Refinery-Trading Integration (8:00 - 10:00)**

**CARLOS**  
"Jennifer, this integrated view is revolutionary. While other traders are making crude-to-products decisions in isolation, we're optimizing our entire value chain in real-time."

**JENNIFER**  
"Exactly. From the operations side, I can adjust our unit operations based on your forward curves, optimize our maintenance scheduling around your trading positions, and ensure we're maximizing every barrel of throughput."

### **Quantified Business Value:**
- **Crack Spread Optimization**: 22% margin improvement ($55M annual impact)
- **Decision Speed**: 15x faster (60 min → 4 min)
- **Yield Optimization**: $2.8M additional monthly revenue
- **Crude Purchasing**: $1.2M saved annually through better timing
- **Inventory Management**: $800K working capital optimization

---

## 🔧 **Key Features Demonstrated:**

✅ **Real-time Refinery Operations**  
✅ **Product Yield Optimization**  
✅ **Crack Spread Analytics**  
✅ **Crude Slate Planning**  
✅ **Unit Performance Monitoring**  
✅ **Inventory Management**  
✅ **Market-Operations Integration**

---

## 📈 **ROI Summary:**
- **Implementation Cost**: $1.1M
- **Annual Benefit**: $59.8M
- **Payback Period**: 6.7 days
- **3-Year NPV**: $167M

---

*This dashboard transforms refinery trading from reactive to proactive, enabling integrated crude-to-products optimization that maximizes refining margins and operational efficiency.*
"""
    
    try:
        # Get the directory of the current script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Multiple path attempts for different deployment scenarios
        possible_paths = [
            # Local development path (original)
            os.path.join(os.path.dirname(os.path.dirname(current_dir)), "DEMO_SCRIPT.md"),
            # Container deployment paths
            os.path.join("/app", "DEMO_SCRIPT.md"),
            os.path.join("/app", "trader-dashboard-refinery", "DEMO_SCRIPT.md"),
            # Relative to current directory
            os.path.join(current_dir, "DEMO_SCRIPT.md"),
            os.path.join(current_dir, "..", "..", "DEMO_SCRIPT.md"),
            # Working directory
            "DEMO_SCRIPT.md",
            "./DEMO_SCRIPT.md"
        ]
        
        # Try each path
        for path in possible_paths:
            try:
                if os.path.exists(path):
                    with open(path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():  # Ensure file is not empty
                            return content
            except Exception as path_error:
                # Log individual path failures but continue trying
                logging.warning(f"Failed to load demo script from {path}: {path_error}")
                continue
        
        # If no file found, return fallback content
        logging.info("Demo script file not found in any expected location, using embedded fallback content")
        return fallback_content
        
    except Exception as e:
        # Final fallback with error info
        logging.error(f"Error in load_demo_script: {str(e)}")
        return f"""
# Demo Script Loading Error

**Error Details:** {str(e)}

**Fallback Content:**

{fallback_content}
"""

# --- Global Definitions for Data Simulation ---
# These lists are now defined globally to be accessible throughout the app
regions = ["North America", "Europe", "Asia Pacific", "South America"]
products = ["Gasoline", "Diesel", "Jet Fuel", "Heavy Fuel Oil", "Naphtha", "LPG", "Lubricants"]
equipment_types = ["Crude Distillation Unit", "Catalytic Cracker", "Reformer", "Hydrotreater", "Coker", "Alkylation Unit", "Blending Unit"]
status_options = ["Optimal", "Minor Deviation", "Planned Maintenance", "Significant Outage", "Shutdown"]
incident_causes = ["Mechanical Failure", "Power Outage", "Process Upset", "Crude Quality Issue", "Scheduled Inspection", "Force Majeure"]
outlook_options = ["Improving", "Stable", "Worsening", "Under Review", "Recovering"]

# Simulate Trader's Book of Business (specific customers/products) - Global
trader_books = {
    "Trader A (Transportation)": {"Products": ["Gasoline", "Diesel", "Jet Fuel"]},
    "Trader B (Industrial)": {"Products": ["Heavy Fuel Oil", "Naphtha", "LPG"]},
    "Trader C (Marine/Aviation)": {"Products": ["Jet Fuel", "Heavy Fuel Oil", "Lubricants"]},
    "Trader D (General)": {"Products": products}
}


# --- Hard-Coded Data Simulation (Representing Real-Life Numbers for 20 Plants) ---

def get_hardcoded_plant_data(num_plants=20):
    """
    Generates hard-coded data for 20 oil refineries, simulating various operational states.
    Uses representative refinery names and distributes them across regions.
    """
    plants_template = [
        {"name": "Texas City Refinery", "region": "North America"},
        {"name": "Louisiana Coast Refinery", "region": "North America"},
        {"name": "Gulf Coast Integrated Refinery", "region": "North America"},
        {"name": "Houston Ship Channel Refinery", "region": "North America"},
        {"name": "Baytown Refinery Complex", "region": "North America"}, # Specific for demo
        {"name": "East Coast Processing Refinery", "region": "North America"},
        {"name": "California Central Valley Refinery", "region": "North America"},
        {"name": "Mediterranean Coastal Refinery", "region": "Europe"},
        {"name": "Rhine Valley Refinery", "region": "Europe"}, # Specific for demo
        {"name": "North Sea Coastal Refinery", "region": "Europe"},
        {"name": "Rotterdam Integrated Refinery", "region": "Europe"},
        {"name": "UK Thames Estuary Refinery", "region": "Europe"},
        {"name": "Italian Adriatic Refinery", "region": "Europe"},
        {"name": "Spanish Mediterranean Refinery", "region": "Europe"},
        {"name": "Yangtze Delta Refinery", "region": "Asia Pacific"}, # China
        {"name": "Pearl River Delta Refinery", "region": "Asia Pacific"}, # China
        {"name": "South China Coastal Refinery", "region": "Asia Pacific"}, # China
        {"name": "East Asia Integrated Refinery", "region": "Asia Pacific"}, # China
        {"name": "Rio de la Plata Refinery", "region": "South America"}, # Representative for SA
        {"name": "Atlantic Coast Refinery", "region": "South America"}, # Representative for SA
    ]
    
    # Ensure we don't try to create more plants than we have names for
    num_plants_to_create = min(num_plants, len(plants_template))
    
    # Shuffle to assign random statuses and products to most plants,
    # but keep specific plants fixed for demo purposes.
    # We will pick specific plants by name later and override their data.
    random_plants = random.sample(plants_template, k=num_plants_to_create)

    all_plants_data = []

    for i, plant_info in enumerate(random_plants):
        plant_name = plant_info["name"]
        plant_id = f"plant_{i+1}" # Assign a generic ID for internal use
        region = plant_info["region"]

        status = random.choices(status_options, weights=[0.55, 0.20, 0.15, 0.05, 0.05], k=1)[0]
        
        # Determine which products this plant "normally" produces
        plant_products = random.sample(products, k=random.randint(3, 5)) # Each plant produces 3-5 random products

        # Assign trader books more dynamically based on region or a random distribution
        assigned_trader_books = []
        if region == "North America":
            assigned_trader_books.append(random.choice(["Trader A (Transportation)", "Trader B (Industrial)", "Trader D (General)"]))
        elif region == "Europe":
            assigned_trader_books.append(random.choice(["Trader B (Industrial)", "Trader C (Marine/Aviation)", "Trader D (General)"]))
        elif region == "Asia Pacific":
            assigned_trader_books.append(random.choice(["Trader A (Transportation)", "Trader C (Marine/Aviation)", "Trader D (General)"]))
        elif region == "South America":
            assigned_trader_books.append(random.choice(["Trader A (Transportation)", "Trader D (General)"]))
        
        if random.random() < 0.2: # 20% chance of having a second trader
            second_trader = random.choice([t for t in trader_books.keys() if t not in assigned_trader_books])
            if second_trader:
                assigned_trader_books.append(second_trader)
        random.shuffle(assigned_trader_books)

        current_plant = {
            "PlantID": plant_id,
            "PlantName": plant_name,
            "Region": region,
            "OverallStatus": status,
            "LastUpdated": datetime.now() - timedelta(minutes=random.randint(5, 60)),
            "TraderBooks": assigned_trader_books,
        }

        # Simulate production and inventory for each product
        for product in products:
            base_production = random.uniform(500, 2500) if product in plant_products else 0 # MT/day
            deviation_factor = 1.0
            if status == "Minor Deviation":
                deviation_factor = random.uniform(0.7, 0.95)
            elif status == "Planned Maintenance":
                deviation_factor = random.uniform(0.4, 0.8)
            elif status == "Significant Outage":
                deviation_factor = random.uniform(0.1, 0.4)
            elif status == "Shutdown":
                deviation_factor = 0.0 # Full shutdown

            current_plant[product] = base_production * deviation_factor
            current_plant[f"{product}_Planned"] = base_production
            
            # Inventory
            current_plant[f"{product}_Inventory"] = random.uniform(base_production * 5, base_production * 20) if base_production > 0 else 0
            current_plant[f"{product}_Capacity"] = current_plant[f"{product}_Inventory"] * random.uniform(1.1, 1.5) if current_plant[f"{product}_Inventory"] > 0 else 0

        # Simulate equipment status
        equipment_status = []
        num_equipment = random.randint(5, 10)
        for eq_idx in range(num_equipment):
            eq_type = random.choice(equipment_types)
            eq_name = f"{eq_type} {eq_idx+1}"
            eq_status_options_eq = ["Optimal", "Reduced Capacity", "Maintenance", "Fault", "Shutdown"]
            eq_status = random.choices(eq_status_options_eq, weights=[0.7, 0.15, 0.1, 0.03, 0.02], k=1)[0]
            
            production_impact_mt_hr = 0
            estimated_duration_hours = 0
            product_impacted_by_eq = random.choice(plant_products) if plant_products else None

            if eq_status in ["Reduced Capacity", "Fault", "Shutdown"] and product_impacted_by_eq:
                base_prod_impact = current_plant.get(f"{product_impacted_by_eq}_Planned", 0)
                if base_prod_impact > 0:
                    if eq_status == "Reduced Capacity":
                        impact_factor = random.uniform(0.05, 0.25)
                        production_impact_mt_hr = base_prod_impact * impact_factor / 24
                        estimated_duration_hours = random.randint(2, 24) # Halved from 4-48 for faster demo
                    elif eq_status == "Fault":
                        impact_factor = random.uniform(0.3, 0.7)
                        production_impact_mt_hr = base_prod_impact * impact_factor / 24
                        estimated_duration_hours = random.randint(12, 84) # Halved from 24-168
                    elif eq_status == "Shutdown":
                        impact_factor = random.uniform(0.8, 1.0)
                        production_impact_mt_hr = base_prod_impact * impact_factor / 24
                        estimated_duration_hours = random.randint(36, 360) # Halved from 72-720

            equipment_status.append({
                "EquipmentID": f"eq_{plant_id}_{eq_idx}",
                "Name": eq_name,
                "Type": eq_type,
                "Status": eq_status,
                "PrimaryProductImpacted": product_impacted_by_eq if production_impact_mt_hr > 0 else None,
                "ProductionImpact_MTHr": round(production_impact_mt_hr, 2),
                "EstimatedDuration_Hours": estimated_duration_hours
            })
        current_plant["Equipment"] = equipment_status
        
        # Simulate incidents/supervisor notes - halved durations
        incidents = []
        if status != "Optimal":
            incident_type = "Unplanned Outage" if status in ["Significant Outage", "Shutdown"] else "Process Upset" if status == "Minor Deviation" else "Planned Maintenance"
            
            incident_duration = 0
            if status == "Significant Outage" or status == "Shutdown":
                incident_duration = random.randint(36, 360) # Halved from 72-720
            elif status == "Minor Deviation":
                incident_duration = random.randint(3, 24) # Halved from 6-48
            elif status == "Planned Maintenance":
                incident_duration = random.randint(60, 240) # Halved from 120-480

            supervisor_note_text = f"Experiencing {incident_type} due to {random.choice(incident_causes)}. Team actively troubleshooting."
            if incident_duration > 0:
                supervisor_note_text += f" Estimated recovery in {incident_duration} hours."
            
            incidents.append({
                "Timestamp": datetime.now() - timedelta(hours=random.randint(1,24)),
                "Type": incident_type,
                "RootCause": random.choice(incident_causes),
                "ImpactConfirmed": f"Reduced {random.choice(products)} output." if plant_products else "General plant impact.",
                "Outlook": random.choice(outlook_options),
                "EstimatedDuration_Hours": incident_duration,
                "QualitativeNotes": supervisor_note_text,
                "Source": "Supervisor"
            })
        current_plant["Incidents"] = incidents
        
        all_plants_data.append(current_plant)
    
    # --- Override specific plants for demo consistency ---
    # Refinery: Rhine Valley Refinery (Europe) - Trader B (Industrial) scenario
    rhine_data = next((item for item in all_plants_data if item["PlantName"] == "Rhine Valley Refinery"), None)
    if rhine_data:
        rhine_data["OverallStatus"] = "Significant Outage"
        rhine_data["TraderBooks"] = ["Trader B (Industrial)", "Trader D (General)"] # Ensure Trader B is assigned
        
        rhine_data["Heavy Fuel Oil_Planned"] = 1000.0 # Planned 1000 MT/day
        rhine_data["Heavy Fuel Oil"] = 300.0        # Actual 300 MT/day during outage
        rhine_data["Heavy Fuel Oil_Inventory"] = 1500.0 # Limited inventory
        rhine_data["Heavy Fuel Oil_Capacity"] = 2000.0 # Storage capacity
        
        rhine_data["Naphtha_Planned"] = 800.0 # Planned 800 MT/day
        rhine_data["Naphtha"] = 250.0        # Actual 250 MT/day during outage
        rhine_data["Naphtha_Inventory"] = 900.0 # Limited inventory
        rhine_data["Naphtha_Capacity"] = 1200.0 # Storage capacity

        rhine_data["Incidents"] = [
            {
                "Timestamp": datetime.now() - timedelta(hours=6),
                "Type": "Unplanned Outage",
                "RootCause": "Power Outage",
                "ImpactConfirmed": "Reduced Heavy Fuel Oil and Naphtha output.",
                "Outlook": "Under Review",
                "EstimatedDuration_Hours": 120, # 5 days
                "QualitativeNotes": "Major electrical grid failure affecting multiple processing units. Engineering teams working with local utility to restore power. Backup generators maintaining critical safety systems.",
                "Source": "Supervisor"
            }
        ]
        
    # Refinery: Baytown Refinery Complex (North America) - Trader A (Transportation) scenario
    bayou_data = next((item for item in all_plants_data if item["PlantName"] == "Baytown Refinery Complex"), None)
    if bayou_data:
        bayou_data["OverallStatus"] = "Minor Deviation"
        bayou_data["TraderBooks"] = ["Trader A (Transportation)", "Trader D (General)"]
        
        bayou_data["Gasoline_Planned"] = 1200.0 # Planned 1200 MT/day
        bayou_data["Gasoline"] = 980.0 # Actual 980 MT/day (minor deviation)
        bayou_data["Gasoline_Inventory"] = 8500.0 # Good inventory levels
        bayou_data["Gasoline_Capacity"] = 15000.0 # Storage capacity
        
        bayou_data["Diesel_Planned"] = 900.0 # Planned 900 MT/day
        bayou_data["Diesel"] = 750.0 # Actual 750 MT/day (minor deviation)
        bayou_data["Diesel_Inventory"] = 5200.0 # Good inventory levels
        bayou_data["Diesel_Capacity"] = 10000.0 # Storage capacity

        bayou_data["Incidents"] = [
            {
                "Timestamp": datetime.now() - timedelta(hours=1),
                "Type": "Process Upset",
                "RootCause": "Minor pump vibration (Diesel Hydrotreater) & Gasoline Blender temperature excursion",
                "ImpactConfirmed": "Slightly reduced diesel hydrotreater throughput and gasoline blending capacity.",
                "Outlook": "Improving",
                "EstimatedDuration_Hours": 12, # 12 hours recovery
                "QualitativeNotes": "Minor vibration detected on Diesel Hydrotreater pump, causing slight reduction in diesel production. Simultaneously, a brief temperature excursion in Gasoline Blender caused a reduction in blending capacity. Maintenance actively troubleshooting both. Expect full recovery within 12 hours. Gasoline/Diesel impact is minor but notable.",
                "Source": "Supervisor"
            }
        ]

    return pd.DataFrame(all_plants_data)

@st.cache_data(ttl=30)
def get_plant_data():
    """Retrieves the hard-coded plant data."""
    return get_hardcoded_plant_data()

# Modified: Now accepts the already selected plant's row data
@st.cache_data(ttl=10)
def get_equipment_details(selected_plant_data):
    """Retrieves equipment details from the provided plant data."""
    if selected_plant_data is None or not isinstance(selected_plant_data, pd.Series):
        st.error("Error: Invalid plant data provided for equipment details.")
        return pd.DataFrame() # Return empty DataFrame
    return pd.DataFrame(selected_plant_data["Equipment"])

# Modified: Now accepts the already selected plant's row data
@st.cache_data(ttl=10)
def get_incidents(selected_plant_data):
    """Retrieves incidents and supervisor notes from the provided plant data."""
    if selected_plant_data is None or not isinstance(selected_plant_data, pd.Series):
        st.error("Error: Invalid plant data provided for incidents.")
        return pd.DataFrame() # Return empty DataFrame
    return pd.DataFrame(selected_plant_data["Incidents"])

@st.cache_data(ttl=30)
def get_product_inventory_data(filtered_plants_df):
    """Aggregates product inventory data across the filtered set of plants."""
    # `products` list is now globally defined
    data = []
    for p in products:
        inventory_col = f"{p}_Inventory"
        capacity_col = f"{p}_Capacity"
        
        current = filtered_plants_df[inventory_col].sum() if inventory_col in filtered_plants_df.columns else 0
        capacity = filtered_plants_df[capacity_col].sum() if capacity_col in filtered_plants_df.columns else 0
        
        data.append({
            "Product": p,
            "Total Inventory (MT)": round(current, 0),
            "Capacity (MT)": round(capacity, 0),
            "Utilization (%)": round((current / capacity) * 100, 1) if capacity > 0 else 0
        })
    return pd.DataFrame(data)

@st.cache_data(ttl=30)
def get_production_trends(plant_id, product_name):
    """
    Generates hard-coded historical production data for a specific product and plant,
    including month-to-date, 30-day forecast, and 30-day rolling average.
    """
    today = datetime.now().date()
    # Ensure full month data for MTD, and enough history for 30-day rolling average.
    # Start 60 days ago for history, extend to 30 days into future for forecast.
    start_date = today - timedelta(days=60)
    end_date = today + timedelta(days=30)
    
    dates = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]
    
    df_plants = get_plant_data()
    plant_row = df_plants[df_plants["PlantID"] == plant_id].iloc[0]

    production_data_points = []
    base_prod = plant_row.get(f"{product_name}_Planned", 0)

    if base_prod == 0:
        return pd.DataFrame(), 0 # Return empty DataFrame and 0 MTD if product not produced

    for date in dates:
        daily_prod = base_prod * random.uniform(0.95, 1.05) # Normal fluctuation

        # Simulate historical impacts and ongoing/future impacts based on plant status
        if date <= today: # Historical data
            if plant_row["OverallStatus"] == "Significant Outage" or plant_row["OverallStatus"] == "Shutdown":
                outage_effect_start_hist = today - timedelta(days=random.randint(3, 10)) # Simulate start within last 3-10 days
                outage_effect_end_hist = outage_effect_start_hist + timedelta(hours=random.randint(72, 720)) # Lasts 3-30 days
                if outage_effect_start_hist <= date <= outage_effect_end_hist:
                    daily_prod = base_prod * random.uniform(0.1, 0.4)
                elif date > outage_effect_end_hist and date <= outage_effect_end_hist + timedelta(days=2):
                    daily_prod = base_prod * random.uniform(0.6, 0.9)
            elif plant_row["OverallStatus"] == "Planned Maintenance":
                maintenance_effect_start_hist = today - timedelta(days=random.randint(5, 15)) # Simulate start within last 5-15 days
                maintenance_effect_end_hist = maintenance_effect_start_hist + timedelta(hours=random.randint(120, 480)) # Lasts 5-20 days
                if maintenance_effect_start_hist <= date <= maintenance_effect_end_hist:
                    daily_prod = base_prod * random.uniform(0.4, 0.7)
                elif date > maintenance_effect_end_hist and date <= maintenance_effect_end_hist + timedelta(days=2):
                    daily_prod = base_prod * random.uniform(0.8, 0.95)
            elif plant_row["OverallStatus"] == "Minor Deviation":
                deviation_effect_start_hist = today - timedelta(days=random.randint(1, 3)) # Simulate start within last 1-3 days
                deviation_effect_end_hist = deviation_effect_start_hist + timedelta(hours=random.randint(6, 48)) # Lasts 6-48 hours
                if deviation_effect_start_hist <= date <= deviation_effect_end_hist:
                    daily_prod = base_prod * random.uniform(0.75, 0.9)
            production_data_points.append({"Date": date, "Production (MT/Day)": daily_prod, "Planned Production (MT/Day)": base_prod, "Type": "Actual"})
        else: # Forecast data
            forecast_prod = base_prod * random.uniform(0.98, 1.02) # Slight variation around planned

            # Project ongoing/future impacts into the forecast
            if plant_row["OverallStatus"] in ["Significant Outage", "Shutdown"]:
                # Assume initial recovery period, then return to normal
                if date <= today + timedelta(hours=72): # First 3 days of forecast from now
                    forecast_prod = base_prod * random.uniform(0.2, 0.6) # Still heavily impacted
                elif date <= today + timedelta(hours=168): # Next 4 days (total 7)
                    forecast_prod = base_prod * random.uniform(0.7, 0.9) # Recovering
            elif plant_row["OverallStatus"] == "Planned Maintenance":
                 if date <= today + timedelta(days=7): # First 7 days of forecast from now
                    forecast_prod = base_prod * random.uniform(0.4, 0.7) # Still impacted by maintenance
            elif plant_row["OverallStatus"] == "Minor Deviation":
                 if date <= today + timedelta(hours=24): # First day of forecast from now
                    forecast_prod = base_prod * random.uniform(0.8, 0.95) # Still minor deviation
            production_data_points.append({"Date": date, "Forecast (MT/Day)": forecast_prod, "Planned Production (MT/Day)": base_prod, "Type": "Forecast"})

    df_combined = pd.DataFrame(production_data_points)
    df_combined["Date"] = pd.to_datetime(df_combined["Date"])
    df_combined.set_index("Date", inplace=True)

    # Calculate 30-Day Rolling Average for historical data only
    df_combined["30-Day Rolling Avg (MT/Day)"] = np.nan # Initialize
    # FIX: Convert df_combined.index to date objects for comparison
    historical_dates_mask = df_combined.index.date <= today
    df_combined.loc[historical_dates_mask, "30-Day Rolling Avg (MT/Day)"] = \
        df_combined.loc[historical_dates_mask, "Production (MT/Day)"].rolling(window=30, min_periods=1).mean()
    
    # Fill NaN in Production (for forecast part) and Forecast (for actual part) for plotting consistency
    df_combined.loc[df_combined['Type'] == 'Forecast', 'Production (MT/Day)'] = np.nan
    df_combined.loc[df_combined['Type'] == 'Actual', 'Forecast (MT/Day)'] = np.nan


    # Calculate Month-to-Date (MTD) production (only from actual historical data)
    first_day_of_month = today.replace(day=1)
    mtd_df = df_combined.loc[(df_combined.index.date >= first_day_of_month) & (df_combined.index.date <= today)] # FIX: Convert index to date for comparison
    mtd_production = mtd_df["Production (MT/Day)"].sum()

    df_combined.reset_index(inplace=True)
    df_combined.rename(columns={"index": "Date"}, inplace=True)

    return df_combined, mtd_production

# --- Streamlit UI Components ---

st.set_page_config(layout="wide", page_title="Oil Refinery Trading Dashboard", page_icon="🛢️")

st.title("🛢️ Oil Refinery Trading Dashboard - Operational Insights")
# Added prominent disclaimer
st.markdown(
    """
    <div style="background-color:#fff3cd; padding: 10px; border-left: 5px solid #ffc107; margin-bottom: 20px;">
        <h4 style="color:#856404; margin-top: 0;">⚠️ IMPORTANT: This is a Mockup Demo</h4>
        <p style="color:#856404; margin-bottom: 0;">
            This dashboard uses **simulated data** to illustrate potential functionalities. It is a **mockup, not even a Proof-of-Concept (POC)**, and does not connect to live LyondellBasell systems. Its purpose is to facilitate discussion and gather feedback on desired features and data presentation.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)
st.markdown("---")

# --- Sidebar Navigation ---
st.sidebar.header("Navigation")

# Add tabs for main dashboard and demo script
page = st.sidebar.radio("Select Page:", ["Dashboard", "Demo Script"])

if page == "Demo Script":
    st.title("⛽ Oil Refinery Trading Dashboard - Demo Script")
    st.markdown("---")
    
    demo_content = load_demo_script()
    st.markdown(demo_content)
    
    st.markdown("---")
    st.caption("Return to the Dashboard using the sidebar navigation.")
    st.stop()  # Stop execution here for demo script page

# --- Filtering Options (Enterprise, Region, Trader's Book of Business) ---
st.sidebar.header("View Filters")

view_mode = st.sidebar.radio(
    "Select View Mode:",
    ("Enterprise Wide", "Region Wide", "My Book of Business")
)

df_plants = get_plant_data()
filtered_plants_df = df_plants.copy()
selected_region = None
selected_trader_book = None

if view_mode == "Region Wide":
    regions_available = sorted(df_plants["Region"].unique().tolist())
    selected_region = st.sidebar.selectbox("Select Region:", regions_available)
    filtered_plants_df = filtered_plants_df[filtered_plants_df["Region"] == selected_region]
elif view_mode == "My Book of Business":
    # Flatten the list of TraderBooks and get unique values
    all_trader_books = df_plants["TraderBooks"].explode().unique().tolist()
    trader_book_options = sorted([book for book in all_trader_books if book]) # Filter out None/empty
    selected_trader_book = st.sidebar.selectbox("Select Trader's Book:", trader_book_options)

    # Filter plants based on if they are in the selected trader's book
    filtered_plants_df = filtered_plants_df[
        filtered_plants_df["TraderBooks"].apply(lambda x: selected_trader_book in x)
    ]
    if filtered_plants_df.empty:
        st.sidebar.warning(f"No plants directly assigned to '{selected_trader_book}' in this simulation. Displaying all plants for context.")
        filtered_plants_df = df_plants.copy() # Fallback to all plants if no match

# Display number of plants in current view
st.sidebar.info(f"Showing **{len(filtered_plants_df)}** plants in the current view.")

st.markdown(f"## {view_mode} Summary")

# --- Overall Network Summary ---
col1, col2 = st.columns(2)

with col1:
    st.subheader("Plant Operational Status")
    status_counts = filtered_plants_df["OverallStatus"].value_counts().reset_index()
    status_counts.columns = ["Status", "Count"]

    status_colors = {
        "Optimal": "green",
        "Minor Deviation": "gold",
        "Planned Maintenance": "lightblue",
        "Significant Outage": "orange",
        "Shutdown": "red"
    }
    # Ensure all status options are present for consistent coloring
    for s_opt in status_options: # Uses the globally defined status_options
        if s_opt not in status_counts["Status"].values:
            status_counts = pd.concat([status_counts, pd.DataFrame([{"Status": s_opt, "Count": 0}])], ignore_index=True)

    fig_status = px.bar(status_counts, x="Status", y="Count", color="Status",
                        color_discrete_map=status_colors,
                        labels={"Status": "Plant Status", "Count": "Number of Plants"},
                        title="Count of Plants by Operational Status")
    fig_status.update_layout(showlegend=False)
    st.plotly_chart(fig_status, use_container_width=True)

with col2:
    st.subheader("Aggregated Product Inventory (MT)")
    df_inventory = get_product_inventory_data(filtered_plants_df)

    if not df_inventory.empty:
        # Filter out products with 0 inventory and capacity for cleaner display
        df_inventory_display = df_inventory[df_inventory["Total Inventory (MT)"] > 0]
        if not df_inventory_display.empty:
            fig_inventory = px.bar(df_inventory_display, x="Product", y="Total Inventory (MT)",
                                color="Utilization (%)", color_continuous_scale=px.colors.sequential.YlGnBu,
                                title="Aggregated Product Inventory")
            st.plotly_chart(fig_inventory, use_container_width=True)
        else:
            st.info("No active product inventory in this view.")
    else:
        st.info("No product inventory data available for this view.")

st.markdown("---")

# --- Plant-Specific Drill Down & Critical Alerts ---
st.header("Plant Details & Trading Actions")

# Critical Alerts for traders
critical_alerts_triggered = False

# Process "Shutdown" or "Significant Outage" alerts first
critical_plants_by_status = filtered_plants_df[filtered_plants_df["OverallStatus"].isin(["Significant Outage", "Shutdown"])]
if not critical_plants_by_status.empty:
    critical_alerts_triggered = True
    st.markdown("### :red[🚨 CRITICAL PRODUCTION ALERTS - IMMEDIATE ACTION REQUIRED! 🚨]", unsafe_allow_html=True)
    for index, plant in critical_plants_by_status.iterrows():
        st.warning(f"🔴 **{plant['PlantName']} ({plant['Region']})**: Current Status: **{plant['OverallStatus']}**.")
        plant_incidents = [inc for inc in plant['Incidents'] if inc['Type'] in ['Unplanned Outage', 'Process Upset']]
        if plant_incidents:
            for inc in plant_incidents:
                st.info(f"  - **Incident:** {inc['QualitativeNotes']} (Est. Recovery: {inc['EstimatedDuration_Hours']} hrs)")
                st.markdown(f"  - **Trading Impact:** Significant supply disruption for key products. Recommend reviewing positions immediately.")
        st.markdown("---")

# Check for plants with significant deviation from planned utilization
plants_with_high_deviation = []
for index, plant in filtered_plants_df.iterrows():
    if plant["PlantID"] not in critical_plants_by_status["PlantID"].tolist(): # Only check if not already critically status-alerted
        for prod in products: # Using globally defined products
            current_prod = plant.get(prod, 0)
            planned_prod = plant.get(f"{prod}_Planned", 0)
            if planned_prod > 0:
                deviation_perc = ((current_prod - planned_prod) / planned_prod) * 100
                if deviation_perc < -20: # Threshold for "significant deviation"
                    plants_with_high_deviation.append(plant)
                    critical_alerts_triggered = True
                    break # Only need one product to trigger for the plant

if plants_with_high_deviation:
    for plant in plants_with_high_deviation:
        st.warning(f"🟡 **{plant['PlantName']} ({plant['Region']})**: Significant Deviation from Planned Production.")
        for prod in products: # Using globally defined products
            current_prod = plant.get(prod, 0)
            planned_prod = plant.get(f"{prod}_Planned", 0)
            if planned_prod > 0:
                deviation_perc = ((current_prod - planned_prod) / planned_prod) * 100
                if deviation_perc < -20:
                    st.info(f"  - **{prod}:** Currently at {round(current_prod, 0)} MT/day (Planned: {round(planned_prod, 0)} MT/day). Deviation: {round(deviation_perc, 1)}%")
        st.markdown(f"  - **Trading Impact:** Monitor closely for potential supply shortfalls. May require minor adjustments to positions.")
        st.markdown("---")

if not critical_alerts_triggered:
    st.success("No plants with 'Significant Outage', 'Shutdown', or major deviations in current view. Operations are stable. (Green status for traders!)")


available_plants = filtered_plants_df["PlantName"].tolist()
if not available_plants:
    st.warning("No plants available in the current filtered view for detailed selection.")
else:
    selected_plant_name = st.selectbox("Select a Plant for Detailed View:", available_plants)
    # Ensure selected_plant is always a Series for consistency
    selected_plant = df_plants[df_plants["PlantName"] == selected_plant_name].iloc[0] 

    # --- Display Selected Plant Info in Title Area ---
    traders_for_plant = ", ".join(selected_plant['TraderBooks']) if selected_plant['TraderBooks'] else "N/A"
    st.markdown(f"### Details for **{selected_plant_name}** ({selected_plant['Region']})")
    st.markdown(f"**Associated Trader(s):** {traders_for_plant}")
    st.markdown("---") # Add a divider below the new title info


    col3, col4 = st.columns(2)

    with col3:
        st.metric(label="Overall Plant Status", value=selected_plant["OverallStatus"])
        st.metric(label="Last Data Update", value=selected_plant["LastUpdated"].strftime("%Y-%m-%d %H:%M:%S"))

        st.subheader("Current Product Production & Deviation (MT/Day)")
        production_summary = []
        for prod in products: # Iterate through all possible products
            current_prod = selected_plant.get(prod, 0)
            planned_prod = selected_plant.get(f"{prod}_Planned", 0)
            
            if planned_prod > 0 or current_prod > 0: # Only show if plant produces or planned to produce
                deviation_perc = ((current_prod - planned_prod) / planned_prod) * 100 if planned_prod > 0 else (100 if current_prod > 0 else 0)
                
                prod_data = {
                    "Product": prod,
                    "Current (MT/Day)": round(current_prod, 2),
                    "Planned (MT/Day)": round(planned_prod, 2),
                    "Deviation (%)": round(deviation_perc, 2)
                }
                production_summary.append(prod_data)
        df_prod_summary = pd.DataFrame(production_summary)

        # Highlight significant deviations visually for the trader
        def color_deviation(val):
            if val < -20: # Significantly below planned
                return 'background-color: #ffe6e6' # Light red
            elif val < 0: # Below planned but not critical
                return 'background-color: #fff2e6' # Light orange
            elif val > 5: # Above planned
                return 'background-color: #e6ffe6' # Light green
            return '' # No special color
        
        st.dataframe(df_prod_summary.style.applymap(color_deviation, subset=['Deviation (%)']), use_container_width=True)
        st.markdown("*(Color highlights: Red for >20% below planned, Orange for 0-20% below, Green for >5% above)*")

    with col4:
        st.subheader("Top Impacting Equipment Status") # Weight/impact of the top five assets
        # Pass the selected_plant (Series) directly to the function
        df_equipment = get_equipment_details(selected_plant)
        
        # Sort by impact (ProductionImpact_MTHr) and display top 5 with actual impact
        top_5_impacting_equipment = df_equipment[df_equipment["ProductionImpact_MTHr"] > 0].sort_values(by="ProductionImpact_MTHr", ascending=False).head(5)

        if not top_5_impacting_equipment.empty:
            st.error("Top 5 Equipment with Significant Production Impact:") # Alert on significant impact
            for idx, row in top_5_impacting_equipment.iterrows():
                status_icon = "🔴" # Force red for top impacting for immediate trader attention
                
                st.write(f"{status_icon} **{row['Name']}** ({row['Type']}): Status: **{row['Status']}**")
                if row['PrimaryProductImpacted'] and row['ProductionImpact_MTHr'] > 0:
                    st.write(f"  - **Impacting:** {row['PrimaryProductImpacted']} by -{round(row['ProductionImpact_MTHr'] * 24, 2)} MT/day") # Convert hourly back to daily for display
                    st.write(f"  - Est. Recovery: {row['EstimatedDuration_Hours']} hours")
                    st.markdown(f"  - **Trader Alert:** This asset significantly impacts {row['PrimaryProductImpacted']} production. Consider its contribution to overall plant status.")
            st.markdown("---")
        else:
            st.success("No top impacting equipment issues detected currently.")

        st.subheader("Plant Product Inventory (MT)")
        plant_inventory_data = []
        for prod in products: # Using globally defined products
            if selected_plant.get(f"{prod}_Inventory") is not None and selected_plant.get(f"{prod}_Capacity") is not None:
                plant_inventory_data.append({
                    "Product": prod,
                    "Inventory (MT)": round(selected_plant[f"{prod}_Inventory"], 0),
                    "Capacity (MT)": round(selected_plant[f"{prod}_Capacity"], 0),
                    "Utilization (%)": round((selected_plant[f"{prod}_Inventory"] / selected_plant[f"{prod}_Capacity"]) * 100, 1) if selected_plant[f"{prod}_Capacity"] > 0 else 0
                })
        df_plant_inventory = pd.DataFrame(plant_inventory_data)
        # Filter out products with no inventory/capacity for cleaner display
        df_plant_inventory_display = df_plant_inventory[df_plant_inventory["Inventory (MT)"] > 0]
        st.dataframe(df_plant_inventory_display, use_container_width=True)

    st.markdown("---")

    # --- Estimated Lost Production & Buy/Sell Guidance ---
    st.header("Estimated Production Impact & Trading Guidance")

    col5, col6 = st.columns(2)

    with col5:
        st.subheader("Quantified Lost Production & Actionable Advice")

        total_lost_production = {}

        for prod in products: # Using globally defined products
            current_prod = selected_plant.get(prod, 0)
            planned_prod = selected_plant.get(f"{prod}_Planned", 0)

            if planned_prod > 0 and current_prod < planned_prod:
                lost_daily = planned_prod - current_prod

                # Determine estimated duration from most severe impacting factor
                estimated_duration_hours = 0

                # 1. From directly impacting equipment for this product
                df_equipment = get_equipment_details(selected_plant) # Get latest equipment details
                product_impacting_equipment = df_equipment[
                    (df_equipment['PrimaryProductImpacted'] == prod) &
                    (df_equipment['Status'].isin(["Reduced Capacity", "Fault", "Shutdown"]))
                ]
                if not product_impacting_equipment.empty:
                    estimated_duration_hours = product_impacting_equipment['EstimatedDuration_Hours'].max()

                # 2. From general plant incidents if no specific equipment link or for broader impacts
                if estimated_duration_hours == 0 and selected_plant["Incidents"]:
                    incident_durations = [inc['EstimatedDuration_Hours'] for inc in selected_plant["Incidents"] if inc['EstimatedDuration_Hours'] > 0]
                    if incident_durations:
                        estimated_duration_hours = max(incident_durations)

                # 3. Fallback to general estimate based on overall plant status if no specific duration found
                if estimated_duration_hours == 0:
                    if selected_plant["OverallStatus"] in ["Significant Outage", "Shutdown"]:
                        estimated_duration_hours = random.randint(72, 240) # Default 3-10 days for major outage
                    elif selected_plant["OverallStatus"] == "Planned Maintenance":
                        estimated_duration_hours = random.randint(120, 480) # Default 5-20 days for planned
                    elif selected_plant["OverallStatus"] == "Minor Deviation":
                        estimated_duration_hours = random.randint(6, 48) # Default 6 hours-2 days for minor


                if lost_daily > 0 and estimated_duration_hours > 0:
                    # Calculate total lost volume based on current daily loss and estimated duration
                    lost_volume_over_duration = (lost_daily / 24) * estimated_duration_hours
                    total_lost_production[prod] = {
                        "Lost Daily (MT)": round(lost_daily, 2),
                        "Estimated Duration (hrs)": estimated_duration_hours,
                        "Total Lost Volume (MT)": round(lost_volume_over_duration, 2)
                    }

        if total_lost_production:
            for product, data in total_lost_production.items():
                st.error(f"**{product}:** Potential Lost Production Detected!")
                st.write(f"  - Current Daily Reduction: -{data['Lost Daily (MT)']} MT")
                st.write(f"  - Estimated Duration of Impact: {data['Estimated Duration (hrs)']} hours")
                st.markdown(f"  - **Total Estimated Lost Volume: {data['Total Lost Volume (MT)']} MT**")
                st.markdown(f"**Trader Action:** Consider **buying {data['Total Lost Volume (MT)']} MT** of {product} to cover this projected deficit, or adjust forward sales positions.")
            st.info("Act quickly - market intelligence suggests early action minimizes price impact.")
        else:
            st.success("No significant lost production detected for this plant currently. Production is at or above planned targets. (Opportunity to sell!)")

    with col6:
        st.subheader("Production Trends and Forecasts")

        # Determine products produced by this plant for the selectbox
        products_for_trend = [p for p in products if selected_plant.get(f"{p}_Planned", 0) > 0]
        if not products_for_trend:
            st.info("This plant does not have historical production data for listed products.")
        else:
            selected_product_for_trend = st.selectbox(
                "Select Product for Trend:",
                products_for_trend,
                key="trend_prod_select"
            )
            df_trend, mtd_production = get_production_trends(selected_plant["PlantID"], selected_product_for_trend)

            if not df_trend.empty:
                st.metric(label=f"Month-to-Date Production ({datetime.now().strftime('%B')})", # Month to Date
                          value=f"{round(mtd_production, 0)} MT")
                
                # Plotting all relevant production metrics
                fig_trend = px.line(df_trend, x="Date", y=["Production (MT/Day)", "Planned Production (MT/Day)",
                                                          "30-Day Rolling Avg (MT/Day)", "Forecast (MT/Day)"],
                                    title=f"{selected_product_for_trend} Production Trend & Forecast ({selected_plant_name})",
                                    color_discrete_map={
                                        "Production (MT/Day)": "blue",
                                        "Planned Production (MT/Day)": "green", # Planned
                                        "30-Day Rolling Avg (MT/Day)": "purple", # 30-day rolling average
                                        "Forecast (MT/Day)": "orange" # Forecast for 30 days
                                    })
                fig_trend.update_layout(hovermode="x unified")
                st.plotly_chart(fig_trend, use_container_width=True)
            else:
                st.info(f"No historical trend or forecast data for {selected_product_for_trend} at this plant.")


    st.markdown("---")

    # --- Systematized Soft Skills / Communication ---
    st.header("Plant Communication & Contextual Insights")

    st.subheader("Supervisor's Real-time Notes / Incident Log")
    # Pass the selected_plant (Series) directly to the function
    df_incidents = get_incidents(selected_plant)

    if not df_incidents.empty:
        for idx, incident in df_incidents.sort_values(by="Timestamp", ascending=False).iterrows():
            st.info(f"**{incident['Timestamp'].strftime('%Y-%m-%d %H:%M')} - {incident['Type']}**") # FIX: Removed `乡`
            st.write(f"  - **Root Cause:** {incident['RootCause']}")
            st.write(f"  - **Outlook:** {incident['Outlook']}")
            if incident['EstimatedDuration_Hours'] > 0:
                st.write(f"  - **Estimated Recovery:** {incident['EstimatedDuration_Hours']} hours")
            st.write(f"  - **Notes:** *\"{incident['QualitativeNotes']}\"*")
            st.write("---")
    else:
        st.info("No recent incidents or supervisor notes for this plant. Operations are smooth.")

    st.subheader("Ask Plant Operations (Systematized Inquiry)")
    with st.form("ask_plant_form"):
        st.markdown("For rapid clarification, your question will be routed to plant operations via integrated CDF workflows.")
        question_type = st.selectbox("Question Type:", ["Production Clarification", "Equipment Status", "Quality Info", "Logistics", "Other"])
        question_text = st.text_area("Your Question for Plant Operations (max 200 chars):", max_chars=200)
        submit_button = st.form_submit_button("Submit Question to Plant Operations")

        if submit_button:
            st.success(f"Question submitted to Plant {selected_plant_name} ({question_type}): '{question_text}'")
            st.info("This inquiry would be routed to the appropriate plant personnel via an integrated workflow (e.g., MS Teams, email, or a dedicated task in their operational system). Their response would subsequently appear in the 'Supervisor's Real-time Notes / Incident Log' section.")

st.markdown("---")
st.caption(f"Dashboard generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} CDT. Data based on hard-coded array simulation for oil refinery operational context.")
