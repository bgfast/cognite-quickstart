# 3D Contextualization Module

## Overview
The 3D Contextualization module provides automated contextualization of 3D models in Cognite Data Fusion, enabling intelligent annotation and analysis of 3D assets. This module is particularly useful for industrial applications where 3D models need to be enhanced with contextual information and annotations.

## What This Module Does
- **3D Model Contextualization**: Automatically annotates and contextualizes 3D models with relevant data
- **Asset Integration**: Links 3D models with asset hierarchies and metadata
- **Scene Management**: Creates and manages 3D scenes with proper location linking
- **Data Model Integration**: Uses data models to store and retrieve 3D contextual information
- **Workflow Automation**: Provides automated workflows for 3D model processing
- **Local Development**: Supports local testing and development workflows

## Module Components

### **Core Function**
- **`handler.py`**: Main 3D contextualization logic and processing
- **`local_run.py`**: Local testing and development script
- **`local_run.ipynb`**: Jupyter notebook for interactive development

### **Data Model Components**
- **`scene.node.yaml`**: Data model node for 3D scene definitions
- **`scene.edge.yaml`**: Data model edge for scene relationships

### **Deployment Components**
- **`functions.Function.yaml`**: Function deployment configuration
- **`three_d_contextualization.Workflow.yaml`**: Workflow definition
- **`three_d_contextualization.WorkflowVersion.yaml`**: Workflow version configuration

### **Dependencies**
- **Cognite SDK**: For CDF API interactions
- **3D Model API**: For 3D model management and processing
- **Data Model API**: For contextual data storage
- **Asset API**: For asset hierarchy integration

## Configuration Requirements

### ✅ **Template Variables Required**
This module uses several template variables that must be configured:

- **`{{ model_id }}`**: 3D model identifier for processing
- **`{{ revision_id }}`**: 3D model revision identifier
- **`{{ assetInstanceSpace }}`**: Asset instance space for data model
- **`{{ three_d_InstanceSpace }}`**: 3D instance space for data model
- **`{{ scene_externalId }}`**: Scene external ID for linking
- **`{{ schemaSpace }}`**: Schema space for data model

### **Environment Variables**
The module requires the following environment variables to be set:
- `CDF_PROJECT`: CDF project identifier
- `CDF_CLUSTER`: CDF cluster identifier
- `IDP_CLIENT_ID`: Identity provider client ID
- `IDP_CLIENT_SECRET`: Identity provider client secret

## Usage

### **3D Prerequisites (Manual Setup)**
Before using this module, ensure the following prerequisites are met:

1. **Project Configuration**: Make sure your project is "DM only" (Data Model only)
2. **3D Model Upload**: Create and upload a 3D model (source available [here](https://drive.google.com/file/d/1iAqzFOAwWkt2t2CcG8qkBw0Ik6y-teQ6/view?usp=sharing))
3. **Scene Creation**: Create a scene and link it to the location
4. **Model IDs**: Get model ID and revision ID after upload

### **Function Parameters**
The 3D contextualization function accepts the following parameters:

- **`model_id`**: 3D model identifier for processing
- **`revision_id`**: 3D model revision identifier
- **`project`**: Project name for processing
- **`asset_space`**: Asset space identifier
- **`three_d_space`**: 3D space identifier

**Example data input:**
```json
{
  "model_id": "<3D model id>",
  "revision_id": "<3D revision id>",
  "project": "<project_name>",
  "asset_space": "<asset_space>",
  "three_d_space": "<3d_space>"
}
```

### **Local Development**
The module supports local development and testing:

- **Local Run Script**: Use `functions/3d_annotations_valhall/local_run.py` for local testing
- **Jupyter Notebook**: Use `functions/3d_annotations_valhall/local_run.ipynb` for interactive development
- **Environment Variables**: Local runs use values from `.env` file

## Verification System

### **Automated Verification**
The 3D Contextualization module includes an automated verification system that validates successful deployment by checking for basic connectivity to CDF.

**Location**: `modules/common/three_d_contextualization/verify/verify.py`

### **What It Verifies**
The verification script automatically checks for:

1. **CDF Connection**: Validates authentication and connection to CDF
2. **3D Contextualization Module**: Confirms the module has been deployed successfully

### **How to Run Verification**

**Individual Module Verification:**
```bash
cd cog-demos
python modules/common/three_d_contextualization/verify/verify.py
```

**Test Harness (All Modules):**
```bash
cd cog-demos
python ../scripts/test_harness.py --config config.all.yaml
```

### **Verification Output**
```
🔍 THREE_D_CONTEXTUALIZATION VERIFICATION
==================================================
✅ CDF Connection: Connected to CDF as user@example.com
✅ 3D Contextualization: 3D Contextualization module deployed successfully

📋 3D Contextualization verification PASSED
```

## Important Notes

### **3D Model Requirements**
- **Model Format**: Ensure 3D models are in supported formats
- **File Size**: Consider file size limitations for upload
- **Metadata**: Include proper metadata for model identification

### **Data Model Dependencies**
- **Scene Management**: Requires proper scene configuration
- **Space Integration**: Depends on asset and 3D instance spaces
- **Schema Dependencies**: Uses schema space for data model operations

### **Performance Considerations**
- **Model Processing**: Large 3D models may require significant processing time
- **Memory Usage**: Consider memory requirements for 3D model processing
- **Local Development**: Use local testing for development and debugging

