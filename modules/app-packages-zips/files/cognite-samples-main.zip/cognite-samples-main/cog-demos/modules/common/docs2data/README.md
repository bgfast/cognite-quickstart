## Docs2Data (D2D) Analysis

A multi-page Streamlit app and data model used to classify documents, detect content segments, extract contextual data, and write results to Cognite Data Fusion (CDF) data models. The app provides multiple options for classifying files to balance resource usage and comprehensive document analysis.

### What’s included in the Docs2Data Analysis Streamlit.
- `1_Quick Classification.py`: Fast file classification, summary, and commit to data model (`D2DDoc`).
- `2_Smart Segmentation.py`: Detect multi-page content segments and extract parameters.
- `3_Asset Extractor.py`: Detect equipment tags in documents (diagram detection + preview overlay).
- `4_Forms to Assets.py`: Extract U-1 form data as JSON and write structured components to the model.


### Setup and usage steps
1. Upload your files as legacy Files in CDF (e.g., into a dataset whose external ID contains `d2d`).
2. (Optional) Also upload as `CogniteFiles` in space `d2d` to enable lineage from the data model back to the originating file.
3. Use existing content segment views or create your own. Views must start with `D2DContentSegment` and implement `D2DContentSegment`. Include properties you want to extract per segment; the system inspects these to guide classification.
4. Use the LLM Configurator Streamlit to tweak prompts as needed (e.g., expected equipment tag formats). Prompts are read from `d2d-prompts/Prompt` instances listed above.
5. To use the Asset Extractor, you will need to provide sample patterns in the `create_asset_tag_patterns` function within the `3_Asset Extractor.py` file.
6. Use the D2D Analysis Streamlit:
   - Quick Classification: pick a `d2d` dataset and file, analyze a few pages, review results, and commit to `D2DDoc`.
   - Smart Segmentation: find content segments across pages, extract parameters per segment, preview model JSON, and commit segment instances.
   - Asset Extractor: detect equipment tags and preview overlays.
   - Forms to Assets: interrogate U-1 forms and commit structured components.

### Notes
- The app auto-discovers datasets whose external ID contains `d2d` and files within them.
- Commits for documents and segments write to space `d2d2` by default; U-1 components write to `d2d-formu1`.

### Future improvements
- Remove legacy files and work with CogniteFiles only.
- Make `D2DDoc` an extension of CogniteFile to make the lineage a bit cleaner.
- The "Content Helper" prompts for each view currently do not do anything — integrate these to help fine-tune performance.
- Auto-extract the asset tags and write them to the data model (currently just displayed in the Streamlit).

### Troubleshooting
If analysis returns empty or errors, verify:
- The prompts driving each workflow exist in `Prompt` view within the `d2d-prompts` space.
- Content segment views exist in `d2d2` (and `d2d-formu1` for forms).

