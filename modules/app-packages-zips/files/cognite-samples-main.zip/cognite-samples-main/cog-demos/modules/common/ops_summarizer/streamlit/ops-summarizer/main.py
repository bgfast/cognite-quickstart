import streamlit as st
from cognite.client import CogniteClient
import PyPDF2
import io
import pandas as pd
from FileHelper import *
from docx import Document
from datetime import datetime

# Initialize Cognite client
client = CogniteClient()

# Setting page title and header
st.set_page_config(page_title="AI Assistant", page_icon="🏆")
st.markdown("<h1 style='text-align: center;'>Operations Summarizer</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center;'>AI Generated Summaries of Plant Operations</h3>", unsafe_allow_html=True)

# Initialize session state variables
if 'generated' not in st.session_state:
    st.session_state['generated'] = []
if 'past' not in st.session_state:
    st.session_state['past'] = []
if 'messages' not in st.session_state:
    st.session_state['messages'] = [
        {"role": "system", "content": "You are an AI assistant for a paper mill. Summarize and answer questions about operations in the paper mill based on the information provided.  Do not make up information.  Top priorties in the paper mill are improving yeild, reducing downtime, improve outage planning, improving safety"}
    ]
if 'model_name' not in st.session_state:
    st.session_state['model_name'] = []

# Function to get available models from the API
def get_available_models():
    response = client.get(f"/api/v1/projects/{client.config.project}/ai/services/availability", headers={'cdf-version': 'alpha'})
    services = response.json().get("items", [])
    for service in services:
        if service["path"] == "/ai/chat/completions":
            return service["supportedLanguageModels"]
    return []

# Get available models
available_models = get_available_models()

# Sidebar for model selection and conversation reset
st.sidebar.title("Settings")
model_name = st.sidebar.radio("Choose a model:", available_models)
#if model_name == "GPT-3.5-turbo":
#    model = "gpt-35-turbo"
#else:
#    model = "gemini-1.5-pro"
#model = model_name
model = "azure/gpt-4o"
clear_button = st.sidebar.button("Clear Conversation")

# Reset conversation if clear button is pressed
if clear_button:
    st.session_state['generated'] = []
    st.session_state['past'] = []
    st.session_state['messages'] = [
        {"role": "system", "content": "You are an AI assistant for a paper mill. Summarize and answer questions about operations in the paper mill based on the information provided.  Do not make up information.  Top priorties in the paper mill are improving yeild, reducing downtime, improve outage planning, improving safety.  Do not make up action items or conclusions."}
    ]

# Function to generate a response from the OpenAI endpoint
def generate_response(prompt):
    st.session_state['messages'].append({"role": "user", "content": prompt})
    
    completion = client.post(
        url=f"/api/v1/projects/{client.config.project}/ai/chat/completions",
        json={
            "messages": st.session_state['messages'],
            "model": model,
            "maxTokens": 16384,
            "temperature": 0.7
        },
        headers={'cdf-version': 'alpha'}
    )
    response = completion.json()["choices"][0]["message"]["content"]
    st.session_state['messages'].append({"role": "assistant", "content": response})

    return response

# Retrieve files from the "lease_test_JAN" dataset and populate the dropdown
def get_lease_files():
    dataset_id = 5447540683713226  # Replace with the correct dataset ID for "lease_test_JAN"
    files = client.files.list(data_set_ids=[dataset_id], limit=100)  # Adjust limit as needed
    return {file.name: file.id for file in files}  # Dictionary with file names and their IDs

def get_events_summary(start_date: str, end_date: str) -> str:
    """
    Retrieve events from Cognite within a date range and create a summary text for LLM input.
    
    Args:
        start_date (str): Start date in 'YYYY-MM-DD' format.
        end_date (str): End date in 'YYYY-MM-DD' format.
    
    Returns:
        str: Text summarizing the events in the date range.
    """
    # Convert date strings to Unix timestamps (milliseconds)
    start_timestamp = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_timestamp = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp() * 1000)
    
    # Retrieve events from the specified date range
    events = client.events.list(
        start_time={"min": start_timestamp, "max": end_timestamp},
        limit=1000  # Adjust limit as needed
    )
def get_events_summary_with_metadata(start_date: str, end_date: str) -> str:
    """
    Retrieve events from Cognite within a date range and create a detailed summary with metadata.
    
    Args:
        start_date (str): Start date in 'YYYY-MM-DD' format.
        end_date (str): End date in 'YYYY-MM-DD' format.
    
    Returns:
        str: Detailed text summarizing the events in the date range.
    """
    # Convert date strings to Unix timestamps (milliseconds)
    start_timestamp = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_timestamp = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp() * 1000)
    
    # Retrieve events from the specified date range
    events = client.events.list(
        start_time={"min": start_timestamp, "max": end_timestamp},
        limit=1000  # Adjust limit as needed
    )
    
    # Check if there are any events
    if not events:
        return f"No events found between {start_date} and {end_date}."
    
    # Format events into a summary string
    summary = f"Summary of events between {start_date} and {end_date}:\
\
"
    for event in events:
        description = event.description or "No description provided."
        start_time = datetime.fromtimestamp(event.start_time / 1000).strftime("%Y-%m-%d %H:%M:%S") if event.start_time else "N/A"
        end_time = datetime.fromtimestamp(event.end_time / 1000).strftime("%Y-%m-%d %H:%M:%S") if event.end_time else "N/A"
        
        # Include metadata fields in the summary
        metadata = event.metadata or {}
        metadata_text = "\
  ".join([f"{key}: {value}" for key, value in metadata.items()])
        
        summary += (
            f"- Event: {event.type or 'Unknown type'}\
"
            f"  Description: {description}\
"
            f"  Start Time: {start_time}\
"
            f"  End Time: {end_time}\
"
            f"  Metadata:\
  {metadata_text if metadata else 'No metadata provided.'}\
\
"
        )
    
    return summary

#select start and end date for date summarization
st.write("Please select a start and end date to retrieve events.")

# Create date input fields
start_date = st.date_input("Start Date", value=datetime(2024, 11, 18))
end_date = st.date_input("End Date", value=datetime(2024, 11, 20))

# Ensure the end date is not before the start date
if start_date > end_date:
    st.error("End date must be on or after the start date.")
else:
    # Show selected date range
    st.write(f"Selected date range: {start_date} to {end_date}")


# Retrieve the ID of the selected file
default_query = "For the paper mill manager coming on shift, summarize these events into a 1 page of handover notes."
query = st.text_input("Enter your query about the selected date range:", value=default_query)

# Button to parse and query the selected file
if st.button("Parse and Query") and start_date < end_date:
    # Retrieve and parse the selected file using the correct file ID
    start_date_str = start_date.strftime("%Y-%m-%d")
    end_date_str = end_date.strftime("%Y-%m-%d")
    text = get_events_summary_with_metadata(start_date_str, end_date_str)
    
    if text:
        # Truncate the text to a manageable length for querying
        max_text_length = 40000
        truncated_text = text[:max_text_length]
    
    # Generate a refined prompt
    refined_prompt = f"""You are analyzing a this document as a Paper Mill SME. Answer the following question based on the content provided below:

    Document Text:
    {truncated_text}

    Question: {query}"""

    # Get response
    output = generate_response(refined_prompt)
    st.session_state['past'].append(query)
    st.session_state['generated'].append(output)
    
    outputDS = 5109349976865705
    #upload_pdf_to_cdf(text = output, dataset_id = outputDS, client = client) #, filename: str "", metadata: dict = None)


    #save output as PyPDF


# Display conversation history
if st.session_state['generated']:
    for i in range(len(st.session_state['generated'])):
        st.write(f"You: {st.session_state['past'][i]}")
        st.write(f"AI: {st.session_state['generated'][i]}")