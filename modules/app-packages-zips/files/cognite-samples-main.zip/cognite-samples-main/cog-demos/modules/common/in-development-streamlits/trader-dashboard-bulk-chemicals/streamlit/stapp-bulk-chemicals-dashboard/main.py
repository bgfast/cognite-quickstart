import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import random
import numpy as np
import os
import logging

# --- Demo Script Functionality ---
def load_demo_script():
    """Load the demo script from the markdown file with robust path resolution and fallback."""
    
    # Embedded fallback content for when file can't be loaded
    fallback_content = """
# 🧪 Bulk Chemicals Trading Dashboard - Demo Script
**Duration: 8-10 minutes | Business Value Story**

---

## 👥 **PERSONAS**

**🎯 AMANDA FOSTER** - Senior Bulk Chemicals Trader  
*19 years experience at ChemGlobal Trading, manages $220M bulk chemicals portfolio*  
*Specializes in ammonia, methanol, and caustic soda trading across global markets*  
*Known for her expertise in fertilizer market cycles and industrial chemical demand*  
*Currently under pressure to improve trading margins by 18% amid volatile feedstock costs*

**⚙️ ROBERT NAKAMURA** - Chemical Operations Manager  
*16 years experience, oversees 12 chemical plants across North America and Europe*  
*Former chemical engineer with expertise in ammonia synthesis and methanol production*  
*Responsible for $85M in annual production optimization initiatives*  
*Leading digital transformation to improve plant-to-market coordination*

---

## 🌅 **SETTING THE SCENE**
*It's 6:00 AM on a Friday morning at ChemGlobal's Houston trading center. Amanda is monitoring global chemical prices that are volatile due to natural gas supply concerns, while fertilizer demand is spiking ahead of planting season. Robert is at the central operations center coordinating multiple chemical complexes across different time zones. Amanda has significant exposure to ammonia and methanol contracts with delivery commitments to major fertilizer and formaldehyde producers.*

---

## 🎬 **SCENE 1: The Crisis Unfolds (0:00 - 2:00)**

**AMANDA** *(monitoring multiple screens showing chemical prices, natural gas futures, and agricultural demand forecasts)*  
"Robert, we have a critical situation developing. Natural gas futures just spiked $3.20 overnight on pipeline disruptions, ammonia prices in Europe jumped 12% on fertilizer demand, and I've got major ag companies expecting 18,000 metric tons of ammonia delivery over the next three weeks for spring fertilizer production."

**ROBERT** *(video call from operations center, with plant status monitors visible)*  
"I saw the gas spike. What's your margin situation looking like?"

**AMANDA** *(analyzing position screens)*  
"We're long 15,000 MT ammonia at an average of $580/MT, but European spot prices just hit $650. The challenge is our feedstock costs - natural gas is 70% of our production cost. I need to understand our production flexibility and gas contract positions."

---

## 📊 **SCENE 2: Dashboard Deep Dive (2:00 - 5:00)**

**ROBERT**  
"Let me show you our real-time chemical production status using our integrated operations dashboard..."

### **Key Dashboard Interactions:**

1. **Enterprise-Wide Chemical Production**
   - Navigate to Enterprise-Wide view
   - Point out: 12 plants, 8,200 TPD total ammonia capacity
   - Current production: 7,400 TPD (90% utilization)
   - Natural gas consumption: 28 MMBtu/MT at current rates

2. **Regional Focus - North America**
   - Switch to Region-Wide filter  
   - Highlight: Gulf Coast and Ohio Valley plants
   - Combined capacity: 4,800 TPD, locked gas contracts at $4.80/MMBtu

3. **Feedstock Cost Analysis**
   - Click on Gulf Coast Chemical Complex
   - Gas consumption efficiency: 27.5 MMBtu/MT (industry leading)
   - Contract vs. spot gas exposure: 60% hedged through Q2

4. **Product Portfolio Optimization**
   - Show ammonia vs. methanol production flexibility
   - Current split: 65% ammonia, 35% methanol
   - Methanol margins improving (+$45/MT vs. yesterday)

---

## 💡 **SCENE 3: Strategic Decision Making (5:00 - 8:00)**

**AMANDA**  
"This is exactly the visibility I need! I can see our feedstock exposure is manageable with those locked contracts. Can we shift some capacity from methanol to ammonia given these price moves?"

**ROBERT**  
"Absolutely. Our Texas plant can adjust the product mix within 24 hours. We can increase ammonia output by 300 TPD and reduce methanol by 180 TPD, given the synthesis gas flexibility."

**AMANDA**  
"Perfect strategic positioning:
- **Immediate**: Confirm 15,000 MT ammonia delivery using our hedged gas position
- **Opportunistic**: Offer additional 3,000 MT at $630/MT capturing the premium
- **Optimization**: Shift 300 TPD capacity to ammonia for next 2 weeks"

### **Business Impact Demonstrated:**

**Before Dashboard:**
- Individual plant calls (90+ minutes)
- Conservative gas cost assumptions  
- Missed product switching opportunities
- Delayed decision making

**With Dashboard:**
- Real-time cost and production visibility (5 minutes)
- Confident margin management
- Optimized product portfolio decisions
- **Result**: Additional $420K profit opportunity over 3 weeks

---

## 🎯 **SCENE 4: Chemical Industry Leadership (8:00 - 10:00)**

**AMANDA**  
"Robert, this integrated approach is transformative. While competitors are struggling with feedstock cost uncertainty, we're making informed decisions that optimize our entire chemical value chain."

**ROBERT**  
"Exactly. From the production side, I can optimize our plant operations based on your forward positions, manage our gas purchasing strategy around your trading book, and ensure we're capturing every efficiency opportunity."

### **Quantified Business Value:**
- **Margin Optimization**: 18% improvement ($39.6M annual impact)
- **Decision Speed**: 18x faster (90 min → 5 min)
- **Product Mix Optimization**: $1.8M additional monthly revenue
- **Feedstock Cost Management**: $2.4M saved annually through better hedging
- **Capacity Utilization**: 95% average vs. 87% industry standard

---

## 🔧 **Key Features Demonstrated:**

✅ **Real-time Chemical Production Monitoring**  
✅ **Feedstock Cost & Contract Tracking**  
✅ **Product Portfolio Optimization**  
✅ **Multi-plant Capacity Coordination**  
✅ **Natural Gas Price Integration**  
✅ **Margin Analysis & Forecasting**  
✅ **Global Market Intelligence**

---

## 📈 **ROI Summary:**
- **Implementation Cost**: $950K
- **Annual Benefit**: $43.8M
- **Payback Period**: 7.9 days
- **3-Year NPV**: $122M

---

*This dashboard transforms bulk chemicals trading from reactive to proactive, enabling integrated feedstock-to-market optimization that maximizes margins while managing volatile input costs.*
"""
    
    try:
        # Get the directory of the current script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Multiple path attempts for different deployment scenarios
        possible_paths = [
            # Local development path (original)
            os.path.join(os.path.dirname(os.path.dirname(current_dir)), "DEMO_SCRIPT.md"),
            # Container deployment paths
            os.path.join("/app", "DEMO_SCRIPT.md"),
            os.path.join("/app", "trader-dashboard-bulk-chemicals", "DEMO_SCRIPT.md"),
            # Relative to current directory
            os.path.join(current_dir, "DEMO_SCRIPT.md"),
            os.path.join(current_dir, "..", "..", "DEMO_SCRIPT.md"),
            # Working directory
            "DEMO_SCRIPT.md",
            "./DEMO_SCRIPT.md"
        ]
        
        # Try each path
        for path in possible_paths:
            try:
                if os.path.exists(path):
                    with open(path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():  # Ensure file is not empty
                            return content
            except Exception as path_error:
                # Log individual path failures but continue trying
                logging.warning(f"Failed to load demo script from {path}: {path_error}")
                continue
        
        # If no file found, return fallback content
        logging.info("Demo script file not found in any expected location, using embedded fallback content")
        return fallback_content
        
    except Exception as e:
        # Final fallback with error info
        logging.error(f"Error in load_demo_script: {str(e)}")
        return f"""
# Demo Script Loading Error

**Error Details:** {str(e)}

**Fallback Content:**

{fallback_content}
"""

# Page configuration
st.set_page_config(layout="wide", page_title="Bulk Chemicals Trading Dashboard", page_icon="🧪")

st.title("🧪 Bulk Chemicals Trading Dashboard - Real-Time Production Insights")

# Prominent disclaimer
st.markdown(
    """
    <div style="background-color:#fff3cd; padding: 10px; border-left: 5px solid #ffc107; margin-bottom: 20px;">
        <h4 style="color:#856404; margin-top: 0;">⚠️ IMPORTANT: This is a Mockup Demo</h4>
        <p style="color:#856404; margin-bottom: 0;">
            This dashboard uses **simulated data** to illustrate potential functionalities for bulk chemical trading operations. 
            It is a **mockup, not a Proof-of-Concept (POC)**, and does not connect to live production systems. 
            Its purpose is to facilitate discussion and gather feedback on desired features and data presentation.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

# --- Global Definitions for Bulk Chemical Data Simulation ---
regions = ["North America", "Europe", "Asia Pacific", "Middle East", "South America", "Africa"]
bulk_chemicals = ["Ammonia", "Methanol", "Caustic Soda (NaOH)", "Sulfuric Acid", "Urea"]
equipment_types = ["Reformer", "Reactor", "Absorption Tower", "Distillation Column", "Heat Exchanger", "Compressor", "Crystallizer", "Neutralizer"]
status_options = ["Optimal", "Reduced Output", "Planned Maintenance", "Forced Outage", "Shutdown"]
incident_causes = ["Equipment Failure", "Feedstock Issue", "Catalyst Problem", "Utility Disruption", "Scheduled Maintenance", "Environmental Limit"]
outlook_options = ["Improving", "Stable", "Declining", "Under Review", "Recovering"]

# Trader's Book of Business (regional and product specializations)
trader_books = {
    "Trader A (Nitrogen)": {"Regions": ["North America", "Europe"], "Products": ["Ammonia", "Urea"]},
    "Trader B (Methanol)": {"Regions": ["Asia Pacific", "Middle East"], "Products": ["Methanol"]},
    "Trader C (Caustics)": {"Regions": ["North America", "South America"], "Products": ["Caustic Soda (NaOH)", "Sulfuric Acid"]},
    "Trader D (Global)": {"Regions": regions, "Products": bulk_chemicals}
}

def get_hardcoded_plant_data(num_plants=20):
    """
    Generates hard-coded data for 20 bulk chemical plants across different products and regions.
    Simulates various operational states for chemical trading scenarios.
    """
    plants_template = [
        {"name": "Gulf Coast Ammonia Complex", "region": "North America", "product": "Ammonia", "capacity_tpd": 3000},
        {"name": "Louisiana Methanol Plant", "region": "North America", "product": "Methanol", "capacity_tpd": 2500},
        {"name": "Texas Caustic Plant", "region": "North America", "product": "Caustic Soda (NaOH)", "capacity_tpd": 1800},
        {"name": "Ohio Sulfuric Acid Plant", "region": "North America", "product": "Sulfuric Acid", "capacity_tpd": 2200},
        {"name": "Illinois Urea Complex", "region": "North America", "product": "Urea", "capacity_tpd": 2800},
        {"name": "Rotterdam Methanol Terminal", "region": "Europe", "product": "Methanol", "capacity_tpd": 2000},
        {"name": "Antwerp Ammonia Plant", "region": "Europe", "product": "Ammonia", "capacity_tpd": 2700},
        {"name": "German Caustic Facility", "region": "Europe", "product": "Caustic Soda (NaOH)", "capacity_tpd": 1600},
        {"name": "UK Sulfuric Plant", "region": "Europe", "product": "Sulfuric Acid", "capacity_tpd": 1900},
        {"name": "French Urea Plant", "region": "Europe", "product": "Urea", "capacity_tpd": 2400},
        {"name": "Singapore Methanol Hub", "region": "Asia Pacific", "product": "Methanol", "capacity_tpd": 3200},
        {"name": "China Ammonia Complex", "region": "Asia Pacific", "product": "Ammonia", "capacity_tpd": 4000},
        {"name": "Japan Caustic Plant", "region": "Asia Pacific", "product": "Caustic Soda (NaOH)", "capacity_tpd": 1500},
        {"name": "Korea Urea Facility", "region": "Asia Pacific", "product": "Urea", "capacity_tpd": 3500},
        {"name": "Saudi Methanol Plant", "region": "Middle East", "product": "Methanol", "capacity_tpd": 5000},
        {"name": "UAE Ammonia Complex", "region": "Middle East", "product": "Ammonia", "capacity_tpd": 3800},
        {"name": "Qatar Urea Plant", "region": "Middle East", "product": "Urea", "capacity_tpd": 4200},
        {"name": "Brazil Methanol Plant", "region": "South America", "product": "Methanol", "capacity_tpd": 1800},
        {"name": "Argentina Urea Plant", "region": "South America", "product": "Urea", "capacity_tpd": 2200},
        {"name": "South Africa Ammonia", "region": "Africa", "product": "Ammonia", "capacity_tpd": 2000},
    ]
    
    num_plants_to_create = min(num_plants, len(plants_template))
    selected_plants = plants_template[:num_plants_to_create]
    
    all_plants_data = []
    
    for i, plant_info in enumerate(selected_plants):
        plant_name = plant_info["name"]
        plant_id = f"plant_{i+1}"
        region = plant_info["region"]
        product = plant_info["product"]
        capacity_tpd = plant_info["capacity_tpd"]
        
        status = random.choices(status_options, weights=[0.60, 0.20, 0.10, 0.07, 0.03], k=1)[0]
        
        # Assign trader books based on region and product
        assigned_trader_books = []
        for trader, details in trader_books.items():
            if region in details["Regions"] and product in details["Products"]:
                assigned_trader_books.append(trader)
        
        if not assigned_trader_books:
            assigned_trader_books = ["Trader D (Global)"]
        
        # Randomize to 1-2 traders max
        if len(assigned_trader_books) > 2:
            assigned_trader_books = random.sample(assigned_trader_books, k=random.randint(1, 2))
        
        current_plant = {
            "PlantID": plant_id,
            "PlantName": plant_name,
            "Region": region,
            "Product": product,
            "CapacityTPD": capacity_tpd,
            "OverallStatus": status,
            "LastUpdated": datetime.now() - timedelta(minutes=random.randint(5, 60)),
            "TraderBooks": assigned_trader_books,
        }
        
        # Calculate current production based on status
        base_production = capacity_tpd * random.uniform(0.75, 0.95)  # Normal utilization
        production_factor = 1.0
        
        if status == "Reduced Output":
            production_factor = random.uniform(0.4, 0.7)
        elif status == "Planned Maintenance":
            production_factor = random.uniform(0.2, 0.5)
        elif status == "Forced Outage":
            production_factor = random.uniform(0.0, 0.2)
        elif status == "Shutdown":
            production_factor = 0.0
        
        current_production = base_production * production_factor
        planned_production = base_production
        
        current_plant["CurrentProduction_TPD"] = current_production
        current_plant["PlannedProduction_TPD"] = planned_production
        current_plant["ProductionDeviation_Pct"] = ((current_production - planned_production) / planned_production) * 100 if planned_production > 0 else 0
        current_plant["Utilization_Pct"] = (current_production / capacity_tpd) * 100
        
        # Market pricing (example ranges in $/metric ton)
        price_ranges = {
            "Ammonia": (400, 600),
            "Methanol": (300, 450),
            "Caustic Soda (NaOH)": (250, 400),
            "Sulfuric Acid": (80, 150),
            "Urea": (350, 500)
        }
        
        price_range = price_ranges.get(product, (200, 400))
        current_price = random.uniform(price_range[0], price_range[1])
        current_plant["MarketPrice_USD_MT"] = current_price
        
        # Equipment status simulation
        equipment_status = []
        num_equipment = random.randint(4, 8)
        
        for eq_idx in range(num_equipment):
            eq_type = random.choice(equipment_types)
            eq_name = f"{eq_type} {eq_idx+1}"
            eq_status_options_eq = ["Optimal", "Reduced Capacity", "Maintenance", "Fault", "Offline"]
            eq_status = random.choices(eq_status_options_eq, weights=[0.75, 0.12, 0.08, 0.03, 0.02], k=1)[0]
            
            production_impact_tpd = 0
            estimated_duration_hours = 0
            
            if eq_status in ["Reduced Capacity", "Fault", "Offline"]:
                if eq_status == "Reduced Capacity":
                    impact_factor = random.uniform(0.05, 0.20)
                    production_impact_tpd = capacity_tpd * impact_factor
                    estimated_duration_hours = random.randint(4, 24)
                elif eq_status == "Fault":
                    impact_factor = random.uniform(0.20, 0.50)
                    production_impact_tpd = capacity_tpd * impact_factor
                    estimated_duration_hours = random.randint(12, 72)
                elif eq_status == "Offline":
                    impact_factor = random.uniform(0.50, 1.0)
                    production_impact_tpd = capacity_tpd * impact_factor
                    estimated_duration_hours = random.randint(24, 168)
            
            equipment_status.append({
                "EquipmentID": f"eq_{plant_id}_{eq_idx}",
                "Name": eq_name,
                "Type": eq_type,
                "Status": eq_status,
                "ProductionImpact_TPD": round(production_impact_tpd, 1),
                "EstimatedDuration_Hours": estimated_duration_hours
            })
        
        current_plant["Equipment"] = equipment_status
        
        # Incidents and supervisor notes
        incidents = []
        if status != "Optimal":
            incident_type = "Forced Outage" if status in ["Forced Outage", "Shutdown"] else "Planned Maintenance" if status == "Planned Maintenance" else "Performance Issue"
            
            incident_duration = 0
            if status in ["Forced Outage", "Shutdown"]:
                incident_duration = random.randint(24, 168)
            elif status == "Planned Maintenance":
                incident_duration = random.randint(48, 336)
            elif status == "Reduced Output":
                incident_duration = random.randint(6, 48)
            
            supervisor_note = f"Experiencing {incident_type} due to {random.choice(incident_causes)}. Production team actively addressing."
            if incident_duration > 0:
                supervisor_note += f" Estimated restoration in {incident_duration} hours."
            
            incidents.append({
                "Timestamp": datetime.now() - timedelta(hours=random.randint(1, 24)),
                "Type": incident_type,
                "RootCause": random.choice(incident_causes),
                "ImpactDescription": f"Reduced production by {abs(current_plant['ProductionDeviation_Pct']):.1f}%",
                "Outlook": random.choice(outlook_options),
                "EstimatedDuration_Hours": incident_duration,
                "SupervisorNotes": supervisor_note,
                "Source": "Operations"
            })
        
        current_plant["Incidents"] = incidents
        all_plants_data.append(current_plant)
    
    # Override specific plants for demo consistency
    # Gulf Coast Ammonia - Major outage scenario
    gulf_ammonia = next((item for item in all_plants_data if item["PlantName"] == "Gulf Coast Ammonia Complex"), None)
    if gulf_ammonia:
        gulf_ammonia["OverallStatus"] = "Forced Outage"
        gulf_ammonia["CurrentProduction_TPD"] = 300.0
        gulf_ammonia["PlannedProduction_TPD"] = 2850.0
        gulf_ammonia["ProductionDeviation_Pct"] = -89.5
        gulf_ammonia["Utilization_Pct"] = 10.0
        gulf_ammonia["TraderBooks"] = ["Trader A (Nitrogen)", "Trader D (Global)"]
        
        gulf_ammonia["Incidents"] = [{
            "Timestamp": datetime.now() - timedelta(hours=6),
            "Type": "Forced Outage",
            "RootCause": "Equipment Failure",
            "ImpactDescription": "Primary reformer trip caused plant shutdown. Emergency generator maintaining minimal production.",
            "Outlook": "Under Review",
            "EstimatedDuration_Hours": 96,
            "SupervisorNotes": "Major reformer failure. Replacement parts being expedited from Europe. Estimated 4-day outage affecting 2,550 TPD capacity.",
            "Source": "Operations"
        }]
    
    return pd.DataFrame(all_plants_data)

@st.cache_data(ttl=30)
def get_plant_data():
    """Retrieves the hard-coded chemical plant data."""
    return get_hardcoded_plant_data()

# --- Additional Helper Functions ---

@st.cache_data(ttl=10)
def get_equipment_details(selected_plant_data):
    """Retrieves equipment details from the provided plant data."""
    if selected_plant_data is None or not isinstance(selected_plant_data, pd.Series):
        return pd.DataFrame()
    return pd.DataFrame(selected_plant_data["Equipment"])

@st.cache_data(ttl=10)
def get_incidents(selected_plant_data):
    """Retrieves incidents and supervisor notes from the provided plant data."""
    if selected_plant_data is None or not isinstance(selected_plant_data, pd.Series):
        return pd.DataFrame()
    return pd.DataFrame(selected_plant_data["Incidents"])

@st.cache_data(ttl=30)
def get_production_trends(plant_id, region, product):
    """
    Generates historical production data for a specific plant, region, or product,
    including month-to-date, 30-day forecast, and 30-day rolling average.
    """
    today = datetime.now().date()
    start_date = today - timedelta(days=60)
    end_date = today + timedelta(days=30)
    
    dates = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]
    
    df_plants = get_plant_data()
    
    if plant_id:
        plant_row = df_plants[df_plants["PlantID"] == plant_id].iloc[0]
        base_production = plant_row["PlannedProduction_TPD"]
        analysis_name = plant_row["PlantName"]
    elif product:
        product_plants = df_plants[df_plants["Product"] == product]
        if region:
            product_plants = product_plants[product_plants["Region"] == region]
        base_production = product_plants["PlannedProduction_TPD"].sum()
        analysis_name = f"{product} - {region}" if region else f"{product} Global"
    else:
        # Regional aggregation
        region_plants = df_plants[df_plants["Region"] == region]
        base_production = region_plants["PlannedProduction_TPD"].sum()
        analysis_name = f"{region} Region"
    
    production_data_points = []
    
    for date in dates:
        if date <= today:  # Historical data
            daily_prod = base_production * random.uniform(0.80, 1.05)
            
            # Simulate operational impacts
            if random.random() < 0.08:  # 8% chance of significant event
                daily_prod *= random.uniform(0.3, 0.8)
            
            production_data_points.append({
                "Date": date,
                "Production (TPD)": daily_prod,
                "Planned Production (TPD)": base_production,
                "Type": "Actual"
            })
        else:  # Forecast data
            forecast_prod = base_production * random.uniform(0.85, 1.02)
            
            # Market demand adjustments
            seasonal_factor = 0.9 + 0.2 * random.random()
            forecast_prod *= seasonal_factor
            
            production_data_points.append({
                "Date": date,
                "Forecast (TPD)": forecast_prod,
                "Planned Production (TPD)": base_production,
                "Type": "Forecast"
            })
    
    df_combined = pd.DataFrame(production_data_points)
    df_combined["Date"] = pd.to_datetime(df_combined["Date"])
    df_combined.set_index("Date", inplace=True)
    
    # Calculate 30-day rolling average for historical data
    historical_mask = df_combined.index.date <= today
    df_combined.loc[historical_mask, "30-Day Rolling Avg (TPD)"] = \
        df_combined.loc[historical_mask, "Production (TPD)"].rolling(window=30, min_periods=1).mean()
    
    # Fill NaN values for plotting
    df_combined.loc[df_combined['Type'] == 'Forecast', 'Production (TPD)'] = np.nan
    df_combined.loc[df_combined['Type'] == 'Actual', 'Forecast (TPD)'] = np.nan
    
    # Calculate Month-to-Date production
    first_day_of_month = today.replace(day=1)
    mtd_df = df_combined.loc[(df_combined.index.date >= first_day_of_month) & (df_combined.index.date <= today)]
    mtd_production = mtd_df["Production (TPD)"].sum()
    
    df_combined.reset_index(inplace=True)
    
    return df_combined, mtd_production, analysis_name

# --- Main Dashboard UI ---

st.markdown("---")

# --- Sidebar Navigation ---
st.sidebar.header("Navigation")

# Add tabs for main dashboard and demo script
page = st.sidebar.radio("Select Page:", ["Dashboard", "Demo Script"])

if page == "Demo Script":
    st.title("🧪 Bulk Chemicals Trading Dashboard - Demo Script")
    st.markdown("---")
    
    demo_content = load_demo_script()
    st.markdown(demo_content)
    
    st.markdown("---")
    st.caption("Return to the Dashboard using the sidebar navigation.")
    st.stop()  # Stop execution here for demo script page

# --- Filtering Options (Enterprise, Region, Trader's Book) ---
st.sidebar.header("View Filters")

view_mode = st.sidebar.radio(
    "Select View Mode:",
    ("Enterprise Wide", "Region Wide", "My Book of Business")
)

df_plants = get_plant_data()
filtered_plants_df = df_plants.copy()
selected_region = None
selected_trader_book = None

if view_mode == "Region Wide":
    regions_available = sorted(df_plants["Region"].unique().tolist())
    selected_region = st.sidebar.selectbox("Select Region:", regions_available)
    filtered_plants_df = filtered_plants_df[filtered_plants_df["Region"] == selected_region]
elif view_mode == "My Book of Business":
    # Flatten trader books and get unique values
    all_trader_books = []
    for _, row in df_plants.iterrows():
        all_trader_books.extend(row["TraderBooks"])
    unique_trader_books = sorted(list(set(all_trader_books)))
    
    selected_trader_book = st.sidebar.selectbox("Select Trader Book:", unique_trader_books)
    
    # Filter plants that include this trader book
    mask = df_plants["TraderBooks"].apply(lambda x: selected_trader_book in x)
    filtered_plants_df = filtered_plants_df[mask]

# Additional filters
st.sidebar.subheader("Additional Filters")
product_filter = st.sidebar.multiselect(
    "Filter by Product:",
    options=sorted(df_plants["Product"].unique()),
    default=sorted(df_plants["Product"].unique())
)

status_filter = st.sidebar.multiselect(
    "Filter by Status:",
    options=status_options,
    default=status_options
)

# Apply additional filters
filtered_plants_df = filtered_plants_df[
    (filtered_plants_df["Product"].isin(product_filter)) &
    (filtered_plants_df["OverallStatus"].isin(status_filter))
]

# --- Summary metrics row ---
col1, col2, col3, col4 = st.columns(4)

total_capacity = filtered_plants_df["CapacityTPD"].sum()
total_current = filtered_plants_df["CurrentProduction_TPD"].sum()
total_planned = filtered_plants_df["PlannedProduction_TPD"].sum()
avg_utilization = filtered_plants_df["Utilization_Pct"].mean() if len(filtered_plants_df) > 0 else 0

with col1:
    st.metric(
        "Total Capacity", 
        f"{total_capacity:,.0f} TPD",
        help="Total production capacity of filtered plants"
    )

with col2:
    st.metric(
        "Current Production", 
        f"{total_current:,.0f} TPD",
        delta=f"{total_current - total_planned:,.0f} TPD vs Plan"
    )

with col3:
    st.metric(
        "Average Utilization", 
        f"{avg_utilization:.1f}%",
        help="Current production as % of capacity"
    )

with col4:
    outage_count = len(filtered_plants_df[filtered_plants_df["OverallStatus"].isin(["Forced Outage", "Shutdown"])])
    st.metric(
        "Plants with Outages", 
        f"{outage_count}",
        delta=f"{len(filtered_plants_df)} total plants"
    )

st.markdown("---")

# Real-time Production Alerts
st.subheader("🚨 Real-Time Production Alerts")

# Identify plants with significant deviations
alert_plants = filtered_plants_df[
    (filtered_plants_df["ProductionDeviation_Pct"] < -20) | 
    (filtered_plants_df["OverallStatus"].isin(["Forced Outage", "Shutdown"]))
].copy()

if len(alert_plants) > 0:
    for _, plant in alert_plants.iterrows():
        deviation = plant["ProductionDeviation_Pct"]
        
        if plant["OverallStatus"] in ["Forced Outage", "Shutdown"]:
            alert_type = "🔴 CRITICAL"
            color = "red"
        elif deviation < -50:
            alert_type = "🟠 HIGH"
            color = "orange"
        else:
            alert_type = "🟡 MEDIUM"
            color = "gold"
        
        shortfall_tpd = plant["PlannedProduction_TPD"] - plant["CurrentProduction_TPD"]
        
        st.markdown(
            f"""
            <div style="border-left: 5px solid {color}; padding: 10px; margin: 10px 0; background-color: #f8f9fa;">
                <strong>{alert_type}: {plant['PlantName']}</strong> ({plant['Region']}, {plant['Product']})<br/>
                <strong>Impact:</strong> {deviation:.1f}% below plan ({shortfall_tpd:.0f} TPD shortfall)<br/>
                <strong>Market Value:</strong> ${shortfall_tpd * plant['MarketPrice_USD_MT']:,.0f}/day lost revenue<br/>
                <strong>Status:</strong> {plant['OverallStatus']} | <strong>Last Updated:</strong> {plant['LastUpdated'].strftime('%H:%M')}
            </div>
            """,
            unsafe_allow_html=True
        )
else:
    st.info("✅ No significant production alerts at this time.")

st.markdown("---")

# Trader Recommendations
st.subheader("📊 Trader Recommendations")

col1, col2 = st.columns(2)

with col1:
    st.write("**Production Shortfall Analysis**")
    
    total_shortfall_tpd = 0
    for _, plant in filtered_plants_df.iterrows():
        if plant["CurrentProduction_TPD"] < plant["PlannedProduction_TPD"]:
            total_shortfall_tpd += plant["PlannedProduction_TPD"] - plant["CurrentProduction_TPD"]
    
    if total_shortfall_tpd > 100:
        st.error(f"**Current Shortfall:** {total_shortfall_tpd:.0f} TPD")
        
        # Calculate financial impact by product
        product_shortfalls = {}
        for _, plant in filtered_plants_df.iterrows():
            if plant["CurrentProduction_TPD"] < plant["PlannedProduction_TPD"]:
                shortfall = plant["PlannedProduction_TPD"] - plant["CurrentProduction_TPD"]
                product = plant["Product"]
                price = plant["MarketPrice_USD_MT"]
                
                if product not in product_shortfalls:
                    product_shortfalls[product] = {"shortfall": 0, "value": 0}
                
                product_shortfalls[product]["shortfall"] += shortfall
                product_shortfalls[product]["value"] += shortfall * price
        
        st.write("**By Product:**")
        total_daily_value = 0
        for product, data in product_shortfalls.items():
            st.write(f"• **{product}:** {data['shortfall']:.0f} TPD (${data['value']:,.0f}/day)")
            total_daily_value += data["value"]
        
        st.write(f"• **Total Daily Impact:** ${total_daily_value:,.0f}")
        
        # Weekly and monthly projections
        weekly_impact = total_daily_value * 7
        monthly_impact = total_daily_value * 30
        st.write(f"• **Weekly Impact:** ${weekly_impact:,.0f}")
        st.write(f"• **Monthly Impact:** ${monthly_impact:,.0f}")
        
    elif total_shortfall_tpd > 0:
        st.warning(f"**Minor Shortfall:** {total_shortfall_tpd:.0f} TPD")
        st.write("• Monitor for potential market tightness")
        st.write("• Review inventory levels")
    else:
        st.success("✅ No production shortfall - meeting planned output")

with col2:
    st.write("**Recommended Actions**")
    if total_shortfall_tpd > 100:
        st.write("🔴 **IMMEDIATE ACTION REQUIRED**")
        st.write("**Purchase Recommendations:**")
        
        for product, data in product_shortfalls.items():
            shortfall = data["shortfall"]
            if shortfall > 0:
                # Calculate purchase recommendations
                immediate_need = shortfall * 3  # 3-day buffer
                weekly_need = shortfall * 7
                
                st.write(f"**{product}:**")
                st.write(f"• Immediate (3-day): {immediate_need:,.0f} MT")
                st.write(f"• Weekly: {weekly_need:,.0f} MT")
        
        st.write("**Actions:**")
        st.write("• Contact suppliers for emergency purchases")
        st.write("• Check spot market availability")
        st.write("• Review contract force majeure clauses")
        st.write("• Consider alternative supply sources")
        
    elif total_shortfall_tpd > 0:
        st.write("🟡 **MONITOR CLOSELY**")
        st.write("• Prepare for potential market purchases")
        st.write("• Monitor production recovery timelines")
        st.write("• Review customer allocation priorities")
        
    else:
        st.write("✅ **NORMAL OPERATIONS**")
        
        # Calculate excess capacity for sales opportunities
        excess_tpd = total_current - total_planned
        if excess_tpd > 50:
            avg_price = filtered_plants_df["MarketPrice_USD_MT"].mean()
            potential_revenue = excess_tpd * avg_price
            
            st.write(f"**Sales Opportunities:**")
            st.write(f"• **Excess Production:** {excess_tpd:.0f} TPD")
            st.write(f"• **Potential Revenue:** ${potential_revenue:,.0f}/day")
            st.write("**Actions:**")
            st.write("• Market excess production")
            st.write("• Consider spot sales opportunities")
            st.write("• Review contract optimization")
        else:
            st.write("**Actions:**")
            st.write("• Continue standard monitoring")
            st.write("• Optimize production efficiency")
            st.write("• Monitor market opportunities")

st.markdown("---")

# Top 5 Equipment Impact
st.subheader("⚙️ Top 5 Equipment Impact")

# Gather all equipment with production impacts
all_equipment = []
for _, plant in filtered_plants_df.iterrows():
    equipment_list = plant["Equipment"]
    for equipment in equipment_list:
        if equipment["ProductionImpact_TPD"] > 0:
            equipment["PlantName"] = plant["PlantName"]
            equipment["Region"] = plant["Region"]
            equipment["Product"] = plant["Product"]
            all_equipment.append(equipment)

if all_equipment:
    df_equipment = pd.DataFrame(all_equipment)
    df_equipment = df_equipment.sort_values("ProductionImpact_TPD", ascending=False).head(5)
    
    for _, equipment in df_equipment.iterrows():
        status_color = "red" if equipment["Status"] in ["Fault", "Offline"] else "orange"
        
        st.markdown(
            f"""
            <div style="border-left: 5px solid {status_color}; padding: 10px; margin: 10px 0; background-color: #f8f9fa;">
                <strong>{equipment['Name']}</strong> - {equipment['PlantName']} ({equipment['Region']})<br/>
                <strong>Product:</strong> {equipment['Product']} | <strong>Status:</strong> {equipment['Status']}<br/>
                <strong>Production Impact:</strong> {equipment['ProductionImpact_TPD']:.0f} TPD reduction<br/>
                <strong>Estimated Duration:</strong> {equipment['EstimatedDuration_Hours']} hours
            </div>
            """,
            unsafe_allow_html=True
        )
else:
    st.success("✅ No equipment issues with significant production impact.")

st.markdown("---")

# Plant Performance Summary
st.subheader("🏭 Plant Performance Summary")

# Create a more detailed plant overview table
display_df = filtered_plants_df[[
    "PlantName", "Region", "Product", "OverallStatus", 
    "CurrentProduction_TPD", "PlannedProduction_TPD", "ProductionDeviation_Pct",
    "Utilization_Pct", "MarketPrice_USD_MT"
]].copy()

display_df["Current Production"] = display_df["CurrentProduction_TPD"].apply(lambda x: f"{x:,.0f} TPD")
display_df["Planned Production"] = display_df["PlannedProduction_TPD"].apply(lambda x: f"{x:,.0f} TPD")
display_df["Deviation %"] = display_df["ProductionDeviation_Pct"].apply(lambda x: f"{x:+.1f}%")
display_df["Utilization %"] = display_df["Utilization_Pct"].apply(lambda x: f"{x:.1f}%")
display_df["Market Price"] = display_df["MarketPrice_USD_MT"].apply(lambda x: f"${x:.0f}/MT")

# Rename columns for display
display_df = display_df.rename(columns={
    "PlantName": "Plant Name",
    "OverallStatus": "Status"
})

# Select only the columns we want to show
final_display_df = display_df[[
    "Plant Name", "Region", "Product", "Status", 
    "Current Production", "Planned Production", "Deviation %", "Utilization %", "Market Price"
]]

# Color code the status
def color_status(val):
    if val in ["Forced Outage", "Shutdown"]:
        return 'background-color: #ffebee'  # Light red
    elif val == "Reduced Output":
        return 'background-color: #fff3e0'  # Light orange
    elif val == "Planned Maintenance":
        return 'background-color: #e3f2fd'  # Light blue
    else:
        return 'background-color: #e8f5e8'  # Light green

def color_deviation(val):
    try:
        numeric_val = float(val.replace('%', '').replace('+', ''))
        if numeric_val < -20:
            return 'background-color: #ffebee; color: red'
        elif numeric_val < -10:
            return 'background-color: #fff3e0; color: orange'
        elif numeric_val > 5:
            return 'background-color: #e8f5e8; color: green'
        else:
            return ''
    except:
        return ''

# Apply styling
try:
    styled_df = final_display_df.style.map(color_status, subset=['Status']).map(color_deviation, subset=['Deviation %'])
    st.dataframe(styled_df, use_container_width=True, hide_index=True)
except:
    # Fallback if styling fails
    st.dataframe(final_display_df, use_container_width=True, hide_index=True)

st.markdown("---")

# Production Analytics Section
st.subheader("📈 Production Analytics")

col1, col2 = st.columns([1, 1])

with col1:
    st.write("**Select Analysis Scope:**")
    
    analysis_type = st.radio(
        "Analysis Type:",
        ("Individual Plant", "Product Analysis", "Regional Analysis"),
        horizontal=True
    )

with col2:
    if analysis_type == "Individual Plant":
        selected_plant_name = st.selectbox(
            "Select Plant:",
            options=filtered_plants_df["PlantName"].tolist()
        )
        selected_plant_data = filtered_plants_df[filtered_plants_df["PlantName"] == selected_plant_name].iloc[0]
        plant_id = selected_plant_data["PlantID"]
        analysis_region = None
        analysis_product = None
    elif analysis_type == "Product Analysis":
        analysis_product = st.selectbox(
            "Select Product:",
            options=sorted(filtered_plants_df["Product"].unique())
        )
        analysis_region = st.selectbox(
            "Select Region (Optional):",
            options=["All Regions"] + sorted(filtered_plants_df["Region"].unique())
        )
        if analysis_region == "All Regions":
            analysis_region = None
        plant_id = None
        selected_plant_data = None
    else:  # Regional Analysis
        analysis_region = st.selectbox(
            "Select Region:",
            options=sorted(filtered_plants_df["Region"].unique())
        )
        analysis_product = None
        plant_id = None
        selected_plant_data = None

# Generate production trends
df_trends, mtd_production, analysis_name = get_production_trends(plant_id, analysis_region, analysis_product)

# Display analytics
col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Month-to-Date Production", f"{mtd_production:,.0f} TPD")

with col2:
    # Calculate 30-day average
    today = datetime.now().date()
    thirty_days_ago = today - timedelta(days=30)
    recent_data = df_trends[
        (pd.to_datetime(df_trends["Date"]).dt.date >= thirty_days_ago) & 
        (pd.to_datetime(df_trends["Date"]).dt.date <= today)
    ]
    avg_30_day = recent_data["Production (TPD)"].mean()
    st.metric("30-Day Average", f"{avg_30_day:,.0f} TPD")

with col3:
    # Calculate next 30-day forecast average
    thirty_days_future = today + timedelta(days=30)
    forecast_data = df_trends[
        (pd.to_datetime(df_trends["Date"]).dt.date > today) & 
        (pd.to_datetime(df_trends["Date"]).dt.date <= thirty_days_future)
    ]
    avg_forecast = forecast_data["Forecast (TPD)"].mean()
    st.metric("30-Day Forecast", f"{avg_forecast:,.0f} TPD")

# Create the production trend chart
fig_trend = go.Figure()

# Add actual production
actual_data = df_trends[df_trends["Type"] == "Actual"]
fig_trend.add_trace(go.Scatter(
    x=actual_data["Date"],
    y=actual_data["Production (TPD)"],
    mode='lines',
    name='Actual Production',
    line=dict(color='blue', width=2)
))

# Add planned production
fig_trend.add_trace(go.Scatter(
    x=df_trends["Date"],
    y=df_trends["Planned Production (TPD)"],
    mode='lines',
    name='Planned Production',
    line=dict(color='gray', dash='dash', width=1)
))

# Add 30-day rolling average
rolling_data = df_trends[df_trends["Type"] == "Actual"]
fig_trend.add_trace(go.Scatter(
    x=rolling_data["Date"],
    y=rolling_data["30-Day Rolling Avg (TPD)"],
    mode='lines',
    name='30-Day Rolling Average',
    line=dict(color='green', width=2)
))

# Add forecast
forecast_data = df_trends[df_trends["Type"] == "Forecast"]
fig_trend.add_trace(go.Scatter(
    x=forecast_data["Date"],
    y=forecast_data["Forecast (TPD)"],
    mode='lines',
    name='30-Day Forecast',
    line=dict(color='orange', dash='dot', width=2)
))

# Add vertical line for today
try:
    fig_trend.add_vline(
        x=pd.Timestamp(today),
        line_dash="solid",
        line_color="red",
        annotation_text="Today",
        annotation_position="top"
    )
except Exception:
    # Fallback if timestamp conversion fails
    fig_trend.add_annotation(
        x=0.5, y=0.95,
        xref="paper", yref="paper",
        text="Today marker unavailable",
        showarrow=False
    )

fig_trend.update_layout(
    title=f"Production Trends: {analysis_name}",
    xaxis_title="Date",
    yaxis_title="Production (TPD)",
    height=400,
    hovermode='x unified'
)

st.plotly_chart(fig_trend, use_container_width=True)

st.markdown("---")

# Operations Intelligence Section
st.subheader("🔍 Operations Intelligence")

tab1, tab2, tab3 = st.tabs(["📋 Incident Logs", "📝 Supervisor Notes", "❓ Operations Inquiry"])

with tab1:
    st.write("**Recent Incidents and Operational Issues**")
    
    all_incidents = []
    for _, plant in filtered_plants_df.iterrows():
        plant_incidents = plant["Incidents"]
        for incident in plant_incidents:
            incident["PlantName"] = plant["PlantName"]
            incident["Region"] = plant["Region"]
            incident["Product"] = plant["Product"]
            all_incidents.append(incident)
    
    if all_incidents:
        df_incidents = pd.DataFrame(all_incidents)
        df_incidents = df_incidents.sort_values("Timestamp", ascending=False)
        
        for _, incident in df_incidents.iterrows():
            timestamp_str = incident["Timestamp"].strftime("%Y-%m-%d %H:%M")
            
            st.markdown(
                f"""
                <div style="border: 1px solid #ddd; padding: 10px; margin: 10px 0; background-color: #f8f9fa; border-radius: 5px;">
                    <strong>{incident['Type']}</strong> - {incident['PlantName']} ({incident['Region']}, {incident['Product']})<br/>
                    <strong>Time:</strong> {timestamp_str} | <strong>Root Cause:</strong> {incident['RootCause']}<br/>
                    <strong>Impact:</strong> {incident['ImpactDescription']}<br/>
                    <strong>Outlook:</strong> {incident['Outlook']} | <strong>Est. Duration:</strong> {incident['EstimatedDuration_Hours']} hours<br/>
                    <strong>Notes:</strong> {incident['SupervisorNotes']}
                </div>
                """,
                unsafe_allow_html=True
            )
    else:
        st.info("No recent incidents recorded.")

with tab2:
    st.write("**Supervisor Notes and Communications**")
    
    # Simulated supervisor notes from recent incidents
    if all_incidents:
        st.write("**Recent Supervisor Communications:**")
        for _, incident in df_incidents.head(5).iterrows():
            timestamp_str = incident["Timestamp"].strftime("%Y-%m-%d %H:%M")
            st.text_area(
                f"{incident['PlantName']} - {timestamp_str}",
                value=incident["SupervisorNotes"],
                height=80,
                disabled=True
            )
    
    st.write("**Add New Supervisor Note:**")
    
    col1, col2 = st.columns(2)
    with col1:
        note_plant = st.selectbox("Select Plant:", options=filtered_plants_df["PlantName"].tolist(), key="note_plant")
    with col2:
        note_priority = st.selectbox("Priority Level:", options=["Low", "Medium", "High", "Critical"], key="note_priority")
    
    note_content = st.text_area("Supervisor Note:", placeholder="Enter operational notes, observations, or communications...")
    
    if st.button("Add Note"):
        st.success(f"Note added for {note_plant} with {note_priority} priority. (Demo: Notes would be saved to operations log)")

with tab3:
    st.write("**Structured Operations Inquiry Form**")
    
    with st.form("operations_inquiry"):
        col1, col2 = st.columns(2)
        
        with col1:
            inquiry_plant = st.selectbox("Target Plant:", options=filtered_plants_df["PlantName"].tolist())
            inquiry_type = st.selectbox("Inquiry Type:", options=[
                "Production Status", "Equipment Status", "Maintenance Schedule", 
                "Quality Issues", "Supply Chain", "Other"
            ])
            urgency = st.selectbox("Urgency:", options=["Low", "Medium", "High", "Urgent"])
        
        with col2:
            requestor_name = st.text_input("Requestor Name:")
            contact_method = st.selectbox("Preferred Contact:", options=["Email", "Phone", "Teams", "In-person"])
            expected_response = st.selectbox("Expected Response Time:", options=["Within 1 hour", "Within 4 hours", "Within 1 day", "Within 3 days"])
        
        inquiry_details = st.text_area("Inquiry Details:", placeholder="Provide specific questions or information needed...")
        
        business_impact = st.text_area("Business Impact:", placeholder="Describe potential trading/commercial impact...")
        
        submitted = st.form_submit_button("Submit Inquiry")
        
        if submitted:
            st.success(f"Inquiry submitted for {inquiry_plant}. (Demo: Inquiry would be routed to operations team with {urgency} priority)")
            st.info(f"Expected response: {expected_response} via {contact_method}")

# Footer
st.markdown("---")
st.markdown(
    """
    <div style="text-align: center; color: #666; font-size: 12px; padding: 20px;">
        <p><strong>Bulk Chemicals Trading Dashboard</strong> | Real-time production insights for commodity traders</p>
        <p>⚠️ This is a mockup demonstration with simulated data - not connected to live production systems</p>
    </div>
    """,
    unsafe_allow_html=True
) 