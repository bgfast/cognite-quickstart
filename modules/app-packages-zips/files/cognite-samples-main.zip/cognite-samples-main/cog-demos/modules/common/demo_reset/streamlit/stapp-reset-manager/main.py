import streamlit as st
from cognite.client import CogniteClient
from cognite.client.exceptions import CogniteAPIError
import logging
from deletes import *  # Assumes all delete functions are in deletes.py

# Set up logging (optional)
logging.basicConfig(level=logging.INFO)

# --- Main App ---

def main():
    st.title("CDF Demo Reset")
    st.write(
        "This tool will delete items from your Cognite Data Fusion instance based on your selection."
    )
    st.warning("WARNING: This action is irreversible. Make sure you have backed up any data you need before proceeding.")
    confirm = st.checkbox("I understand that this action is irreversible and want to proceed with deletion.")

    # Define all deletion tasks with friendly names
    deletion_tasks = {
        "Time Series (classic)": delete_time_series,
        "Assets (classic)": delete_assets,
        "Events (classic)": delete_events,
        "Files": delete_files,
        "Sequences": delete_sequences,
        "Hosted Extractors": delete_hosted_extractors,
        "RAW Tables": delete_raw_tables,
        "Workflows": delete_workflows,
        "Functions": delete_functions,
        "Transformations": delete_transformations,
        "Extraction Pipelines": delete_extraction_pipelines,
        "Non-System Data Models, Spaces, and Instances": delete_all_non_system_spaces
    }

    # Expandable section for selecting artifact types
    with st.expander("Customize Deletion (all selected by default)", expanded=False):
        st.write("Select the artifact types you want to delete:")
        selected_tasks = {}
        for name, func in deletion_tasks.items():
            # Checkbox for each artifact type, default True
            selected_tasks[name] = st.checkbox(name, value=True, key=name)

    if confirm and st.button("Delete Environment"):
        try:
            # Initialize the Cognite client
            client = CogniteClient()

            # Filter tasks based on user selection
            tasks_to_execute = [func for name, func in deletion_tasks.items() if selected_tasks[name]]

            if not tasks_to_execute:
                st.info("No artifact types selected for deletion.")
            else:
                # Execute only selected deletion functions
                for task in tasks_to_execute:
                    task(client)
                st.success("Deletion process complete for selected artifact types.")
        except Exception as e:
            st.error(f"An error occurred while performing deletion: {e}")

if __name__ == "__main__":
    main()