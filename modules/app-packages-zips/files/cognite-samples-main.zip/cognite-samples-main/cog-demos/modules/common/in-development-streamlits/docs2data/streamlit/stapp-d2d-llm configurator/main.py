import streamlit as st
from cognite.client import CogniteClient
from config import *
from dm_helper import get_latest_view, get_instances, get_instance_properties, populate_instance_properties

# Initialize CogniteClient
@st.cache_resource
def get_client():
    return CogniteClient()

def main():
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.image("https://mms.businesswire.com/media/20250519865188/en/2474150/5/cognite-tagline-horizontal_6.jpg?download=1&_gl=1*16caelh*_gcl_au*MTg1MTcxMzU0MS4xNzU0NTg2MzAy*_ga*MTEyNzQ1NDMxMy4xNzU0NTg2MzAz*_ga_ZQWF70T3FK*czE3NTQ1ODYzMDIkbzEkZzAkdDE3NTQ1ODYzMDIkajYwJGwwJGgw", width=300)
    st.markdown("<h1 style='text-align: center;'>Docs2Data LLM Configuration</h1>", unsafe_allow_html=True)
    st.markdown("<p style='margin-top: -20px; font-style: italic; font-size: 18px; text-align: center;'>Powered by Cognite Data Modeling Service</p>", unsafe_allow_html=True)
    
    client = get_client()
    
    # Configuration type selection
    config_type = st.selectbox(
        "Configuration Type",
        ["Workflow Prompt", "Content Helper"]
    )
    
    # Determine view name based on selection
    view_name = "Prompt" if config_type == "Workflow Prompt" else "SegmentPrompt"
    
    # Space name input
    space_name = st.text_input("Space Name", value=PROMPTS_SPACE, placeholder="Enter space name")
    
    if not space_name:
        st.info("Please enter a space name to continue")
        return
    
    # Get latest version of selected view
    try:
        prompt_view_version = get_latest_view(client, view_name, space_name)
        if not prompt_view_version:
            st.error(f"No '{view_name}' view found in space '{space_name}'")
            return
        
        # Get instances in the selected view
        instances = get_instances(client, view_name, prompt_view_version, space_name, space_name)
        
        if not instances:
            st.warning(f"No instances found in the {view_name} view")
            return
        
        # Create selectbox with instances - get names for display
        instance_options = {}
        instance_names = {}
        
        for inst in instances:
            external_id = inst.external_id
            
            # Filter out instances with external_id "determine_content_boundaries"
            if external_id == "determine_content_boundaries":
                continue
                
            # Get properties to retrieve the name
            inst_properties = get_instance_properties(
                client, view_name, prompt_view_version, space_name, external_id
            )
            display_name = inst_properties.get("name", external_id) if inst_properties else external_id
            instance_options[external_id] = external_id
            instance_names[external_id] = display_name
        
        # Sort instances alphanumerically by display name
        sorted_external_ids = sorted(instance_options.keys(), key=lambda x: instance_names[x].lower())
        
        selected_instance = st.selectbox(
            "Select Instance", 
            options=sorted_external_ids,
            format_func=lambda x: instance_names.get(x, x)
        )
        
        if selected_instance:
            instance_id = instance_options[selected_instance]
            
            # Get current prompt property
            properties = get_instance_properties(
                client, view_name, prompt_view_version, space_name, instance_id
            )
            
            st.markdown("---")
            st.subheader("Configuration")
            
            with st.container():
                # Model selection for Workflow Prompt (above prompt)
                selected_model = None
                if config_type == "Workflow Prompt":
                    model_options = [
                        "",  # Blank option
                        "azure/gpt-4o",
                        "azure/gpt-4o-mini", 
                        "azure/gpt-4.1",
                        "azure/gpt-4.1-mini",
                        "azure/gpt-4.1-nano",
                        "azure/o3",
                        "azure/o4-mini"
                    ]
                    
                    current_model = ""
                    if properties and "model" in properties:
                        current_model = properties["model"] or ""  # Handle None case
                    
                    # Find index of current model or default to blank
                    default_index = 0  # Default to blank option
                    if current_model in model_options:
                        default_index = model_options.index(current_model)
                    elif current_model:  # If model exists but not in options
                        st.info(f"ℹ️ Current model '{current_model}' is not in available options. Defaulting to blank.")
                    
                    selected_model = st.selectbox(
                        "Model",
                        options=model_options,
                        index=default_index,
                        format_func=lambda x: "Select Model..." if x == "" else x
                    )
                
                current_prompt = ""
                if properties and "prompt" in properties:
                    current_prompt = properties["prompt"]
                
                # Editable text area for prompt
                new_prompt = st.text_area(
                    "Instructions", 
                    value=current_prompt,
                    height=200,
                    placeholder="Enter prompt text here..."
                )
                
                # User content field for Workflow Prompt
                new_user_content = None
                if config_type == "Workflow Prompt":
                    current_user_content = ""
                    if properties and "user_content" in properties:
                        current_user_content = properties["user_content"]
                    
                    new_user_content = st.text_area(
                        "User Content",
                        value=current_user_content,
                        height=200,
                        placeholder="Enter user content here..."
                    )
            
            # Update button
            if st.button("Update Configuration", type="primary"):
                try:
                    # Build properties dict
                    properties_to_update = {"prompt": new_prompt}
                    if new_user_content is not None:
                        properties_to_update["user_content"] = new_user_content
                    if selected_model is not None:
                        properties_to_update["model"] = selected_model
                    
                    success = populate_instance_properties(
                        client,
                        properties_to_update,
                        instance_id,
                        view_name,
                        prompt_view_version,
                        space_name
                    )
                    
                    if success:
                        st.success(f"✅ Successfully updated prompt for instance '{instance_id}'")
                    else:
                        st.error("❌ Failed to update prompt")
                        
                except Exception as e:
                    st.error(f"❌ Error updating prompt: {str(e)}")
    
    except Exception as e:
        st.error(f"Error: {str(e)}")

if __name__ == "__main__":
    main()
