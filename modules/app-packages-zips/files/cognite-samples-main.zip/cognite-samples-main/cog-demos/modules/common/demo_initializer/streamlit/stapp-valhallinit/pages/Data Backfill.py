import streamlit as st
from cognite.client import CogniteClient
from cognite.client.exceptions import CogniteAPIError
from datetime import datetime
import time

# Initialize Cognite Client
def initialize_client():
    client = CogniteClient()
    return client

# Convert datetime to Unix epoch milliseconds
def to_unix_ms(dt):
    return int(dt.timestamp() * 1000)

# Validate and convert granularity
def validate_granularity(granularity):
    if not any(granularity.endswith(unit) for unit in ['s', 'm', 'h', 'd']):
        raise ValueError("Granularity must end with s, m, h, or d")
    try:
        num = int(granularity[:-1])
        if num <= 0:
            raise ValueError("Granularity number must be positive")
        return granularity
    except ValueError:
        raise ValueError("Granularity must start with a positive number")

def calculate_backfill_time(interval, backfillDays):
    # Dictionary to convert time units to seconds
    time_units = {
        's': 1,      # seconds
        'm': 60,     # minutes
        'h': 3600,   # hours
        'd': 86400   # days
    }
    
    # Split interval into number and unit
    num = int(''.join(filter(str.isdigit, interval)))
    unit = ''.join(filter(str.isalpha, interval))
    
    # Calculate seconds per interval
    seconds_per_interval = num * time_units[unit]
    
    # Calculate intervals per hour (3600 seconds in an hour)
    intervals_per_hour = 3600 / seconds_per_interval
    
    # Calculate total intervals (intervals per hour * 24 hours * days)
    total_intervals = intervals_per_hour * 24 * backfillDays
    
    # Calculate minutes based on formula: (total_intervals / 3963) * 10
    minutes = (total_intervals / 100000) * 10  # testing shows 100000 dp per tag is about the max
    
    return round(minutes,1)
# Call Cognite Function
def call_oid_dp_sync(client, start_time, end_time, granularity=None):
    try:
        params = {
            "startTime": start_time,
            "endTime": end_time
        }
        if granularity is not None:
            params["granularity"] = granularity
        
        function_call = client.functions.call(
            external_id="oid_dp_sync-dm",
            data=params
        )
        return function_call
    except CogniteAPIError as e:
        st.error(f"Error calling function: {str(e)}")
        return None

# Main Streamlit app
def main():
    st.title("Data Backfill Tool")
    
    try:
        client = initialize_client()
    except Exception as e:
        st.error(f"Failed to initialize Cognite client: {str(e)}")
        return

    # Date inputs (midnight assumed)
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start Date", value=datetime.now().date())
    with col2:
        end_date = st.date_input("End Date", value=datetime.now().date())

    # Combine date with midnight time
    start_datetime = datetime.combine(start_date, datetime.min.time())  # 00:00
    end_datetime = datetime.combine(end_date, datetime.min.time())      # 00:00

    # Granularity selection
    granularity_option = st.selectbox(
        "Data Granularity",
        ["Raw", "Custom"]
    )

    granularity = None
    if granularity_option == "Custom":
        granularity_input = st.text_input(
            "Enter Granularity (e.g., 5m, 1h, 2d)",
            value="1h",
            help="Use format: number + unit (s=seconds, m=minutes, h=hours, d=days)"
        )
        try:
            granularity = validate_granularity(granularity_input)
        except ValueError as e:
            st.error(f"Invalid granularity: {str(e)}")
            return

    # Preview the parameters
    st.subheader("Parameters Preview")
    params = {
        "startTime": to_unix_ms(start_datetime),
        "endTime": to_unix_ms(end_datetime)
    }
    if granularity is not None:
        params["granularity"] = granularity
        estimated_minutes = calculate_backfill_time(granularity, abs((end_datetime - start_datetime).days))
        st.write(f"Estimated function runtime: {estimated_minutes} minutes.")
        if estimated_minutes > 10:
            st.warning("You are requesting too much data and your function might time out, which results in an incomplete backfill.")
    st.json(params)

    # Execute button
    if st.button("Start Backfill"):
        if start_datetime >= end_datetime:
            st.error("Start date must be before end date")
            return
        
        with st.spinner("Initiating backfill process..."):
            function_call = call_oid_dp_sync(client, params["startTime"], params["endTime"], granularity)
            if function_call:
                st.success("Backfill process initiated!")
                st.write("Function Call ID:", function_call.id)
                with st.spinner("Waiting for completion..."):
                    function_call.wait_for_completion()
                    st.write("Status:", function_call.status)
                    if function_call.status == "Completed":
                        result = function_call.get_response()
                        st.write("Result:")
                        st.json(result)
                    elif function_call.status == "Failed":
                        st.error(f"Backfill failed: {function_call.error}")
            else:
                st.error("Failed to initiate backfill")

if __name__ == "__main__":
    st.set_page_config(
        page_title="Data Backfill App",
        page_icon="⏮️",
        layout="wide"
    )
    main()