import streamlit as st
from cognite.client import CogniteClient
from doc_workflows import Document
from dm_helper import save_document_to_model, prepare_document_properties
# Temporarily comment out config import to debug
# from config import *

# Initialize CogniteClient
@st.cache_resource
def get_client():
    return CogniteClient()

@st.cache_data
def get_datasets_list(_client):
    datasets = _client.data_sets.list(limit=None)
    # Return all datasets for user selection
    return [dataset for dataset in datasets if dataset.external_id]

@st.cache_data
def get_files_list(_client, dataset_id):
    """Get list of files from a specific dataset"""
    files = _client.files.list(data_set_ids=[dataset_id], limit=1000)
    return [file for file in files if file.name]

def analyze_document(client, selected_file, num_pages):
    """
    Perform the full document analysis workflow using Document classes.
    Returns analysis results or error information.
    """
    try:
        # Create appropriate document instance
        document = Document.create(client, selected_file)
        
        # Check if document type is supported
        if not document.is_supported():
            return {"error": f"Unsupported file type: {selected_file.name}"}
        
        # Display document type detection info
        document_type = type(document).__name__
        if document_type == "PDFDocument":
            st.info("📄 Detected PDF document. Using OCR-based analysis workflow.")
            # For PDFs, we need to pass num_pages
            return document.analyze_for_classification(num_pages=num_pages)
        elif document_type == "WordDocument":
            st.info("📝 Detected Word document. Using specialized text extraction workflow.")
            return document.analyze_for_classification()
        elif document_type == "ExcelDocument":
            st.info("📊 Detected Excel document. Using specialized data extraction workflow.")
            return document.analyze_for_classification()
        elif document_type == "EmailDocument":
            st.info("📧 Detected Outlook message. Using specialized email extraction workflow.")
            return document.analyze_for_classification()
        else:
            return {"error": f"Unsupported document type: {document_type}"}
        
    except Exception as e:
        return {"error": f"Analysis failed: {str(e)}"}

def commit_to_data_model(client, analysis_results):
    """
    Commit the analysis results to the CDF data model
    """
    return save_document_to_model(client, analysis_results)

def main():
    with st.container():
        st.markdown(
            f"""
            <div style="display: flex; justify-content: center;">
                <img src="https://mms.businesswire.com/media/20250519865188/en/2474150/5/cognite-tagline-horizontal_6.jpg?download=1&_gl=1*16caelh*_gcl_au*MTg1MTcxMzU0MS4xNzU0NTg2MzAy*_ga*MTEyNzQ1NDMxMy4xNzU0NTg2MzAz*_ga_ZQWF70T3FK*czE3NTQ1ODYzMDIkbzEkZzAkdDE3NTQ1ODYzMDIkajYwJGwwJGgw" width=300>
            </div>
            """,
            unsafe_allow_html=True
        )
    st.markdown("<h1 style='text-align: center;'>Docs2Data Auto-Analyzer</h1>", unsafe_allow_html=True)
    st.markdown("<p style='margin-top: -20px; font-style: italic; font-size: 18px; text-align: center;'>Powered by Cognite's Industrial Knowledge Graph</p>", unsafe_allow_html=True)
    
    client = get_client()
    
    # Configuration Section
    with st.expander("⚙️ Configuration", expanded=False):
        st.markdown("**Dataset Configuration:**")
        st.markdown("- Select any dataset containing files you want to analyze")
        st.markdown("- The app will automatically detect supported file types")
        st.markdown("- Analysis results are saved to the D2D data model")
        st.markdown("")
        st.markdown("**Supported File Types:**")
        st.markdown("- 📄 PDF files (OCR-based analysis)")
        st.markdown("- 📝 Word documents (text extraction)")
        st.markdown("- 📊 Excel files (data extraction)")
        st.markdown("- 📧 Outlook messages (email extraction)")
    
    # Initialize session state
    if 'analysis_results' not in st.session_state:
        st.session_state.analysis_results = None
    if 'analysis_complete' not in st.session_state:
        st.session_state.analysis_complete = False
    
    st.markdown("---")
    
    # Input Section
    st.header("1. Document Selection & Analysis")
    
    # Dataset Selection
    with st.spinner("Loading datasets from CDF..."):
        datasets = get_datasets_list(client)
    
    if not datasets:
        st.error("No datasets found in CDF. Please create a dataset and upload some files first.")
        return
    
    # Dataset selector
    dataset_options = {f"{dataset.name or dataset.external_id} ({dataset.external_id})": dataset for dataset in datasets}
    
    # Use first dataset as default
    default_index = 0
    
    selected_dataset_key = st.selectbox(
        "Select Dataset",
        options=list(dataset_options.keys()),
        index=default_index,
        help="Choose any dataset containing files you want to analyze"
    )
    selected_dataset = dataset_options[selected_dataset_key]
    
    # Load files from selected dataset
    with st.spinner("Loading files from selected dataset..."):
        files = get_files_list(client, selected_dataset.id)
    
    if not files:
        st.error(f"No files found in dataset '{selected_dataset.external_id}'")
        return
    
    # File selection
    file_options = {f"{file.name}": file for i, file in enumerate(files)}
    selected_file_key = st.selectbox(
        "Select File",
        options=list(file_options.keys()),
        help="Choose a file from your CDF dataset"
    )
    selected_file = file_options[selected_file_key]
    
    # Create document instance to check type
    document = Document.create(client, selected_file)
    document_type = type(document).__name__
    
    if document_type == "PDFDocument":
        # PDF files need page selection
        st.info("📄 Selected PDF document will be processed using OCR")
        num_pages = st.number_input(
            "Number of Pages to Analyze",
            min_value=1,
            max_value=10,
            value=3,
            help="Number of pages from the beginning of the PDF document to analyze"
        )
    elif document_type == "WordDocument":
        st.info("📝 Selected Word document will be processed using text extraction (no OCR needed)")
        num_pages = 1  # Not used for non-PDF files, but needed for function signature
    elif document_type == "ExcelDocument":
        st.info("📊 Selected Excel document will be processed using data extraction (no OCR needed)")
        num_pages = 1  # Not used for non-PDF files, but needed for function signature
    elif document_type == "EmailDocument":
        st.info("📧 Selected Outlook message will be processed using email extraction (no OCR needed)")
        num_pages = 1  # Not used for non-PDF files, but needed for function signature
    else:
        st.error(f"❌ Unsupported file type: {selected_file.name}")
        return
    
    # Analyze button
    analyze_col1, analyze_col2, analyze_col3 = st.columns([1, 1, 1])
    with analyze_col2:
        analyze_clicked = st.button("✨ Analyze", type="primary", use_container_width=True)
    
    # Handle analyze outside of columns so messages span full width
    if analyze_clicked:
        with st.spinner("Analyzing document..."):
            st.session_state.analysis_results = analyze_document(client, selected_file, num_pages)
            st.session_state.analysis_complete = True
    
    # Results Section
    if st.session_state.analysis_complete:
        st.markdown("---")
        st.header("📊 Analysis Results")
        
        results = st.session_state.analysis_results
        
        if 'error' in results:
            st.error(f"❌ {results['error']}")
        else:
            # Display the five key outputs with smaller font
            overall = results['overall_classification']
            classification = results['classification']
            
            # Custom CSS for smaller metrics
            st.markdown("""
            <style>
            .metric-container {
                background-color: #f0f2f6;
                padding: 0.5rem;
                border-radius: 0.5rem;
                margin-bottom: 0.5rem;
            }
            .metric-label {
                font-size: 0.875rem;
                color: #262730;
                margin-bottom: 0.25rem;
            }
            .metric-value {
                font-size: 1.125rem;
                font-weight: 600;
                color: #262730;
                word-wrap: break-word;
            }
            </style>
            """, unsafe_allow_html=True)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"""
                <div class="metric-container">
                    <div class="metric-label">📖 Document Title</div>
                    <div class="metric-value">{overall.get('document_title', 'Not determined')}</div>
                </div>
                """, unsafe_allow_html=True)
                
                st.markdown(f"""
                <div class="metric-container">
                    <div class="metric-label">🏭 Equipment Unit</div>
                    <div class="metric-value">{overall.get('equipment_unit', 'Not determined')}</div>
                </div>
                """, unsafe_allow_html=True)
                
                st.markdown(f"""
                <div class="metric-container">
                    <div class="metric-label">📄 Document Type</div>
                    <div class="metric-value">{overall.get('document_type', 'Not determined')}</div>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                st.markdown(f"""
                <div class="metric-container">
                    <div class="metric-label">🏷️ Equipment Tag</div>
                    <div class="metric-value">{overall.get('equipment_tag', 'Not determined')}</div>
                </div>
                """, unsafe_allow_html=True)
                
                st.markdown(f"""
                <div class="metric-container">
                    <div class="metric-label">📁 File Type</div>
                    <div class="metric-value">{classification['file_type']}</div>
                </div>
                """, unsafe_allow_html=True)
                
                st.markdown(f"""
                <div class="metric-container">
                    <div class="metric-label">📊 Page Count</div>
                    <div class="metric-value">{classification['page_count']}</div>
                </div>
                """, unsafe_allow_html=True)
            
            # Data Model Properties expander
            with st.expander("📋 Data Model Properties"):
                # Get the properties that will be written to the data model
                properties = prepare_document_properties(results)
                
                # Display as formatted JSON
                st.json(properties)
            
            # Additional details in expander
            with st.expander("🔍 Additional Details"):
                st.write(f"**Confidence Level:** {overall.get('confidence_level', 'Not specified')}")
                st.write(f"**Reasoning:** {overall.get('reasoning', 'No reasoning provided')}")
                if overall.get('key_indicators'):
                    st.write("**Key Indicators:**")
                    for indicator in overall['key_indicators']:
                        st.write(f"• {indicator}")
            
            # Commit button
            st.markdown("---")
            commit_col1, commit_col2, commit_col3 = st.columns([1, 1, 1])
            with commit_col2:
                if st.button("💾 Commit to Knowledge Graph", type="secondary", use_container_width=True):
                    with st.spinner("Committing to knowledge graph..."):
                        commit_result = commit_to_data_model(client, results)
                        
                        if 'error' in commit_result:
                            st.error(f"❌ {commit_result['error']}")
                        else:
                            st.success(f"✅ Successfully committed to data model! Instance ID: {commit_result['instance_id']}")

if __name__ == "__main__":
    main()