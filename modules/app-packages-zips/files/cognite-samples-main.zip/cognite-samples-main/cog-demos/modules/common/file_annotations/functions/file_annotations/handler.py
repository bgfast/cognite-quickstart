from cognite.client.data_classes.data_modeling import (
    ViewId,
    EdgeApply,
    DirectRelationReference,
    NodeId,
    NodeOrEdgeData,
)
from enum import Enum
from cognite.client.data_classes.data_modeling.cdm.v1 import CogniteFileApply
import random
import asyncio

ASSET_LINK_EXTERNAL_ID = "diagrams.AssetLink"
FILE_LINK_EXTERNAL_ID = "diagrams.FileLink"


class DiagramAnnotationStatus(Enum):
    SUGGESTED = "Suggested"
    APPROVED = "Approved"
    REJECTED = "Rejected"


def detect_annotation_to_edge_applies(file_instance_id, detect_annotation, space):
    diagram_annotations = []

    for entity in detect_annotation["entities"]:
        properties = {
            "confidence": detect_annotation["confidence"],
            "status": DiagramAnnotationStatus.SUGGESTED.value,
            "startNodePageNumber": detect_annotation["region"]["page"],
            "startNodeXMin": min(
                v["x"] for v in detect_annotation["region"]["vertices"]
            ),
            "startNodeYMin": min(
                v["y"] for v in detect_annotation["region"]["vertices"]
            ),
            "startNodeXMax": max(
                v["x"] for v in detect_annotation["region"]["vertices"]
            ),
            "startNodeYMax": max(
                v["y"] for v in detect_annotation["region"]["vertices"]
            ),
            "startNodeText": detect_annotation["text"],
        }

        random_integer = random.randint(1, 10)
        # add IF statement to do different logic if its a file or an asset
        edge_apply = EdgeApply(
            space=space,
            external_id=f"annotation_{file_instance_id.external_id}-{entity['external_id']}-{properties['startNodeXMin']}-{random_integer}",
            type=DirectRelationReference(
                space=space, external_id=entity["annotation_type_external_id"]
            ),
            start_node=DirectRelationReference(
                space=file_instance_id.space, external_id=file_instance_id.external_id
            ),
            end_node=DirectRelationReference(
                space=entity["space"], external_id=entity["external_id"]
            ),
            sources=[
                NodeOrEdgeData(
                    source=ViewId(
                        space="cdf_cdm",
                        external_id="CogniteDiagramAnnotation",
                        version="v1",
                    ),
                    properties=properties,
                )
            ],
        )
        diagram_annotations.append(edge_apply)

        # After appending all EdgeApply objects, remove duplicates based on external_id
        unique_annotations = {
            edge.external_id: edge for edge in diagram_annotations
        }.values()
        # Convert back to a list if needed
        diagram_annotations = list(unique_annotations)
    return diagram_annotations


def result_item_to_edge_applies(result_item, space):
    file_instance_id_dict = result_item.get("fileInstanceId")
    if file_instance_id_dict is not None:
        file_instance_id = NodeId.load(file_instance_id_dict)

    annotations_count = len(result_item["annotations"])
    print(f"Number of annotations: {annotations_count}")
    return [
        edge_apply
        for detect_annotation in result_item["annotations"]
        for edge_apply in detect_annotation_to_edge_applies(
            file_instance_id=file_instance_id,
            detect_annotation=detect_annotation,
            space=space,
        )
    ]


def push_result_to_annotations(result_item, space, client):
    edge_applies = result_item_to_edge_applies(result_item, space)
    return client.data_modeling.instances.apply(edge_applies)


async def create_asset_links(client, file_node_id, annotations):
    asset_references = []

    for annotation in annotations: # todo - include IF statement to check if its an asset link
        linked_asset = annotation["entities"][0]
        if linked_asset["annotation_type_external_id"] == "diagrams.AssetLink":
                    linked_asset_relation_reference = DirectRelationReference(
                        external_id=linked_asset["external_id"], 
                        space=linked_asset["space"]
                    )
                    asset_references.append(linked_asset_relation_reference)
        # Implicitly skip if it'’'s not "diagrams.AssetLink"
    print(asset_references)

    # Fetch current file metadata to get name and mimeType
    file_metadata = client.files.retrieve(instance_id=file_node_id)

    if file_metadata:
        current_name = file_metadata.name
        current_mime_type = file_metadata.mime_type
    else:
        print("Failed to get metadata for file", file_node_id)

    # Apply the update, preserving name and mimeType
    client.data_modeling.instances.apply(
        CogniteFileApply(
            space=file_node_id.space,
            external_id=file_node_id.external_id,
            assets=asset_references[:100],
            name=current_name,         # Explicitly set name
            mime_type=current_mime_type  # Explicitly set mimeType
        )
    )


async def detect_entities(file_node_ids, entities, client):
    # Pass all file_node_ids to detect in one batch
    job = client.diagrams.detect(
        entities=entities, search_field="name", file_instance_ids=file_node_ids
    )
    while job.update_status() != "Completed":
        await asyncio.sleep(0.5)
    await asyncio.sleep(1.0)  # Keep this delay if needed for stability
    print(job.update_status())
    return job.result  # Return the full result for all files


async def file_contextualize(client, file_names, file_space, asset_space):
    # Create NodeIds for all files
    file_node_ids = [NodeId(space=file_space, external_id=file_name) for file_name in file_names]
    print(f"Processing {len(file_node_ids)} files: {file_names}")
    
    print("Fetching assets")
    my_assets = client.data_modeling.instances.list(space=asset_space, limit=None)
    asset_entities = assets_to_entities(my_assets)

    print("Fetching files")
    my_assets = client.data_modeling.instances.list(space=file_space, limit=None)
    file_entities = files_to_entities(my_assets)

    entities = asset_entities + file_entities
    
    print("Running diagram parsing for all files")
    annotation_job_result = await detect_entities(file_node_ids, entities, client)
    
    print("Processing results for each file")
    for result_item in annotation_job_result["items"]:
        file_instance_id_dict = result_item.get("fileInstanceId")
        if file_instance_id_dict is not None:
            file_node_id = NodeId.load(file_instance_id_dict)
        else:
            print(f"Warning: No fileInstanceId in result item: {result_item}")
            continue
        
        print(f"Creating asset references for {file_node_id.external_id}")
        await create_asset_links(client, file_node_id, result_item["annotations"])
        
        print(f"Creating annotations for {file_node_id.external_id}")
        push_result_to_annotations(result_item, file_space, client)
    
    print("----------- Done -----------")

def assets_to_entities(assets):
    entities = []
    for asset in assets:
        entities.append(
            {
                "external_id": asset.external_id,
                "space": asset.space,
                "name": asset.external_id.replace("WMT:", ""),
                "annotation_type_external_id": ASSET_LINK_EXTERNAL_ID,
            }
        )
    return entities

def files_to_entities(files):
    entities = []
    for file in files:
        entities.append(
            {
                "external_id": file.external_id,
                "space": file.space,
                "name": file.external_id.replace(".pdf", ""),
                "annotation_type_external_id": FILE_LINK_EXTERNAL_ID,
            }
        )
    return entities


def handle(data, client):
    file_space = data["file_space"]
    asset_space = data["asset_space"]
    file_names = data["file_names"]
    
    print(f"Starting batch processing for {len(file_names)} files")
    asyncio.run(file_contextualize(client, file_names, file_space, asset_space))