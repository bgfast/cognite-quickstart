import streamlit as st
from cognite.client import CogniteClient
from cognite.client.exceptions import CogniteAPIError

# --- Deletion functions for each resource ---

def delete_files(client):
    st.info("Deleting files (excluding Streamlit apps and CogniteFiles)...")
    try:
        files = list(client.files.list(limit=None))
        file_ids = [
            f.id for f in files 
            if f.directory != "/streamlit-apps/" and not f.instance_id
        ]

        if file_ids:
            deleted_count = 0
            for file_id in file_ids:
                try:
                    client.files.delete(id=file_id)
                    deleted_count += 1
                except Exception as delete_error:
                    st.warning(f"Failed to delete file ID {file_id}: {delete_error}")
            st.success(f"Deleted {deleted_count} file(s), skipped {len(file_ids) - deleted_count}.")
        else:
            st.info("No files to delete.")
    except Exception as e:
        st.error(f"Error retrieving files: {e}")



def delete_time_series(client):
    st.info("Deleting time series...")
    try:
        ts_list = list(client.time_series.list(limit=None))
        # Only delete time series that have an external_id attribute
        ts_ids = [ts.id for ts in ts_list if getattr(ts, "external_id", None) is not None]
        if ts_ids:
            client.time_series.delete(id=ts_ids)
            st.success(f"Deleted {len(ts_ids)} time series.")
        else:
            st.info("No time series to delete.")
    except Exception as e:
        st.error(f"Error deleting time series: {e}")

def delete_assets(client):
    st.info("Deleting assets...")
    try:
        assets_list = list(client.assets.list(limit=None))
        asset_ids = [asset.id for asset in assets_list]
        if asset_ids:
            client.assets.delete(id=asset_ids, recursive=True)
            st.success(f"Deleted {len(asset_ids)} asset(s).")
        else:
            st.info("No assets to delete.")
    except Exception as e:
        st.error(f"Error deleting assets: {e}")

def delete_events(client):
    st.info("Deleting events...")
    try:
        events_list = list(client.events.list(limit=None))
        event_ids = [event.id for event in events_list]
        if event_ids:
            client.events.delete(id=event_ids)
            st.success(f"Deleted {len(event_ids)} event(s).")
        else:
            st.info("No events to delete.")
    except Exception as e:
        st.error(f"Error deleting events: {e}")

def delete_sequences(client):
    st.info("Deleting sequences...")
    try:
        sequences_list = list(client.sequences.list(limit=None))
        sequence_ids = [sequence.id for sequence in sequences_list]
        if sequence_ids:
            client.sequences.delete(id=sequence_ids)
            st.success(f"Deleted {len(sequence_ids)} sequence(s).")
        else:
            st.info("No sequences to delete.")
    except Exception as e:
        st.error(f"Error deleting sequences: {e}")

def delete_hosted_extractors(client: CogniteClient) -> None:
    """Deletes all hosted extractors including sources, jobs, and destinations."""
    st.info("Deleting hosted extractors...")
    try:
        # Delete all jobs
        jobs = client.hosted_extractors.jobs.list(limit=None)
        if jobs:
            job_ids = [job.external_id for job in jobs]
            client.hosted_extractors.jobs.delete(external_ids=job_ids)
            st.success(f"Deleted {len(job_ids)} hosted extractor job(s).")
        else:
            st.info("No hosted extractor jobs to delete.")

        # Delete all sources
        sources = client.hosted_extractors.sources.list(limit=None)
        if sources:
            source_ids = [source.external_id for source in sources]
            client.hosted_extractors.sources.delete(external_ids=source_ids)
            st.success(f"Deleted {len(source_ids)} hosted extractor source(s).")
        else:
            st.info("No hosted extractor sources to delete.")

        # Delete all destinations
        destinations = client.hosted_extractors.destinations.list(limit=None)
        if destinations:
            destination_ids = [destination.external_id for destination in destinations]
            client.hosted_extractors.destinations.delete(external_ids=destination_ids)
            st.success(f"Deleted {len(destination_ids)} hosted extractor destination(s).")
        else:
            st.info("No hosted extractor destinations to delete.")

    except CogniteAPIError as e:
        st.error(f"Error deleting hosted extractors: {e}")
    except Exception as e:
        st.error(f"Unexpected error deleting hosted extractors: {e}")

def delete_raw_tables(client: CogniteClient) -> None:
    """Deletes all RAW tables and databases."""
    st.info("Deleting RAW tables and databases...")
    try:
        # Get all databases
        databases = client.raw.databases.list(limit=None)
        if not databases:
            st.info("No RAW databases to delete.")
            return

        # Delete tables in each database first
        for db in databases:
            tables = client.raw.tables.list(db_name=db.name, limit=None)
            if tables:
                table_names = [table.name for table in tables]
                client.raw.tables.delete(db_name=db.name, name=table_names)
                st.success(f"Deleted {len(table_names)} table(s) in database {db.name}")
            else:
                st.info(f"No tables to delete in database {db.name}")

        # Delete all databases
        db_names = [db.name for db in databases]
        client.raw.databases.delete(name=db_names)
        st.success(f"Deleted {len(db_names)} RAW database(s).")

    except CogniteAPIError as e:
        st.error(f"Error deleting RAW tables/databases: {e}")
    except Exception as e:
        st.error(f"Unexpected error deleting RAW tables/databases: {e}")

def delete_workflows(client: CogniteClient) -> None:
    """Deletes all workflows and their versions."""
    st.info("Deleting workflows...")
    try:
        # Get all workflows
        workflows = client.workflows.list(limit=None)
        if not workflows:
            st.info("No workflows to delete.")
            return

        # Delete each workflow and its versions
        for workflow in workflows:
            # List all versions for this workflow using the external_id
            # Note: We need to delete versions implicitly by deleting the workflow
            # as there's no direct versions.list() with workflow_external_id in newer SDKs
            client.workflows.delete(external_id=workflow.external_id)
            st.success(f"Deleted workflow {workflow.external_id} and all its versions")

        st.success(f"Deleted {len(workflows)} workflow(s).")

    except CogniteAPIError as e:
        st.error(f"Error deleting workflows: {e}")
    except Exception as e:
        st.error(f"Unexpected error deleting workflows: {e}")
        
def delete_transformations(client):
    st.info("Deleting transformations...")
    try:
        transformations_list = list(client.transformations.list(limit=None))
        transformation_ids = [transformation.id for transformation in transformations_list]
        if transformation_ids:
            client.transformations.delete(id=transformation_ids)
            st.success(f"Deleted {len(transformation_ids)} transformation(s).")
        else:
            st.info("No transformations to delete.")
    except Exception as e:
        st.error(f"Error deleting transformations: {e}")

def delete_functions(client: CogniteClient) -> None:
    """Deletes all Functions in CDF."""
    st.info("Deleting functions...")
    try:
        # List all functions
        functions = client.functions.list(limit=None)
        if not functions:
            st.info("No functions to delete.")
            return

        # Delete all functions
        function_ids = [func.id for func in functions]
        client.functions.delete(id=function_ids)
        st.success(f"Deleted {len(function_ids)} function(s).")

    except CogniteAPIError as e:
        st.error(f"Error deleting functions: {e}")
    except Exception as e:
        st.error(f"Unexpected error deleting functions: {e}")

# Optional: Function to delete all non-system spaces
def delete_space(client: CogniteClient, space_id: str) -> None:
    """
    Deletes a given space and all its associated data modeling contents (instances, containers, views, data models).

    Args:
        client (CogniteClient): The Cognite client instance.
        space_id (str): The ID of the space to delete.
    """
    st.info(f"Preparing to delete space {space_id}...")

    # Step 1: Delete all edges
    try:
        edges = client.data_modeling.instances.list(instance_type="edge", space=space_id, limit=None)
        if edges:
            edge_ids = [(edge.space, edge.external_id) for edge in edges]
            client.data_modeling.instances.delete(edges=edge_ids)
            st.success(f"Deleted {len(edge_ids)} edge(s) in space {space_id}.")
        else:
            st.info(f"No edges found in space {space_id}.")
    except Exception as e:
        st.error(f"Error deleting edges in space {space_id}: {e}")
        return

    # Step 2: Delete all nodes
    try:
        nodes = client.data_modeling.instances.list(instance_type="node", space=space_id, limit=None)
        if nodes:
            node_ids = [(node.space, node.external_id) for node in nodes]
            client.data_modeling.instances.delete(nodes=node_ids)
            st.success(f"Deleted {len(node_ids)} node(s) in space {space_id}.")
        else:
            st.info(f"No nodes found in space {space_id}.")
    except Exception as e:
        st.error(f"Error deleting nodes in space {space_id}: {e}")
        return

    # Step 3: Delete all containers
    try:
        containers = client.data_modeling.containers.list(space=space_id, limit=None)
        if containers:
            container_ids = [(container.space, container.external_id) for container in containers]
            client.data_modeling.containers.delete(container_ids)
            st.success(f"Deleted {len(container_ids)} container(s) in space {space_id}.")
        else:
            st.info(f"No containers found in space {space_id}.")
    except Exception as e:
        st.error(f"Error deleting containers in space {space_id}: {e}")
        return

    # Step 4: Delete all views
    try:
        views = client.data_modeling.views.list(space=space_id, limit=None)
        if views:
            view_ids = [(view.space, view.external_id, view.version) for view in views]
            client.data_modeling.views.delete(view_ids)
            st.success(f"Deleted {len(view_ids)} view(s) in space {space_id}.")
        else:
            st.info(f"No views found in space {space_id}.")
    except Exception as e:
        st.error(f"Error deleting views in space {space_id}: {e}")
        return

    # Step 5: Delete all data models
    try:
        data_models = client.data_modeling.data_models.list(space=space_id, limit=None)
        if data_models:
            data_model_ids = [(dm.space, dm.external_id, dm.version) for dm in data_models]
            client.data_modeling.data_models.delete(data_model_ids)
            st.success(f"Deleted {len(data_model_ids)} data model(s) in space {space_id}.")
        else:
            st.info(f"No data models found in space {space_id}.")
    except Exception as e:
        st.error(f"Error deleting data models in space {space_id}: {e}")
        return

    # Step 6: Delete the space itself
    try:
        client.data_modeling.spaces.delete(space_id)
        st.success(f"Deleted space {space_id}.")
    except Exception as e:
        st.error(f"Error deleting space {space_id}: {e}")

def delete_extraction_pipelines(client: CogniteClient) -> None:
    """
    Deletes all extraction pipelines in Cognite Data Fusion.

    Args:
        client (CogniteClient): The Cognite client instance.
    """
    st.info("Deleting all extraction pipelines...")
    try:
        # List all extraction pipelines
        pipelines = client.extraction_pipelines.list(limit=None)
        if not pipelines:
            st.info("No extraction pipelines to delete.")
            return

        # Collect pipeline IDs
        pipeline_ids = [pipeline.id for pipeline in pipelines]
        
        # Delete all pipelines
        client.extraction_pipelines.delete(id=pipeline_ids)
        st.success(f"Deleted {len(pipeline_ids)} extraction pipeline(s).")
    except Exception as e:
        st.error(f"Error deleting extraction pipelines: {e}")

def delete_all_non_system_spaces(client: CogniteClient) -> None:
    """
    Deletes all non-system spaces (those not starting with 'cdf_') and their contents.

    Args:
        client (CogniteClient): The Cognite client instance.
    """
    st.info("Deleting all non-system spaces...")
    try:
        spaces = client.data_modeling.spaces.list()
        non_system_spaces = [space for space in spaces if not space.space.startswith("cdf_")]
        if not non_system_spaces:
            st.info("No non-system spaces to delete.")
            return
        for space in non_system_spaces:
            delete_space(client, space.space)
        st.success(f"Deleted {len(non_system_spaces)} non-system space(s).")
    except Exception as e:
        st.error(f"Error listing or deleting spaces: {e}")