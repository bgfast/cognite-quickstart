"""
This library contains some reusable functions related to Github
and the reading of Cognite toolkit repositories in Github.
"""

from github import Github, InputGitTreeElement
import streamlit as st
import re

def commit_multiple_to_github(repo_name, branch, files_dict, commit_message, github_pat):
    """
    Commits multiple files to GitHub in a single commit using PyGithub.
    
    :param repo_name: Repository in the format 'owner/repo' (e.g., 'username/my-repo')
    :param branch: Branch name (e.g., 'main')
    :param files_dict: Dictionary with file paths as keys and contents as values
    :param commit_message: Commit message for the batch update
    :param github_pat: GitHub personal access token
    """
    try:
        # Authenticate with GitHub and get the repository
        g = Github(github_pat)
        repo = g.get_repo(repo_name)
        
        # Get the branch and its current commit
        branch_obj = repo.get_branch(branch)
        current_commit = repo.get_commit(branch_obj.commit.sha)
        
        # Prepare tree elements for the new files
        tree_elements = []
        for path, content in files_dict.items():
            # Create a blob for the file content
            blob = repo.create_git_blob(content, "utf-8")
            # Define the tree element (mode '100644' is for regular files)
            element = InputGitTreeElement(path=path, mode="100644", type="blob", sha=blob.sha)
            tree_elements.append(element)
        
        # Create a new tree based on the current commit's tree
        base_tree = current_commit.commit.tree
        new_tree = repo.create_git_tree(tree_elements, base_tree)
        
        # Create a new commit with the tree and parent commit
        new_commit = repo.create_git_commit(
            message=commit_message,
            tree=new_tree,
            parents=[current_commit.commit]
        )
        
        # Update the branch to point to the new commit
        branch_ref = repo.get_git_ref(f"heads/{branch}")
        branch_ref.edit(new_commit.sha)
        
        st.success("Successfully committed files to GitHub!")
    except Exception as e:
        st.error(f"Failed to commit files: {str(e)}")

def is_valid_pat(github_pat):
    pat_pattern = re.compile(r'^[a-zA-Z0-9_]{40}$')
    if github_pat and not pat_pattern.match(github_pat):
        return False
    else:
        return True

from github import Github, GithubException

def get_modules(repo_name, branch, github_pat):
    """
    Identify all module folders within 'cog-demos/modules' in a GitHub repository.
    
    Parameters:
    - repo_name (str): Name of the GitHub repository (e.g., 'username/repo').
    - branch (str): Branch name to search in (e.g., 'main').
    - github_pat (str): GitHub Personal Access Token for authentication.
    
    Returns:
    - list[str]: List of relative paths to module folders from 'cog-demos/modules', or an error message string if a 404 occurs.
    """
    # Authenticate with GitHub using the PAT
    g = Github(github_pat)
    # Access the specified repository
    repo = g.get_repo(repo_name)
    
    # Define the root directory to search
    root_path = "cog-demos/modules"
    
    # Set of CDF resource subfolder names that indicate a module
    resource_folders = {
        "3dmodels", "auth", "classic", "data_models", "data_sets", "extraction_pipelines",
        "files", "functions", "hosted_extractors", "locations", "raw", "robotics",
        "streamlit", "timeseries", "transformations", "workflows"
    }
    
    def find_modules(folder_path):
        """
        Recursively find module folders within the given folder path.
        
        Parameters:
        - folder_path (str): Full path of the folder to analyze.
        
        Returns:
        - list[str]: List of full paths to module folders in this subtree.
        """
        # Fetch all contents of the folder in one API call
        contents = repo.get_contents(folder_path, ref=branch)
        # Extract subfolders (directories only)
        subfolders = [content for content in contents if content.type == "dir"]
        
        # Check if the folder contains any special subfolders
        if any(subfolder.name in resource_folders for subfolder in subfolders):
            return [folder_path]  # This folder is a module; do not recurse further
        # Check if the folder is empty (no subfolders)
        elif len(subfolders) == 0:
            return [folder_path]  # Empty folder is a module
        else:
            # Not a module; recurse into subfolders
            modules = []
            for subfolder in subfolders:
                modules.extend(find_modules(subfolder.path))
            return modules
    
    try:
        # Get contents of the root path
        contents = repo.get_contents(root_path, ref=branch)
        modules = []
        
        # Process each top-level subfolder in 'cog-demos/modules'
        for content in contents:
            if content.type == "dir":
                modules.extend(find_modules(content.path))
        
        return modules
    
    except GithubException as e:
        if e.status == 404:
            st.error("Encountered 404 error. Does your branch exist?")
        else:
            # Re-raise other exceptions (e.g., authentication errors) for debugging
            raise