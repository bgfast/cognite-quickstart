from cognite.client import CogniteClient
from cognite.client.data_classes.data_modeling import ViewId, NodeApply, NodeOrEdgeData, MultiReverseDirectRelation
from cognite.client.data_classes.filters import Prefix, ContainsAny

class View:
    """A wrapper class for Cognite Data Modeling Views to simplify common operations."""

    def __init__(self, client: CogniteClient, space: str, external_id: str):
        """
        Initialize the View wrapper.

        Args:
            client (CogniteClient): The Cognite client instance.
            space (str): The space of the view.
            external_id (str): The external ID of the view.
        """
        self.client = client
        self.space = space
        self.external_id = external_id

        # Get the latest version of the view
        view_id = ViewId(self.space, self.external_id)
        view_list = self.client.data_modeling.views.retrieve(view_id)
        if not view_list:
            raise ValueError(f"No view found with external_id {self.external_id} in space {self.space}")
        self.view = max(view_list, key=lambda v: v.created_time)
        self.version = self.view.version

    def get_properties(self):
        """Return a list of property names in the view."""
        return list(self.view.properties.keys())

    def get_instance(self, external_id: str, space: str):
        """
        Retrieve properties of a single instance.

        Args:
            external_id (str): External ID of the instance.
            space (str): Space of the instance.

        Returns:
            dict: Dictionary of properties, including 'externalId'.
        """
        result = self.client.data_modeling.instances.retrieve(nodes=[(space, external_id)], sources=[self.view.as_id()])
        
        if result.nodes:
            props = result.nodes[0].properties.get(self.view.as_id(), {})
            props["externalId"] = external_id
            return props
        return {}

    def search_instances(self, external_id_prefix: str, space: str):
        """
        Search for instances by external ID prefix.

        Args:
            external_id_prefix (str): Prefix to search for.
            space (str): Space to limit search to.

        Returns:
            list[tuple]: List of (space, external_id) tuples.
        """
        filter_ = Prefix(["node", "externalId"], external_id_prefix)
        result = self.client.data_modeling.instances.list(
            instance_type="node",
            filter=filter_,
            space=space,
            sources=[self.view.as_id()],
            limit=-1
        )
        return [(inst.space, inst.external_id) for inst in result]

    def upsert_instance(self, external_id: str, properties: dict, space: str, clear_existing: bool = False):
        """
        Upsert an instance with given properties.

        Args:
            external_id (str): External ID of the instance.
            properties (dict): Properties to set.
            space (str): Space of the instance.
            clear_existing (bool): If True, clear existing properties before upsert.
        """
        if clear_existing:
            props = properties
        else:
            result = self.client.data_modeling.instances.retrieve(nodes=[(space, external_id)], sources=[self.view.as_id()])
            if result.nodes:
                current_props = result.nodes[0].properties.get(self.view.as_id(), {})
                current_props.update(properties)
                props = current_props
            else:
                props = properties
        
        node = NodeApply(
            space=space,
            external_id=external_id,
            sources=[NodeOrEdgeData(source=self.view.as_id(), properties=props)]
        )
        self.client.data_modeling.instances.apply(nodes=[node])

    def get_reverse_property_value(self, external_id: str, property: str, space: str):
        """
        Retrieve instances linked via reverse direct relation. For example, this can be used to retrieve all timeSeries linked to a CogniteAsset.

        Args:
            external_id (str): External ID of the source instance.
            property (str): Name of the reverse property (e.g., 'timeSeries').
            space (str): Space of the source instance.

        Returns:
            list[tuple]: List of (space, external_id) for linked instances.
        """
        prop_def = self.view.properties.get(property)
        if not prop_def:
            raise ValueError(f"Property {property} not found in view {self.view.as_id()}")
        
        if not isinstance(prop_def, MultiReverseDirectRelation):
            raise ValueError(f"Property {property} is not a MultiReverseDirectRelation")
        
        target_view_id = prop_def.source
        through_prop = prop_def.through.property
        
        reference = {"space": space, "externalId": external_id}
        
        filter_ = ContainsAny(
            property=[target_view_id.space, f"{target_view_id.external_id}/{target_view_id.version}", through_prop],
            values=[reference]
        )
        
        result = self.client.data_modeling.instances.list(
            instance_type="node",
            sources=[target_view_id],
            filter=filter_,
            limit=-1
        )
        
        return [(inst.space, inst.external_id) for inst in result] 