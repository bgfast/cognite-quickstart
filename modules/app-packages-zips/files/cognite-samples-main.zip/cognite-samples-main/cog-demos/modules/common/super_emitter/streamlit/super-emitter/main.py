import streamlit as st
from cognite.client import CogniteClient
from cognite.client.data_classes import EventUpdate
from FileUtils import FileHelper
from SuperEmitter import SuperEmitterClient
from Canvas import generate
import datetime
import asyncio
import pydeck as pdk
import pandas as pd

st.set_page_config(layout="wide")

client = CogniteClient()

blue = '#000080'

st.title(":green[Super Emitter Diagnostics - DEMO]")

# logos
cog_logo='https://www.cognite.com/hs-fs/hubfs/TPC%20-%20CO%20-%20Web%20Templates%202019/Image/CogniteLogo.png?width=400&height=90&name=CogniteLogo.png'

def set_top_logos(left_img_url, right_img_url):
    st.markdown(
        f"""
    <style>
        .top-logos-container {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            color: white;
        }}
        .top-logos-container img {{
            height: 100px;
            width: auto;
            margin-right: 20px;
        }}
    </style>
    <div class="top-logos-container">
        <img src="{right_img_url}">
    </div>
    """,
        unsafe_allow_html=True,
    )

def set_bottom_sidebar_text(text):
    # Add text to the bottom of the sidebar with custom CSS
    st.markdown(
        f'<div style="position: fixed; bottom: 0; width: 100%; text-align: center; color: gray; font-size: small;">{text}</div>',
        unsafe_allow_html=True
    )


def set_styling():
    st._config.set_option(f'theme.primaryColor', blue)
    set_top_logos(cog_logo, cog_logo)
    st.markdown("""
        <style>
            .block-container {
                padding-top: 150px;
            }
        </style>
        """, unsafe_allow_html=True)


set_styling()

# Function to create a map
def create_map(data):
    view_state = pdk.ViewState(
        latitude=data['latitude'].mean(),
        longitude=data['longitude'].mean(),
        zoom=12,
        pitch=0)

    layer = pdk.Layer(
        "ScatterplotLayer",
        data,
        get_position='[longitude, latitude]',
        get_color='[200, 30, 0, 160]',
        get_radius=100,
    )

    return pdk.Deck(layers=[layer], initial_view_state=view_state, tooltip={"text": "{name}"}, map_style='mapbox://styles/mapbox/light-v10')


# functions for highlighting various rows in the dataframes

# work orders

def highlight_wo_rows(row):
    if row['Order_Type'] == "PM01":
        return ['background-color: red; color: white'] * len(row)
    elif row['Order_Type'] == "PM03":
        return ['background-color: orange'] * len(row)
    else:
        return [''] * len(row)

# trucking events

def highlight_trucking_rows(row):
    if row['oil_transport'] == "Trucking":
        return ['background-color: red; color: white'] * len(row)
    else:
        return [''] * len(row)

# equipment summary

def highlight_equip_summary(row):
    styles = []
    for val in row:
        if val == "Y":
            styles.append('background-color: green; color: white')
        elif val == "N":
            styles.append('background-color: red; color: white')
        else:
            styles.append('')
    return styles

# inputs is the list that all files, assets, events, etc. go into to be placed on the canvas.
# if you add an additional source, make sure to append it to inputs as in the examples below.

inputs = []

# inputs for the pad, event time, and investigation window

date_input = st.date_input("Date of event")
time_input = st.time_input('Time of event', datetime.time(0, 0), step=60)
lookback_days = st.number_input("Time Series Lookback Days", value=14)
lookforward_days = st.number_input("Time Series Lookforward Days", value=14)


search_query = st.text_input(
  label = 'Enter Pad Functional Location',
  value='flareDs-22737',
  key="workorder",
  help="Pad functional location (external_id in CDF)")

# Important: Rest of dashboard does not display until something is entered for pad functional location

#search_button = st.button("Generate Info")

#if search_button:
if search_query:

  super_emitter = SuperEmitterClient(client=client,
                                     search_query=search_query,
                                     date_input=date_input,
                                     time_input=time_input,
                                     lookback_days=lookback_days,
                                     lookforward_days=lookforward_days)
  
  st.markdown("## Site Map")


  #st.image(super_emitter.download_image_file(), caption="Note: This image is not from the selected pad. This is for demonstration purposes.")
  pad_latitude = 31.99638 #round(float(super_emitter.pad_asset.metadata['Surface_LAT_NAD83']),5)
  pad_longitude = -102.0752 #round(float(super_emitter.pad_asset.metadata['Surface_LONG_NAD83']),5)
  mapData = pd.DataFrame({"latitude": [pad_latitude], "longitude": [pad_longitude], "name": [super_emitter.pad_asset.name]})
  map_ = create_map(mapData)
  st.pydeck_chart(map_) 
  st.caption("Note: This image is not from the selected pad. This is for demonstration purposes.")



  st.markdown("## Equipment Summary")

  equip_summary = super_emitter.generate_pad_equipment()

  styled_equip = equip_summary.style.apply(highlight_equip_summary, axis=1)
  st.dataframe(styled_equip, use_container_width=True, hide_index=True)
  
  with st.spinner("Getting EBS signals, PI time series, well activity..."):
    
    # This await is needed to get the spinner to show up
    await asyncio.sleep(2.0)
    # Main function to get all data
    super_emitter.get_relevant_data()
  
  # Adding asset, time series, image to canvas inputs

  inputs.append({'type': 'asset', 'label': super_emitter.pad_asset.name, 'id': super_emitter.pad_asset.id})

  file_helper = FileHelper(client=client, site_name=super_emitter.pad_asset.name)

  inputs.append({'type': 'file', 'label': super_emitter.se_img.name, 'id': super_emitter.se_img.id})
  inputs.append({'type': 'file', 'label': 'wellsite_report_map', 'id': 5725474436038615})

  for ts in super_emitter.flare_temp_timeseries:
    inputs.append({'type': 'timeseries', 'label': ts['name'], 'id': ts['id'], 'end_timestamp': super_emitter.TS_END_CANVAS, 'start_timestamp': super_emitter.TS_START_CANVAS})

  for ts in super_emitter.flare_rate_timeseries:
    inputs.append({'type': 'timeseries', 'label': ts['name'], 'id': ts['id'], 'end_timestamp': super_emitter.TS_END_CANVAS, 'start_timestamp': super_emitter.TS_START_CANVAS})

  for ts in super_emitter.tank_timeseries:
    inputs.append({'type': 'timeseries', 'label': ts['name'], 'id': ts['id'], 'end_timestamp': super_emitter.TS_END_CANVAS, 'start_timestamp': super_emitter.TS_START_CANVAS})
  
  for ts in super_emitter.combustor_timeseries:
    inputs.append({'type': 'timeseries', 'label': ts['name'], 'id': ts['id'], 'end_timestamp': super_emitter.TS_END_CANVAS, 'start_timestamp': super_emitter.TS_START_CANVAS})
  
  for ts in super_emitter.vapor_recovery_timeseries:
    inputs.append({'type': 'timeseries', 'label': ts['name'], 'id': ts['id'], 'end_timestamp': super_emitter.TS_END_CANVAS, 'start_timestamp': super_emitter.TS_START_CANVAS})
  


  flare_col, other_col = st.columns(2)

  with flare_col:
    st.divider()

    st.markdown("### Flare Temperature Timeseries")

    if len(super_emitter.flare_temp_timeseries)==0:
      st.markdown("_No flare temperature time series!_")
    else:
      super_emitter.generate_timeseries_display(super_emitter.flare_temp_timeseries, "Temperature", "Degrees F")

    st.markdown("### Flare Rate Timeseries")

    if len(super_emitter.flare_rate_timeseries)==0:
      st.markdown("_No flare rate time series!_")
    else:
      super_emitter.generate_timeseries_display(super_emitter.flare_rate_timeseries, "Flare Rate", "mscfd")


  with other_col:
    st.divider()

    st.markdown("### Tank Pressure Timeseries")

    if len(super_emitter.tank_timeseries)==0:
      st.markdown("_No tank pressure time series!_")
    else:
      super_emitter.generate_timeseries_display(super_emitter.tank_timeseries, 'Tank Pressure', 'OSI')

    st.markdown("### Treater Temperature Timeseries")
    
    if len(super_emitter.treater_temp_timeseries)==0:
      st.markdown("_No treater temperature time series!_")
    else:
      super_emitter.generate_timeseries_display(super_emitter.treater_temp_timeseries, 'Treater Temperature', 'Degrees F')

    if len(super_emitter.combustor_timeseries)==0:
      st.markdown("_No combustor time series!_")
    else:
      super_emitter.generate_timeseries_display(super_emitter.combustor_timeseries, 'Combustor', 'Unknown')
    if len(super_emitter.vapor_recovery_timeseries)==0:
      st.markdown("_No vapor recovery time series!_")
    else:
      super_emitter.generate_timeseries_display(super_emitter.vapor_recovery_timeseries, 'Vapor Recovery', 'Unknown')

  st.divider()
  st.markdown("## EBS")
  st.markdown("### Flare Temperature History")
  if super_emitter.ebs_flare.empty:
    st.markdown("_No EBS flare events!_")
  else:
    formatted_ebs_flare, ebs_flare_file = file_helper.format_and_upload(df=super_emitter.ebs_flare, df_type="ebs")
    # Adding file to inputs
    inputs.append({'type': 'file', 'label': ebs_flare_file.name, 'id': ebs_flare_file.id})
    st.dataframe(formatted_ebs_flare, use_container_width=True, hide_index=True)

  st.markdown("### Tank Pressure History")

  if super_emitter.ebs_tank.empty:
    st.markdown("_No EBS tank pressure events!_")
  else:
    formatted_ebs_tank, ebs_tank_file = file_helper.format_and_upload(df=super_emitter.ebs_tank, df_type="ebs")
    inputs.append({'type': 'file', 'label': ebs_tank_file.name, 'id': ebs_tank_file.id})
    st.dataframe(formatted_ebs_tank, use_container_width=True, hide_index=True)

  st.markdown("### Treater Temperature History")

  if super_emitter.ebs_treater.empty:
    st.markdown("_No EBS treater temperature events!_")
  else:
    formatted_ebs_treater, ebs_treater_file = file_helper.format_and_upload(df=super_emitter.ebs_treater, df_type="ebs")
    inputs.append({'type': 'file', 'label': ebs_treater_file.name, 'id': ebs_treater_file.id})
    st.dataframe(formatted_ebs_treater, use_container_width=True, hide_index=True)

  st.divider()

  st.markdown("## Tank Unload Events")
  
  if super_emitter.trucking_events.empty:
    st.markdown("_No tank unloading activity during event window!_")
  else:
    formatted_tank_unload, tank_unload_file = file_helper.format_and_upload(df=super_emitter.trucking_events, df_type="tank_unload")
    inputs.append({'type': 'file', 'label': tank_unload_file.name, 'id': tank_unload_file.id})
    
    styled_unload = formatted_tank_unload.style.apply(highlight_trucking_rows, axis=1)
    st.dataframe(styled_unload, use_container_width=True, hide_index=True)
      
  st.divider()

  st.markdown("## Autonomous Maintenance Events", help="AM events generated by the Planning Optimizer Tool")
  
  if super_emitter.am_events.empty:
    st.markdown("_No AM events during event window!_")
  else:
    formatted_am_event, am_event_file = file_helper.format_and_upload(df=super_emitter.am_events, df_type="am_events")
    inputs.append({'type': 'file', 'label': am_event_file.name, 'id': am_event_file.id})
    st.dataframe(formatted_am_event, use_container_width=True, hide_index=True)

  st.divider()

  st.markdown("## Rig/Well Activity", help='Workovers, drilling, completions, etc from WellView.')
  
  if super_emitter.ops.empty:
    st.markdown("_No rig / well activity during event window!_")
  else:
    formatted_ops, ops_file = file_helper.format_and_upload(df=super_emitter.ops, df_type="operations_activity")
    inputs.append({'type': 'file', 'label': ops_file.name, 'id': ops_file.id})
    st.dataframe(formatted_ops, use_container_width=True, hide_index=True)

  st.divider()

  st.markdown("## Pigging Activity")
  
  st.markdown(":red[Coming soon...]")


  st.divider()
  st.markdown("## SOOFIE Alerts")

  if super_emitter.soofie.empty:
    st.markdown("_No SOOFIE alerts during event window!_")
  else:
    formatted_soofie, soofie_file = file_helper.format_and_upload(df=super_emitter.soofie, df_type="soofie")
    inputs.append({'type': 'file', 'label': soofie_file.name, 'id': soofie_file.id})
    st.dataframe(formatted_soofie, use_container_width=True, hide_index=True)

  st.divider()

  st.markdown("## Workorders")

  if super_emitter.wos.empty:
    st.markdown("_No work order events._")
  else:
    formatted_wos, wos_file = file_helper.format_and_upload(df=super_emitter.wos, df_type="workorders")
    inputs.append({'type': 'file', 'label': wos_file.name, 'id': wos_file.id})

    styled_wos = formatted_wos.style.apply(highlight_wo_rows, axis=1)
    st.dataframe(styled_wos, use_container_width=True, hide_index=True)



  if st.button("Create Work Package in Canvas"):  
    canvas_name = f"Super Emitter Dashboard for {super_emitter.pad_asset.name}"
#    canvas_name = f"Super Emitter Dashboard"
    #st.write(inputs) #Troubleshooting line
    #await asyncio.sleep(2.0) #troubleshooting line

    canvas_id = generate(canvas_name, inputs, client)

    st.write("Canvas successfully generated:")

    predefined_url_1=(f"https://cog-tech-sales.fusion.cognite.com/petro-tech-staging/industrial-canvas/canvas?canvasId={canvas_id}&cluster=api.cognitedata.com&env=api&workspace=industrial-tools")

    # Display a disguised button as a link
    button_html = f'<a href="{predefined_url_1}" target="_blank" style="text-decoration:none; color:white; background-color:#3498db; padding:10px 20px; border-radius:5px;">Open Industrial Canvas</a>'
    st.markdown(button_html, unsafe_allow_html=True)  

#st.sidebar.success("Select a demo above.")

st.markdown(
    """
"""
)
        