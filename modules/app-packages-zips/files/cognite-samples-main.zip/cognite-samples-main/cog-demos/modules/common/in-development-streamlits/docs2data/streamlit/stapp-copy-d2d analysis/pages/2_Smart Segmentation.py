"""
Enhanced Content Discovery

A Streamlit application for analyzing document content segments and extracting parameters.
"""

import streamlit as st
from cognite.client import CogniteClient
# Temporarily comment out config import to debug
# from config import *
from doc_workflows import Document
from LLM_workflows import extract_segment_parameters
from dm_helper import get_dynamic_schema_for_content_type, save_segments_to_model

def initialize_client():
    return CogniteClient()



@st.cache_data
def get_datasets_list(_client):
    datasets = _client.data_sets.list(limit=None)
    # Return all datasets for user selection (no filtering)
    return [dataset for dataset in datasets if dataset.external_id]

@st.cache_data
def get_files_list(_client, dataset_id):
    """Get list of files from a specific dataset"""
    files = _client.files.list(data_set_ids=[dataset_id], limit=1000)
    return [file for file in files if file.name]





def analyze_content_segments(client, selected_file, max_pages):
    """
    Comprehensive Content Segment Analysis using Document classes.
    Routes to appropriate workflow based on file type.
    """
    try:
        # Create appropriate document instance
        document = Document.create(client, selected_file)
        
        # Check if document type is supported
        if not document.is_supported():
            return {"selected_file": selected_file, "success": False, "error": f"Unsupported file type: {selected_file.name}"}
        
        # Display document type detection info and analyze
        document_type = type(document).__name__
        if document_type == "PDFDocument":
            st.info("📄 Detected PDF document. Using OCR-based analysis workflow.")
            return document.analyze_for_content_segments(max_pages=max_pages)
        elif document_type == "WordDocument":
            st.info("📝 Detected Word document. Using specialized text extraction workflow.")
            return document.analyze_for_content_segments()
        elif document_type == "ExcelDocument":
            st.info("📊 Detected Excel document. Using specialized data extraction workflow.")
            return document.analyze_for_content_segments()
        elif document_type == "EmailDocument":
            st.info("📧 Detected Outlook message. Using specialized email extraction workflow.")
            return document.analyze_for_content_segments()
        else:
            return {"selected_file": selected_file, "success": False, "error": f"Unsupported document type: {document_type}"}
        
    except Exception as e:
        st.error(f"❌ Content segment analysis failed: {str(e)}")
        return {
            "selected_file": selected_file,
            "success": False,
            "error": f"Analysis failed: {str(e)}"
        }


def extract_parameters(client, content_analysis_results):
    """
    Content Segment Parameter Extraction
    """
    results = {
        "success": False,
        "segment_extractions": []
    }
    
    try:
        selected_file = content_analysis_results['selected_file']
        content_segments = content_analysis_results['content_segments']
        
        # Create document instance for content extraction
        document = Document.create(client, selected_file)
        
        st.write(f"📄 Extracting parameters from {len(content_segments)} content segments in: {selected_file.name}")
        segment_extractions = []
        progress_bar = st.progress(0)
        
        for i, segment in enumerate(content_segments):
            segment_title = segment.get('document_title', f'Segment {i+1}')
            content_type = segment.get('content_type', 'Other (Unclassified)')
            start_page = segment.get('start_page', 1)
            end_page = segment.get('end_page', 1)
            
            # Get dynamic schema for this content type
            schema = get_dynamic_schema_for_content_type(client, content_type)
            
            if "error" in schema:
                st.warning(f"   ⚠️ Could not get schema for {content_type}: {schema['error']}")
                segment_extractions.append({
                    'segment_id': i+1,
                    'segment_title': segment_title,
                    'content_type': content_type,
                    'error': f"Schema error: {schema['error']}",
                    'pages': f"{start_page}-{end_page}"
                })
                continue
            
            schema_name = content_type.replace(" ", "").replace("(", "").replace(")", "")
            
            # Extract content for this segment using document class
            segment_content = document.extract_segment_content(start_page, end_page)
            
            if not segment_content.strip():
                st.warning(f"   ⚠️ No content found for pages {start_page}-{end_page}")
                segment_extractions.append({
                    'segment_id': i+1,
                    'segment_title': segment_title,
                    'content_type': content_type,
                    'schema_name': schema_name,
                    'error': 'No content found',
                    'pages': f"{start_page}-{end_page}"
                })
                continue
            
            # Extract parameters using AI
            extraction_result = extract_segment_parameters(
                client, segment_content, content_type, schema, 
                selected_file.name, i+1, segment_title, schema_name
            )
            
            # Add segment metadata
            extraction_result.update({
                'segment_title': segment_title,
                'pages': f"{start_page}-{end_page}",
                'content_length': len(segment_content)
            })
            segment_extractions.append(extraction_result)
            progress_bar.progress((i + 1) / len(content_segments))
        
        results.update({
            "segment_extractions": segment_extractions,
            "success": True
        })
        
        return results
        
    except Exception as e:
        st.error(f"❌ Parameter extraction failed: {str(e)}")
        return results

def display_content_segments(content_segments, overall_classification):
    """Display content segments in a table-of-contents style"""
    st.subheader("📚 Document Content Structure")
    
    # Overall classification
    st.info(f"📦 **Overall Package Classification:** {overall_classification}")
    
    # Content segments table
    st.write("### Content Segments")
    
    for i, segment in enumerate(content_segments, 1):
        with st.expander(f"**Segment {i}:** {segment.get('document_title', 'Untitled')}"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.write(f"**Type:** {segment.get('content_type', 'Unknown')}")
            with col2:
                st.write(f"**Pages:** {segment.get('start_page', '?')}-{segment.get('end_page', '?')}")
            with col3:
                if segment.get('ad_hoc_classification'):
                    st.write(f"**Classification:** {segment.get('ad_hoc_classification')}")
            
            if segment.get('summary'):
                st.write(f"**Summary:** {segment.get('summary')}")


def display_parameter_results(segment_extractions):
    """Display parameter extraction results"""
    st.subheader("🔧 Extracted Parameters")
    successful_extractions = [s for s in segment_extractions if not s.get('error')]
    failed_extractions = [s for s in segment_extractions if s.get('error')]
    st.info(f"✅ Successfully processed {len(successful_extractions)} segments, {len(failed_extractions)} failed")
    
    for extraction in segment_extractions:
        segment_title = extraction.get('segment_title', 'Unknown Segment')
        with st.expander(f"**{segment_title}** ({extraction.get('content_type', 'Unknown')})"):
            if extraction.get('error'):
                st.error(f"❌ Error: {extraction['error']}")
            else:
                # Display extracted parameters
                extracted_params = extraction.get('extracted_parameters', {})
                if extracted_params:
                    st.write("**Extracted Parameters:**")
                    for param_name, param_value in extracted_params.items():
                        if param_value is not None:
                            st.write(f"- **{param_name}:** {param_value}")
                        else:
                            st.write(f"- **{param_name}:** *Not found*")
                
                # Display extraction metadata
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.write(f"**Confidence:** {extraction.get('confidence_level', 'Unknown')}")
                with col2:
                    st.write(f"**Fields Found:** {len(extraction.get('fields_found', []))}")
                with col3:
                    st.write(f"**Fields Missing:** {len(extraction.get('fields_not_found', []))}")
                if extraction.get('extraction_notes'):
                    st.write(f"**Notes:** {extraction.get('extraction_notes')}")


def prepare_segment_data_for_model(segment_extractions):
    """Prepare extracted segment data for data model JSON preview"""
    model_data = {}
    for extraction in segment_extractions:
        if not extraction.get('error'):
            segment_id = extraction.get('segment_id', 'unknown')
            segment_title = extraction.get('segment_title', 'Unknown Segment')
            model_data[f"segment_{segment_id}"] = {
                "title": segment_title,
                "content_type": extraction.get('content_type'),
                "schema_name": extraction.get('schema_name'),
                "pages": extraction.get('pages'),
                "extracted_parameters": extraction.get('extracted_parameters', {}),
                "confidence_level": extraction.get('confidence_level'),
                "fields_found": extraction.get('fields_found', []),
                "extraction_notes": extraction.get('extraction_notes')
            }
    
    return model_data


def main():
    st.set_page_config(
        page_title="Enhanced Content Discovery",
        page_icon="🔍",
        layout="wide"
    )
    
    with st.container():
        st.markdown(
            f"""
            <div style="display: flex; justify-content: center;">
                <img src="https://mms.businesswire.com/media/20250519865188/en/2474150/5/cognite-tagline-horizontal_6.jpg?download=1&_gl=1*16caelh*_gcl_au*MTg1MTcxMzU0MS4xNzU0NTg2MzAy*_ga*MTEyNzQ1NDMxMy4xNzU0NTg2MzAz*_ga_ZQWF70T3FK*czE3NTQ1ODYzMDIkbzEkZzAkdDE3NTQ1ODYzMDIkajYwJGwwJGgw" width=300>
            </div>
            """,
            unsafe_allow_html=True
        )
    st.markdown("<h1 style='text-align: center;'>Docs2Data Auto-Analyzer</h1>", unsafe_allow_html=True)
    st.markdown("<p style='margin-top: -20px; font-style: italic; font-size: 18px; text-align: center;'>Powered by Cognite's Industrial Knowledge Graph</p>", unsafe_allow_html=True)
    st.markdown("---")
    
    # Initialize session state
    if 'content_analysis_results' not in st.session_state:
        st.session_state.content_analysis_results = None
    if 'parameter_results' not in st.session_state:
        st.session_state.parameter_results = None
    
    # Initialize client
    try:
        client = initialize_client()
    except Exception as e:
        st.error(f"Failed to initialize Cognite client: {e}")
        return
    
    # Input Section
    st.header("2. Smart Segmentation")
    
    # Dataset Selection
    with st.spinner("Loading datasets from CDF..."):
        datasets = get_datasets_list(client)
    
    if not datasets:
        st.error("No datasets found in CDF. Please create a dataset and upload some files first.")
        return
    
    # Dataset selector
    dataset_options = {f"{dataset.name or dataset.external_id} ({dataset.external_id})": dataset for dataset in datasets}
    
    # Use first dataset as default
    default_index = 0
    
    selected_dataset_key = st.selectbox(
        "Select Dataset",
        options=list(dataset_options.keys()),
        index=default_index,
        help="Choose any dataset containing files you want to analyze"
    )
    selected_dataset = dataset_options[selected_dataset_key]
    
    # Load files from selected dataset
    with st.spinner("Loading files from selected dataset..."):
        files = get_files_list(client, selected_dataset.id)
    
    if not files:
        st.error(f"No files found in dataset '{selected_dataset.external_id}'")
        return
    
    # File selection
    file_options = {f"{file.name}": file for i, file in enumerate(files)}
    selected_file_key = st.selectbox(
        "Select File",
        options=list(file_options.keys()),
        help="Choose a file from your CDF dataset"
    )
    selected_file = file_options[selected_file_key]
    
    # Create document instance to check type
    document = Document.create(client, selected_file)
    document_type = type(document).__name__
    
    if document_type == "PDFDocument":
        # PDF files need page selection
        st.info("📄 Selected PDF document will be processed using OCR-based workflow")
        max_pages = st.number_input(
            "Number of Pages to Analyze",
            min_value=1,
            max_value=100,
            value=30,
            help="Maximum number of pages to analyze for content segmentation"
        )
    elif document_type == "WordDocument":
        st.info("📝 Selected Word document will be processed using text extraction workflow")
        max_pages = 1  # Not used for non-PDF files, but needed for function signature
    elif document_type == "ExcelDocument":
        st.info("📊 Selected Excel document will be processed using data extraction workflow")
        max_pages = 1  # Not used for non-PDF files, but needed for function signature
    elif document_type == "EmailDocument":
        st.info("📧 Selected Outlook message will be processed using email extraction workflow")
        max_pages = 1  # Not used for non-PDF files, but needed for function signature
    else:
        st.error(f"❌ Unsupported file type: {selected_file.name}")
        return
    
    # Analyze button
    analyze_col1, analyze_col2, analyze_col3 = st.columns([1, 1, 1])
    with analyze_col2:
        analyze_clicked = st.button("✨ Find Content Segments", type="primary", use_container_width=True)
    
    # Handle analyze outside of columns so messages span full width
    if analyze_clicked:
        with st.spinner("Analyzing content segments..."):
            st.session_state.content_analysis_results = analyze_content_segments(client, selected_file, max_pages)
            st.session_state.parameter_results = None  # Reset parameter results
    
    # Display Content Analysis Results
    if st.session_state.content_analysis_results and st.session_state.content_analysis_results.get('success'):
        content_segments = st.session_state.content_analysis_results['content_segments']
        overall_classification = st.session_state.content_analysis_results['overall_package_classification']
        display_content_segments(content_segments, overall_classification)
        
        # Parameter Extraction button
        extract_col1, extract_col2, extract_col3 = st.columns([1, 1, 1])
        with extract_col2:
            extract_clicked = st.button("✨ Extract Contextual Data", type="primary", use_container_width=True)
        
        # Handle parameter extraction outside of columns so messages span full width
        if extract_clicked:
            with st.spinner("Extracting parameters from content segments..."):
                st.session_state.parameter_results = extract_parameters(client, st.session_state.content_analysis_results)
        
        # Display Parameter Results
        if st.session_state.parameter_results and st.session_state.parameter_results.get('success'):
            segment_extractions = st.session_state.parameter_results['segment_extractions']
            display_parameter_results(segment_extractions)
            
            # Data Model Preview
            with st.expander("📋 Data Model Properties"):
                model_data = prepare_segment_data_for_model(segment_extractions)
                st.json(model_data)
            
            # Commit button
            st.markdown("---")
            commit_col1, commit_col2, commit_col3 = st.columns([1, 1, 1])
            with commit_col2:
                if st.button("💾 Commit to Knowledge Graph", type="secondary", use_container_width=True):
                    with st.spinner("Saving to knowledge graph..."):
                        save_results = save_segments_to_model(
                            client=client,
                            segment_extractions=segment_extractions,
                            selected_file=selected_file
                        )
                        
                        if save_results.get("success", False):
                            st.success(f"✅ Successfully saved {save_results['segments_saved']} segments to data model!")
                            
                            # Show details
                            with st.expander("📋 Save Details", expanded=False):
                                for detail in save_results["details"]:
                                    if detail["status"] == "saved":
                                        st.write(f"✅ Segment {detail['segment_id']}: {detail['external_id']} → {detail['view_name']}")
                                    else:
                                        st.write(f"❌ Segment {detail['segment_id']}: {detail['error']}")
                        else:
                            st.error(f"❌ Failed to save segments: {save_results.get('error', 'Unknown error')}")
                            st.write(f"Saved: {save_results['segments_saved']}, Failed: {save_results['segments_failed']}")
    
    elif st.session_state.content_analysis_results and not st.session_state.content_analysis_results.get('success'):
        st.error("❌ Content analysis failed. Please try again.")

if __name__ == "__main__":
    main()