from cognite.client import CogniteClient
import json
import re
from typing import Dict, Any, Union, Optional
from data_modeling import View
import base64
from cognite.client.data_classes import filters
from cognite.client.data_classes.documents import DocumentProperty
import warnings

def _clean_and_parse_json(content: str) -> Dict[str, Any]:
    """
    Clean and parse JSON from AI response.

    Args:
        content (str): Raw response content.

    Returns:
        Dict[str, Any]: Parsed JSON object.
    """
    # Remove markdown code blocks
    content = re.sub(r'```json\s*', '', content)
    content = re.sub(r'```\s*', '', content)
    
    # Find JSON-like content
    json_match = re.search(r'\{.*\}', content, re.DOTALL)
    if json_match:
        json_str = json_match.group(0)
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            pass
    
    # Fallback: try to parse the whole content
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        raise ValueError(f"Could not parse JSON from response: {content}")


class AtlasAgent:
    """Helper class for managing Atlas Agents via the experimental AI Agents API."""

    _VERSION_HEADER = {"cdf-version": "20250101-alpha"}

    @classmethod
    def list_agents(cls, client: CogniteClient):
        """Return list of (external_id, name) for all agents."""
        url = f"/api/v1/projects/{client.config.project}/ai/agents"
        resp = client.get(url, headers=cls._VERSION_HEADER)
        resp.raise_for_status()
        items = resp.json().get("items", [])
        return [(item["externalId"], item.get("name", "")) for item in items]

    def __init__(self, client: CogniteClient, external_id: str):
        """
        Initialize AtlasAgent.

        Args:
            client (CogniteClient): Cognite client instance.
            external_id (str): External ID of the agent.
        """
        self.client = client
        self.external_id = external_id
        self._details_cache: Dict[str, Any] = {}

    # Internal helpers
    def _url(self, suffix: str = "") -> str:
        """Build API URL for the agent."""
        base = f"/api/v1/projects/{self.client.config.project}/ai/agents/{self.external_id}"
        return base + suffix

    def get_details(self) -> Dict[str, Any]:
        """Retrieve full agent details from the API."""
        resp = self.client.get(self._url(), headers=self._VERSION_HEADER)
        resp.raise_for_status()
        self._details_cache = resp.json()
        return self._details_cache

    def delete_agent(self) -> None:
        """Delete the agent permanently."""
        resp = self.client.delete(self._url(), headers=self._VERSION_HEADER)
        resp.raise_for_status()

    def recreate_agent(self, new_owner_id: str) -> None:
        """Recreate the agent with the same externalId but a new ownerId."""
        details = self.get_details()
        create_payload = {k: v for k, v in details.items() if k not in ["id", "createdTime", "lastUpdatedTime", "ownerId"]}
        create_payload["ownerId"] = new_owner_id
        create_payload["externalId"] = self.external_id  # ensure same externalId

        # Delete existing agent
        delete_body = {"items": [{"externalId": self.external_id}]}
        self.client.post(f"/api/v1/projects/{self.client.config.project}/ai/agents/delete", headers=self._VERSION_HEADER, json=delete_body).raise_for_status()

        # Recreate agent with same externalId
        create_body = {"items": [create_payload]}
        self.client.post(f"/api/v1/projects/{self.client.config.project}/ai/agents", headers=self._VERSION_HEADER, json=create_body).raise_for_status()

    def publish_agent(self):
        """Ensure the agent has the 'published' label. Tries PATCH first, then delete+recreate fallback."""
        details = self.get_details()
        labels = details.get("labels", []) or []
        if "published" in labels:
            return  # Already published

        # First attempt: PATCH labels
        try:
            patch_body = {"labels": labels + ["published"]}
            resp = self.client.patch(self._url(), headers=self._VERSION_HEADER, json=patch_body)
            if resp.status_code == 200:
                return
        except Exception:
            # Fall back to recreation
            pass

        # Fallback: delete and recreate with published label
        import copy
        new_labels = labels + ["published"]
        agent_config = {k: copy.deepcopy(v) for k, v in details.items() if k not in ["id", "createdTime", "lastUpdatedTime"]}
        agent_config["labels"] = new_labels

        # Delete existing agent
        delete_payload = {"items": [{"externalId": self.external_id}]}
        self.client.post(f"/api/v1/projects/{self.client.config.project}/ai/agents/delete", headers=self._VERSION_HEADER, json=delete_payload).raise_for_status()

        # Recreate
        create_payload = {"items": [agent_config]}
        self.client.post(f"/api/v1/projects/{self.client.config.project}/ai/agents", headers=self._VERSION_HEADER, json=create_payload).raise_for_status()

    def call_agent(self, messages, cursor: str = None):
        """Chat with the agent. messages can be a string or list[str]. Returns (answer, cursor)."""
        if isinstance(messages, str):
            messages = [messages]
        body = {
            "messages": [{"role": "user", "content": m} for m in messages]
        }
        if cursor:
            body["cursor"] = cursor
        resp = self.client.post(self._url("/chat/completions"), headers=self._VERSION_HEADER, json=body)
        resp.raise_for_status()
        data = resp.json()
        answer = data["choices"][0]["message"]["content"]
        new_cursor = data.get("cursor")
        return answer, new_cursor


class Completions:
    """Class for handling AI completions with optional data model integration."""

    def __init__(self, client: CogniteClient, system_prompt: Optional[str] = None, user_content: Optional[str] = None, model: str = "azure/gpt-4o"):
        self.client = client
        self.system_prompt = system_prompt
        self.user_content = user_content
        self.model = model

    def get_prompts_from_dm(self, view_space: str, view_external_id: str, instance_external_id: str, instance_space: str, mapping: Dict[str, str]):
        """
        Optional method to load prompts from data model instance.

        Args:
            view_space (str): View space.
            view_external_id (str): View external ID.
            instance_external_id (str): Instance external ID.
            instance_space (str): Instance space.
            mapping (Dict[str, str]): Map 'system_prompt'/'user_content' to view properties.
        """
        view = View(self.client, view_space, view_external_id)
        instance = view.get_instance(instance_external_id, instance_space)
        
        if "system_prompt" in mapping:
            self.system_prompt = instance.get(mapping["system_prompt"])
        if "user_content" in mapping:
            self.user_content = instance.get(mapping["user_content"])

    def substitute_params(self, substitutions: Dict[str, str]):
        """
        Optional method to substitute placeholders in prompts. 

        Args:
            substitutions (Dict[str, str]): Placeholder to value mappings.
        """
        for placeholder, value in substitutions.items():
            if self.system_prompt:
                self.system_prompt = self.system_prompt.replace(placeholder, value)
            if self.user_content:
                self.user_content = self.user_content.replace(placeholder, value)

    def append_to_user_content(self, text_to_append: str):
        """
        Append text to the user_content string.

        Args:
            text_to_append (str): The text to append.
        """
        if self.user_content is None:
            self.user_content = ""
        self.user_content += text_to_append

    def _get_document_data_url(self, file_id: int, page_number: int) -> str:
        """Internal: Get base64 data URL for a document page preview."""
        document = self.client.documents.list(filter=filters.Equals(DocumentProperty.id, file_id))[0]
        
        if page_number < 1 or page_number > document.page_count:
            raise ValueError(f"Page {page_number} out of range (1-{document.page_count})")
        
        page_content = self.client.documents.previews.download_page_as_png_bytes(
            id=document.id, page_number=page_number
        )
        
        return f"data:image/png;base64,{base64.b64encode(page_content).decode('utf-8')}"

    def call_endpoint(self, clean_json: bool = False) -> Union[str, Dict[str, Any]]:
        """
        Call AI endpoint with current prompts.

        Args:
            clean_json (bool): Clean and parse as JSON if True.

        Returns:
            Union[str, Dict]: Response text or JSON.
        """
        if not self.system_prompt or not self.user_content:
            raise ValueError("System prompt and user content must be set")

        response = self.client.post(
            url=f"/api/v1/projects/{self.client.config.project}/ai/chat/completions",
            json={
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": self.user_content}
                ],
                "model": self.model
            }
        )
        
        if response.status_code != 200:
            raise ValueError(f"AI API failed: {response.status_code}")
        
        content = response.json()['choices'][0]['message']['content']
        
        if clean_json:
            return _clean_and_parse_json(content)
        
        return content

    def call_endpoint_with_file(self, file_id: int, start_page: int, end_page: Optional[int] = None, clean_json: bool = False) -> Union[str, Dict[str, Any]]:
        """
        Call AI endpoint with file preview images.

        Args:
            file_id (int): File ID.
            start_page (int): Starting page.
            end_page (Optional[int]): Ending page (if None, only start_page).
            clean_json (bool): Return parsed JSON if True.

        Returns:
            Union[str, Dict]: AI response.
        """
        if not self.system_prompt:
            raise ValueError("System prompt must be set")
        
        end = end_page or start_page
        if start_page > end:
            raise ValueError("start_page must be <= end_page")
        
        if any(p > 10 for p in range(start_page, end + 1)):
            warnings.warn("Document previews only supported for pages 1-10")
        
        user_content = []
        if self.user_content:
            user_content.append({"type": "text", "text": self.user_content})
        
        for page in range(start_page, end + 1):
            data_url = self._get_document_data_url(file_id, page)
            user_content.append({
                "type": "image_url",
                "imageUrl": {"url": data_url}
            })
        
        response = self.client.post(
            url=f"/api/v1/projects/{self.client.config.project}/ai/chat/completions",
            json={
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": user_content}
                ],
                "model": self.model
            }
        )
        
        if response.status_code != 200:
            raise ValueError(f"AI API failed: {response.status_code}")
        
        content = response.json()['choices'][0]['message']['content']
        
        if clean_json:
            return _clean_and_parse_json(content)
        
        return content