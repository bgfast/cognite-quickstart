import pandas as pd
import time 
import streamlit as st

class FileHelper:

    def __init__(self, client, site_name):

        self.client = client
        self.site_name = site_name
        self.dataset_id = 4369769663225479
        self.version = 0.0

        # This defines the columns you want on each event. To add a column to the display, simply add it to the list of the data source.

        self.column_mapping = {"ebs" :  ['metadata.ParentId', 'metadata.WellName', 'subtype', 'metadata.CreateDate', 'metadata.Comments', 'metadata.RO_comment'],
                               "workorders" : ["start_time", "end_time", "metadata.PM_Order_No", "metadata.Notification_No", "metadata.Order_Description", "metadata.Tasklist_Description", "metadata.Order_Type"],
                               "operations_activity" : ['start_time', 'end_time', 'type', 'metadata.client', 'metadata.targetform', 'metadata.objective'], 
                                "soofie" : ["start_time", "metadata.alertEmission", "description"],
                                "tank_unload" : ['start_time', "end_time", "metadata.volume", "metadata.well", "metadata.tank", "metadata.oil_transport"],
                                "am_events" : ["start_time", "description", "metadata.ScheduleType", "metadata.ProgressStatus", "metadata.Action", "metadata.Person"]}

    def format_df(self, df, df_type):

        # This function cleans the dataframe and updates the columns to a more readable name based on the column mapping above

        NEED_COLS = self.column_mapping.get(df_type)

        # fill all np.nan values with a more explicit "N/A"
        
        df.fillna(value="N/A", inplace=True)

        for col in NEED_COLS:
            
            # Ensure all needed columns are present even if they have no data

            if col not in df.columns:
                df[col] = None
        
        # Remove "metadata" from column name

        COL_MAP_UPDATE = {col : col.replace("metadata.", "") for col in NEED_COLS}
        KEEP_COLS = COL_MAP_UPDATE.values()
        
        # Make all columns strings

        for col in df.columns:

            df[col] = df[col].astype(str)

        df.rename(columns=COL_MAP_UPDATE, inplace=True)
        return df[KEEP_COLS]


    def create_file(self, raw_df, formatted_df, df_type):

        # This function creates a file which is displayed when a canvas is generated. 
        # It does not currently implement the formatting that is displayed on the Streamlit app. 

        current_time = time.strftime("%m_%d_%Y_%H_%M_%S", time.localtime())
        file_name = f"super_emitter_{df_type}_{current_time}.xlsx".strip()
        if df_type == "ebs":
            display_name = f"{df_type.upper()} {raw_df['subtype'].iloc[0]} {self.site_name}".strip()
        else:
            display_name = f"{df_type.upper()} {self.site_name}".strip()

        display_name = display_name.replace(r"/", "").replace("\\", r"")
        writer = pd.ExcelWriter(file_name, engine="xlsxwriter")
        formatted_df.to_excel(writer, sheet_name="data", index=False)
    # Use context manager to handle the ExcelWriter lifecycle
        with pd.ExcelWriter(file_name, engine="xlsxwriter") as writer:
            formatted_df.to_excel(writer, sheet_name="data", index=False)
        # Formatting column widths 
            for column in formatted_df.columns:
                if "time" in column:
                    column_length = 25
                elif formatted_df[column].dtype == object:  # Check if column is of type object for string operations
                    column_length = max(formatted_df[column].astype(str).map(len).max(), len(column))  # Account for header size
                else:
                    column_length = len(column)  # Default column width for non-object types
                #else:
                #    column_length = max(formatted_df[column].str.len())
                col_idx = formatted_df.columns.get_loc(column)
                writer.sheets['data'].set_column(col_idx, col_idx, column_length)
        # Upload the file

        res = self.client.files.upload(path=file_name,
                                        data_set_id=self.dataset_id, 
                                        external_id=file_name, 
                                        mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        source='streamlit_super_emitter_ic_app',
                                        metadata={"version" : self.version},
                                        name=display_name,
                                        overwrite=True)
        return res


    def format_and_upload(self, df, df_type):
        
        # Main function to both format and create the file.
        
        formatted_df = self.format_df(df, df_type)
        created_file = self.create_file(df, formatted_df, df_type)

        return formatted_df, created_file