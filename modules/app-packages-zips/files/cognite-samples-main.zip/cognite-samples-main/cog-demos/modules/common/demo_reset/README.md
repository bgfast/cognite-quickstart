# Reset Manager
Reset Manager
Type: Streamlit