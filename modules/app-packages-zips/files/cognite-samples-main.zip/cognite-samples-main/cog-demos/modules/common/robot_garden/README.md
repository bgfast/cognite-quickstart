# Robot Garden
This is a self-contained module that has a 3D Drone image based photogrammetry model, along with equipment data sheets and an asset hierarchy.
Type: Industrial Applications

Steps:
1. Run the rg-tr-assets transformation to create the assets.
2. Upload the 3D model (stored in Google Drive as RobotGarden_adjusted_cleaned2.laz)
3. Contextualize the 3D model (not done by this module)