select
  cast(`ExternalID` as STRING) as externalId,
  cast(`Name` as STRING) as name,
  case 
    when `ParentExternalID` is null or `ParentExternalID` = '' then null 
    else node_reference("robot-garden-assets", `ParentExternalID`) 
  end as parent,
  cast(`Description` as STRING) as description
from
  `robot_garden`.`assets`;
