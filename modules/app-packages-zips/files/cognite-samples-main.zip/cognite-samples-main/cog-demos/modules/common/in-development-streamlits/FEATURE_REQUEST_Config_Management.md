# Feature Request: Configuration Management System for Trader Dashboards

**Date:** 2024-06-20  
**Requested by:** User  
**Priority:** Medium  
**Status:** Not Started  

## Overview

Add a configuration management system to enable personalization of trader dashboards for specific clients/companies, making the dashboards more valuable for client demonstrations and deployments.

## Current State

- Dashboards use hardcoded generic plant names and product configurations
- No way to customize for specific companies without code changes
- Limited personalization options for client demonstrations

## Proposed Solution

### **Option 1: Source Control + Runtime Selection (Recommended)**

**Architecture:**
- Company templates stored as YAML files in source control
- Configuration page for runtime selection and customization
- Session state management for active configuration
- Easy migration path to CDF Raw for persistence in production

**Directory Structure:**
```
cog-demos/modules/common/in-development-streamlits/
├── config/
│   ├── companies/
│   │   ├── lyondellbasell.yaml
│   │   ├── exxonmobil.yaml
│   │   ├── shell.yaml
│   │   ├── generic_petrochemical.yaml
│   │   └── generic_refinery.yaml
│   └── company_schema.yaml
```

## Features to Implement

### **1. Company Information Configuration**
- Company name and branding
- Logo URL/base64 encoding
- Primary colors/theme customization
- Contact information

### **2. Plant/Facility Configuration**
- Plant names and locations
- Regional mappings
- Capacity ranges
- Equipment types specific to company

### **3. Product Configuration**
- Product portfolios (varies by company)
- Product categories and units
- Trading segments

### **4. Trader Configuration**
- Trader categories/names
- Customer segments
- Product responsibilities

### **5. UI Customization**
- Dashboard title and subtitle
- Color scheme
- Default filters
- Layout preferences

## Example Configuration Structure

```yaml
# config/companies/lyondellbasell.yaml
company:
  name: "LyondellBasell"
  display_name: "LyondellBasell Industries"
  logo_url: "data:image/..."
  theme:
    primary_color: "#1f4e79"
    accent_color: "#00a651"
  
plants:
  - name: "Channelview Complex"
    region: "North America"
    location: "Texas, USA"
    primary_products: ["Ethylene", "Propylene"]
  - name: "Wesseling"
    region: "Europe" 
    location: "Germany"
    primary_products: ["Polyethylene", "Polypropylene"]

products:
  categories:
    - name: "Olefins"
      products: ["Ethylene", "Propylene", "Butadiene"]
    - name: "Aromatics" 
      products: ["Benzene", "Toluene", "Xylene"]
    - name: "Polymers"
      products: ["Polyethylene", "Polypropylene"]

traders:
  - name: "Trader A (Automotive)"
    focus: ["Ethylene", "Propylene", "Butadiene"]
    customer_segment: "Automotive"
  - name: "Trader B (Packaging)"
    focus: ["Polyethylene", "Polypropylene"]
    customer_segment: "Packaging"
```

## Implementation Plan

1. **Phase 1: Configuration Infrastructure**
   - Create config directory structure
   - Define company YAML schema
   - Create generic company templates

2. **Phase 2: Configuration Page**
   - Add company selection dropdown
   - Implement session state management
   - Add basic customization options

3. **Phase 3: Dashboard Integration**
   - Modify dashboards to use dynamic configuration
   - Update plant data generation to use config
   - Implement theme/branding changes

4. **Phase 4: Advanced Features**
   - Real-time configuration editing
   - Configuration validation
   - Export/import configurations

## Benefits

- **Demo-friendly**: Easy to switch between company configurations
- **Client-ready**: Personalized dashboards for specific clients
- **Scalable**: Simple to add new companies
- **Maintainable**: Version-controlled configurations
- **Flexible**: Runtime customization capabilities

## Alternative Approaches Considered

### **Option 2: CDF Raw Tables**
- Store configurations in Cognite Data Fusion Raw tables
- More enterprise-ready but requires CDF Raw permissions
- More complex setup

### **Option 3: Hybrid Approach**
- Default templates in source control
- Runtime customization in session state
- Optional CDF Raw persistence for production

## Questions to Resolve

1. Which companies should have initial templates? (LyondellBasell, Shell, ExxonMobil, Generic?)
2. How extensive should UI customization be? (branding only vs. full layout/colors)
3. Should config page be separate streamlit or integrated into each dashboard?
4. What level of real-time editing should be supported?

## Success Criteria

- [ ] Easy company configuration switching (< 30 seconds)
- [ ] Professional client-ready appearance
- [ ] Minimal code changes required for new companies
- [ ] Maintains current dashboard functionality
- [ ] Clear documentation for adding new companies

## Estimated Effort

**Medium** - 2-3 weeks of development time

## Dependencies

- Current streamlit applications (petrochem-dashboard, refinery-dashboard)
- YAML parsing libraries
- Streamlit session state management 