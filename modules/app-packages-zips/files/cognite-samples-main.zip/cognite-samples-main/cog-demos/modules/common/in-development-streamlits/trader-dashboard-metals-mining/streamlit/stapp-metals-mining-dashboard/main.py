import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import random
import numpy as np
import os
import logging

# --- Demo Script Functionality ---
def load_demo_script():
    """Load the demo script from the markdown file with robust path resolution and fallback."""
    
    # Embedded fallback content for when file can't be loaded
    fallback_content = """
# ⛏️ Metals & Mining Trading Dashboard - Demo Script
**Duration: 8-10 minutes | Business Value Story**

---

## 👥 **PERSONAS**

**🎯 VICTORIA STEEL** - Senior Metals Trader  
*17 years experience at MetalMax Global, manages $280M metals trading portfolio*  
*Specializes in copper, aluminum, and steel trading across global commodity exchanges*  
*Known for her expertise in industrial demand cycles and supply chain disruptions*  
*Currently under pressure to improve trading margins by 24% amid volatile energy costs*

**⚙️ JAMES RODRIGUEZ** - Mining Operations Manager  
*20 years experience, oversees 15 mining and processing facilities across 4 continents*  
*Former mining engineer with expertise in ore processing and smelting operations*  
*Responsible for $120M in annual production optimization initiatives*  
*Leading digital transformation to improve mine-to-market coordination*

---

## 🌅 **SETTING THE SCENE**
*It's 5:30 AM on a Tuesday morning at MetalMax's London trading floor. Victoria is monitoring global metals prices that are volatile due to Chinese demand concerns and energy cost inflation, while copper futures are spiking on supply disruption rumors. James is at the central operations center coordinating multiple mining sites across different time zones. Victoria has significant exposure to copper and aluminum contracts with delivery commitments to major manufacturing companies.*

---

## 🎬 **SCENE 1: The Crisis Unfolds (0:00 - 2:00)**

**VICTORIA** *(monitoring multiple screens showing metals prices, Chinese PMI data, and energy cost indicators)*  
"James, we have a critical situation unfolding. Copper futures just jumped $400 per ton overnight on Chinese infrastructure spending rumors, energy costs are spiking across Europe, and I've got major manufacturers expecting 12,000 metric tons of copper delivery over the next month for automotive and construction projects."

**JAMES** *(video call from operations center, with mining status displays visible)*  
"I saw the copper move. What's your exposure situation?"

**VICTORIA** *(analyzing position screens)*  
"We're short 8,000 MT copper at an average of $8,200/MT, but LME prices just hit $8,600. The good news is we have mine production, but I need to understand our concentrate output and smelting capacity - energy costs are killing our processing margins."

---

## 📊 **SCENE 2: Dashboard Deep Dive (2:00 - 5:00)**

**JAMES**  
"Let me show you our global mining operations using our integrated dashboard..."

### **Key Dashboard Interactions:**

1. **Global Mining Operations Overview**
   - Navigate to Enterprise-Wide view
   - Point out: 15 facilities, 18,500 MT/month copper production
   - Current output: 16,200 MT/month (88% capacity utilization)
   - Energy cost impact: $420/MT average processing cost

2. **Regional Focus - South America**
   - Switch to Region-Wide filter
   - Highlight: Chile and Peru copper mines
   - Combined production: 12,000 MT/month, lower energy costs

3. **Smelting & Processing Analysis**
   - Click on Chilean Copper Complex
   - Concentrate grade: 28% copper content (industry leading)
   - Energy contracts: 65% locked at $85/MWh through Q3
   - Processing capacity: can handle additional 2,000 MT concentrate/month

4. **Supply Chain Optimization**
   - Show ore quality vs. processing efficiency
   - Transportation costs: rail vs. truck logistics
   - Port inventory: 8-day shipping buffer maintained

---

## 💡 **SCENE 3: Strategic Decision Making (5:00 - 8:00)**

**VICTORIA**  
"Excellent visibility! I can see we can cover the shortage and then some. With our locked energy contracts, what's our all-in cost for additional copper production?"

**JAMES**  
"Our Chilean operation can increase output by 1,500 MT over the next month at an all-in cost of $7,800/MT, including energy and transportation. The Peruvian site can add another 800 MT at $8,100/MT."

**VICTORIA**  
"Perfect arbitrage opportunity:
- **Immediate**: Cover 8,000 MT short position using current production
- **Opportunistic**: Sell additional 2,300 MT at $8,500/MT+ for premium capture
- **Hedge**: Lock in energy costs for Q4 while prices are elevated"

### **Business Impact Demonstrated:**

**Before Dashboard:**
- Individual mine reports (2+ hours across time zones)
- Conservative production estimates
- Missed spot market opportunities
- Manual energy cost calculations

**With Dashboard:**
- Global production and cost visibility (4 minutes)
- Confident spot market decisions
- Optimized mine-to-market coordination
- **Result**: Additional $1.8M profit opportunity over 1 month

---

## 🎯 **SCENE 4: Mining Industry Excellence (8:00 - 10:00)**

**VICTORIA**  
"James, this global coordination is transformative. While other traders are guessing about production costs and capacity, we're making data-driven decisions across our entire mining portfolio."

**JAMES**  
"Exactly. From the mining side, I can optimize our production scheduling based on your forward positions, manage our energy purchasing around market volatility, and ensure every ton of ore delivers maximum value."

### **Quantified Business Value:**
- **Trading Margin Improvement**: 24% increase ($67.2M annual impact)
- **Decision Speed**: 30x faster (2 hours → 4 min)
- **Production Optimization**: $3.6M additional monthly revenue
- **Energy Cost Management**: $2.8M saved annually through better hedging
- **Global Coordination**: 94% on-time delivery vs. 78% industry average

---

## 🔧 **Key Features Demonstrated:**

✅ **Global Mining Operations Monitoring**  
✅ **Energy Cost & Contract Management**  
✅ **Ore Quality & Processing Optimization**  
✅ **Multi-site Production Coordination**  
✅ **Transportation & Logistics Planning**  
✅ **Market Price Integration**  
✅ **Supply Chain Risk Management**

---

## 📈 **ROI Summary:**
- **Implementation Cost**: $1.3M
- **Annual Benefit**: $73.6M
- **Payback Period**: 6.5 days
- **3-Year NPV**: $206M

---

*This dashboard transforms metals trading from reactive to proactive, enabling integrated mine-to-market optimization that maximizes margins while managing global supply chain complexity.*
"""
    
    try:
        # Get the directory of the current script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Multiple path attempts for different deployment scenarios
        possible_paths = [
            # Local development path (original)
            os.path.join(os.path.dirname(os.path.dirname(current_dir)), "DEMO_SCRIPT.md"),
            # Container deployment paths
            os.path.join("/app", "DEMO_SCRIPT.md"),
            os.path.join("/app", "trader-dashboard-metals-mining", "DEMO_SCRIPT.md"),
            # Relative to current directory
            os.path.join(current_dir, "DEMO_SCRIPT.md"),
            os.path.join(current_dir, "..", "..", "DEMO_SCRIPT.md"),
            # Working directory
            "DEMO_SCRIPT.md",
            "./DEMO_SCRIPT.md"
        ]
        
        # Try each path
        for path in possible_paths:
            try:
                if os.path.exists(path):
                    with open(path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():  # Ensure file is not empty
                            return content
            except Exception as path_error:
                # Log individual path failures but continue trying
                logging.warning(f"Failed to load demo script from {path}: {path_error}")
                continue
        
        # If no file found, return fallback content
        logging.info("Demo script file not found in any expected location, using embedded fallback content")
        return fallback_content
        
    except Exception as e:
        # Final fallback with error info
        logging.error(f"Error in load_demo_script: {str(e)}")
        return f"""
# Demo Script Loading Error

**Error Details:** {str(e)}

**Fallback Content:**

{fallback_content}
"""

# Page configuration
st.set_page_config(layout="wide", page_title="Metals & Mining Trading Dashboard", page_icon="⛏️")

st.title("⛏️ Metals & Mining Trader Dashboard - Real-Time Production Insights")

# Prominent disclaimer
st.markdown(
    """
    <div style="background-color: #f0f2f6; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
        <strong>⚠️ DEMO SIMULATION:</strong> This dashboard displays simulated data for demonstration purposes only. 
        All production figures, mining operations, and trading recommendations are fictional and not connected to real systems.
    </div>
    """,
    unsafe_allow_html=True
)

# --- Global Definitions for Metals & Mining Data Simulation ---
regions = ["North America", "South America", "Europe", "Asia Pacific", "Africa", "Australia", "Russia/CIS"]
metal_products = ["Copper (refined)", "Aluminum (primary)", "Nickel", "Zinc", "Iron Ore", "Steel (Hot Rolled Coil)"]
equipment_types = ["Blast Furnace", "Smelter", "Crusher", "Rolling Mill", "Flotation Cell", "Electrolytic Cell", "Concentrator", "Kiln"]
facility_types = ["Smelter", "Refinery", "Mine", "Steel Mill", "Processing Plant"]
status_options = ["Optimal", "Reduced Output", "Planned Maintenance", "Forced Outage", "Shutdown"]
incident_causes = ["Equipment Failure", "Ore Quality Issue", "Power Outage", "Environmental Compliance", "Scheduled Maintenance", "Labor Strike"]
outlook_options = ["Improving", "Stable", "Declining", "Under Review", "Recovering"]

# Trader's Book of Business (regional and product specializations)
trader_books = {
    "Trader A (Base Metals)": {"Regions": ["South America", "Africa"], "Products": ["Copper (refined)", "Zinc", "Nickel"]},
    "Trader B (Steel & Iron)": {"Regions": ["Asia Pacific", "Australia"], "Products": ["Iron Ore", "Steel (Hot Rolled Coil)"]},
    "Trader C (Aluminum)": {"Regions": ["North America", "Europe"], "Products": ["Aluminum (primary)"]},
    "Trader D (Precious)": {"Regions": ["Africa", "Russia/CIS"], "Products": ["Copper (refined)", "Nickel"]},
    "Trader E (Global Metals)": {"Regions": ["Europe", "Asia Pacific", "North America"], "Products": ["Copper (refined)", "Aluminum (primary)", "Steel (Hot Rolled Coil)"]}
}

# Facility names by type and region
facility_names = {
    "Smelter": ["Atacama Copper Smelter", "Boreal Aluminum Smelter", "Siberian Nickel Works", "Andean Zinc Complex"],
    "Refinery": ["Pacific Metals Refinery", "Nordic Copper Refinery", "Australian Aluminum Refinery", "Congo Copper Refinery"],
    "Mine": ["Copper Mountain Mine", "Iron Ridge Mine", "Nickel Valley Mine", "Zinc Creek Mine", "Bauxite Hills Mine"],
    "Steel Mill": ["Great Lakes Steel", "Rhine Valley Steel", "Yangtze Steel Works", "Urals Steel Complex"],
    "Processing Plant": ["Desert Ore Processing", "Tundra Concentrator", "Savanna Processing", "Alpine Metals Plant"]
}

# Generate comprehensive trading recommendations
def generate_trading_recommendation(product, shortfall_tons, region, facility_type):
    """Generate detailed trading recommendations based on product, shortfall size, region, and facility type"""
    
    # Product-specific pricing and sourcing strategies
    product_strategies = {
        "Copper (refined)": {
            "spot_premium": 18,  # % premium over LME
            "lead_time": "2-4 weeks",
            "key_suppliers": ["Chile", "Peru", "Australia", "Zambia"],
            "seasonal_factor": "Q1 supply tightness",
            "base_price": 8500,  # USD/ton
            "volatility": "High - geopolitical sensitive"
        },
        "Aluminum (primary)": {
            "spot_premium": 12,
            "lead_time": "3-6 weeks",
            "key_suppliers": ["China", "Russia", "Canada", "Australia"],
            "seasonal_factor": "Energy costs drive Q4 pricing",
            "base_price": 2100,
            "volatility": "Medium - energy dependent"
        },
        "Nickel": {
            "spot_premium": 25,
            "lead_time": "4-8 weeks",
            "key_suppliers": ["Indonesia", "Philippines", "Russia", "Canada"],
            "seasonal_factor": "EV demand surge Q2-Q3",
            "base_price": 18000,
            "volatility": "Very High - EV market driven"
        },
        "Zinc": {
            "spot_premium": 15,
            "lead_time": "2-3 weeks",
            "key_suppliers": ["China", "Australia", "Peru", "India"],
            "seasonal_factor": "Construction demand Q2-Q3",
            "base_price": 2800,
            "volatility": "Medium - construction linked"
        },
        "Iron Ore": {
            "spot_premium": 8,
            "lead_time": "1-2 weeks",
            "key_suppliers": ["Australia", "Brazil", "India", "South Africa"],
            "seasonal_factor": "Chinese steel production cycles",
            "base_price": 120,
            "volatility": "High - China demand dependent"
        },
        "Steel (Hot Rolled Coil)": {
            "spot_premium": 10,
            "lead_time": "3-5 weeks",
            "key_suppliers": ["China", "Japan", "South Korea", "Germany"],
            "seasonal_factor": "Infrastructure spending Q2",
            "base_price": 650,
            "volatility": "Medium - trade policy sensitive"
        }
    }
    
    strategy = product_strategies.get(product, {
        "spot_premium": 15, "lead_time": "2-4 weeks", 
        "key_suppliers": ["Global"], "seasonal_factor": "Standard",
        "base_price": 5000, "volatility": "Medium"
    })
    
    # Facility type impact on urgency
    urgency_multiplier = {
        "Smelter": 1.3,  # Critical for downstream
        "Refinery": 1.2,  # High impact on finished products
        "Mine": 1.1,     # Upstream impact
        "Steel Mill": 1.4, # Major downstream impact
        "Processing Plant": 1.0
    }.get(facility_type, 1.0)
    
    adjusted_shortfall = shortfall_tons * urgency_multiplier
    
    if adjusted_shortfall > 5000:
        # Critical shortage - immediate action required
        cost_impact = shortfall_tons * strategy["base_price"] * (strategy["spot_premium"] / 100)
        return f"""🚨 **CRITICAL METALS SHORTAGE ALERT**
        
**Immediate Actions Required:**
• Emergency spot purchases: {shortfall_tons:,.0f} tons {product}
• Facility Type: {facility_type} - HIGH PRIORITY
• Contact key suppliers: {', '.join(strategy['key_suppliers'][:2])}
• Expect {strategy['spot_premium']}% LME premium (~${cost_impact:,.0f} extra cost)
• Lead time: {strategy['lead_time']} - expedite logistics
        
**Trading Strategy:**
• Split orders: 40% spot, 30% short-term contracts, 30% emergency suppliers
• Activate force majeure clauses if needed
• Consider metal financing/warehouse draws
• Alert downstream customers of potential allocation
        
**Market Intelligence:**
• Volatility: {strategy['volatility']}
• Regional focus: {region}
• Seasonal context: {strategy['seasonal_factor']}
        
**Risk Management:**
• Hedge 70% of exposure immediately
• Monitor LME inventory levels
• Prepare customer communication plan"""
        
    elif adjusted_shortfall > 2000:
        # Major shortage - structured approach needed
        cost_impact = shortfall_tons * strategy["base_price"] * (strategy["spot_premium"] / 100 * 0.7)
        return f"""🟠 **MAJOR METALS SHORTAGE - STRUCTURED RESPONSE**
        
**Primary Actions:**
• Secure {shortfall_tons:,.0f} tons {product} via preferred network
• Facility impact: {facility_type} in {region}
• Target suppliers: {', '.join(strategy['key_suppliers'])}
• Budget for {strategy['spot_premium']*0.7:.0f}% premium (~${cost_impact:,.0f})
• Timeline: {strategy['lead_time']}
        
**Procurement Strategy:**
• 60% contract suppliers, 40% spot market
• Negotiate volume discounts for bulk purchase
• Consider alternative grades/specifications
• Review quarterly contract terms
        
**Market Analysis:**
• Base price: ${strategy['base_price']}/ton
• Volatility: {strategy['volatility']}
• Supply chain: Monitor {', '.join(strategy['key_suppliers'][:3])}
        
**Financial Planning:**
• Working capital impact: ${shortfall_tons * strategy['base_price']:,.0f}
• Hedge recommendation: 50% of exposure
• Payment terms: Negotiate extended terms"""
        
    elif adjusted_shortfall > 1000:
        # Moderate shortage - managed response
        cost_impact = shortfall_tons * strategy["base_price"] * (strategy["spot_premium"] / 100 * 0.4)
        return f"""🟡 **MODERATE METALS SHORTAGE - MANAGED RESPONSE**
        
**Recommended Actions:**
• Source {shortfall_tons:,.0f} tons {product} through existing network
• Primary region: {region}
• Expected premium: {strategy['spot_premium']*0.4:.0f}% (~${cost_impact:,.0f})
• Standard timeline: {strategy['lead_time']}
        
**Sourcing Strategy:**
• 70% existing contracts, 30% spot market
• Leverage long-term supplier relationships
• Consider inventory optimization
• Review safety stock levels
        
**Market Context:**
• {strategy['seasonal_factor']}
• Facility type: {facility_type} - moderate impact
• Monitor competitor activity in {region}
        
**Operational Notes:**
• Quality specifications: Standard grade acceptable
• Logistics: Standard shipping terms
• Documentation: Ensure compliance certificates"""
        
    else:
        # Minor shortage - monitoring required
        return f"""ℹ️ **MINOR METALS SHORTAGE - MONITORING MODE**
        
**Current Status:**
• Monitor {shortfall_tons:,.0f} tons {product} exposure
• Region: {region} | Facility: {facility_type}
• No immediate action required
        
**Proactive Measures:**
• Contact 2-3 backup suppliers for quotes
• Review inventory buffers across portfolio
• Track LME prices and warehouse stocks
• Monitor regional supply disruptions
        
**Market Watch:**
• Base price: ${strategy['base_price']}/ton
• Key suppliers: {', '.join(strategy['key_suppliers'])}
• Seasonal factor: {strategy['seasonal_factor']}
        
**Timeline:** {strategy['lead_time']} if action becomes necessary
**Next Review:** 48 hours or on status change"""

# Generate facility data
def generate_facility_data():
    facilities = []
    for i in range(25):  # 25 facilities
        facility_type = random.choice(facility_types)
        facility_name = random.choice(facility_names[facility_type])
        region = random.choice(regions)
        primary_product = random.choice(metal_products)
        
        # Production capacity varies by product type
        if "Iron Ore" in primary_product:
            base_capacity = random.randint(50000, 200000)  # Iron ore in higher volumes
        elif "Steel" in primary_product:
            base_capacity = random.randint(20000, 80000)
        else:
            base_capacity = random.randint(5000, 25000)  # Refined metals
        
        current_production = base_capacity * random.uniform(0.65, 1.05)
        
        # Equipment status
        equipment = random.choice(equipment_types)
        status = random.choice(status_options)
        
        # Calculate production impact
        if status == "Optimal":
            impact_pct = random.uniform(-3, 8)
            impact_tons = current_production * (impact_pct / 100)
        elif status == "Reduced Output":
            impact_pct = random.uniform(-30, -15)
            impact_tons = current_production * (impact_pct / 100)
        elif status == "Planned Maintenance":
            impact_pct = random.uniform(-50, -25)
            impact_tons = current_production * (impact_pct / 100)
        elif status == "Forced Outage":
            impact_pct = random.uniform(-85, -60)
            impact_tons = current_production * (impact_pct / 100)
        else:  # Shutdown
            impact_pct = -100
            impact_tons = -current_production
        
        facilities.append({
            "Facility": f"{facility_name} ({facility_type})",
            "Region": region,
            "Type": facility_type,
            "Primary Product": primary_product,
            "Equipment": equipment,
            "Status": status,
            "Base Capacity (t/day)": base_capacity,
            "Current Production (t/day)": max(0, current_production + impact_tons),
            "Impact (t/day)": impact_tons,
            "Impact (%)": impact_pct,
            "Duration (hours)": random.randint(6, 240) if status != "Optimal" else 0,
            "Incident Cause": random.choice(incident_causes) if status != "Optimal" else "Normal Operations",
            "Outlook": random.choice(outlook_options),
            "Last Updated": datetime.now() - timedelta(minutes=random.randint(1, 45))
        })
    
    return pd.DataFrame(facilities)

# Generate production alerts
def generate_production_alerts(df):
    alerts = []
    critical_facilities = df[df['Status'].isin(['Forced Outage', 'Shutdown'])]
    
    for _, facility in critical_facilities.iterrows():
        severity = "🔴 Critical" if facility['Status'] == 'Shutdown' else "🟠 High"
        
        # Calculate shortfall
        shortfall_tons = abs(facility['Impact (t/day)']) * (facility['Duration (hours)'] / 24)
        
        alerts.append({
            "Severity": severity,
            "Facility": facility['Facility'],
            "Issue": f"{facility['Equipment']} - {facility['Status']}",
            "Product": facility['Primary Product'],
            "Shortfall": f"{shortfall_tons:.0f} tons",
            "Duration": f"{facility['Duration (hours)']} hours",
            "Recommendation": generate_trading_recommendation(
                facility['Primary Product'], 
                shortfall_tons, 
                facility['Region'],
                facility['Type']
            )
        })
    
    return pd.DataFrame(alerts)

# Generate historical production data
def generate_production_trends(selected_facilities, days=30):
    trends = []
    base_date = datetime.now() - timedelta(days=days)
    
    for facility in selected_facilities:
        base_production = facility['Base Capacity (t/day)']
        
        for day in range(days + 1):
            date = base_date + timedelta(days=day)
            
            # Add some variability
            daily_variation = random.uniform(0.80, 1.10)
            production = base_production * daily_variation
            
            # Add occasional disruptions
            if random.random() < 0.08:  # 8% chance of disruption
                production *= random.uniform(0.2, 0.6)
            
            trends.append({
                "Date": date,
                "Facility": facility['Facility'],
                "Product": facility['Primary Product'],
                "Production (t/day)": production,
                "Region": facility['Region'],
                "Type": facility['Type']
            })
    
    return pd.DataFrame(trends)

# Generate forecast data
def generate_forecast_data(selected_facilities, days=30):
    forecasts = []
    base_date = datetime.now() + timedelta(days=1)
    
    for facility in selected_facilities:
        base_production = facility['Current Production (t/day)']
        
        for day in range(days):
            date = base_date + timedelta(days=day)
            
            # Forecast with trend and seasonality
            trend_factor = 1 + (day * 0.0015)  # Slight upward trend
            seasonal_factor = 1 + 0.1 * np.sin(2 * np.pi * day / 30)  # Monthly cycle
            forecast = base_production * trend_factor * seasonal_factor * random.uniform(0.92, 1.08)
            
            forecasts.append({
                "Date": date,
                "Facility": facility['Facility'],
                "Product": facility['Primary Product'],
                "Forecast (t/day)": forecast,
                "Region": facility['Region'],
                "Type": facility['Type']
            })
    
    return pd.DataFrame(forecasts)

# Initialize data
if 'facility_data' not in st.session_state:
    st.session_state.facility_data = generate_facility_data()

facility_data = st.session_state.facility_data

# Sidebar filters
st.sidebar.header("Navigation")

# Add tabs for main dashboard and demo script
page = st.sidebar.radio("Select Page:", ["Dashboard", "Demo Script"])

if page == "Demo Script":
    st.title("⛏️ Metals & Mining Trading Dashboard - Demo Script")
    st.markdown("---")
    
    demo_content = load_demo_script()
    st.markdown(demo_content)
    
    st.markdown("---")
    st.caption("Return to the Dashboard using the sidebar navigation.")
    st.stop()  # Stop execution here for demo script page

st.sidebar.header("⚙️ Dashboard Filters")

# View selection
view_option = st.sidebar.selectbox(
    "Select View:",
    ["Enterprise-Wide", "Region-Wide", "My Book of Business"]
)

if view_option == "Region-Wide":
    selected_regions = st.sidebar.multiselect(
        "Select Regions:",
        regions,
        default=regions[:3]
    )
    filtered_data = facility_data[facility_data['Region'].isin(selected_regions)]
elif view_option == "My Book of Business":
    selected_trader = st.sidebar.selectbox(
        "Select Trader:",
        list(trader_books.keys())
    )
    trader_regions = trader_books[selected_trader]["Regions"]
    trader_products = trader_books[selected_trader]["Products"]
    filtered_data = facility_data[
        (facility_data['Region'].isin(trader_regions)) & 
        (facility_data['Primary Product'].isin(trader_products))
    ]
else:  # Enterprise-Wide
    filtered_data = facility_data

# Product filter
selected_products = st.sidebar.multiselect(
    "Filter by Products:",
    metal_products,
    default=metal_products
)
filtered_data = filtered_data[filtered_data['Primary Product'].isin(selected_products)]

# Facility type filter
selected_types = st.sidebar.multiselect(
    "Filter by Facility Type:",
    facility_types,
    default=facility_types
)
filtered_data = filtered_data[filtered_data['Type'].isin(selected_types)]

# Status filter
selected_statuses = st.sidebar.multiselect(
    "Filter by Status:",
    status_options,
    default=status_options
)
filtered_data = filtered_data[filtered_data['Status'].isin(selected_statuses)]

# Main dashboard layout
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("🚨 Production Alerts & Trading Impact Analysis")
    
    # Generate and display alerts
    alerts_df = generate_production_alerts(filtered_data)
    
    if not alerts_df.empty:
        for _, alert in alerts_df.iterrows():
            with st.expander(f"{alert['Severity']} - {alert['Facility']}", expanded=True):
                col_a, col_b = st.columns([1, 2])
                with col_a:
                    st.metric("Product Impact", alert['Product'])
                    st.metric("Shortfall", alert['Shortfall'])
                    st.metric("Duration", alert['Duration'])
                    st.write(f"**Issue:** {alert['Issue']}")
                with col_b:
                    st.write("**📋 Trading Recommendation:**")
                    st.markdown(alert['Recommendation'])
    else:
        st.info("✅ No critical production alerts at this time")

with col2:
    st.subheader("📊 Portfolio Summary")
    
    # Key metrics
    total_facilities = len(filtered_data)
    total_capacity = filtered_data['Base Capacity (t/day)'].sum()
    current_production = filtered_data['Current Production (t/day)'].sum()
    utilization = (current_production / total_capacity) * 100 if total_capacity > 0 else 0
    
    st.metric("Active Facilities", total_facilities)
    st.metric("Total Capacity", f"{total_capacity:,.0f} t/day")
    st.metric("Current Production", f"{current_production:,.0f} t/day")
    st.metric("Utilization Rate", f"{utilization:.1f}%")
    
    # Status distribution
    status_counts = filtered_data['Status'].value_counts()
    fig_status = px.pie(
        values=status_counts.values,
        names=status_counts.index,
        title="Facility Status Distribution",
        color_discrete_map={
            'Optimal': '#00CC44',
            'Reduced Output': '#FFB000',
            'Planned Maintenance': '#0066CC',
            'Forced Outage': '#FF6600',
            'Shutdown': '#CC0000'
        }
    )
    fig_status.update_traces(textposition='inside', textinfo='percent+label')
    fig_status.update_layout(height=300)
    st.plotly_chart(fig_status, use_container_width=True)

# Top 5 Equipment Impact
st.subheader("⚙️ Top 5 Equipment Impact Analysis")

# Get top 5 facilities by absolute impact
top_impact = filtered_data.loc[filtered_data['Impact (t/day)'].abs().nlargest(5).index]

if not top_impact.empty:
    cols = st.columns(5)
    for i, (_, facility) in enumerate(top_impact.iterrows()):
        with cols[i]:
            # Color coding based on status
            if facility['Status'] == 'Shutdown':
                color = "🔴"
            elif facility['Status'] == 'Forced Outage':
                color = "🟠"
            elif facility['Status'] == 'Planned Maintenance':
                color = "🟡"
            elif facility['Status'] == 'Reduced Output':
                color = "🟨"
            else:
                color = "🟢"
            
            st.markdown(f"**{color} {facility['Facility'].split('(')[0].strip()}**")
            st.write(f"**Type:** {facility['Type']}")
            st.write(f"**Equipment:** {facility['Equipment']}")
            st.write(f"**Status:** {facility['Status']}")
            st.metric("Impact", f"{facility['Impact (t/day)']:+.0f} t/day")
            st.write(f"**Duration:** {facility['Duration (hours)']} hrs")
            st.write(f"**Product:** {facility['Primary Product']}")

# Production Analytics
st.subheader("📈 Production Analytics & Forecasting")

# Facility selection for detailed analysis
selected_facility_names = st.multiselect(
    "Select Facilities for Detailed Analysis:",
    filtered_data['Facility'].tolist(),
    default=filtered_data['Facility'].tolist()[:3]
)

if selected_facility_names:
    selected_facilities_data = filtered_data[filtered_data['Facility'].isin(selected_facility_names)]
    
    # Generate trend data
    trend_data = generate_production_trends(selected_facilities_data.to_dict('records'))
    forecast_data = generate_forecast_data(selected_facilities_data.to_dict('records'))
    
    # Production trends chart
    fig_trend = go.Figure()
    
    colors = px.colors.qualitative.Set1
    for i, facility in enumerate(selected_facility_names):
        facility_trend = trend_data[trend_data['Facility'] == facility]
        facility_forecast = forecast_data[forecast_data['Facility'] == facility]
        color = colors[i % len(colors)]
        
        # Historical data
        fig_trend.add_trace(go.Scatter(
            x=facility_trend['Date'],
            y=facility_trend['Production (t/day)'],
            mode='lines',
            name=f"{facility.split('(')[0].strip()} (Historical)",
            line=dict(width=2, color=color)
        ))
        
        # Forecast data
        fig_trend.add_trace(go.Scatter(
            x=facility_forecast['Date'],
            y=facility_forecast['Forecast (t/day)'],
            mode='lines',
            name=f"{facility.split('(')[0].strip()} (Forecast)",
            line=dict(dash='dash', width=2, color=color)
        ))
    
    # Add vertical line for today
    try:
        fig_trend.add_vline(
            x=datetime.now(),
            line_dash="dot",
            line_color="red",
            annotation_text="Today"
        )
    except Exception:
        # Fallback for datetime handling
        import pandas as pd
        today_ts = pd.Timestamp.now()
        fig_trend.add_annotation(
            x=today_ts,
            y=trend_data['Production (t/day)'].max(),
            text="Today",
            showarrow=True,
            arrowhead=2,
            arrowcolor="red"
        )
    
    fig_trend.update_layout(
        title="Production Trends & 30-Day Forecast by Facility",
        xaxis_title="Date",
        yaxis_title="Production (tons/day)",
        height=500,
        hovermode='x unified',
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    
    st.plotly_chart(fig_trend, use_container_width=True)
    
    # Summary analytics
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📅 Month-to-Date Performance")
        mtd_data = []
        for facility in selected_facilities_data.to_dict('records'):
            facility_trend = trend_data[trend_data['Facility'] == facility['Facility']]
            current_month = datetime.now().replace(day=1)
            mtd_trend = facility_trend[facility_trend['Date'] >= current_month]
            
            if not mtd_trend.empty:
                mtd_avg = mtd_trend['Production (t/day)'].mean()
                mtd_total = mtd_trend['Production (t/day)'].sum()
                capacity_util = (mtd_avg / facility['Base Capacity (t/day)']) * 100
                
                mtd_data.append({
                    "Facility": facility['Facility'].split('(')[0].strip(),
                    "MTD Avg (t/day)": f"{mtd_avg:,.0f}",
                    "MTD Total (tons)": f"{mtd_total:,.0f}",
                    "Capacity Util %": f"{capacity_util:.1f}%",
                    "Status": facility['Status']
                })
        
        if mtd_data:
            mtd_df = pd.DataFrame(mtd_data)
            st.dataframe(mtd_df, use_container_width=True)
    
    with col2:
        st.subheader("📊 30-Day Rolling Metrics")
        rolling_data = []
        for facility in selected_facilities_data.to_dict('records'):
            facility_trend = trend_data[trend_data['Facility'] == facility['Facility']]
            if not facility_trend.empty:
                rolling_avg = facility_trend['Production (t/day)'].tail(30).mean()
                rolling_std = facility_trend['Production (t/day)'].tail(30).std()
                
                rolling_data.append({
                    "Facility": facility['Facility'].split('(')[0].strip(),
                    "30-Day Avg": f"{rolling_avg:,.0f} t/day",
                    "Volatility": f"{rolling_std:,.0f} t/day",
                    "vs Capacity": f"{(rolling_avg / facility['Base Capacity (t/day)']) * 100:.1f}%",
                    "Product": facility['Primary Product']
                })
        
        if rolling_data:
            rolling_df = pd.DataFrame(rolling_data)
            st.dataframe(rolling_df, use_container_width=True)

# Operations Intelligence
st.subheader("🧠 Operations Intelligence & Communication")

col1, col2 = st.columns(2)

with col1:
    st.subheader("📝 Incident Log & Supervisor Notes")
    
    # Generate sample incident logs
    incident_logs = []
    for _, facility in filtered_data[filtered_data['Status'] != 'Optimal'].iterrows():
        incident_logs.append({
            "Timestamp": facility['Last Updated'].strftime("%Y-%m-%d %H:%M"),
            "Facility": facility['Facility'],
            "Incident": f"{facility['Equipment']} - {facility['Incident Cause']}",
            "Impact": f"{facility['Impact (t/day)']:+.0f} t/day",
            "Status": facility['Status'],
            "Notes": f"Site supervisor reported {facility['Incident Cause'].lower()}. Estimated restoration: {facility['Duration (hours)']} hours. Production outlook: {facility['Outlook']}. Coordinating with maintenance team."
        })
    
    if incident_logs:
        for log in incident_logs[:6]:  # Show top 6
            with st.expander(f"{log['Timestamp']} - {log['Facility'].split('(')[0].strip()}", expanded=False):
                st.write(f"**Incident:** {log['Incident']}")
                st.write(f"**Production Impact:** {log['Impact']}")
                st.write(f"**Current Status:** {log['Status']}")
                st.write(f"**Supervisor Notes:** {log['Notes']}")
    else:
        st.info("No recent incidents to display")

with col2:
    st.subheader("📋 Operations Inquiry System")
    
    with st.form("operations_inquiry"):
        inquiry_facility = st.selectbox("Select Facility:", filtered_data['Facility'].tolist())
        inquiry_type = st.selectbox(
            "Inquiry Type:",
            ["Production Status", "Equipment Maintenance", "Quality Control", "Safety Incident", "Supply Chain", "Environmental", "Other"]
        )
        priority = st.selectbox("Priority Level:", ["Low", "Medium", "High", "Critical"])
        inquiry_details = st.text_area("Inquiry Details:", height=120, 
                                     placeholder="Describe the issue, request, or information needed...")
        
        submitted = st.form_submit_button("Submit Inquiry")
        
        if submitted:
            st.success(f"✅ Inquiry submitted for {inquiry_facility.split('(')[0].strip()}")
            st.info(f"**Priority: {priority}** - Operations team will respond within {'1 hour' if priority in ['Critical', 'High'] else '4 hours' if priority == 'Medium' else '24 hours'}")

# Detailed Facility Performance Table
st.subheader("🏭 Detailed Facility Performance Overview")

# Style the dataframe
def style_status(val):
    if val == 'Shutdown':
        return 'background-color: #ffcccc'
    elif val == 'Forced Outage':
        return 'background-color: #ffe6cc'
    elif val == 'Planned Maintenance':
        return 'background-color: #cce6ff'
    elif val == 'Reduced Output':
        return 'background-color: #fff2cc'
    else:
        return 'background-color: #ccffcc'

# Display table with formatting
display_df = filtered_data[[
    'Facility', 'Region', 'Type', 'Primary Product', 'Equipment', 'Status',
    'Base Capacity (t/day)', 'Current Production (t/day)', 'Impact (t/day)',
    'Impact (%)', 'Duration (hours)', 'Outlook'
]].copy()

# Format numerical columns
display_df['Base Capacity (t/day)'] = display_df['Base Capacity (t/day)'].round(0).astype(int)
display_df['Current Production (t/day)'] = display_df['Current Production (t/day)'].round(0).astype(int)
display_df['Impact (t/day)'] = display_df['Impact (t/day)'].round(0).astype(int)
display_df['Impact (%)'] = display_df['Impact (%)'].round(1)

# Shorten facility names for display
display_df['Facility'] = display_df['Facility'].apply(lambda x: x.split('(')[0].strip())

# Apply styling
try:
    styled_df = display_df.style.map(style_status, subset=['Status'])
    st.dataframe(styled_df, use_container_width=True)
except:
    # Fallback if styling fails
    st.dataframe(display_df, use_container_width=True)

# Footer
st.markdown("---")
st.markdown(
    """
    <div style="text-align: center; color: #666; font-size: 12px;">
        ⛏️ Metals & Mining Trader Dashboard | Powered by Cognite Industrial Canvas<br>
        <strong>Disclaimer:</strong> This is a demonstration with simulated data. All facility operations, production figures, and trading recommendations are fictional.
    </div>
    """,
    unsafe_allow_html=True
) 