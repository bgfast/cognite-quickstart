import sys


def handle(client, data):
    model_id = data["model_id"]
    revision_id = data["revision_id"]
    project = client.config.project
    asset_space = data["asset_space"]
    three_d_space = data["three_d_space"]

    if (
        not model_id
        or not revision_id
        or not project
        or not asset_space
        or not three_d_space
    ):
        print(
            "Please specify model_id, revision_id, project, asset_space and three_d_space"
        )
        print(
            'Example: data={"model_id":2184189928228059,"revision_id":7861918894738722,"project":"uat-qs-aws-dev","asset_space":"valhall-assets","three_d_space":"valhall-three_d"}'
        )
        sys.exit(1)

    mapping_names_assets = {
        "/23-XX-9114_IS-MCT": "WMT:23-XX-9114",
        "/23-GK-9107B-A01/CS": "WMT:23-GK-9107B-A01",
        "/23-XX-9106/TP16": "WMT:23-XX-9106",
        "/23-XX-9114/TP6": "WMT:23-XX-9114",
        "/23-VA-9110-A01/SUPP": "WMT:23-VA-9110-A01",
        "/60-EN-9010A/2xVFD-15kW": "WMT:60-EN-9010A+28A2",
        "/23-PC-9109-A01/SUPP": "WMT:23-PC-9109-A01",
        "/23-PC-9109-A01": "WMT:23-PC-9109-A01",
        "/23-HA-9103": "WMT:23-HA-9103",
        "/23-XX-9114/TP18": "WMT:23-XX-9114",
        "/23-VG-9101/N4": "WMT:23-VG-9101",
        "/23-KA-9101A-A01/SUPP": "WMT:23-KA-9101-A01",
        "/23-XX-9114_PLATF_STEEL": "WMT:23-XX-9114",
        "/23-VA-9110-A01/CS": "WMT:23-VA-9110-A01",
        "/PH-S-2217": "WMT:PH-S-2217",
        "/48-XI-96964B": "WMT:48-XI-96964B",
        "/23-GK-9108B-A01/SUPP": "WMT:23-GK-9107B-A01",
        "/23-XX-9106/TP15": "WMT:23-XX-9106",
        "/23-VG-9101": "WMT:23-VG-9101",
        "/P/UK-23-XX-9106/EQP": "WMT:23-XX-9106",
        "/P/UK-23-XX-9106/TSTL": "WMT:23-XX-9106",
        "/48-XI-96964A": "WMT:48-XI-96964A",
        "/23-XX-9114/TP16": "WMT:23-XX-9114",
        "/23-XX-9106/TP17": "WMT:23-XX-9106",
        "/APL/23-XX-9114/5.": "WMT:23-XX-9114",
        "/23-PC-9109-A01/CS": "WMT:23-PC-9109-A01",
        "/23-XX-9114": "WMT:23-XX-9114",
        "PRO-P_UK-23-XX-9106.nwd": "WMT:23-XX-9106",
        "/23-XX-9114/TP7": "WMT:23-XX-9114",
        "/60-EN-9010A/MCC-2": "WMT:60-EN-9010A+28A2",
        "/23-XX-9114/NOZZLES": "WMT:23-XX-9114",
        "/PH-S-1305": "WMT:PH-S-1305",
        "/23-VG-9101/N5": "WMT:23-VG-9101",
        "/23-GK-9107B-A01/SUPP": "WMT:23-GK-9107B-A01",
        "/23-KA-9101/EQP/ENCL": "WMT:23-KA-9101",
        "/23-FE-9122/SUBS": "WMT:23-FE-9122",
        "/23-XX-9114/TP5": "WMT:23-XX-9114",
        "/23-KA-9101A-A01/CS": "WMT:23-KA-9101-A01",
        "/23-NY-96144-J01": "WMT:23-NY-96144-J01",
        "/48-XI-96964B-old": "WMT:48-XI-96964B",
        "/23-NY-96144/SUPP": "WMT:23-NY-96144",
        "/23-KA-9101/TP4": "WMT:23-KA-9101",
        "/23-FE-9106/SUBS": "WMT:23-FE-9106",
        "/23-KA-9101A-A01": "WMT:23-KA-9101-A01",
        "/23-XX-9106/TP5": "WMT:23-XX-9106",
        "/23-XX-9114/TP9": "WMT:23-XX-9114",
        "/APL/23-XX-9106/8": "WMT:23-XX-9106",
        "/23-VA-9110-A01": "WMT:23-VA-9110-A01",
        "/P/UK-23-XX-9114/TSTL": "WMT:23-XX-9114",
        "/23-XX-9106/TP7": "WMT:23-XX-9106",
        "/48-XI-96964A/F": "WMT:48-XI-96964A",
        "/48-XI-96964B/F": "WMT:48-XI-96964B",
        "/23-KA-9101-DRAIN/NOZZLES": "WMT:23-KA-9101",
        "/48-XI-96964B-old/F": "WMT:48-XI-96964B",
        "/APL/23-XX-9106/4": "WMT:23-XX-9106",
        "PRO-P_UK-23-XX-9114.nwd": "WMT:23-XX-9114",
        "/23-XX-9106/TP6": "WMT:23-XX-9106",
        "/23-XX-9106_IS-MCT": "WMT:23-XX-9106",
        "/48-XI-96964B/SUPP": "WMT:48-XI-96964B",
        "/23-FE-9122": "WMT:23-FE-9122",
        "/48-SU-9113": "WMT:48-SU-9113",
        "/APL/23-XX-9106/5": "WMT:23-XX-9106",
        "/23-GK-9107B-A01": "WMT:23-GK-9107B-A01",
        "/23-XX-9106_IS-MCT/MCT": "WMT:23-XX-9106",
        "/UK-23-KA-9101-SKID-FRAME": "WMT:23-KA-9101",
        "/23-XX-9106/TP8": "WMT:23-XX-9106",
        "/23-GK-9108B-A01": "WMT:23-GK-9107B-A01",
        "/P/UK-23-XX-9106": "WMT:23-XX-9106",
        "/PH-S-1400": "WMT:PH-S-1400",
        "/23-GK-9107A-A01": "WMT:23-GK-9107A-A01",
        "/23-GK-9107A-A01/CS": "WMT:23-GK-9107A-A01",
        "/23-XX-9106/TP9": "WMT:23-XX-9106",
        "/23-XX-9106/NOZZLES": "WMT:23-XX-9106",
        "/23-XX-9106": "WMT:23-XX-9106",
        "/23-KA-9101": "WMT:23-KA-9101",
        "/UK-23-KA-9101": "WMT:23-KA-9101",
        "/23-NY-96144": "WMT:23-NY-96144",
        "/23-XX-9114/TP8": "WMT:23-XX-9114",
        "/23-XX-9106/TP18": "WMT:23-XX-9106",
        "/APL/23-XX-9114/5": "WMT:23-XX-9114",
        "/23-XX-9114/TP17": "WMT:23-XX-9114",
        "/APL/23-XX-9106/6": "WMT:23-XX-9106",
        "/23-XX-9114/TP15": "WMT:23-XX-9114",
        "/UK-23-KA-9101-SKID": "WMT:23-KA-9101",
        "/23-GK-9107A-A01/SUPP": "WMT:23-GK-9107A-A01",
        "/P/UK-23-XX-9114/EQP": "WMT:23-XX-9114",
        "/APL/23-XX-9106/7": "WMT:23-XX-9106",
        "/23-FE-9106": "WMT:23-FE-9106",
        "/PH-S-2301": "WMT:PH-S-2301",
        "/23-GK-9108B-A01/CS": "WMT:23-GK-9107B-A01",
        "/23-XX-9114_IS-MCT/MCT": "WMT:23-XX-9114",
        "/P/UK-23-XX-9114": "WMT:23-XX-9114",
    }

    node_names = list(mapping_names_assets.keys())

    print("Retrieving 3D nodes")
    nodes = client.three_d.revisions.filter_nodes(
        model_id=model_id, properties={"Item": {"Name": node_names}}, revision_id=revision_id, limit=None
        )

    print("Creating mapping name <-> assets")
    mapping_node_name = {}
    for key in mapping_names_assets:
        for r in nodes:
            if r.name == key:
                mapping_node_name[str(r.id)] = mapping_names_assets[key]

    print("Creating asset mapping")
    my_asset_mapping = []
    for key, value in mapping_node_name.items():
        my_asset_mapping.append(
            {
                "nodeId": int(key),
                "assetInstanceId": {"space": asset_space, "externalId": value},
            }
        )

    print("Creating asset mapping in CDF")

    url = f"/api/v1/projects/{project}/3d/models/{model_id}/revisions/{revision_id}/mappings"
    print(url)
 
    def chunk_list(lst, chunk_size):
        """Split a list into chunks of specified size"""
        for i in range(0, len(lst), chunk_size):
            yield lst[i:i + chunk_size]

    # Set maximum chunk size to 100 as per endpoint requirement
    MAX_CHUNK_SIZE = 100

    # Process my_asset_mapping in chunks
    for chunk in chunk_list(my_asset_mapping, MAX_CHUNK_SIZE):
        print("Chunk size: ", len(chunk))
        client.post(
            url,
            json={
                "items": chunk,
                "dmsContextualizationConfig": {
                    "object3DSpace": three_d_space,
                    "cadNodeSpace": three_d_space,
                },
            },
        )

    print("Done")
