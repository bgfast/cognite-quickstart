#!/usr/bin/env python3
"""
Foundation Module Verification

This module verifies that the Foundation module has been successfully deployed
by checking for authentication groups, RAW tables, and data relationships in CDF.
"""

import os
import sys
from typing import Dict, Any, List, Optional
from cognite.client import CogniteClient, ClientConfig
from cognite.client.credentials import OAuthClientCredentials


def get_cognite_client() -> CogniteClient:
    """Create and return a configured CogniteClient using environment variables."""
    # Check for required environment variables
    required_vars = ['CDF_PROJECT', 'CDF_CLUSTER', 'IDP_CLIENT_ID', 'IDP_CLIENT_SECRET', 'IDP_TENANT_ID']
    missing_vars = [var for var in required_vars if not os.getenv(var)]
    
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
    
    # Create OAuth credentials
    credentials = OAuthClientCredentials(
        token_url=os.getenv('IDP_TOKEN_URL', f"https://login.microsoftonline.com/{os.getenv('IDP_TENANT_ID')}/oauth2/v2.0/token"),
        client_id=os.getenv('IDP_CLIENT_ID', ''),
        client_secret=os.getenv('IDP_CLIENT_SECRET', ''),
        scopes=os.getenv('IDP_SCOPES', f"https://{os.getenv('CDF_CLUSTER')}.cognitedata.com/.default").split(),
    )
    
    # Create client config
    config = ClientConfig(
        client_name="foundation-verification",
        project=os.getenv('CDF_PROJECT', ''),
        credentials=credentials,
        base_url=os.getenv('CDF_URL', f"https://{os.getenv('CDF_CLUSTER')}.cognitedata.com"),
    )
    
    return CogniteClient(config)


def get_raw_tables() -> List[Dict[str, Any]]:
    """Get all RAW tables from CDF."""
    try:
        client = get_cognite_client()
        # First get all databases, then get tables from each
        databases = client.raw.databases.list()
        table_list = []
        
        for db in databases:
            tables = client.raw.tables.list(db_name=db.name)
            for table in tables:
                table_list.append({
                    "name": table.name,
                    "external_id": getattr(table, 'external_id', None),
                    "id": getattr(table, 'id', None),
                    "db_name": db.name,
                    "table": table
                })
        
        return table_list
    except Exception as e:
        print(f"Error fetching RAW tables: {e}")
        return []


def find_foundation_tables() -> List[Dict[str, Any]]:
    """Find the Foundation module RAW tables."""
    tables = get_raw_tables()
    
    if not tables:
        return []
    
    # Look for specific table names from the Foundation module
    foundation_tables = []
    expected_tables = [
        "assets", "workorders", "workitems", "equipment", 
        "files_metadata", "timeseries2assets", "workitem2assets",
        "workorder2assets", "workorder2items", "asset2children"
    ]
    
    for table in tables:
        table_name = table["name"].lower()
        for expected in expected_tables:
            if expected in table_name:
                foundation_tables.append(table)
                break
    
    return foundation_tables


def verify_module() -> Dict[str, Any]:
    """Main verification function."""
    results = {
        'module_name': 'foundation',
        'success': False,
        'checks': [],
        'summary': ''
    }
    
    try:
        # Test CDF connection
        client = get_cognite_client()
        user_info = client.iam.user_profiles.me()
        
        results['checks'].append({
            'name': 'CDF Connection',
            'success': True,
            'message': f"Connected to CDF as {user_info.email}"
        })
        
        # Skip authentication group checks for now
        
        # Check for RAW tables
        tables = find_foundation_tables()
        table_count = len(tables)
        
        if table_count > 0:
            results['checks'].append({
                'name': 'RAW Tables',
                'success': True,
                'message': f"Found {table_count} Foundation RAW data tables"
            })
        else:
            results['checks'].append({
                'name': 'RAW Tables',
                'success': False,
                'message': "No Foundation RAW data tables found"
            })
        
        # Check for data relationships
        relationship_tables = [t for t in tables if any(rel in t["name"].lower() for rel in ["2assets", "2items", "2children"])]
        relationship_count = len(relationship_tables)
        
        if relationship_count > 0:
            results['checks'].append({
                'name': 'Data Relationships',
                'success': True,
                'message': f"Found {relationship_count} relationship tables"
            })
        else:
            results['checks'].append({
                'name': 'Data Relationships',
                'success': False,
                'message': "No relationship tables found"
            })
        
        # Core success depends on finding tables
        results['success'] = table_count > 0
        results['summary'] = f"Foundation verification {'PASSED' if results['success'] else 'FAILED'}"
        
    except Exception as e:
        results['checks'].append({
            'name': 'Connection',
            'success': False,
            'message': f"Error: {e}"
        })
        results['summary'] = "Foundation verification FAILED"
    
    return results


if __name__ == "__main__":
    result = verify_module()
    print(f"🔍 {result['module_name'].upper()} VERIFICATION")
    print("=" * 50)
    
    for check in result['checks']:
        status = "✅" if check['success'] else "❌"
        print(f"{status} {check['name']}: {check['message']}")
    
    print(f"\n📋 {result['summary']}")
    sys.exit(0 if result['success'] else 1)
