#!/usr/bin/env python3
"""
3D Contextualization Module Verification

This module verifies that the 3D Contextualization module has been successfully deployed
by checking for basic connectivity to CDF.
"""

import os
import sys
from typing import Dict, Any, List, Optional
from cognite.client import CogniteClient, ClientConfig
from cognite.client.credentials import OAuthClientCredentials

def get_cognite_client() -> CogniteClient:
    """Create and return a configured CogniteClient using environment variables."""
    # Get environment variables
    cdf_project = os.getenv("CDF_PROJECT")
    cdf_cluster = os.getenv("CDF_CLUSTER")
    cdf_url = os.getenv("CDF_URL")
    idp_client_id = os.getenv("IDP_CLIENT_ID")
    idp_client_secret = os.getenv("IDP_CLIENT_SECRET")
    idp_scopes = os.getenv("IDP_SCOPES")
    idp_tenant_id = os.getenv("IDP_TENANT_ID")
    idp_token_url = os.getenv("IDP_TOKEN_URL")

    if not all([cdf_project, cdf_cluster, cdf_url, idp_client_id, idp_client_secret, idp_scopes, idp_tenant_id, idp_token_url]):
        raise ValueError("Missing required environment variables for CDF authentication")

    # Create OAuth credentials
    credentials = OAuthClientCredentials(
        token_url=idp_token_url,
        client_id=idp_client_id,
        client_secret=idp_client_secret,
        scopes=idp_scopes.split(",") if idp_scopes else [f"{cdf_url}/.default"]
    )

    # Create client config
    config = ClientConfig(
        client_name="three-d-contextualization-verification",
        project=cdf_project,
        base_url=cdf_url,
        credentials=credentials
    )

    return CogniteClient(config)

def verify_module() -> Dict[str, Any]:
    """Main verification function for the 3D Contextualization module."""
    results = {
        'module_name': 'three_d_contextualization',
        'success': False,
        'checks': [],
        'summary': ''
    }

    try:
        client = get_cognite_client()
        user_info = client.iam.user_profiles.me()

        results['checks'].append({
            'name': 'CDF Connection',
            'success': True,
            'message': f"Connected to CDF as {user_info.email}"
        })

        # Check for 3D contextualization functions
        functions = client.functions.list()
        three_d_functions = [f for f in functions if '3d' in f.name.lower() or 'contextualization' in f.name.lower() or 'annotations' in f.name.lower()]
        function_count = len(three_d_functions)
        
        results['checks'].append({
            'name': '3D Contextualization Functions',
            'success': function_count > 0,
            'message': f"Found {function_count} 3D contextualization functions" if function_count > 0 else "No 3D contextualization functions found"
        })
        
        # Check for 3D contextualization workflows
        workflows = client.workflows.list()
        three_d_workflows = [w for w in workflows if '3d' in getattr(w, 'name', str(w)).lower() or 'contextualization' in getattr(w, 'name', str(w)).lower()]
        workflow_count = len(three_d_workflows)
        
        results['checks'].append({
            'name': '3D Contextualization Workflows',
            'success': workflow_count > 0,
            'message': f"Found {workflow_count} 3D contextualization workflows" if workflow_count > 0 else "No 3D contextualization workflows found"
        })
        
        # Overall module success
        results['checks'].append({
            'name': '3D Contextualization Module',
            'success': function_count > 0 and workflow_count > 0,
            'message': "3D Contextualization module deployed successfully" if function_count > 0 and workflow_count > 0 else "3D Contextualization module deployment incomplete"
        })

        results['success'] = True
        results['summary'] = f"3D Contextualization verification {'PASSED' if results['success'] else 'FAILED'}"

    except Exception as e:
        results['checks'].append({
            'name': 'Connection',
            'success': False,
            'message': f"Error: {e}"
        })
        results['summary'] = "3D Contextualization verification FAILED"

    return results

if __name__ == "__main__":
    result = verify_module()
    print(f"🔍 {result['module_name'].upper()} VERIFICATION")
    print("=" * 50)

    for check in result['checks']:
        status = "✅" if check['success'] else "❌"
        print(f"{status} {check['name']}: {check['message']}")

    print(f"\n📋 {result['summary']}")
    sys.exit(0 if result['success'] else 1)
