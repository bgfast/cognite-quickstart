"""
Central configuration for Docs2Data Streamlit Application
This file contains all configurable values that were previously hardcoded as 'd2d'
"""

# Dataset Configuration
DEFAULT_DATASET_PREFIX = "d2d"  # Prefix for dataset filtering
DEFAULT_DATASET_ID = "d2d"      # Default dataset external ID

# Space Configuration
DOCUMENT_SPACE = "d2d2"                    # Space for document data
PROMPTS_SPACE = "d2d-prompts"              # Space for LLM prompts
FORMS_SPACE = "d2d-formu1"                 # Space for form data

# View Configuration
DOCUMENT_VIEW = "D2DDoc"                   # Main document view
CONTENT_SEGMENT_PREFIX = "D2DContentSegment"  # Prefix for content segment views

# Error Messages
NO_DATASETS_ERROR = "No datasets found in CDF. Please create a dataset and upload some files first."
NO_D2D_DATASETS_ERROR = "No D2D datasets found in CDF."

# Help Text
DATASET_SELECTION_HELP = "Choose any dataset containing files you want to analyze"
D2D_DATASET_SELECTION_HELP = "Choose a dataset containing 'd2d' in the external ID"

# Configuration Section Text
CONFIG_SECTION_TITLE = "⚙️ Configuration"
CONFIG_DATASET_TEXT = "**Dataset Configuration:**"
CONFIG_DATASET_DESC = "- Select any dataset containing files you want to analyze"
CONFIG_AUTO_DETECT = "- The app will automatically detect supported file types"
CONFIG_SAVE_RESULTS = "- Analysis results are saved to the D2D data model"
CONFIG_FILE_TYPES = "**Supported File Types:**"
CONFIG_PDF = "- 📄 PDF files (OCR-based analysis)"
CONFIG_WORD = "- 📝 Word documents (text extraction)"
CONFIG_EXCEL = "- 📊 Excel files (data extraction)"
CONFIG_EMAIL = "- 📧 Outlook messages (email extraction)" 