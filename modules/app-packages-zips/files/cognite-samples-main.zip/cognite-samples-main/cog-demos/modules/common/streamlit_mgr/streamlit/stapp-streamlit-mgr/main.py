import streamlit as st
from cognite.client import CogniteClient
from cognite.client.data_classes import FileMetadataUpdate
import json
from github import Github, InputGitTreeElement
import yaml
from github_cogtk import commit_multiple_to_github, is_valid_pat, get_modules
import time

client = CogniteClient()

def get_streamlit_apps():
    """
    Retrieves all Streamlit apps from Cognite Data Fusion, returning a list of dictionaries 
    containing the external ID and the name (from metadata).
    """
    files = client.files.list(directory_prefix="/streamlit-apps/")
    
    # Extract relevant metadata fields
    app_list = []
    for file in files:
        app_list.append({
            "external_id": file.external_id,
            "name": file.metadata.get("name", "Unknown")
        })
    
    return app_list

def get_streamlit_app_content(app_extid):
    # Retrieve the content of the selected Streamlit app file from the /streamlit-apps/ directory
    file = client.files.retrieve(external_id=app_extid)
    if file:
        file_id = file.id
        file_content = client.files.download_bytes(id=file_id)
        return json.loads(file_content.decode('utf-8'))
    else:
        return {}

def get_streamlit_metadata(client, app_extid, entrypoint):
    """
    Retrieves metadata from Cognite Data Fusion to construct the YAML file.
    
    :param client: CogniteClient instance
    :param app_name: Name of the Streamlit app
    :param entrypoint: The main script file for the Streamlit app
    :return: Dictionary containing YAML metadata
    """
    file = client.files.retrieve(external_id=app_extid)
    if not file:
        st.error(f"No source file found for {app_extid} in CDF.")
        return None
    
    file_metadata = file.metadata  # Get the first matching file metadata
    
    yaml_data = {
        "externalId": file.external_id,
        "name": file_metadata.get("name", "Unknown"),
        "creator": file_metadata.get("creator", "Unknown"),
        "description": file_metadata.get("description", ""),
        "published": file_metadata.get("published", "false"),
        "theme": file_metadata.get("theme", "Default"),
        "thumbnail": file_metadata.get('thumbnail', ''),
        "entrypoint": entrypoint
    }
    
    return yaml_data

def parse_streamlit_files(app_extid, module_path):
    """
    Parses JSON data, structures files into a dictionary
    
    :param app_extid: Name of the app (e.g., 'my_app')
    :param module_path: Base path in the repository (e.g., 'cog-demos/modules/common/foundation')
    """
    # Define the base path for the app files
    app_folder = f"{module_path}/streamlit/{app_extid}"
    yaml_path = f"{module_path}/streamlit/{app_extid}.Streamlit.yaml"

    # Get Streamlit JSON content
    json_content = get_streamlit_app_content(app_extid)

    # Extract data from JSON
    files = json_content.get("files", {})
    requirements = json_content.get("requirements", [])
    entrypoint = json_content.get("entrypoint", "main.py")
    
    # Fetch YAML metadata
    yaml_metadata = get_streamlit_metadata(client, app_extid, entrypoint)
    if yaml_metadata:
        yaml_content = yaml.dump(yaml_metadata, default_flow_style=False, sort_keys=False)
    else:
        yaml_content = ""
    
    # Initialize dictionary for files to commit
    files_to_commit = {}
    
    # Add YAML file
    if yaml_content:
        files_to_commit[yaml_path] = yaml_content

    # Add requirements.txt if present
    if requirements:
        requirements_content = "\n".join(requirements)
        files_to_commit[f"{app_folder}/requirements.txt"] = requirements_content

    # Add app files from JSON
    for file_path, file_data in files.items():
        file_content = file_data.get("content", {}).get("text", "")
        if file_content:
            full_file_path = f"{app_folder}/{file_path}"
            files_to_commit[full_file_path] = file_content

    return files_to_commit

def main():
    # Title of the app
    st.title("Export Streamlits to Github")
    st.write("Push Streamlit apps from Cognite Data Fusion to the cognite-samples Github.")

    # Initialize session state for caching
    if 'last_repo' not in st.session_state:
        st.session_state.last_repo = None
    if 'last_branch' not in st.session_state:
        st.session_state.last_branch = None
    if 'modules_list' not in st.session_state:
        st.session_state.modules_list = None

    # Get available Streamlits in CDF
    st.header("Select Streamlit Application")
    streamlit_apps = get_streamlit_apps()

    # Format Streamlits with a placeholder option
    app_options = {f"{app['name']} ({app['external_id']})": (app['name'], app['external_id']) for app in streamlit_apps}
    app_select_options = ["Select a Streamlit app..."] + list(app_options.keys())
    selected_option = st.selectbox(
        "Choose a Streamlit application to publish:",
        app_select_options,
        index=0,
        help="The Streamlit apps are listed as <name> (<external id>). If multiple Streamlits have the same name, verify the external ID for uniqueness."
    )

    # Extract name and external_id, or set to None if placeholder is selected
    if selected_option == "Select a Streamlit app...":
        selected_app_name = None
        selected_app_extid = None
    else:
        selected_app_name, selected_app_extid = app_options[selected_option]

    # Get content of the selected Streamlit application
    app_content = {}
    if selected_app_extid:  # TODO - move outside of UI
        app_content = get_streamlit_app_content(selected_app_extid)

    # GitHub PAT
    st.header("GitHub Personal Access Token (PAT)")
    github_pat = st.text_input(
        "Enter your GitHub Personal Access Token:",
        type="password",
        help="A Personal Access Token (PAT) is required for GitHub authentication. It allows you to push changes to the repository. Make sure to keep this token private."
    )

    # Validate PAT format
    if not is_valid_pat(github_pat):
        st.error("Invalid GitHub PAT format. Please ensure it is a valid 40-character token.")

    # Target repository and Branch input side by side
    st.header("Repository and Branch Information")
    col1, col2 = st.columns([2, 1])
    with col1:
        target_repository = st.text_input(
            "Target Repository URL:",
            help="Enter the full GitHub repository URL, such as 'username/repository'",
            value="cognitedata/cognite-samples",
            disabled=True
        )
    with col2:
        branch_name = st.text_input(
            "Existing Branch Name:",
            help="Enter the name of an existing branch that you want to push to. It cannot be 'main' as this is a protected branch. You can create a new branch through the GitHub web UI. https://github.com/cognitedata/cognite-samples/branches"
        )

    # Module selection with caching
    selected_module = None
    if target_repository and branch_name:
        # Check if repo or branch has changed 
        if (target_repository != st.session_state.last_repo or
            branch_name != st.session_state.last_branch):
            with st.spinner("Fetching modules, please wait..."):
                time.sleep(1)
                st.session_state.modules_list = get_modules(target_repository, branch_name, github_pat)
                st.session_state.last_repo = target_repository
                st.session_state.last_branch = branch_name
        else:
            # Use cached modules_list
            pass
        modules_list = st.session_state.modules_list

        # Create a mapping with a placeholder and "Create New..." option
        module_display_mapping = {module.replace("cog-demos/modules/", ""): module for module in modules_list}
        module_display_mapping["Create New..."] = None
        module_options = ["Select a module..."] + list(module_display_mapping.keys())
        selected_display_module = st.selectbox(
            "Choose a module, or select \"Create New...\":",
            module_options,
            index=0
        )

        # Determine selected_module based on user choice
        if selected_display_module == "Select a module...":
            selected_module = None
        elif selected_display_module == "Create New...":
            new_module_name = st.text_input("Enter new module name (e.g., common/mymodule):")
            if new_module_name:
                selected_module = f"cog-demos/modules/{new_module_name}"
            else:
                selected_module = None
        else:
            selected_module = module_display_mapping[selected_display_module]

    # Commit message
    st.header("Commit Message")
    commit_message = st.text_input("Enter a commit message for the changes:")

    # Validation function
    def validate_inputs(selected_app_extid, branch_name, selected_module, commit_message):
        if not selected_app_extid:
            return False, "Please select a Streamlit application."
        if not branch_name:
            return False, "Please enter a branch name."
        if not selected_module:
            return False, "Please select a module or create a new one."
        if not commit_message:
            return False, "Please enter a commit message."
        return True, ""

    # Publish to GitHub button
    if st.button("Publish to GitHub"):
        is_valid, error_message = validate_inputs(selected_app_extid, branch_name, selected_module, commit_message)
        if not is_valid:
            st.error(error_message)
        else:
            with st.spinner("Committing to GitHub, please wait..."):
                time.sleep(1)
                try:
                    files_to_commit = parse_streamlit_files(
                        app_extid=selected_app_extid,
                        module_path=selected_module
                    )
                    try:
                        if files_to_commit:
                            commit_multiple_to_github(
                                repo_name=target_repository.replace("https://github.com/", "").replace(".git", ""),
                                branch=branch_name,
                                files_dict=files_to_commit,
                                commit_message=commit_message,
                                github_pat=github_pat
                            )
                        else:
                            st.warning("No files to commit.")
                    except Exception as e:
                        st.error(f"An error occurred during GitHub push: {str(e)}")
                except Exception as e:
                    st.error(f"An error occurred during parsing: {str(e)}")

if __name__ == "__main__":
    main()