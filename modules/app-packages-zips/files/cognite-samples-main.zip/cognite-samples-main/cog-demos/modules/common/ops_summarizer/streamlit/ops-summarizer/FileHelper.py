import streamlit as st
from cognite.client import CogniteClient
from reportlab.pdfgen import canvas
from datetime import datetime
import io


def create_pdf(text: str, filename: str) -> bytes:
    """
    Generate a PDF from a text string.

    :param text: Text to include in the PDF.
    :param filename: Filename for the PDF.
    :return: PDF content as bytes.
    """
    pdf_buffer = io.BytesIO()
    pdf = canvas.Canvas(pdf_buffer)
    pdf.drawString(100, 750, text)  # Add text at a specific position
    pdf.save()
    pdf_buffer.seek(0)  # Rewind buffer
    return pdf_buffer.read()

def upload_pdf_to_cdf(text: str, dataset_id: int,  client: CogniteClient, filename: str = "", metadata: dict = None):
    """
    Create a PDF from text and upload it to a Cognite dataset.

    :param text: The text to include in the PDF.
    :param dataset_id: The ID of the Cognite dataset.
    :param metadata: Metadata to associate with the file.
    """
    # Create a filename based on current time
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if filename == "":
        filename = f"text_to_pdf_{timestamp}.pdf"
    
    ext_id = f"text_to_pdf_{timestamp}.pdf"

    # Generate PDF content
    pdf_content = create_pdf(text, filename)

    # Upload PDF to Cognite
    client.files.upload(
        data_set_id = dataset_id,
        name=filename,
        path=pdf_content,
        external_id=ext_id,
        mime_type="application/pdf",
        source='streamlit_AI_app',
    )
    print(f"PDF '{filename}' successfully uploaded to dataset {dataset_id}.")