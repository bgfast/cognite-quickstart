# Foundation Module

## Overview
The Foundation module provides the essential building blocks and foundational data structures for other modules in the Cognite Data Fusion environment. This module contains core RAW data, authentication groups, and basic data mappings that serve as the foundation for more specialized modules.

## What This Module Does
- **Creates foundational data structures** for the Valhall dataset
- **Establishes authentication groups** with appropriate permissions
- **Provides RAW data tables** containing assets, work orders, and time series mappings
- **Sets up data relationships** between different data types
- **Enables data foundation** for other modules to build upon

## Module Components

### 1. **Authentication Groups**
- **Superuser Group**: Full permissions to all resources
- **Readonly Group**: Limited read-only access for general users
- **Group Management**: Proper access control and permissions

### 2. **RAW Data Tables**
- **Assets Table**: Core asset information and metadata
- **Work Orders Table**: Work order data and status information
- **Work Items Table**: Individual work items and tasks
- **Equipment Table**: Equipment specifications and details
- **Files Metadata Table**: File information and metadata
- **Time Series Mappings**: Asset-to-timeseries relationships
- **Relationship Tables**: Various asset and work order relationships

### 3. **Data Relationships**
- **Asset-to-Children**: Parent-child asset relationships
- **Work Order-to-Assets**: Work order asset assignments
- **Work Order-to-Items**: Work order task breakdowns
- **Work Item-to-Assets**: Work item asset associations
- **Time Series-to-Assets**: Time series data asset mappings

### 4. **Dependencies**
- **Cognite SDK**: CDF client library
- **RAW Database**: CDF RAW database for data storage
- **Authentication**: CDF authentication and authorization

## Configuration Requirements

### ✅ **No Variables Required!**
This module is **completely self-contained** and doesn't use any template variables (`{{variable}}`). It's designed to be plug-and-play.

### **Deployment**
- **No configuration needed** - deploy as-is
- **No environment variables required**
- **No template substitutions needed**

## Usage
Once deployed, this module provides:
- Foundational data structures for the Valhall dataset
- Proper authentication and access control
- RAW data tables ready for transformation
- Data relationships and mappings
- Base infrastructure for other modules

## Verification System

### **Automated Verification**
The Foundation module includes an automated verification system that validates successful deployment by checking the foundational data structures and authentication groups in CDF.

**Location**: `modules/common/foundation/verify/verify.py`

### **What It Verifies**
The verification script automatically checks for:

1. **CDF Connection**: Validates authentication and connection to CDF
2. **Authentication Groups**: Confirms superuser and readonly groups are created
3. **RAW Tables**: Verifies RAW data tables are accessible
4. **Data Relationships**: Checks that data relationship tables exist

### **How to Run Verification**

**Individual Module Verification:**
```bash
cd cog-demos
python modules/common/foundation/verify/verify.py
```

**Test Harness (All Modules):**
```bash
cd cog-demos
python ../scripts/test_harness.py --config config.all.yaml
```

### **Verification Output**
```
🔍 FOUNDATION VERIFICATION
==================================================
✅ CDF Connection: Connected to CDF as user@example.com
✅ Authentication Groups: Found superuser and readonly groups
✅ RAW Tables: Found 12 RAW data tables
✅ Data Relationships: All relationship tables accessible

📋 Foundation verification PASSED
```

### **Integration with Deployment**
The verification system is designed to run automatically after each successful deployment to ensure the Foundation module's data structures and authentication groups are properly deployed and accessible.

**Key Features:**
- **Group Validation**: Ensures authentication groups are properly created
- **RAW Table Verification**: Confirms all RAW data tables are accessible
- **Relationship Checking**: Validates data relationship tables exist
- **Detailed Logging**: Shows exactly what was found and verified
- **Error Handling**: Provides clear error messages if verification fails
- **Exit Codes**: Returns proper exit codes for automated integration

## Type
Foundation 
