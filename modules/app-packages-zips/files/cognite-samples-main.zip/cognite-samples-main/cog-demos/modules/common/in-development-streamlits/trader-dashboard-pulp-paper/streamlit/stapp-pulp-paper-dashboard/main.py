import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import random
import numpy as np
import os
import logging

# --- Demo Script Functionality ---
def load_demo_script():
    """Load the demo script from the markdown file with robust path resolution and fallback."""
    
    # Embedded fallback content for when file can't be loaded
    fallback_content = """
# 🌲 Pulp & Paper Trading Dashboard - Demo Script
**Duration: 8-10 minutes | Business Value Story**

---

## 👥 **PERSONAS**

**🎯 MICHELLE ZHANG** - Senior Pulp & Paper Trader  
*15 years experience at FiberMax Trading, manages $160M pulp and paper portfolio*  
*Specializes in wood pulp, newsprint, and containerboard trading across global markets*  
*Known for her expertise in packaging demand cycles and fiber cost optimization*  
*Currently under pressure to improve trading margins by 20% amid volatile wood chip costs*

**⚙️ THOMAS ANDERSSON** - Mill Operations Manager  
*18 years experience, oversees 10 pulp and paper mills across North America and Scandinavia*  
*Former pulp engineer with expertise in kraft pulping and paper machine operations*  
*Responsible for $70M in annual production optimization initiatives*  
*Leading digital transformation to improve mill-to-market coordination*

---

## 🌅 **SETTING THE SCENE**
*It's 6:15 AM on a Monday morning at FiberMax's Vancouver trading center. Michelle is monitoring global pulp prices that are volatile due to Chinese packaging demand and North American lumber costs, while containerboard futures are rising on e-commerce growth. Thomas is at the central operations center coordinating multiple mills across different time zones. Michelle has significant exposure to pulp and containerboard contracts with delivery commitments to major packaging companies.*

---

## 🎬 **SCENE 1: The Crisis Unfolds (0:00 - 2:00)**

**MICHELLE** *(monitoring multiple screens showing pulp prices, packaging demand forecasts, and wood chip cost indicators)*  
"Thomas, we have a critical situation developing. Hardwood pulp prices just spiked $80 per ton overnight on Chinese packaging demand, wood chip costs are up 15% on logging restrictions, and I've got major packaging companies expecting 22,000 metric tons of pulp and containerboard delivery over the next month for holiday season production."

**THOMAS** *(video call from mill control room, with paper machine displays in background)*  
"I saw the pulp price move. What's your current book looking like?"

**MICHELLE** *(analyzing trading positions)*  
"We're long 18,000 MT mixed grades at an average of $1,120/MT, but BHKP is now trading at $1,200+ in Asia. The challenge is our wood chip costs have jumped to $160/BDT from $140 last month. I need to understand our fiber inventory and production flexibility."

---

## 📊 **SCENE 2: Dashboard Deep Dive (2:00 - 5:00)**

**THOMAS**  
"Let me show you our integrated mill operations using our real-time dashboard..."

### **Key Dashboard Interactions:**

1. **Multi-Mill Production Overview**
   - Navigate to Enterprise-Wide view
   - Point out: 10 mills, 4,200 MT/day total pulp capacity
   - Current production: 3,800 MT/day (90% utilization)
   - Product mix: 55% BHKP, 30% containerboard, 15% newsprint

2. **Regional Focus - North America**
   - Switch to Region-Wide filter
   - Highlight: British Columbia and Georgia mills
   - Combined capacity: 2,600 MT/day, optimal fiber costs

3. **Fiber Supply & Cost Analysis**
   - Click on BC Pulp Mill Complex
   - Wood chip inventory: 21-day supply at current consumption
   - Fiber cost breakdown: $145/BDT average with long-term contracts
   - Quality metrics: 85% softwood, 15% hardwood blend

4. **Production Optimization Options**
   - Show capacity to shift from newsprint to BHKP production
   - Newsprint margins: $85/MT vs. BHKP margins now $280/MT
   - Can redirect 400 MT/day within 72 hours

---

## 💡 **SCENE 3: Strategic Decision Making (5:00 - 8:00)**

**MICHELLE**  
"Excellent visibility! I can see we're in good shape with fiber costs and inventory. Can we really shift 400 MT/day from newsprint to BHKP that quickly?"

**THOMAS**  
"Yes, our BC mill has flexible bleaching lines. We can adjust the kraft process and redirect fiber flow. Newsprint demand is soft anyway, so this timing is perfect. The switch will take 72 hours for quality stabilization."

**MICHELLE**  
"Perfect market timing opportunity:
- **Immediate**: Confirm 18,000 MT delivery using current production
- **Opportunistic**: Offer additional 8,000 MT BHKP at $1,180/MT premium
- **Optimization**: Shift 400 MT/day from newsprint to BHKP for 6 weeks"

### **Business Impact Demonstrated:**

**Before Dashboard:**
- Phone calls to each mill (90+ minutes across time zones)
- Conservative fiber cost estimates
- Missed product switching opportunities
- Manual inventory tracking

**With Dashboard:**
- Real-time mill and inventory visibility (4 minutes)
- Confident grade optimization decisions
- Optimized fiber-to-market coordination
- **Result**: Additional $1.25M profit opportunity over 6 weeks

---

## 🎯 **SCENE 4: Forest Products Excellence (8:00 - 10:00)**

**MICHELLE**  
"Thomas, this mill integration is revolutionary. While other traders are operating with outdated production info, we're optimizing our entire forest products value chain in real-time."

**THOMAS**  
"Exactly. From the mill side, I can optimize our production scheduling based on your forward curves, manage our fiber purchasing around market cycles, and ensure we're maximizing the value of every ton of wood chips."

### **Quantified Business Value:**
- **Trading Margin Improvement**: 20% increase ($32M annual impact)
- **Decision Speed**: 22x faster (90 min → 4 min)
- **Product Mix Optimization**: $2.1M additional monthly revenue
- **Fiber Cost Management**: $1.6M saved annually through better timing
- **Production Efficiency**: 92% capacity utilization vs. 85% industry average

---

## 🔧 **Key Features Demonstrated:**

✅ **Multi-Mill Production Coordination**  
✅ **Fiber Supply & Cost Management**  
✅ **Product Grade Optimization**  
✅ **Inventory & Quality Tracking**  
✅ **Market Demand Integration**  
✅ **Production Switching Capabilities**  
✅ **Global Supply Chain Visibility**

---

## 📈 **ROI Summary:**
- **Implementation Cost**: $920K
- **Annual Benefit**: $35.7M
- **Payback Period**: 9.4 days
- **3-Year NPV**: $99M

---

*This dashboard transforms pulp & paper trading from reactive to proactive, enabling integrated fiber-to-market optimization that maximizes margins while ensuring sustainable forest product operations.*
"""
    
    try:
        # Get the directory of the current script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Multiple path attempts for different deployment scenarios
        possible_paths = [
            # Local development path (original)
            os.path.join(os.path.dirname(os.path.dirname(current_dir)), "DEMO_SCRIPT.md"),
            # Container deployment paths
            os.path.join("/app", "DEMO_SCRIPT.md"),
            os.path.join("/app", "trader-dashboard-pulp-paper", "DEMO_SCRIPT.md"),
            # Relative to current directory
            os.path.join(current_dir, "DEMO_SCRIPT.md"),
            os.path.join(current_dir, "..", "..", "DEMO_SCRIPT.md"),
            # Working directory
            "DEMO_SCRIPT.md",
            "./DEMO_SCRIPT.md"
        ]
        
        # Try each path
        for path in possible_paths:
            try:
                if os.path.exists(path):
                    with open(path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():  # Ensure file is not empty
                            return content
            except Exception as path_error:
                # Log individual path failures but continue trying
                logging.warning(f"Failed to load demo script from {path}: {path_error}")
                continue
        
        # If no file found, return fallback content
        logging.info("Demo script file not found in any expected location, using embedded fallback content")
        return fallback_content
        
    except Exception as e:
        # Final fallback with error info
        logging.error(f"Error in load_demo_script: {str(e)}")
        return f"""
# Demo Script Loading Error

**Error Details:** {str(e)}

**Fallback Content:**

{fallback_content}
"""

# Page configuration
st.set_page_config(layout="wide", page_title="Pulp & Paper Trading Dashboard", page_icon="🌲")

st.title("🌲 Pulp & Paper Mills Trading Dashboard - Real-Time Production Insights")

# Prominent disclaimer
st.markdown(
    """
    <div style="background-color: #f0f2f6; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
        <strong>⚠️ DEMO SIMULATION:</strong> This dashboard displays simulated data for demonstration purposes only. 
        All production figures, mill operations, and trading recommendations are fictional and not connected to real systems.
    </div>
    """,
    unsafe_allow_html=True
)

# --- Global Definitions for Pulp & Paper Data Simulation ---
regions = ["North America", "Europe", "Asia Pacific", "South America", "Scandinavia", "Russia/CIS"]
paper_products = ["Bleached Softwood Kraft (BSK) Pulp", "Unbleached Kraft Paper", "Newsprint", "Coated Paperboard", "Tissue Paper"]
equipment_types = ["Digester", "Paper Machine", "De-inking Line", "Bleaching Tower", "Recovery Boiler", "Pulp Dryer", "Coating Station", "Winder"]
status_options = ["Optimal", "Reduced Output", "Planned Maintenance", "Forced Outage", "Shutdown"]
incident_causes = ["Digester Malfunction", "Paper Break", "Chemical Shortage", "Fiber Quality Issue", "Scheduled Maintenance", "Environmental Limit"]
outlook_options = ["Improving", "Stable", "Declining", "Under Review", "Recovering"]

# Trader's Book of Business (regional and product specializations)
trader_books = {
    "Trader A (Kraft Pulp)": {"Regions": ["North America", "Scandinavia"], "Products": ["Bleached Softwood Kraft (BSK) Pulp", "Unbleached Kraft Paper"]},
    "Trader B (Newsprint)": {"Regions": ["Europe", "Asia Pacific"], "Products": ["Newsprint", "Coated Paperboard"]},
    "Trader C (Tissue)": {"Regions": ["North America", "South America"], "Products": ["Tissue Paper"]},
    "Trader D (Multi-Product)": {"Regions": ["Europe", "Russia/CIS"], "Products": ["Bleached Softwood Kraft (BSK) Pulp", "Coated Paperboard", "Tissue Paper"]},
    "Trader E (Global Kraft)": {"Regions": ["Asia Pacific", "South America", "Russia/CIS"], "Products": ["Bleached Softwood Kraft (BSK) Pulp", "Unbleached Kraft Paper"]}
}

# Mill facility names
mill_facilities = [
    "Nordic Pine Mill", "Canadian Forest Complex", "Siberian Timber Works", "Pacific Northwest Mill",
    "Scandinavian Pulp Center", "Brazilian Eucalyptus Plant", "Finnish Paper Works", "Oregon Kraft Mill",
    "Swedish Newsprint Facility", "Quebec Tissue Mill", "Russian Softwood Complex", "BC Pulp Operations",
    "Chilean Pine Mill", "Boreal Forest Plant", "Taiga Pulp Works", "Great Lakes Paper Mill",
    "Atlantic Coast Facility", "Rocky Mountain Mill", "European Kraft Center", "Asian Pulp Complex"
]

# Generate mock mill data
def generate_mill_data():
    mills = []
    for i, facility in enumerate(mill_facilities):
        region = random.choice(regions)
        primary_product = random.choice(paper_products)
        
        # Production capacity (tons/day)
        base_capacity = random.randint(800, 2500)
        current_production = base_capacity * random.uniform(0.65, 1.05)
        
        # Equipment status
        equipment = random.choice(equipment_types)
        status = random.choice(status_options)
        
        # Calculate production impact
        if status == "Optimal":
            impact_pct = random.uniform(-5, 5)
            impact_tons = current_production * (impact_pct / 100)
        elif status == "Reduced Output":
            impact_pct = random.uniform(-25, -10)
            impact_tons = current_production * (impact_pct / 100)
        elif status == "Planned Maintenance":
            impact_pct = random.uniform(-40, -20)
            impact_tons = current_production * (impact_pct / 100)
        elif status == "Forced Outage":
            impact_pct = random.uniform(-80, -50)
            impact_tons = current_production * (impact_pct / 100)
        else:  # Shutdown
            impact_pct = -100
            impact_tons = -current_production
        
        mills.append({
            "Mill": facility,
            "Region": region,
            "Primary Product": primary_product,
            "Equipment": equipment,
            "Status": status,
            "Base Capacity (t/day)": base_capacity,
            "Current Production (t/day)": max(0, current_production + impact_tons),
            "Impact (t/day)": impact_tons,
            "Impact (%)": impact_pct,
            "Duration (hours)": random.randint(4, 168) if status != "Optimal" else 0,
            "Incident Cause": random.choice(incident_causes) if status != "Optimal" else "Normal Operations",
            "Outlook": random.choice(outlook_options),
            "Last Updated": datetime.now() - timedelta(minutes=random.randint(1, 30))
        })
    
    return pd.DataFrame(mills)

# Generate production alerts
def generate_production_alerts(df):
    alerts = []
    critical_mills = df[df['Status'].isin(['Forced Outage', 'Shutdown'])]
    
    for _, mill in critical_mills.iterrows():
        severity = "🔴 Critical" if mill['Status'] == 'Shutdown' else "🟠 High"
        
        # Calculate shortfall
        shortfall_tons = abs(mill['Impact (t/day)']) * (mill['Duration (hours)'] / 24)
        
        alerts.append({
            "Severity": severity,
            "Mill": mill['Mill'],
            "Issue": f"{mill['Equipment']} - {mill['Status']}",
            "Product": mill['Primary Product'],
            "Shortfall": f"{shortfall_tons:.0f} tons",
            "Duration": f"{mill['Duration (hours)']} hours",
            "Recommendation": generate_trading_recommendation(mill['Primary Product'], shortfall_tons, mill['Region'])
        })
    
    return pd.DataFrame(alerts)

# Generate comprehensive trading recommendations
def generate_trading_recommendation(product, shortfall_tons, region):
    """Generate detailed trading recommendations based on product, shortfall size, and region"""
    
    # Product-specific pricing and sourcing strategies
    product_strategies = {
        "Bleached Softwood Kraft (BSK) Pulp": {
            "spot_premium": 15,  # % premium over contract price
            "lead_time": "2-3 weeks",
            "key_suppliers": ["Scandinavia", "North America", "Russia/CIS"],
            "seasonal_factor": "Q1 tight supply"
        },
        "Unbleached Kraft Paper": {
            "spot_premium": 8,
            "lead_time": "1-2 weeks", 
            "key_suppliers": ["North America", "Europe", "South America"],
            "seasonal_factor": "Stable year-round"
        },
        "Newsprint": {
            "spot_premium": 12,
            "lead_time": "3-4 weeks",
            "key_suppliers": ["North America", "Europe", "Asia Pacific"],
            "seasonal_factor": "Q4 demand surge"
        },
        "Coated Paperboard": {
            "spot_premium": 10,
            "lead_time": "2-3 weeks",
            "key_suppliers": ["Europe", "Asia Pacific", "North America"],
            "seasonal_factor": "Holiday packaging demand"
        },
        "Tissue Paper": {
            "spot_premium": 6,
            "lead_time": "1-2 weeks",
            "key_suppliers": ["North America", "Europe", "South America"],
            "seasonal_factor": "Pandemic-driven demand"
        }
    }
    
    strategy = product_strategies.get(product, {
        "spot_premium": 10, "lead_time": "2-3 weeks", 
        "key_suppliers": ["Global"], "seasonal_factor": "Standard"
    })
    
    if shortfall_tons > 2000:
        # Critical shortage - immediate action required
        cost_impact = shortfall_tons * 850 * (strategy["spot_premium"] / 100)  # Assume $850/ton base
        return f"""🚨 **CRITICAL SHORTAGE ALERT**
        
**Immediate Actions Required:**
• Emergency spot purchases: {shortfall_tons:,.0f} tons {product}
• Contact key suppliers in {', '.join(strategy['key_suppliers'][:2])}
• Expect {strategy['spot_premium']}% premium (~${cost_impact:,.0f} extra cost)
• Lead time: {strategy['lead_time']} - expedite shipping
        
**Trading Strategy:**
• Split purchases across 2-3 suppliers to reduce risk
• Consider forward contracts to lock in Q2 supply
• Alert sales team of potential customer allocation
        
**Market Context:** {strategy['seasonal_factor']}"""
        
    elif shortfall_tons > 1000:
        # Major shortage - structured approach needed
        cost_impact = shortfall_tons * 850 * (strategy["spot_premium"] / 100 * 0.7)
        return f"""🟠 **MAJOR SHORTAGE - STRUCTURED RESPONSE**
        
**Primary Actions:**
• Secure {shortfall_tons:,.0f} tons {product} via preferred suppliers
• Target suppliers: {', '.join(strategy['key_suppliers'])}
• Budget for {strategy['spot_premium']*0.7:.0f}% premium (~${cost_impact:,.0f})
• Standard lead time: {strategy['lead_time']}
        
**Risk Management:**
• 70% spot market, 30% contract suppliers
• Monitor competitor activity in {region}
• Prepare customer communication on potential delays
        
**Opportunity:** Consider building strategic inventory"""
        
    elif shortfall_tons > 500:
        # Moderate shortage - managed response
        cost_impact = shortfall_tons * 850 * (strategy["spot_premium"] / 100 * 0.4)
        return f"""🟡 **MODERATE SHORTAGE - MANAGED RESPONSE**
        
**Recommended Actions:**
• Source {shortfall_tons:,.0f} tons {product} through contract network
• Primary region: {region}
• Expected premium: {strategy['spot_premium']*0.4:.0f}% (~${cost_impact:,.0f})
• Timeline: {strategy['lead_time']}
        
**Strategy:**
• 50% existing contracts, 50% spot market
• Negotiate volume discounts for bulk purchase
• Review Q2 contract terms for similar situations
        
**Note:** {strategy['seasonal_factor']} - factor into timing"""
        
    else:
        # Minor shortage - monitoring required
        return f"""ℹ️ **MINOR SHORTAGE - MONITORING MODE**
        
**Current Status:**
• Monitor {shortfall_tons:,.0f} tons {product} exposure
• Region: {region}
• No immediate action required
        
**Proactive Measures:**
• Contact 2-3 backup suppliers for quotes
• Review inventory buffers for similar mills
• Track market prices for potential opportunities
        
**Timeline:** {strategy['lead_time']} if action becomes necessary"""

# Generate historical production data
def generate_production_trends(selected_mills, days=30):
    trends = []
    base_date = datetime.now() - timedelta(days=days)
    
    for mill in selected_mills:
        base_production = mill['Base Capacity (t/day)']
        
        for day in range(days + 1):
            date = base_date + timedelta(days=day)
            
            # Add some variability
            daily_variation = random.uniform(0.85, 1.05)
            production = base_production * daily_variation
            
            # Add occasional disruptions
            if random.random() < 0.05:  # 5% chance of disruption
                production *= random.uniform(0.3, 0.7)
            
            trends.append({
                "Date": date,
                "Mill": mill['Mill'],
                "Product": mill['Primary Product'],
                "Production (t/day)": production,
                "Region": mill['Region']
            })
    
    return pd.DataFrame(trends)

# Generate forecast data
def generate_forecast_data(selected_mills, days=30):
    forecasts = []
    base_date = datetime.now() + timedelta(days=1)
    
    for mill in selected_mills:
        base_production = mill['Current Production (t/day)']
        
        for day in range(days):
            date = base_date + timedelta(days=day)
            
            # Forecast with trend
            trend_factor = 1 + (day * 0.001)  # Slight upward trend
            forecast = base_production * trend_factor * random.uniform(0.95, 1.05)
            
            forecasts.append({
                "Date": date,
                "Mill": mill['Mill'],
                "Product": mill['Primary Product'],
                "Forecast (t/day)": forecast,
                "Region": mill['Region']
            })
    
    return pd.DataFrame(forecasts)

# Initialize data
if 'mill_data' not in st.session_state:
    st.session_state.mill_data = generate_mill_data()

mill_data = st.session_state.mill_data

# Sidebar filters
st.sidebar.header("Navigation")

# Add tabs for main dashboard and demo script
page = st.sidebar.radio("Select Page:", ["Dashboard", "Demo Script"])

if page == "Demo Script":
    st.title("🌲 Pulp & Paper Trading Dashboard - Demo Script")
    st.markdown("---")
    
    demo_content = load_demo_script()
    st.markdown(demo_content)
    
    st.markdown("---")
    st.caption("Return to the Dashboard using the sidebar navigation.")
    st.stop()  # Stop execution here for demo script page

st.sidebar.header("🎛️ Dashboard Filters")

# View selection
view_option = st.sidebar.selectbox(
    "Select View:",
    ["Enterprise-Wide", "Region-Wide", "My Book of Business"]
)

if view_option == "Region-Wide":
    selected_regions = st.sidebar.multiselect(
        "Select Regions:",
        regions,
        default=regions[:3]
    )
    filtered_data = mill_data[mill_data['Region'].isin(selected_regions)]
elif view_option == "My Book of Business":
    selected_trader = st.sidebar.selectbox(
        "Select Trader:",
        list(trader_books.keys())
    )
    trader_regions = trader_books[selected_trader]["Regions"]
    trader_products = trader_books[selected_trader]["Products"]
    filtered_data = mill_data[
        (mill_data['Region'].isin(trader_regions)) & 
        (mill_data['Primary Product'].isin(trader_products))
    ]
else:  # Enterprise-Wide
    filtered_data = mill_data

# Product filter
selected_products = st.sidebar.multiselect(
    "Filter by Products:",
    paper_products,
    default=paper_products
)
filtered_data = filtered_data[filtered_data['Primary Product'].isin(selected_products)]

# Status filter
selected_statuses = st.sidebar.multiselect(
    "Filter by Status:",
    status_options,
    default=status_options
)
filtered_data = filtered_data[filtered_data['Status'].isin(selected_statuses)]

# Main dashboard layout
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("🚨 Production Alerts & Impact Analysis")
    
    # Generate and display alerts
    alerts_df = generate_production_alerts(filtered_data)
    
    if not alerts_df.empty:
        for _, alert in alerts_df.iterrows():
            with st.expander(f"{alert['Severity']} - {alert['Mill']}", expanded=True):
                col_a, col_b, col_c = st.columns(3)
                with col_a:
                    st.metric("Product Impact", alert['Product'])
                    st.metric("Shortfall", alert['Shortfall'])
                with col_b:
                    st.metric("Duration", alert['Duration'])
                    st.write(f"**Issue:** {alert['Issue']}")
                with col_c:
                    st.write("**Trading Recommendation:**")
                    st.write(alert['Recommendation'])
    else:
        st.info("✅ No critical production alerts at this time")

with col2:
    st.subheader("📊 Portfolio Summary")
    
    # Key metrics
    total_mills = len(filtered_data)
    total_capacity = filtered_data['Base Capacity (t/day)'].sum()
    current_production = filtered_data['Current Production (t/day)'].sum()
    utilization = (current_production / total_capacity) * 100
    
    st.metric("Active Mills", total_mills)
    st.metric("Total Capacity", f"{total_capacity:,.0f} t/day")
    st.metric("Current Production", f"{current_production:,.0f} t/day")
    st.metric("Utilization Rate", f"{utilization:.1f}%")
    
    # Status distribution
    status_counts = filtered_data['Status'].value_counts()
    fig_status = px.pie(
        values=status_counts.values,
        names=status_counts.index,
        title="Mill Status Distribution",
        color_discrete_map={
            'Optimal': '#00CC44',
            'Reduced Output': '#FFB000',
            'Planned Maintenance': '#0066CC',
            'Forced Outage': '#FF6600',
            'Shutdown': '#CC0000'
        }
    )
    fig_status.update_traces(textposition='inside', textinfo='percent+label')
    fig_status.update_layout(height=300)
    st.plotly_chart(fig_status, use_container_width=True)

# Top 5 Equipment Impact
st.subheader("⚙️ Top 5 Equipment Impact Analysis")

# Get top 5 mills by impact
top_impact = filtered_data.nlargest(5, 'Impact (t/day)', keep='all')
if len(top_impact) > 5:
    top_impact = top_impact.head(5)

if not top_impact.empty:
    cols = st.columns(5)
    for i, (_, mill) in enumerate(top_impact.iterrows()):
        with cols[i]:
            # Color coding based on status
            if mill['Status'] == 'Shutdown':
                color = "🔴"
            elif mill['Status'] == 'Forced Outage':
                color = "🟠"
            elif mill['Status'] == 'Planned Maintenance':
                color = "🟡"
            elif mill['Status'] == 'Reduced Output':
                color = "🟨"
            else:
                color = "🟢"
            
            st.markdown(f"**{color} {mill['Mill']}**")
            st.write(f"**Equipment:** {mill['Equipment']}")
            st.write(f"**Status:** {mill['Status']}")
            st.metric("Impact", f"{mill['Impact (t/day)']:+.0f} t/day")
            st.write(f"**Duration:** {mill['Duration (hours)']} hrs")
            st.write(f"**Product:** {mill['Primary Product']}")

# Production Analytics
st.subheader("📈 Production Analytics")

# Mill selection for detailed analysis
selected_mill_names = st.multiselect(
    "Select Mills for Detailed Analysis:",
    filtered_data['Mill'].tolist(),
    default=filtered_data['Mill'].tolist()[:3]
)

if selected_mill_names:
    selected_mills_data = filtered_data[filtered_data['Mill'].isin(selected_mill_names)]
    
    # Generate trend data
    trend_data = generate_production_trends(selected_mills_data.to_dict('records'))
    forecast_data = generate_forecast_data(selected_mills_data.to_dict('records'))
    
    # Production trends chart
    fig_trend = go.Figure()
    
    for mill in selected_mill_names:
        mill_trend = trend_data[trend_data['Mill'] == mill]
        mill_forecast = forecast_data[forecast_data['Mill'] == mill]
        
        # Historical data
        fig_trend.add_trace(go.Scatter(
            x=mill_trend['Date'],
            y=mill_trend['Production (t/day)'],
            mode='lines',
            name=f"{mill} (Historical)",
            line=dict(width=2)
        ))
        
        # Forecast data
        fig_trend.add_trace(go.Scatter(
            x=mill_forecast['Date'],
            y=mill_forecast['Forecast (t/day)'],
            mode='lines',
            name=f"{mill} (Forecast)",
            line=dict(dash='dash', width=2)
        ))
    
    # Add vertical line for today
    try:
        fig_trend.add_vline(
            x=datetime.now(),
            line_dash="dot",
            line_color="red",
            annotation_text="Today"
        )
    except Exception:
        # Fallback for datetime handling
        import pandas as pd
        today_ts = pd.Timestamp.now()
        fig_trend.add_annotation(
            x=today_ts,
            y=trend_data['Production (t/day)'].max(),
            text="Today",
            showarrow=True,
            arrowhead=2,
            arrowcolor="red"
        )
    
    fig_trend.update_layout(
        title="Production Trends & 30-Day Forecast",
        xaxis_title="Date",
        yaxis_title="Production (tons/day)",
        height=400,
        hovermode='x unified'
    )
    
    st.plotly_chart(fig_trend, use_container_width=True)
    
    # Month-to-date summary
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📅 Month-to-Date Summary")
        mtd_data = []
        for mill in selected_mills_data.to_dict('records'):
            mill_trend = trend_data[trend_data['Mill'] == mill['Mill']]
            current_month = datetime.now().replace(day=1)
            mtd_trend = mill_trend[mill_trend['Date'] >= current_month]
            
            mtd_avg = mtd_trend['Production (t/day)'].mean()
            mtd_total = mtd_trend['Production (t/day)'].sum()
            
            mtd_data.append({
                "Mill": mill['Mill'],
                "MTD Avg (t/day)": mtd_avg,
                "MTD Total (tons)": mtd_total,
                "Current Status": mill['Status']
            })
        
        mtd_df = pd.DataFrame(mtd_data)
        st.dataframe(mtd_df, use_container_width=True)
    
    with col2:
        st.subheader("📊 30-Day Rolling Average")
        rolling_data = []
        for mill in selected_mills_data.to_dict('records'):
            mill_trend = trend_data[trend_data['Mill'] == mill['Mill']]
            rolling_avg = mill_trend['Production (t/day)'].tail(30).mean()
            
            rolling_data.append({
                "Mill": mill['Mill'],
                "30-Day Avg (t/day)": rolling_avg,
                "vs Base Capacity": f"{(rolling_avg / mill['Base Capacity (t/day)']) * 100:.1f}%"
            })
        
        rolling_df = pd.DataFrame(rolling_data)
        st.dataframe(rolling_df, use_container_width=True)

# Operations Intelligence
st.subheader("🧠 Operations Intelligence")

col1, col2 = st.columns(2)

with col1:
    st.subheader("📝 Incident Log & Supervisor Notes")
    
    # Generate sample incident logs
    incident_logs = []
    for _, mill in filtered_data[filtered_data['Status'] != 'Optimal'].iterrows():
        incident_logs.append({
            "Timestamp": mill['Last Updated'].strftime("%Y-%m-%d %H:%M"),
            "Mill": mill['Mill'],
            "Incident": f"{mill['Equipment']} - {mill['Incident Cause']}",
            "Impact": f"{mill['Impact (t/day)']:+.0f} t/day",
            "Status": mill['Status'],
            "Notes": f"Supervisor reported {mill['Incident Cause'].lower()}. Estimated duration: {mill['Duration (hours)']} hours. {mill['Outlook']} outlook."
        })
    
    if incident_logs:
        for log in incident_logs[:5]:  # Show top 5
            with st.expander(f"{log['Timestamp']} - {log['Mill']}", expanded=False):
                st.write(f"**Incident:** {log['Incident']}")
                st.write(f"**Impact:** {log['Impact']}")
                st.write(f"**Status:** {log['Status']}")
                st.write(f"**Notes:** {log['Notes']}")
    else:
        st.info("No recent incidents to display")

with col2:
    st.subheader("📋 Operations Inquiry Form")
    
    with st.form("operations_inquiry"):
        inquiry_mill = st.selectbox("Select Mill:", filtered_data['Mill'].tolist())
        inquiry_type = st.selectbox(
            "Inquiry Type:",
            ["Production Status", "Maintenance Schedule", "Quality Issues", "Supply Chain", "Other"]
        )
        priority = st.selectbox("Priority:", ["Low", "Medium", "High", "Critical"])
        inquiry_details = st.text_area("Inquiry Details:", height=100)
        
        submitted = st.form_submit_button("Submit Inquiry")
        
        if submitted:
            st.success(f"✅ Inquiry submitted for {inquiry_mill} - Priority: {priority}")
            st.info("Operations team will respond within 2 hours for High/Critical priorities, 24 hours for others.")

# Detailed Mill Performance Table
st.subheader("🏭 Detailed Mill Performance")

# Style the dataframe
def style_status(val):
    if val == 'Shutdown':
        return 'background-color: #ffcccc'
    elif val == 'Forced Outage':
        return 'background-color: #ffe6cc'
    elif val == 'Planned Maintenance':
        return 'background-color: #cce6ff'
    elif val == 'Reduced Output':
        return 'background-color: #fff2cc'
    else:
        return 'background-color: #ccffcc'

# Display table with formatting
display_df = filtered_data[[
    'Mill', 'Region', 'Primary Product', 'Equipment', 'Status',
    'Base Capacity (t/day)', 'Current Production (t/day)', 'Impact (t/day)',
    'Impact (%)', 'Duration (hours)', 'Outlook'
]].copy()

# Format numerical columns
display_df['Base Capacity (t/day)'] = display_df['Base Capacity (t/day)'].round(0).astype(int)
display_df['Current Production (t/day)'] = display_df['Current Production (t/day)'].round(0).astype(int)
display_df['Impact (t/day)'] = display_df['Impact (t/day)'].round(0).astype(int)
display_df['Impact (%)'] = display_df['Impact (%)'].round(1)

# Apply styling
try:
    styled_df = display_df.style.map(style_status, subset=['Status'])
    st.dataframe(styled_df, use_container_width=True)
except:
    # Fallback if styling fails
    st.dataframe(display_df, use_container_width=True)

# Footer
st.markdown("---")
st.markdown(
    """
    <div style="text-align: center; color: #666; font-size: 12px;">
        🌲 Pulp & Paper Mills Trading Dashboard | Powered by Cognite Industrial Canvas<br>
        <strong>Disclaimer:</strong> This is a demonstration with simulated data. All mill operations, production figures, and trading recommendations are fictional.
    </div>
    """,
    unsafe_allow_html=True
) 