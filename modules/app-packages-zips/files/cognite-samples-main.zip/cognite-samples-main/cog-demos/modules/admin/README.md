# Admin Module

This module contains administrative tools and interfaces for managing the Cognite Data Fusion environment.

## Components

### admin-streamlit
A Streamlit-based admin dashboard that provides:
- **One-Click Deployment**: Deploy CDF modules and configurations
- **GitHub Token Management**: Secure storage and management of GitHub Personal Access Tokens
- **Environment Configuration**: Manage CDF project settings and configurations
- **Administrative Controls**: Debug mode, token validation, and system monitoring

## Features

### 🔐 **Secure GitHub Token Management**
- **Encrypted Storage**: GitHub tokens stored securely in CDF Data Modeling with Fernet encryption
- **First-time Setup**: Guided token configuration with validation
- **Token Testing**: Validate token permissions and connectivity
- **Token Rotation**: Easy token updates and management
- **Automatic Fallback**: Graceful fallback to existing tokens during transition

### 🚀 **One-Click Deployment**
- **Module Deployment**: Deploy predefined module sets to CDF environments
- **GitHub Integration**: Trigger GitHub Actions workflows for automated deployment
- **Configuration Management**: Handle environment-specific configurations
- **Status Monitoring**: Track deployment progress and results

### ⚙️ **Administrative Tools**
- **Debug Mode**: Comprehensive debugging and logging capabilities
- **Token Validation**: Real-time GitHub API connectivity testing
- **User Management**: Track deployment activities by user
- **Settings Panel**: Centralized configuration management

## Data Model

The admin module uses CDF Data Modeling for secure token storage:

- **Space**: `gtoken_space` - Dedicated space for GitHub token storage
- **Container**: `gtoken_container` - Defines token and encryption key properties
- **View**: `gtoken_view` - Provides access interface for encrypted data
- **Encryption**: Fernet symmetric encryption with CDF-stored keys

## Usage

### First-Time Setup

1. **Deploy the Admin Module**: Use Cognite Toolkit to deploy the admin module
2. **Configure GitHub Token**: 
   - Navigate to "Token Settings" in the admin streamlit
   - Follow the guided setup to create and store your GitHub Personal Access Token
   - Validate token permissions
3. **Start Deploying**: Use the "Main Deployment" page for one-click deployments

### Token Management

```bash
# The streamlit automatically handles:
# - Token encryption/decryption
# - Secure storage in CDF Data Modeling
# - Token validation and testing
# - Fallback to existing tokens
```

### Running Locally

```bash
# Navigate to the streamlit directory
cd cog-demos/modules/admin/admin-streamlit/streamlit/stapp-admin-streamlit

# Run the streamlit app
streamlit run main.py
```

## Security Features

- **🔐 Encrypted Storage**: All tokens encrypted with Fernet before storage
- **🔑 Key Management**: Encryption keys stored separately in CDF Data Modeling
- **✅ Token Validation**: Real-time GitHub API testing
- **🔄 Automatic Rotation**: Support for token updates and rotation
- **👤 User Tracking**: Audit trail of token creation and updates

## Development

### Adding New Features

1. **Token Storage**: Uses existing `store_github_token()` and `get_stored_token()` functions
2. **Validation**: Extend `validate_github_token()` for additional checks
3. **UI Components**: Add new pages to the navigation system
4. **Data Models**: Extend the existing CDF Data Modeling structure

### Architecture

```
Admin Streamlit
├── Token Management (CDF Data Modeling)
├── Deployment Engine (GitHub Actions)
├── Configuration Management (JSON/YAML)
└── User Interface (Streamlit Pages)
```

## Migration from Previous Versions

- **Automatic Fallback**: Existing hardcoded tokens continue to work
- **Gradual Migration**: Set up new token storage alongside existing systems
- **Zero Downtime**: No disruption to existing deployments
- **Easy Transition**: Use Token Settings page to migrate to secure storage

## TODO

- [ ] Integrate with actual deployment APIs
- [ ] Add authentication and authorization
- [ ] Implement environment variable management
- [ ] Add logging and monitoring capabilities
- [ ] Connect to Azure KeyVault for secure token storage 