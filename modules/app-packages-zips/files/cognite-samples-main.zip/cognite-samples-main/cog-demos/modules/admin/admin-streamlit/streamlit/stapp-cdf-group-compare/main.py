import streamlit as st
import os
import tempfile
from cognite.client import CogniteClient, ClientConfig
from cognite.client.credentials import OAuthClientCredentials
from cognite.client.exceptions import CogniteAPIError, CogniteNotFoundError
import pandas as pd
from typing import Dict, Any, Optional, Tuple
import json

def get_readable_capability_name(capability: Dict) -> str:
    """Convert technical capability names to readable names."""
    cap_type = capability.get('capability', 'Unknown')
    
    # Enhanced mapping of technical names to readable names
    capability_mapping = {
        # Projects
        'projectsAcl': 'Projects: List Projects',
        'projectsAcl:LIST': 'Projects: List Projects',
        'projectsAcl:READ': 'Projects: Read Projects',
        
        # Groups
        'groupsAcl': 'Groups: Read Groups',
        'groupsAcl:LIST': 'Groups: List Groups',
        'groupsAcl:READ': 'Groups: Read Groups',
        'groupsAcl:CREATE': 'Groups: Create Groups',
        'groupsAcl:UPDATE': 'Groups: Update Groups',
        'groupsAcl:DELETE': 'Groups: Delete Groups',
        
        # Raw Data
        'rawAcl': 'Raw: Read Raw Data',
        'rawAcl:READ': 'Raw: Read Raw Data',
        'rawAcl:WRITE': 'Raw: Write Raw Data',
        'rawAcl:LIST': 'Raw: List Raw Data',
        
        # Data Models
        'dataModelsAcl': 'Data Models: List Data Models',
        'dataModelsAcl:READ': 'Data Models: Read Data Models',
        'dataModelsAcl:WRITE': 'Data Models: Write Data Models',
        'dataModelsAcl:CREATE': 'Data Models: Create Data Models',
        
        # Data Model Instances
        'dataModelInstancesAcl': 'Data Model Instances: Read Data Model Instances',
        'dataModelInstancesAcl:READ': 'Data Model Instances: Read Data Model Instances',
        'dataModelInstancesAcl:WRITE': 'Data Model Instances: Write Data Model Instances',
        'dataModelInstancesAcl:CREATE': 'Data Model Instances: Create Data Model Instances',
        
        # Data Sets
        'dataSetsAcl': 'Data Sets: Read Data Sets',
        'dataSetsAcl:READ': 'Data Sets: Read Data Sets',
        'dataSetsAcl:WRITE': 'Data Sets: Write Data Sets',
        'dataSetsAcl:OWNER': 'Data Sets: Owner Data Sets',
        
        # Extraction Pipelines
        'extractionPipelinesAcl': 'Extraction Pipelines: Read Extraction Pipelines',
        'extractionPipelinesAcl:READ': 'Extraction Pipelines: Read Extraction Pipelines',
        'extractionPipelinesAcl:WRITE': 'Extraction Pipelines: Write Extraction Pipelines',
        
        # Extraction Runs
        'extractionRunsAcl': 'Extraction Runs: Read Extraction Runs',
        'extractionRunsAcl:READ': 'Extraction Runs: Read Extraction Runs',
        'extractionRunsAcl:WRITE': 'Extraction Runs: Write Extraction Runs',
        
        # Extraction Configs
        'extractionConfigsAcl': 'Extraction Configs: Read Extraction Configs',
        'extractionConfigsAcl:READ': 'Extraction Configs: Read Extraction Configs',
        'extractionConfigsAcl:WRITE': 'Extraction Configs: Write Extraction Configs',
        
        # Functions
        'functionsAcl': 'Functions: Read Functions',
        'functionsAcl:READ': 'Functions: Read Functions',
        'functionsAcl:WRITE': 'Functions: Write Functions',
        'functionsAcl:USE': 'Functions: Use Functions',
        
        # Sessions
        'sessionsAcl': 'Sessions: Read Sessions',
        'sessionsAcl:LIST': 'Sessions: List Sessions',
        'sessionsAcl:READ': 'Sessions: Read Sessions',
        'sessionsAcl:CREATE': 'Sessions: Create Sessions',
        
        # Transformations
        'transformationsAcl': 'Transformations: List Transformations',
        'transformationsAcl:READ': 'Transformations: Read Transformations',
        'transformationsAcl:WRITE': 'Transformations: Write Transformations',
        'transformationsAcl:RUN': 'Transformations: Run Transformations',
        
        # File Pipelines
        'filePipelinesAcl': 'File Pipelines: Read File Pipelines',
        'filePipelinesAcl:READ': 'File Pipelines: Read File Pipelines',
        'filePipelinesAcl:WRITE': 'File Pipelines: Write File Pipelines',
        
        # Security Categories
        'securityCategoriesAcl': 'Security Categories: List Security Categories',
        'securityCategoriesAcl:MEMBEROF': 'Security Categories: Member Of Security Categories',
        'securityCategoriesAcl:LIST': 'Security Categories: List Security Categories',
        'securityCategoriesAcl:READ': 'Security Categories: Read Security Categories',
        
        # Hosted Extractors
        'hostedExtractorsAcl': 'Hosted Extractors: List Hosted Extractors',
        'hostedExtractorsAcl:READ': 'Hosted Extractors: Read Hosted Extractors',
        'hostedExtractorsAcl:WRITE': 'Hosted Extractors: Write Hosted Extractors',
        
        # Workflow Orchestration
        'workflowOrchestrationAcl': 'Workflow Orchestration: Read Workflow Orchestration',
        'workflowOrchestrationAcl:READ': 'Workflow Orchestration: Read Workflow Orchestration',
        'workflowOrchestrationAcl:WRITE': 'Workflow Orchestration: Write Workflow Orchestration',
        
        # Time Series Subscriptions
        'timeSeriesSubscriptionsAcl': 'Time Series Subscriptions: List Time Series Subscriptions',
        'timeSeriesSubscriptionsAcl:READ': 'Time Series Subscriptions: Read Time Series Subscriptions',
        'timeSeriesSubscriptionsAcl:WRITE': 'Time Series Subscriptions: Write Time Series Subscriptions',
        
        # Location Filters
        'locationFiltersAcl': 'Location Filters: Read Location Filters',
        'locationFiltersAcl:READ': 'Location Filters: Read Location Filters',
        'locationFiltersAcl:WRITE': 'Location Filters: Write Location Filters',
        
        # Files
        'filesAcl': 'Files: Read Files',
        'filesAcl:READ': 'Files: Read Files',
        'filesAcl:WRITE': 'Files: Write Files',
        
        # 3D
        'threedAcl': '3D: Read 3D',
        'threedAcl:READ': '3D: Read 3D',
        'threedAcl:CREATE': '3D: Create 3D',
        'threedAcl:UPDATE': '3D: Update 3D',
        
        # Time Series
        'timeSeriesAcl': 'Time Series: Read Time Series',
        'timeSeriesAcl:READ': 'Time Series: Read Time Series',
        'timeSeriesAcl:WRITE': 'Time Series: Write Time Series',
        
        # Events
        'eventsAcl': 'Events: Read Events',
        'eventsAcl:READ': 'Events: Read Events',
        'eventsAcl:WRITE': 'Events: Write Events',
        
        # Assets
        'assetsAcl': 'Assets: Read Assets',
        'assetsAcl:READ': 'Assets: Read Assets',
        'assetsAcl:WRITE': 'Assets: Write Assets',
        
        # Sequences
        'sequencesAcl': 'Sequences: Read Sequences',
        'sequencesAcl:READ': 'Sequences: Read Sequences',
        'sequencesAcl:WRITE': 'Sequences: Write Sequences',
        
        # Relationships
        'relationshipsAcl': 'Relationships: Read Relationships',
        'relationshipsAcl:READ': 'Relationships: Read Relationships',
        'relationshipsAcl:WRITE': 'Relationships: Write Relationships',
        
        # Labels
        'labelsAcl': 'Labels: Read Labels',
        'labelsAcl:READ': 'Labels: Read Labels',
        'labelsAcl:CREATE': 'Labels: Create Labels',
        
        # Annotations
        'annotationsAcl': 'Annotations: Read Annotations',
        'annotationsAcl:READ': 'Annotations: Read Annotations',
        'annotationsAcl:WRITE': 'Annotations: Write Annotations'
    }
    
    # Try to get a readable name, fallback to original if not found
    readable_name = capability_mapping.get(cap_type, cap_type if cap_type else "Unknown")
    if readable_name is None:
        readable_name = "Unknown"
    
    # If it has scope details, include key information
    scope = capability.get('scope', {})
    if scope and isinstance(scope, dict) and scope != {}:
        # Add scope info for context
        if 'all' in str(scope).lower():
            readable_name += " (All Resources)"
        elif 'datasetscope' in str(scope).lower():
            readable_name += " (Dataset Scoped)"
        elif scope:
            readable_name += " (Scoped Access)"
    
    return readable_name

def safe_serialize_capability(cap: Dict) -> str:
    """Safely serialize a capability to JSON string, handling non-serializable objects."""
    try:
        return json.dumps(cap, sort_keys=True)
    except TypeError:
        # If direct serialization fails, convert all values to strings
        safe_cap = {}
        for key, value in cap.items():
            if isinstance(value, dict):
                safe_value = {}
                for k, v in value.items():
                    safe_value[k] = str(v)
                safe_cap[key] = safe_value
            else:
                safe_cap[key] = str(value)
        return json.dumps(safe_cap, sort_keys=True)

def add_capability_to_group(client: CogniteClient, group_name: str, capability: Dict) -> Tuple[bool, str]:
    """Add a missing capability to a CDF group."""
    try:
        # Get the group first
        groups = client.iam.groups.list()
        target_group = None
        for group in groups:
            if group.name == group_name:
                target_group = group
                break
        
        if not target_group:
            return False, f"Group '{group_name}' not found"
        
        # This is a placeholder - the actual implementation would depend on the CDF SDK
        # and the specific capability structure
        # For now, we'll just return a success message indicating what would be done
        cap_name = capability.get('capability', 'Unknown')
        scope_info = capability.get('scope', {})
        
        return True, f"Would add capability '{cap_name}' with scope {scope_info} to group '{group_name}'"
        
    except Exception as e:
        return False, f"Error adding capability: {str(e)}"

def parse_env_content(env_content: str) -> Dict[str, str]:
    """Parse .env file content into a dictionary."""
    env_vars = {}
    for line in env_content.strip().split('\n'):
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            key, value = line.split('=', 1)
            # Remove quotes if present
            value = value.strip('"').strip("'")
            env_vars[key.strip()] = value
    return env_vars

def create_cdf_client(env_vars: Dict[str, str]) -> Tuple[Optional[CogniteClient], Optional[str]]:
    """Create CDF client from environment variables."""
    try:
        required_vars = ['CDF_CLUSTER', 'CDF_PROJECT', 'IDP_CLIENT_ID', 'IDP_CLIENT_SECRET', 'IDP_TENANT_ID']
        missing_vars = [var for var in required_vars if var not in env_vars]
        
        if missing_vars:
            return None, f"Missing required variables: {', '.join(missing_vars)}"
        
        # Create client configuration
        credentials = OAuthClientCredentials(
            token_url=f"https://login.microsoftonline.com/{env_vars['IDP_TENANT_ID']}/oauth2/v2.0/token",
            client_id=env_vars['IDP_CLIENT_ID'],
            client_secret=env_vars['IDP_CLIENT_SECRET'],
            scopes=[f"https://{env_vars['CDF_CLUSTER']}.cognitedata.com/.default"]
        )
        
        config = ClientConfig(
            client_name="cdf-group-compare",
            project=env_vars['CDF_PROJECT'],
            credentials=credentials,
            base_url=f"https://{env_vars['CDF_CLUSTER']}.cognitedata.com"
        )
        
        client = CogniteClient(config)
        
        # Test connection
        client.iam.token.inspect()
        
        return client, None
        
    except Exception as e:
        return None, f"Authentication failed: {str(e)}"

def get_all_groups_details(client: CogniteClient) -> Tuple[Optional[Dict[str, Dict]], Optional[str]]:
    """Get detailed information for all groups from CDF."""
    try:
        groups = client.iam.groups.list()
        all_groups = {}
        
        for group in groups:
            # Get detailed group information
            group_details = {
                'name': group.name,
                'id': group.id,
                'source_id': getattr(group, 'source_id', None),
                'capabilities': [],
                'metadata': getattr(group, 'metadata', {})
            }
            
            # Get capabilities
            if hasattr(group, 'capabilities') and group.capabilities:
                for cap in group.capabilities:
                    # Convert scope to serializable format
                    scope = getattr(cap, 'scope', {})
                    if scope:
                        # Convert scope object to dictionary
                        if hasattr(scope, '__dict__'):
                            scope_dict = {}
                            for key, value in scope.__dict__.items():
                                # Convert non-serializable values to strings
                                if hasattr(value, '__dict__') or callable(value):
                                    scope_dict[key] = str(value)
                                else:
                                    scope_dict[key] = value
                            scope = scope_dict
                        else:
                            scope = str(scope)
                    
                    cap_dict = {
                        'capability': getattr(cap, 'capability_name', str(cap)),
                        'scope': scope,
                    }
                    group_details['capabilities'].append(cap_dict)
            
            all_groups[group.name] = group_details
        
        return all_groups, None
        
    except Exception as e:
        return None, f"Error retrieving groups: {str(e)}"

def compare_all_groups(groups1: Dict[str, Dict], groups2: Dict[str, Dict], env1_name: str, env2_name: str, group_mappings: Optional[Dict[str, str]] = None) -> Dict:
    """Compare all groups between two environments."""
    if group_mappings is None:
        group_mappings = {}
    
    # Create reverse mapping for easier lookup
    reverse_mappings = {v: k for k, v in group_mappings.items()}
    
    # Get all unique group names, considering mappings
    all_group_names = set(groups1.keys()) | set(groups2.keys())
    
    comparison = {
        'summary': {
            'total_groups': len(all_group_names),
            'common_groups': 0,
            'only_in_env1': 0,
            'only_in_env2': 0,
            'groups_with_differences': 0
        },
        'groups_in_both': {},
        'only_in_env1': {},
        'only_in_env2': {}
    }
    
    # Track processed groups to avoid duplicates
    processed_groups = set()
    
    for group_name in all_group_names:
        if group_name in processed_groups:
            continue
            
        # Check if this group has a mapping
        mapped_group_name = group_mappings.get(group_name)
        reverse_mapped_name = reverse_mappings.get(group_name)
        
        if mapped_group_name:
            # group_name in env1 maps to mapped_group_name in env2
            group1 = groups1.get(group_name)
            group2 = groups2.get(mapped_group_name)
            display_name = f"{group_name} ↔ {mapped_group_name}"
            processed_groups.add(group_name)
            processed_groups.add(mapped_group_name)
        elif reverse_mapped_name:
            # group_name in env2 maps to reverse_mapped_name in env1
            group1 = groups1.get(reverse_mapped_name)
            group2 = groups2.get(group_name)
            display_name = f"{reverse_mapped_name} ↔ {group_name}"
            processed_groups.add(reverse_mapped_name)
            processed_groups.add(group_name)
        else:
            # No mapping, try exact match
            group1 = groups1.get(group_name)
            group2 = groups2.get(group_name)
            display_name = group_name
            processed_groups.add(group_name)
        
        if group1 and group2:
            # Group exists in both environments (either exact match or mapped)
            comparison['summary']['common_groups'] += 1
            group_comparison = compare_single_group(group1, group2, env1_name, env2_name)
            comparison['groups_in_both'][display_name] = group_comparison
            
            # Check if there are differences
            has_differences = False
            for field_info in group_comparison['basic_info'].values():
                if not field_info['identical']:
                    has_differences = True
                    break
            
            if not has_differences:
                caps = group_comparison['capabilities']
                if caps['only_in_env1'] or caps['only_in_env2']:
                    has_differences = True
            
            if has_differences:
                comparison['summary']['groups_with_differences'] += 1
                
        elif group1 and not group2:
            # Group only in environment 1
            comparison['summary']['only_in_env1'] += 1
            comparison['only_in_env1'][group_name] = group1
        elif group2 and not group1:
            # Group only in environment 2
            comparison['summary']['only_in_env2'] += 1
            comparison['only_in_env2'][group_name] = group2
    
    return comparison

def compare_single_group(group1: Dict, group2: Dict, env1_name: str, env2_name: str) -> Dict:
    """Compare two individual group detail dictionaries."""
    comparison = {
        'basic_info': {},
        'capabilities': {
            'identical': [],
            'only_in_env1': [],
            'only_in_env2': []
        }
    }
    
    # Compare basic info
    basic_fields = ['name', 'id', 'source_id']
    for field in basic_fields:
        val1 = group1.get(field)
        val2 = group2.get(field)
        comparison['basic_info'][field] = {
            env1_name: val1,
            env2_name: val2,
            'identical': val1 == val2
        }
    
    # Compare capabilities
    caps1 = {safe_serialize_capability(cap): cap for cap in group1.get('capabilities', [])}
    caps2 = {safe_serialize_capability(cap): cap for cap in group2.get('capabilities', [])}
    
    all_cap_keys = set(caps1.keys()) | set(caps2.keys())
    
    for cap_key in all_cap_keys:
        cap1 = caps1.get(cap_key)
        cap2 = caps2.get(cap_key)
        
        if cap1 and cap2:
            comparison['capabilities']['identical'].append(cap1)
        elif cap1 and not cap2:
            comparison['capabilities']['only_in_env1'].append(cap1)
        elif cap2 and not cap1:
            comparison['capabilities']['only_in_env2'].append(cap2)
    
    return comparison

def display_missing_group_details(group_details: Dict, env1_name: str, env2_name: str, missing_type: str):
    """Display detailed information for a completely missing group."""
    
    # Show basic group information
    st.write("**📋 Group Information:**")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.write(f"**Name:** {group_details.get('name', 'N/A')}")
    with col2:
        st.write(f"**ID:** {group_details.get('id', 'N/A')}")
    with col3:
        st.write(f"**Source ID:** {group_details.get('source_id', 'N/A')}")
    
    # Show all capabilities with high visibility
    capabilities = group_details.get('capabilities', [])
    if capabilities:
        st.write(f"**🔐 All Capabilities ({len(capabilities)} total):**")
        st.warning(f"⚠️ All {len(capabilities)} capabilities below need to be recreated in the missing environment!")
        
        # Group capabilities by readable type for better organization
        cap_by_type = {}
        for cap in capabilities:
            readable_name = get_readable_capability_name(cap)
            base_name = readable_name.split(':')[0] if ':' in readable_name else readable_name
            if base_name not in cap_by_type:
                cap_by_type[base_name] = []
            cap_by_type[base_name].append((cap, readable_name))
        
        # Display capabilities grouped by type
        for cap_category, cap_list in cap_by_type.items():
            st.write(f"**{cap_category.title()}** ({len(cap_list)} capabilities):")
            for i, (cap, readable_name) in enumerate(cap_list):
                with st.expander(f"📜 {readable_name}"):
                    # Show capability in a more readable format
                    cap_display = {k: v for k, v in cap.items() if v is not None}
                    
                    # Display key information prominently
                    st.write(f"**Readable Name:** `{readable_name}`")
                    st.write(f"**Technical Name:** `{cap.get('capability', 'Unknown')}`")
                    
                    # Show full details
                    st.write("**Full Configuration:**")
                    st.json(cap_display)
                    
                    # Add copy-friendly format for recreation
                    st.write("**For Recreation:**")
                    st.code(str(cap_display), language="json")
    else:
        st.info("ℹ️ This group has no capabilities defined.")
    
    # Show impact analysis
    st.write("**💥 Impact Analysis:**")
    if missing_type == "missing_from_env2":
        st.error(f"🎯 **Action Required:** Create this group in {env2_name} with all {len(capabilities)} capabilities above")
    else:
        st.error(f"🎯 **Action Required:** Create this group in {env1_name} with all {len(capabilities)} capabilities above")
    
    # Show recreation checklist and bulk actions
    if capabilities:
        st.write("**✅ Recreation Checklist:**")
        st.markdown(f"""
        1. Create group with name: `{group_details.get('name', 'N/A')}`
        2. Add all {len(capabilities)} capabilities listed above
        3. Verify source_id matches: `{group_details.get('source_id', 'N/A')}`
        4. Test access permissions after creation
        """)
        
        # Bulk capability addition feature
        st.write("**🚀 Quick Actions:**")
        col1, col2 = st.columns(2)
        with col1:
            if st.button(f"📋 Copy All Capabilities", key=f"copy_caps_{group_details.get('name', 'unknown')}"):
                import json
                caps_json = json.dumps([cap for cap in capabilities], indent=2)
                st.code(caps_json, language="json")
                st.success("✅ All capabilities formatted for recreation!")
        
        with col2:
            target_env = env2_name if missing_type == "missing_from_env2" else env1_name
            if st.button(f"➕ Add All to {target_env}", key=f"add_all_caps_{group_details.get('name', 'unknown')}"):
                st.info("🔧 **Bulk Capability Addition**")
                st.write(f"This feature would create the group '{group_details.get('name')}' in {target_env} and add all {len(capabilities)} capabilities.")
                st.warning("⚠️ This is a preview - actual implementation requires:")
                st.markdown("""
                - Group creation API call
                - Capability addition for each capability
                - Error handling and rollback
                - Confirmation dialog
                """)

def display_all_groups_comparison(comparison: Dict, env1_name: str, env2_name: str):
    """Display the comprehensive group comparison results in Streamlit."""
    st.header("🔍 Complete Group Access Comparison")
    
    # Summary Dashboard
    st.subheader("📊 Summary Dashboard")
    summary = comparison['summary']
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Groups", summary['total_groups'])
    with col2:
        st.metric("Common Groups", summary['common_groups'])
    with col3:
        st.metric("Groups with Differences", summary['groups_with_differences'])
    with col4:
        health_score = round((summary['common_groups'] - summary['groups_with_differences']) / max(summary['common_groups'], 1) * 100, 1)
        st.metric("Health Score", f"{health_score}%")
    
    col1, col2 = st.columns(2)
    with col1:
        st.metric(f"Only in {env1_name}", summary['only_in_env1'])
    with col2:
        st.metric(f"Only in {env2_name}", summary['only_in_env2'])
    
    # Missing Groups Analysis
    if comparison['only_in_env1'] or comparison['only_in_env2']:
        st.subheader("⚠️ Missing Groups - Full Capability Review")
        
        if comparison['only_in_env1']:
            st.error(f"**🚨 Groups missing from {env2_name} ({len(comparison['only_in_env1'])} groups):**")
            st.markdown("These groups exist in the source environment but are completely missing from the target. Review all capabilities below:")
            
            for group_name, group_details in comparison['only_in_env1'].items():
                with st.expander(f"❌ Missing Group: {group_name}", expanded=False):
                    display_missing_group_details(group_details, env1_name, env2_name, "missing_from_env2")
        
        if comparison['only_in_env2']:
            st.error(f"**🚨 Groups missing from {env1_name} ({len(comparison['only_in_env2'])} groups):**")
            st.markdown("These groups exist in the target environment but are completely missing from the source. Review all capabilities below:")
            
            for group_name, group_details in comparison['only_in_env2'].items():
                with st.expander(f"❌ Missing Group: {group_name}", expanded=False):
                    display_missing_group_details(group_details, env1_name, env2_name, "missing_from_env1")
    
    # Groups with Differences
    if comparison['groups_in_both']:
        st.subheader("🔍 Detailed Group Analysis")
        
        # Create filter for groups with differences only
        show_only_differences = st.checkbox("Show only groups with differences", value=True)
        
        for group_name, group_comparison in comparison['groups_in_both'].items():
            # Check if group has differences
            has_differences = False
            for field_info in group_comparison['basic_info'].values():
                if not field_info['identical']:
                    has_differences = True
                    break
            
            if not has_differences:
                caps = group_comparison['capabilities']
                if caps['only_in_env1'] or caps['only_in_env2']:
                    has_differences = True
            
            # Skip if showing only differences and this group has none
            if show_only_differences and not has_differences:
                continue
            
            # Display group comparison
            status_icon = "❌" if has_differences else "✅"
            with st.expander(f"{status_icon} {group_name}"):
                display_single_group_comparison(group_comparison, env1_name, env2_name, group_name)

def display_single_group_comparison(comparison: Dict, env1_name: str, env2_name: str, group_name: str):
    """Display comparison for a single group."""
    
    # Capabilities Analysis (Primary Focus)
    st.write("**🔐 Capabilities Analysis**")
    caps = comparison['capabilities']
    
    # Summary metrics with prominent display
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Identical", len(caps['identical']), help="Capabilities that match exactly")
    with col2:
        st.metric(f"Missing from {env2_name}", len(caps['only_in_env1']), 
                 delta=f"-{len(caps['only_in_env1'])}" if caps['only_in_env1'] else None,
                 delta_color="inverse")
    with col3:
        st.metric(f"Missing from {env1_name}", len(caps['only_in_env2']),
                 delta=f"-{len(caps['only_in_env2'])}" if caps['only_in_env2'] else None,
                 delta_color="inverse")
    with col4:
        total_caps = len(caps['identical']) + len(caps['only_in_env1']) + len(caps['only_in_env2'])
        health_pct = round(len(caps['identical']) / max(total_caps, 1) * 100, 1)
        st.metric("Health %", f"{health_pct}%")
    
    # Critical Differences First - with Add Capability buttons
    if caps['only_in_env1']:
        st.error(f"**🚨 Missing from {env2_name} ({len(caps['only_in_env1'])} capabilities):**")
        for i, cap in enumerate(caps['only_in_env1']):
            readable_name = get_readable_capability_name(cap)
            with st.expander(f"❌ {readable_name}"):
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write(f"**Readable Name:** `{readable_name}`")
                    st.write(f"**Technical Name:** `{cap.get('capability', 'Unknown')}`")
                    st.write("**Full Configuration:**")
                    st.json(cap)
                with col2:
                    if st.button(f"➕ Add to {env2_name}", key=f"add_cap_env2_{group_name}_{i}", 
                                 help=f"Add this capability to the {group_name} group in {env2_name}"):
                        st.info("🔧 **Capability Addition Feature**")
                        st.write("This feature would add the missing capability to the target group.")
                        st.code(f"add_capability_to_group(client2, '{group_name}', {cap})")
                        st.warning("⚠️ This is a preview - actual implementation requires proper CDF SDK integration")
    
    if caps['only_in_env2']:
        st.error(f"**🚨 Missing from {env1_name} ({len(caps['only_in_env2'])} capabilities):**")
        for i, cap in enumerate(caps['only_in_env2']):
            readable_name = get_readable_capability_name(cap)
            with st.expander(f"❌ {readable_name}"):
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write(f"**Readable Name:** `{readable_name}`")
                    st.write(f"**Technical Name:** `{cap.get('capability', 'Unknown')}`")
                    st.write("**Full Configuration:**")
                    st.json(cap)
                with col2:
                    if st.button(f"➕ Add to {env1_name}", key=f"add_cap_env1_{group_name}_{i}",
                                 help=f"Add this capability to the {group_name} group in {env1_name}"):
                        st.info("🔧 **Capability Addition Feature**")
                        st.write("This feature would add the missing capability to the target group.")
                        st.code(f"add_capability_to_group(client1, '{group_name}', {cap})")
                        st.warning("⚠️ This is a preview - actual implementation requires proper CDF SDK integration")
    
    # Show identical capabilities in a collapsed section
    if caps['identical']:
        with st.expander(f"✅ Identical Capabilities ({len(caps['identical'])})"):
            for i, cap in enumerate(caps['identical']):
                readable_name = get_readable_capability_name(cap)
                st.write(f"**{i+1}. {readable_name}**")
                if st.checkbox(f"Show details for {readable_name}", key=f"show_{group_name}_{i}"):
                    st.json(cap)
    
    # Success message for perfect matches
    if caps['identical'] and not caps['only_in_env1'] and not caps['only_in_env2']:
        st.success("✅ Perfect match! All capabilities are identical between environments")
    
    # Basic Information (Secondary, Collapsed)
    with st.expander("📋 Basic Group Information"):
        basic_data = []
        for field, values in comparison['basic_info'].items():
            status = "✅ Identical" if values['identical'] else "❌ Different"
            # Convert all values to strings to avoid Arrow serialization issues
            env1_value = str(values[env1_name]) if values[env1_name] is not None else "None"
            env2_value = str(values[env2_name]) if values[env2_name] is not None else "None"
            basic_data.append({
                'Field': field.replace('_', ' ').title(),
                env1_name: env1_value,
                env2_name: env2_value,
                'Status': status
            })
        
        df_basic = pd.DataFrame(basic_data)
        st.dataframe(df_basic, use_container_width=True)

def main():
    st.set_page_config(
        page_title="CDF Group Access Comparison",
        page_icon="🔍",
        layout="wide"
    )
    
    st.title("🔍 CDF Complete Group Access Audit")
    st.markdown("Comprehensive comparison of ALL group access permissions between two CDF instances for troubleshooting and environment validation.")
    
    # Check for local mode (can be set via environment variable or query param)
    local_mode = os.environ.get('STREAMLIT_LOCAL_MODE', '').lower() == 'true' or st.experimental_get_query_params().get('local', ['false'])[0].lower() == 'true'
    
    if local_mode:
        st.info("🏠 **Local Development Mode** - Using pre-configured .env files")
        
        # Pre-configured local .env files
        env1_path = os.path.expanduser("~/envs/.env.bluefield.cog-bgfast.bgfast")
        env2_path = os.path.expanduser("~/envs/.env.az-eastus-1.cog-demos.z-brent")
        
        # Try to load the files automatically
        env1_vars = {}
        env2_vars = {}
        env1_project_name = "Environment 1"
        env2_project_name = "Environment 2"
        env1_name = "Environment 1"
        env2_name = "Environment 2"
        
        try:
            if os.path.exists(env1_path):
                with open(env1_path, 'r') as f:
                    env1_content = f.read()
                env1_vars = parse_env_content(env1_content)
                env1_project_name = env1_vars.get('CDF_PROJECT', 'Environment 1')
                env1_name = env1_project_name
                st.success(f"✅ **Environment 1 Loaded:** `{env1_project_name}`")
                cluster1 = env1_vars.get('CDF_CLUSTER', 'Unknown')
                st.caption(f"🌐 **Cluster:** `{cluster1}` | 📁 **File:** `{env1_path}`")
                # Debug info
                st.write(f"🔧 **Debug:** Found {len(env1_vars)} variables in env1")
            else:
                st.error(f"❌ Environment 1 file not found: `{env1_path}`")
                
            if os.path.exists(env2_path):
                with open(env2_path, 'r') as f:
                    env2_content = f.read()
                env2_vars = parse_env_content(env2_content)
                env2_project_name = env2_vars.get('CDF_PROJECT', 'Environment 2')
                env2_name = env2_project_name
                st.success(f"✅ **Environment 2 Loaded:** `{env2_project_name}`")
                cluster2 = env2_vars.get('CDF_CLUSTER', 'Unknown')
                st.caption(f"🌐 **Cluster:** `{cluster2}` | 📁 **File:** `{env2_path}`")
                # Debug info
                st.write(f"🔧 **Debug:** Found {len(env2_vars)} variables in env2")
            else:
                st.error(f"❌ Environment 2 file not found: `{env2_path}`")
                
        except Exception as e:
            st.error(f"Error loading local .env files: {str(e)}")
            import traceback
            st.code(traceback.format_exc())
            local_mode = False  # Fall back to upload mode
        
        # Set flags for the rest of the logic (don't use file-like objects)
        env1_file_loaded = bool(env1_vars)
        env2_file_loaded = bool(env2_vars)
        env1_file = None  # No actual file object in local mode
        env2_file = None  # No actual file object in local mode
        
    else:
        # SaaS Mode - File upload interface
        st.header("📁 Environment Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Environment 1")
            env1_file = st.file_uploader(
                "Upload first .env file",
                type=None,
                key="env1",
                help="Upload the .env file for the first CDF environment"
            )
            
            # Auto-populate project name if file is uploaded and display as info
            env1_project_name = "Environment 1"
            env1_name = "Environment 1"
            env1_vars = {}
            if env1_file is not None:
                try:
                    env1_content = env1_file.read().decode('utf-8')
                    env1_vars = parse_env_content(env1_content)
                    env1_project_name = env1_vars.get('CDF_PROJECT', 'Environment 1')
                    env1_name = env1_project_name
                    # Reset file pointer for later use
                    env1_file.seek(0)
                    # Display project info
                    st.info(f"📋 **CDF Project:** `{env1_project_name}`")
                    cluster = env1_vars.get('CDF_CLUSTER', 'Unknown')
                    st.caption(f"🌐 **CDF Cluster:** `{cluster}`")
                except Exception:
                    env1_project_name = "Environment 1"
                    env1_name = "Environment 1"
        
        with col2:
            st.subheader("Environment 2")
            env2_file = st.file_uploader(
                "Upload second .env file",
                type=None,
                key="env2",
                help="Upload the .env file for the second CDF environment"
            )
            
            # Auto-populate project name if file is uploaded and display as info
            env2_project_name = "Environment 2"
            env2_name = "Environment 2"
            env2_vars = {}
            if env2_file is not None:
                try:
                    env2_content = env2_file.read().decode('utf-8')
                    env2_vars = parse_env_content(env2_content)
                    env2_project_name = env2_vars.get('CDF_PROJECT', 'Environment 2')
                    env2_name = env2_project_name
                    # Reset file pointer for later use
                    env2_file.seek(0)
                    # Display project info
                    st.info(f"📋 **CDF Project:** `{env2_project_name}`")
                    cluster = env2_vars.get('CDF_CLUSTER', 'Unknown')
                    st.caption(f"🌐 **CDF Cluster:** `{cluster}`")
                except Exception:
                    env2_project_name = "Environment 2"
                    env2_name = "Environment 2"
    
    # Group Mapping Section (only show if both files are loaded)
    group_mappings = {}
    files_available = (local_mode and env1_file_loaded and env2_file_loaded) or (not local_mode and env1_file and env2_file)
    if files_available:
        st.header("🔗 Group Mapping (Optional)")
        st.markdown("Specify groups that should be compared together despite having different names.")
        
        with st.expander("Configure Group Mappings", expanded=False):
            st.info("💡 Example: Map 'superuser' from Environment 1 to 'Superusers' from Environment 2")
            
            # Get group names for autocomplete - both local and SaaS mode should work
            try:
                # In SaaS mode, read from uploaded files  
                if not local_mode and env1_file is not None and env2_file is not None:
                    env1_content = env1_file.read().decode('utf-8')
                    temp_env1_vars = parse_env_content(env1_content)
                    env1_file.seek(0)  # Reset file pointer
                    
                    env2_content = env2_file.read().decode('utf-8') 
                    temp_env2_vars = parse_env_content(env2_content)
                    env2_file.seek(0)  # Reset file pointer
                    
                    # Use temporary vars for group loading
                    mapping_env1_vars = temp_env1_vars
                    mapping_env2_vars = temp_env2_vars
                else:
                    # In local mode, use the already loaded vars
                    mapping_env1_vars = env1_vars
                    mapping_env2_vars = env2_vars
                
                # Debug: Show what variables we're using
                st.write(f"🔧 **Debug Mapping Variables:**")
                st.write(f"Local mode: {local_mode}")
                st.write(f"Env1 vars keys: {list(mapping_env1_vars.keys())[:5]}...")  # Show first 5 keys
                st.write(f"Env2 vars keys: {list(mapping_env2_vars.keys())[:5]}...")
                
                # Create temporary clients to get group names
                client1, error1 = create_cdf_client(mapping_env1_vars)
                client2, error2 = create_cdf_client(mapping_env2_vars)
                
                if error1:
                    st.error(f"Connection error for {env1_project_name}: {error1}")
                if error2:
                    st.error(f"Connection error for {env2_project_name}: {error2}")
                
                if client1 and client2:
                    st.info("🔄 Loading groups from both environments for mapping...")
                    groups1, groups1_error = get_all_groups_details(client1)
                    groups2, groups2_error = get_all_groups_details(client2)
                    
                    if groups1 and groups2:
                        group_names_1 = sorted(groups1.keys())
                        group_names_2 = sorted(groups2.keys())
                        
                        st.success(f"✅ Loaded {len(group_names_1)} groups from {env1_project_name} and {len(group_names_2)} groups from {env2_project_name}")
                        
                        # Show potential matches for convenience
                        potential_matches = []
                        for g1 in group_names_1:
                            for g2 in group_names_2:
                                if g1.lower() == g2.lower() and g1 != g2:
                                    potential_matches.append((g1, g2))
                        
                        if potential_matches:
                            st.info(f"💡 **Potential name mismatches detected:** {', '.join([f'{g1}↔{g2}' for g1, g2 in potential_matches])}")
                        
                        # Interface for adding mappings
                        num_mappings = st.number_input("Number of group mappings", min_value=0, max_value=10, value=0)
                        
                        for i in range(num_mappings):
                            col1, col2 = st.columns(2)
                            with col1:
                                group1_select = st.selectbox(
                                    f"Group from {env1_project_name}",
                                    [""] + group_names_1,
                                    key=f"group1_{i}",
                                    help=f"Select from {len(group_names_1)} available groups"
                                )
                            with col2:
                                group2_select = st.selectbox(
                                    f"Group from {env2_project_name}",
                                    [""] + group_names_2,
                                    key=f"group2_{i}",
                                    help=f"Select from {len(group_names_2)} available groups"
                                )
                            
                            if group1_select and group2_select:
                                group_mappings[group1_select] = group2_select
                        
                        if group_mappings:
                            st.success(f"✅ {len(group_mappings)} group mapping(s) configured")
                            for g1, g2 in group_mappings.items():
                                st.write(f"• {g1} ↔ {g2}")
                    else:
                        st.error(f"Failed to load groups: {groups1_error or groups2_error}")
                else:
                    st.error(f"Failed to connect: {error1 or error2}")
                                
            except Exception as e:
                st.warning(f"Could not load groups for mapping interface: {str(e)}")
                import traceback
                st.code(traceback.format_exc())
    
    # Compare button
    if st.button("🔍 Compare All Groups", type="primary"):
        # Check if files are available based on mode
        if local_mode:
            if not env1_file_loaded or not env2_file_loaded:
                st.error("Local mode files are not available - please check .env file paths")
                return
        else:
            if not env1_file or not env2_file:
                st.error("Please upload both .env files")
                return
        
        # Parse environment files (if not already done in local mode)
        try:
            if not local_mode and env1_file is not None and env2_file is not None:
                env1_content = env1_file.read().decode('utf-8')
                env2_content = env2_file.read().decode('utf-8')
                
                env1_vars = parse_env_content(env1_content)
                env2_vars = parse_env_content(env2_content)
            # In local mode, env1_vars and env2_vars are already loaded above
            
        except Exception as e:
            st.error(f"Error reading .env files: {str(e)}")
            return
        
        # Create progress indicators
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        # Create CDF clients
        status_text.text(f"Connecting to {env1_project_name}...")
        progress_bar.progress(25)
        
        client1, error1 = create_cdf_client(env1_vars)
        if error1 or client1 is None:
            st.error(f"Failed to connect to {env1_project_name}: {error1}")
            return
        
        status_text.text(f"Connecting to {env2_project_name}...")
        progress_bar.progress(50)
        
        client2, error2 = create_cdf_client(env2_vars)
        if error2 or client2 is None:
            st.error(f"Failed to connect to {env2_project_name}: {error2}")
            return
        
        # Get all groups details
        status_text.text(f"Retrieving all groups from {env1_project_name}...")
        progress_bar.progress(75)
        
        groups1, error1 = get_all_groups_details(client1)
        if error1 or groups1 is None:
            st.error(f"Error from {env1_project_name}: {error1}")
            return
        
        status_text.text(f"Retrieving all groups from {env2_project_name}...")
        progress_bar.progress(85)
        
        groups2, error2 = get_all_groups_details(client2)
        if error2 or groups2 is None:
            st.error(f"Error from {env2_project_name}: {error2}")
            return
        
        status_text.text("Comparing all groups...")
        progress_bar.progress(95)
        
        # Use project names directly
        project1_name = env1_project_name
        project2_name = env2_project_name
        
        # Compare and display results
        comparison = compare_all_groups(groups1, groups2, project1_name, project2_name, group_mappings)
        
        # Clear progress indicators
        progress_bar.empty()
        status_text.empty()
        
        # Display results
        display_all_groups_comparison(comparison, project1_name, project2_name)
        
        # Success message
        st.success("✅ Comparison completed successfully!")

if __name__ == "__main__":
    main() 