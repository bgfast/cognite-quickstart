#!/bin/bash

# CDF Group Comparison Streamlit Startup Script
# This script starts the Group Comparison Streamlit with pre-configured environment files

echo "🚀 Starting CDF Group Comparison Streamlit..."
echo "📁 Using .env files:"
echo "   - Environment 1: ~/envs/.env.bluefield.cog-bgfast.bgfast"
echo "   - Environment 2: ~/envs/.env.az-eastus-1.cog-demos.z-brent"

# Check if .env files exist
ENV1_FILE="$HOME/envs/.env.bluefield.cog-bgfast.bgfast"
ENV2_FILE="$HOME/envs/.env.az-eastus-1.cog-demos.z-brent"

if [ ! -f "$ENV1_FILE" ]; then
    echo "❌ Error: Environment file not found: $ENV1_FILE"
    exit 1
fi

if [ ! -f "$ENV2_FILE" ]; then
    echo "❌ Error: Environment file not found: $ENV2_FILE"
    exit 1
fi

echo "✅ Both environment files found"

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Change to the streamlit directory
cd "$SCRIPT_DIR"

# Set local mode and start streamlit
echo "🌟 Starting Streamlit in LOCAL MODE on http://localhost:8501"
echo "🏠 Local mode enabled - .env files will be loaded automatically"
echo ""

export STREAMLIT_LOCAL_MODE=true
streamlit run main.py --server.port 8501 