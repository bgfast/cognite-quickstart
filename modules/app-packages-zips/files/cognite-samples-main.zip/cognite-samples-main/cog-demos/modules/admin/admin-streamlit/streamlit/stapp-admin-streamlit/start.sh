#!/bin/bash

# Admin Streamlit Startup Script
# This script properly loads the GitHub token and starts the admin streamlit

echo "🚀 Starting Admin Streamlit..."

# Load GitHub token from environment file
if [ -f "$HOME/envs/.env.github" ]; then
    echo "✅ Loading GitHub token from ~/envs/.env.github"
    GITHUB_TOKEN="$(grep 'GITHUB_TOKEN=' ~/envs/.env.github | cut -d'=' -f2)"
    export GITHUB_TOKEN
else
    echo "⚠️  GitHub token file not found at ~/envs/.env.github"
    echo "Please ensure you have a GitHub token configured"
fi

# Start Streamlit with proper environment variable
echo "🌐 Starting Streamlit on port 8501..."
env GITHUB_TOKEN="$GITHUB_TOKEN" streamlit run main.py --server.port 8501

echo "�� Streamlit stopped" 