import streamlit as st
import requests
import zipfile
import tempfile
import os
import subprocess
import json
import base64
import urllib.parse
import re
from pathlib import Path
from cognite.client import CogniteClient
import time

# --- Global Initialization ---
CLIENT = None
IS_LOCAL_ENV = False

# GitHub OAuth Configuration
GITHUB_CLIENT_ID = os.getenv('GITHUB_CLIENT_ID', '')
GITHUB_CLIENT_SECRET = os.getenv('GITHUB_CLIENT_SECRET', '')
GITHUB_REDIRECT_URI = os.getenv('GITHUB_REDIRECT_URI', 'http://localhost:8501')

def initialize_cdf_client():
    """Initialize CogniteClient with proper error handling for local/SaaS environments"""
    global CLIENT, IS_LOCAL_ENV
    
    try:
        CLIENT = CogniteClient()
        IS_LOCAL_ENV = False
        return True
    except Exception as e:
        # Running locally without CDF authentication
        CLIENT = None
        IS_LOCAL_ENV = True
        if st.session_state.get('debug_mode', False):
            st.warning(f"Running in LOCAL MODE: {e}")
        return False

def get_cdf_environment_info():
    """Get current CDF environment information from the connected client"""
    if not CLIENT:
        return None
    
    try:
        # Get project info
        project_info = CLIENT.config.project
        cluster_info = CLIENT.config.base_url.replace('https://', '').replace('.cognitedata.com', '')
        
        return {
            'project': project_info,
            'cluster': cluster_info,
            'base_url': CLIENT.config.base_url,
            'client_id': getattr(CLIENT.config, 'client_id', ''),
            'client_secret': getattr(CLIENT.config, 'client_secret', ''),
            'tenant_id': getattr(CLIENT.config, 'tenant_id', ''),
            'scopes': getattr(CLIENT.config, 'scopes', ''),
            'token_url': getattr(CLIENT.config, 'token_url', '')
        }
    except Exception as e:
        st.error(f"Error getting CDF environment info: {e}")
        return None

def generate_env_file_from_cdf():
    """Generate .env file content from current CDF connection"""
    env_info = get_cdf_environment_info()
    if not env_info:
        return None
    
    env_content = f"""# Generated from current CDF connection
# CDF Project Configuration
CDF_PROJECT={env_info['project']}
CDF_CLUSTER={env_info['cluster']}
CDF_URL={env_info['base_url']}

# IDP Authentication Configuration
IDP_CLIENT_ID={env_info['client_id']}
IDP_CLIENT_SECRET={env_info['client_secret']}
IDP_TENANT_ID={env_info['tenant_id']}
IDP_SCOPES={env_info['scopes']}
IDP_TOKEN_URL={env_info['token_url']}

# Optional: Function/Transformation Client Credentials
FUNCTION_CLIENT_ID=
FUNCTION_CLIENT_SECRET=
TRANSFORMATION_CLIENT_ID=
TRANSFORMATION_CLIENT_SECRET=

# Optional: Superuser Source ID
SUPERUSER_SOURCEID_ENV=
USER_IDENTIFIER=

# GitHub OAuth Configuration (for private repository access)
GITHUB_CLIENT_ID=
GITHUB_CLIENT_SECRET=
GITHUB_REDIRECT_URI=http://localhost:8501
"""
    return env_content

def parse_env_file_content(content):
    """Parse .env file content and return as dictionary"""
    env_vars = {}
    for line in content.split('\n'):
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            key, value = line.split('=', 1)
            env_vars[key.strip()] = value.strip()
    return env_vars

def validate_env_vars(env_vars):
    """Validate that required environment variables are present"""
    required_vars = ['CDF_PROJECT', 'CDF_CLUSTER']
    missing_vars = []
    
    for var in required_vars:
        if var not in env_vars or not env_vars[var]:
            missing_vars.append(var)
    
    return missing_vars

def write_env_file(env_vars, temp_dir):
    """Write environment variables to a temporary .env file"""
    env_file_path = os.path.join(temp_dir, '.env')
    with open(env_file_path, 'w') as f:
        for key, value in env_vars.items():
            f.write(f"{key}={value}\n")
    return env_file_path

def update_config_file(project_path, env_vars):
    """Update config.all.yaml with actual values from environment variables and create config.dev.yaml"""
    config_all_path = os.path.join(project_path, 'config.all.yaml')
    config_dev_path = os.path.join(project_path, 'config.dev.yaml')
    
    if not os.path.exists(config_all_path):
        return False
    
    try:
        # Read the config.all.yaml file
        with open(config_all_path, 'r') as f:
            content = f.read()
        
        # Replace the name and project fields with actual values
        if 'CDF_PROJECT' in env_vars:
            # Replace project name
            content = re.sub(
                r'project:\s*cognite-quickstart',
                f'project: {env_vars["CDF_PROJECT"]}',
                content
            )
            # Replace environment name
            content = re.sub(
                r'name:\s*cognite-quickstart',
                f'name: {env_vars["CDF_PROJECT"]}',
                content
            )
        
        # Write the updated config.all.yaml back
        with open(config_all_path, 'w') as f:
            f.write(content)
        
        # Also create config.dev.yaml (which is what the toolkit expects for dev environment)
        with open(config_dev_path, 'w') as f:
            f.write(content)
        
        return True
    except Exception as e:
        st.error(f"Error updating config file: {e}")
        return False

def update_requirements_file(project_path):
    """Update requirements.txt to include missing dependencies"""
    req_path = os.path.join(project_path, 'modules/admin/github-repo-deployer/streamlit/github-repo-deployer/requirements.txt')
    
    if not os.path.exists(req_path):
        return False
    
    try:
        # Read the requirements file
        with open(req_path, 'r') as f:
            lines = f.readlines()
        
        # Clean up the lines - remove empty lines and whitespace-only lines
        cleaned_lines = []
        for line in lines:
            line = line.strip()
            if line and not line.startswith('#'):  # Keep non-empty, non-comment lines
                cleaned_lines.append(line)
        
        # Add pyodide-http if it's not already there
        has_pyodide = any('pyodide-http' in line for line in cleaned_lines)
        if not has_pyodide:
            cleaned_lines.append('pyodide-http>=0.2.0')
        
        # Write the cleaned requirements back
        with open(req_path, 'w') as f:
            for line in cleaned_lines:
                f.write(line + '\n')
        
        return True
    except Exception as e:
        st.error(f"Error updating requirements file: {e}")
        return False

def run_command_with_env(command, env_vars=None, cwd=None):
    """Run a command with custom environment variables"""
    import subprocess
    
    # Start with current environment
    env = os.environ.copy()
    
    # Add custom environment variables if provided
    if env_vars:
        env.update(env_vars)
    
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            env=env,
            cwd=cwd
        )
        return result.returncode, result.stdout, result.stderr
    except Exception as e:
        return -1, "", str(e)

# Try to initialize CDF client
initialize_cdf_client()

def get_github_oauth_url():
    """Generate GitHub OAuth authorization URL"""
    params = {
        'client_id': GITHUB_CLIENT_ID,
        'redirect_uri': GITHUB_REDIRECT_URI,
        'scope': 'repo',
        'state': 'github_oauth_state'
    }
    return f"https://github.com/login/oauth/authorize?{urllib.parse.urlencode(params)}"

def exchange_code_for_token(code):
    """Exchange OAuth authorization code for access token"""
    url = "https://github.com/login/oauth/access_token"
    data = {
        'client_id': GITHUB_CLIENT_ID,
        'client_secret': GITHUB_CLIENT_SECRET,
        'code': code,
        'redirect_uri': GITHUB_REDIRECT_URI
    }
    headers = {'Accept': 'application/json'}
    
    try:
        response = requests.post(url, data=data, headers=headers)
        response.raise_for_status()
        return response.json().get('access_token')
    except Exception as e:
        st.error(f"Failed to exchange code for token: {e}")
        return None

def get_github_user_info(token):
    """Get GitHub user information using access token"""
    headers = {'Authorization': f'token {token}'}
    try:
        response = requests.get('https://api.github.com/user', headers=headers)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"Failed to get user info: {e}")
        return None

def parse_github_url(url):
    """Parse GitHub repository URL to extract owner and repo name"""
    import re
    
    # Remove trailing slash and .git if present
    url = url.rstrip('/')
    if url.endswith('.git'):
        url = url[:-4]  # Remove '.git' from the end
    
    # GitHub URL patterns
    patterns = [
        r'https?://github\.com/([^/]+)/([^/]+)',
        r'git@github\.com:([^/]+)/([^/]+)',
        r'github\.com/([^/]+)/([^/]+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            owner = match.group(1)
            repo = match.group(2)
            return owner, repo
    
    return None, None

def download_github_repo_zip(repo_owner, repo_name, branch="main", token=None):
    """Download a GitHub repository as a ZIP file with optional authentication"""
    if token:
        # Use authenticated API for private repos
        url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/zipball/{branch}"
        headers = {'Authorization': f'token {token}'}
    else:
        # Use public ZIP URL for public repos
        url = f"https://github.com/{repo_owner}/{repo_name}/archive/refs/heads/{branch}.zip"
        headers = {}
    
    try:
        response = requests.get(url, stream=True, headers=headers)
        response.raise_for_status()
        
        # Create a temporary file to store the ZIP
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.zip')
        
        # Download the ZIP file
        for chunk in response.iter_content(chunk_size=8192):
            temp_file.write(chunk)
        temp_file.close()
        
        return temp_file.name
        
    except requests.exceptions.RequestException as e:
        if response.status_code == 404:
            st.error(f"Repository not found or not accessible. Make sure it exists and you have access to it.")
        elif response.status_code == 403:
            st.error(f"Access denied. This might be a private repository - please authenticate with GitHub.")
        else:
            st.error(f"Failed to download repository: {e}")
        return None

def extract_zip_to_temp_dir(zip_path, extract_to=None):
    """Extract ZIP file to a temporary directory"""
    if extract_to is None:
        extract_to = tempfile.mkdtemp()
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        
        # Find the extracted folder (GitHub adds a suffix to the folder name)
        extracted_folders = [f for f in os.listdir(extract_to) if os.path.isdir(os.path.join(extract_to, f))]
        if extracted_folders:
            return os.path.join(extract_to, extracted_folders[0])
        else:
            return extract_to
            
    except zipfile.BadZipFile as e:
        st.error(f"Failed to extract ZIP file: {e}")
        return None
    except Exception as e:
        st.error(f"Error extracting files: {e}")
        return None

def run_cognite_toolkit_build(project_path, env_vars=None):
    """Run cdf build command in the project directory with optional environment variables"""
    try:
        # Use the custom command runner with environment variables
        returncode, stdout, stderr = run_command_with_env(
            'cdf build',
            env_vars=env_vars,
            cwd=project_path
        )
        
        return returncode == 0, stdout, stderr
        
    except Exception as e:
        return False, "", f"Error running build command: {e}"

def run_cognite_toolkit_deploy(project_path, env_vars=None):
    """Run cdf deploy command in the project directory with optional environment variables"""
    try:
        # Use the custom command runner with environment variables
        returncode, stdout, stderr = run_command_with_env(
            'cdf deploy',
            env_vars=env_vars,
            cwd=project_path
        )
        
        return returncode == 0, stdout, stderr
        
    except Exception as e:
        return False, "", f"Error running deploy command: {e}"

def run_cognite_toolkit_dry_run(project_path, env_vars=None):
    """Run cdf deploy --dry-run command in the project directory with optional environment variables"""
    try:
        # Use the custom command runner with environment variables
        returncode, stdout, stderr = run_command_with_env(
            'cdf deploy --dry-run',
            env_vars=env_vars,
            cwd=project_path
        )
        
        return returncode == 0, stdout, stderr
        
    except Exception as e:
        return False, "", f"Error running dry-run command: {e}"

def get_github_branches(repo_owner, repo_name, token=None):
    """Get available branches from a GitHub repository"""
    url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/branches"
    headers = {}
    if token:
        headers['Authorization'] = f'token {token}'
    
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        branches = [branch["name"] for branch in response.json()]
        return branches
        
    except requests.exceptions.RequestException as e:
        if response.status_code == 404:
            st.error(f"Repository not found or not accessible. Make sure it exists and you have access to it.")
        elif response.status_code == 403:
            st.error(f"Access denied. This might be a private repository - please authenticate with GitHub.")
        else:
            st.error(f"Failed to fetch branches: {e}")
        return []

def handle_oauth_callback():
    """Handle OAuth callback and store token"""
    query_params = st.query_params
    
    if 'code' in query_params and 'state' in query_params:
        if query_params['state'] == 'github_oauth_state':
            code = query_params['code']
            token = exchange_code_for_token(code)
            
            if token:
                user_info = get_github_user_info(token)
                if user_info:
                    st.session_state['github_token'] = token
                    st.session_state['github_user'] = user_info
                    st.success(f"✅ Successfully authenticated as {user_info.get('login', 'Unknown')}")
                    # Clear the URL parameters
                    st.query_params.clear()
                    st.rerun()
                else:
                    st.error("Failed to get user information")
            else:
                st.error("Failed to exchange code for token")

def main():
    st.set_page_config(
        page_title="GitHub Repo to CDF Deployer",
        page_icon="🚀",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    st.title("🚀 GitHub Repo to CDF Deployer")
    st.markdown("Download files from GitHub repositories (public or private) and deploy them using the Cognite toolkit")
    
    # Handle OAuth callback
    handle_oauth_callback()
    
    # Debug mode toggle
    if 'debug_mode' not in st.session_state:
        st.session_state['debug_mode'] = False
    
    with st.sidebar:
        st.header("Settings")
        st.session_state['debug_mode'] = st.toggle("Debug Mode", value=st.session_state['debug_mode'])
        
        if st.session_state['debug_mode']:
            st.markdown("**Debug Info:**")
            st.write(f"CDF Client: {'Connected' if CLIENT else 'Not Connected'}")
            st.write(f"Local Mode: {IS_LOCAL_ENV}")
            st.write(f"GitHub OAuth: {'Configured' if GITHUB_CLIENT_ID else 'Not Configured'}")
        
        # GitHub Authentication Section
        st.markdown("---")
        st.header("🔐 GitHub Authentication")
        
        if 'github_token' in st.session_state:
            user = st.session_state.get('github_user', {})
            st.success(f"✅ Authenticated as: {user.get('login', 'Unknown')}")
            st.write(f"**Name:** {user.get('name', 'N/A')}")
            st.write(f"**Email:** {user.get('email', 'N/A')}")
            
            if st.button("🚪 Logout"):
                del st.session_state['github_token']
                del st.session_state['github_user']
                st.rerun()
        else:
            st.info("🔓 Not authenticated")
            st.write("Authenticate to access private repositories")
            
            if GITHUB_CLIENT_ID:
                oauth_url = get_github_oauth_url()
                st.markdown(f'<a href="{oauth_url}" target="_self">🔑 Login with GitHub</a>', unsafe_allow_html=True)
            else:
                st.warning("⚠️ GitHub OAuth not configured")
                st.write("Set GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET environment variables")
    
    # Environment Configuration
    st.header("⚙️ Environment Configuration")
    
    # Environment file management options
    env_option = st.radio(
        "Choose how to handle environment variables:",
        ["📁 Upload .env file", "🔄 Generate from current CDF connection", "⏭️ Skip (use existing environment)"],
        help="Select how you want to provide environment variables for the deployment"
    )
    
    env_vars = {}
    
    if env_option == "📁 Upload .env file":
        st.info("📁 **Upload .env File** - Upload your own environment file")
        
        uploaded_file = st.file_uploader(
            "Choose environment file",
            type=None,
            help="Upload any environment file containing your CDF project configuration (accepts all file types)"
        )
        
        if uploaded_file is not None:
            try:
                # Read the uploaded file
                content = uploaded_file.read().decode('utf-8')
                env_vars = parse_env_file_content(content)
                
                # Validate environment variables
                missing_vars = validate_env_vars(env_vars)
                if missing_vars:
                    st.error(f"❌ Missing required environment variables: {', '.join(missing_vars)}")
                else:
                    st.success("✅ Environment file loaded successfully!")
                    
                    # Show preview of environment variables (hide sensitive values)
                    with st.expander("🔍 Preview Environment Variables"):
                        for key, value in env_vars.items():
                            if 'secret' in key.lower() or 'password' in key.lower() or 'token' in key.lower():
                                display_value = "***" + value[-4:] if len(value) > 4 else "***"
                            else:
                                display_value = value
                            st.text(f"{key}={display_value}")
                
                # Store in session state for later use
                st.session_state['env_vars'] = env_vars
                
            except Exception as e:
                st.error(f"❌ Error reading .env file: {e}")
    
    elif env_option == "🔄 Generate from current CDF connection":
        st.info("🔄 **Generate from CDF** - Create .env file from your current CDF connection")
        
        if CLIENT:
            st.success("✅ Connected to CDF! Generating environment file...")
            
            env_content = generate_env_file_from_cdf()
            if env_content:
                # Show the generated content
                st.text_area(
                    "Generated .env file content:",
                    value=env_content,
                    height=300,
                    help="Copy this content to a .env file or use it directly"
                )
                
                # Parse and store the generated environment variables
                env_vars = parse_env_file_content(env_content)
                st.session_state['env_vars'] = env_vars
                
                # Download button
                st.download_button(
                    label="📥 Download .env file",
                    data=env_content,
                    file_name="cdfenv.local.sh",
                    mime="text/plain",
                    help="Download the generated environment file"
                )
            else:
                st.error("❌ Could not generate environment file from CDF connection")
        else:
            st.warning("⚠️ **No CDF Connection** - Cannot generate environment file")
            st.write("Make sure you're running this app in a CDF environment or have proper authentication configured.")
    
    else:  # Skip option
        st.info("⏭️ **Skip Environment Setup** - Using existing environment variables")
        st.write("The deployment will use environment variables that are already available in the current environment.")
    
    st.divider()
    
    # Repository configuration
    st.header("📁 Repository Configuration")
    
    # Input method selection
    input_method = st.radio(
        "How would you like to specify the repository?",
        ["🔗 Paste GitHub URL", "✏️ Enter Owner & Name"],
        help="Choose how you want to specify the repository"
    )
    
    # Repository access type selection
    access_type = st.radio(
        "Choose repository access type:",
        ["🌐 Public Repository (No GitHub account needed)", "🔐 Private Repository (Requires GitHub account)"],
        help="Select whether you want to access a public or private repository"
    )
    
    # Initialize repo_owner and repo_name
    repo_owner = ""
    repo_name = ""
    
    # Show different UI based on input method and access type
    if "Paste GitHub URL" in input_method:
        # URL input method
        if "Public Repository" in access_type:
            st.info("🌐 **Public Repository Mode** - No GitHub account or authentication required")
            
            github_url = st.text_input(
                "GitHub Repository URL",
                value="https://github.com/bgfast/cognite-quickstart",
                help="Paste the GitHub repository URL (e.g., https://github.com/owner/repo)",
                key="public_github_url"
            )
            
            # Clear any GitHub authentication for public mode
            if 'github_token' in st.session_state:
                del st.session_state['github_token']
                del st.session_state['github_user']
        else:  # Private Repository
            st.info("🔐 **Private Repository Mode** - GitHub authentication required")
            
            # Check if user is authenticated
            if 'github_token' not in st.session_state:
                st.warning("⚠️ **Authentication Required**")
                st.write("You need to authenticate with GitHub to access private repositories.")
                st.write("Please use the login button in the sidebar to authenticate.")
                
                github_url = st.text_input(
                    "GitHub Repository URL",
                    value="",
                    help="Paste the GitHub repository URL (requires authentication)",
                    key="private_github_url",
                    disabled=True
                )
            else:
                github_url = st.text_input(
                    "GitHub Repository URL",
                    value="",
                    help="Paste the GitHub repository URL (e.g., https://github.com/owner/repo)",
                    key="private_github_url"
                )
        
        # Parse the URL
        if github_url:
            parsed_owner, parsed_repo = parse_github_url(github_url)
            if parsed_owner and parsed_repo:
                repo_owner = parsed_owner
                repo_name = parsed_repo
                st.success(f"✅ Parsed: **{repo_owner}/{repo_name}**")
            else:
                st.error("❌ Invalid GitHub URL. Please use a valid GitHub repository URL.")
                st.info("Example: `https://github.com/bgfast/cognite-quickstart`")
    
    else:  # Manual input method
        if "Public Repository" in access_type:
            st.info("🌐 **Public Repository Mode** - No GitHub account or authentication required")
            
            col1, col2 = st.columns(2)
            
            with col1:
                repo_owner = st.text_input(
                    "Repository Owner",
                    value="bgfast",
                    help="GitHub username or organization name",
                    key="public_repo_owner"
                )
            
            with col2:
                repo_name = st.text_input(
                    "Repository Name",
                    value="cognite-quickstart",
                    help="Name of the GitHub repository",
                    key="public_repo_name"
                )
            
            # Clear any GitHub authentication for public mode
            if 'github_token' in st.session_state:
                del st.session_state['github_token']
                del st.session_state['github_user']
        
        else:  # Private Repository
            st.info("🔐 **Private Repository Mode** - GitHub authentication required")
            
            # Check if user is authenticated
            if 'github_token' not in st.session_state:
                st.warning("⚠️ **Authentication Required**")
                st.write("You need to authenticate with GitHub to access private repositories.")
                st.write("Please use the login button in the sidebar to authenticate.")
                
                # Disable repository inputs
                repo_owner = st.text_input(
                    "Repository Owner",
                    value="",
                    help="GitHub username or organization name (requires authentication)",
                    key="private_repo_owner",
                    disabled=True
                )
                
                repo_name = st.text_input(
                    "Repository Name",
                    value="",
                    help="Name of the GitHub repository (requires authentication)",
                    key="private_repo_name",
                    disabled=True
                )
            else:
                # User is authenticated, show normal inputs
                col1, col2 = st.columns(2)
                
                with col1:
                    repo_owner = st.text_input(
                        "Repository Owner",
                        value="",
                        help="GitHub username or organization name",
                        key="private_repo_owner"
                    )
                
                with col2:
                    repo_name = st.text_input(
                        "Repository Name",
                        value="",
                        help="Name of the GitHub repository",
                        key="private_repo_name"
                    )
    
    # Branch selection
    if st.button("🔄 Load Branches"):
        if not repo_owner or not repo_name:
            st.error("Please provide both repository owner and name")
        else:
            with st.spinner("Loading branches..."):
                # For public repos, don't use token; for private repos, use token if available
                token = None
                if "Private Repository" in access_type:
                    token = st.session_state.get('github_token')
                    if not token:
                        st.error("Authentication required for private repositories. Please login with GitHub first.")
                        return
                
                branches = get_github_branches(repo_owner, repo_name, token)
                if branches:
                    st.session_state['available_branches'] = branches
                    st.success(f"Found {len(branches)} branches")
                else:
                    st.error("Failed to load branches")
    
    # Show branch selector if branches are loaded
    if 'available_branches' in st.session_state:
        selected_branch = st.selectbox(
            "Select Branch",
            st.session_state['available_branches'],
            index=0 if "main" not in st.session_state['available_branches'] else st.session_state['available_branches'].index("main")
        )
    else:
        selected_branch = st.text_input("Branch", value="main")
    
    st.markdown("---")
    
    # Download and deploy section
    st.header("⬇️ Download & Deploy")
    
    if st.button("🚀 Download Repository & Deploy", type="primary"):
        if not repo_owner or not repo_name:
            st.error("Please provide both repository owner and name")
            return
        
        # Check authentication for private repos
        if "Private Repository" in access_type and 'github_token' not in st.session_state:
            st.error("Authentication required for private repositories. Please login with GitHub first.")
            return
        
        # Check if environment variables are available
        env_vars = st.session_state.get('env_vars', {})
        if not env_vars and env_option != "⏭️ Skip (use existing environment)":
            st.error("Please configure environment variables first using one of the options above.")
            return
        
        # Step 1: Download repository
        with st.spinner(f"Downloading {repo_owner}/{repo_name} from branch {selected_branch}..."):
            # For public repos, don't use token; for private repos, use token
            token = None
            if "Private Repository" in access_type:
                token = st.session_state.get('github_token')
            
            zip_path = download_github_repo_zip(repo_owner, repo_name, selected_branch, token)
            
            if not zip_path:
                st.error("Failed to download repository")
                return
            
            st.success("✅ Repository downloaded successfully")
        
        # Step 2: Extract files
        with st.spinner("Extracting files..."):
            extracted_path = extract_zip_to_temp_dir(zip_path)
            
            if not extracted_path:
                st.error("Failed to extract files")
                return
            
            st.success("✅ Files extracted successfully")
            
            if st.session_state['debug_mode']:
                st.info(f"Extracted to: {extracted_path}")
        
        # Step 3: Check for config files
        config_files = []
        for config_name in ['config.all.yaml', 'config.yaml', 'config.yml']:
            config_path = os.path.join(extracted_path, config_name)
            if os.path.exists(config_path):
                config_files.append(config_name)
        
        if config_files:
            st.success(f"✅ Found configuration files: {', '.join(config_files)}")
        else:
            st.warning("⚠️ No configuration files found. The repository might not be a Cognite toolkit project.")
        
        # Step 4: Update config file, requirements, and write environment file
        if env_vars:
            # Update config.all.yaml with actual project name and create config.dev.yaml
            config_updated = update_config_file(extracted_path, env_vars)
            if config_updated:
                st.info(f"📝 Updated config files with project: {env_vars.get('CDF_PROJECT', 'unknown')}")
            
            # Update requirements.txt to include missing dependencies
            req_updated = update_requirements_file(extracted_path)
            if req_updated:
                st.info("📝 Updated requirements.txt with missing dependencies")
            
            # Write environment file
            env_file_path = write_env_file(env_vars, extracted_path)
            st.info(f"📝 Environment file written to: {env_file_path}")
        
        # Step 5: Run cdf build
        st.subheader("🔨 Building Project")
        with st.spinner("Running cdf build..."):
            build_success, build_stdout, build_stderr = run_cognite_toolkit_build(extracted_path, env_vars)
            
            if build_success:
                st.success("✅ Build completed successfully")
                
                # Always show build details in expandable section
                with st.expander("🔍 Build Details", expanded=False):
                    st.subheader("Build Output")
                    if build_stdout:
                        st.code(build_stdout, language="text")
                    else:
                        st.info("No build output available")
                    
                    st.subheader("Build Command")
                    st.code("cdf build", language="bash")
                    
                    st.subheader("Environment Variables Used")
                    if env_vars:
                        for key, value in env_vars.items():
                            if 'secret' in key.lower() or 'password' in key.lower() or 'token' in key.lower():
                                display_value = "***" + value[-4:] if len(value) > 4 else "***"
                            else:
                                display_value = value
                            st.text(f"{key}={display_value}")
                    else:
                        st.info("No environment variables provided")
            else:
                st.error("❌ Build failed")
                
                # Show build error details in expandable section
                with st.expander("🔍 Build Error Details", expanded=True):
                    st.subheader("Build Error")
                    if build_stderr:
                        st.code(build_stderr, language="text")
                    else:
                        st.info("No error details available")
                    
                    st.subheader("Build Command")
                    st.code("cdf build", language="bash")
                    
                    st.subheader("Troubleshooting")
                    st.markdown("""
                    **Common build issues:**
                    - Missing environment variables
                    - Invalid YAML syntax in config files
                    - Missing dependencies in requirements.txt
                    - Network connectivity issues
                    """)
                return
        
        # Step 6: Deploy to CDF
        st.subheader("🚀 Deploying to CDF")
        
        # Deploy options
        deploy_option = st.radio(
            "Choose deployment option:",
            ["🚀 Deploy to CDF", "🔍 Dry Run (Preview Changes)"],
            help="Deploy will make actual changes to CDF. Dry run will show what would be deployed without making changes."
        )
        
        # Note: CDF client check removed - deployment works via subprocess calls
        
        if "Deploy to CDF" in deploy_option:
            with st.spinner("Running cdf deploy..."):
                deploy_success, deploy_stdout, deploy_stderr = run_cognite_toolkit_deploy(extracted_path, env_vars)
                command_used = "cdf deploy"
            
            if deploy_success:
                st.success("🎉 Deployment completed successfully!")
                
                # Show deploy details in expandable section
                with st.expander("🔍 Deploy Details", expanded=False):
                    st.subheader("Output")
                    if deploy_stdout:
                        st.code(deploy_stdout, language="text")
                    else:
                        st.info("No output available")
                    
                    st.subheader("Command Used")
                    st.code(command_used, language="bash")
                    
                    st.subheader("Environment Variables Used")
                    if env_vars:
                        for key, value in env_vars.items():
                            if 'secret' in key.lower() or 'password' in key.lower() or 'token' in key.lower():
                                display_value = "***" + value[-4:] if len(value) > 4 else "***"
                            else:
                                display_value = value
                            st.text(f"{key}={display_value}")
                    else:
                        st.info("No environment variables provided")
            else:
                st.error("❌ Deployment failed")
                
                # Show deploy error details in expandable section
                with st.expander("🔍 Deploy Error Details", expanded=True):
                    st.subheader("Error")
                    if deploy_stderr:
                        st.code(deploy_stderr, language="text")
                    else:
                        st.info("No error details available")
                    
                    st.subheader("Command Used")
                    st.code(command_used, language="bash")
                    
                    st.subheader("Troubleshooting")
                    st.markdown("""
                    **Common deployment issues:**
                    - CDF project permissions
                    - Authentication problems
                    - Network connectivity issues
                    - Resource conflicts
                    - Invalid configuration
                    """)
        else:  # Dry Run
            with st.spinner("Running cdf deploy --dry-run..."):
                deploy_success, deploy_stdout, deploy_stderr = run_cognite_toolkit_dry_run(extracted_path, env_vars)
                command_used = "cdf deploy --dry-run"
            
            if deploy_success:
                st.success("🔍 Dry run completed successfully!")
                st.info("This was a preview of what would be deployed. No actual changes were made to CDF.")
                
                # Show dry run details in expandable section
                with st.expander("🔍 Dry Run Details", expanded=True):  # Expanded by default for dry run
                    st.subheader("Dry Run Output")
                    if deploy_stdout:
                        st.code(deploy_stdout, language="text")
                    else:
                        st.info("No output available")
                    
                    st.subheader("Command Used")
                    st.code(command_used, language="bash")
                    
                    st.subheader("Environment Variables Used")
                    if env_vars:
                        for key, value in env_vars.items():
                            if 'secret' in key.lower() or 'password' in key.lower() or 'token' in key.lower():
                                display_value = "***" + value[-4:] if len(value) > 4 else "***"
                            else:
                                display_value = value
                            st.text(f"{key}={display_value}")
                    else:
                        st.info("No environment variables provided")
            else:
                st.error("❌ Dry run failed")
                
                # Show dry run error details in expandable section
                with st.expander("🔍 Dry Run Error Details", expanded=True):
                    st.subheader("Error")
                    if deploy_stderr:
                        st.code(deploy_stderr, language="text")
                    else:
                        st.info("No error details available")
                    
                    st.subheader("Command Used")
                    st.code(command_used, language="bash")
                    
                    st.subheader("Troubleshooting")
                    st.markdown("""
                    **Common dry run issues:**
                    - CDF project permissions
                    - Authentication problems
                    - Network connectivity issues
                    - Invalid configuration
                    - Build errors
                    """)
        
        # Cleanup
        try:
            os.unlink(zip_path)  # Delete the ZIP file
            if st.session_state['debug_mode']:
                st.info(f"Cleaned up temporary files")
        except:
            pass
    
    # Information section
    st.markdown("---")
    st.header("ℹ️ Information")
    
    with st.expander("How to use this tool"):
        st.markdown("""
        This tool allows you to:
        
        1. **Download** any GitHub repository (public or private) as a ZIP file
        2. **Extract** the files to a temporary directory
        3. **Build** the project using `cdf build`
        4. **Deploy** to CDF using `cdf deploy`
        
        **Two Access Modes:**
        
        🌐 **Public Repository Mode** (Recommended for most users):
        - No GitHub account required
        - No authentication needed
        - Works with any public repository
        - Perfect for trying out Cognite samples and public projects
        
        🔐 **Private Repository Mode**:
        - Requires GitHub account and authentication
        - Access to private repositories you own or have access to
        - Use the login button in the sidebar to authenticate
        
        **Requirements:**
        - The repository should contain Cognite toolkit configuration files
        - You need to have the Cognite toolkit (`cdf`) installed
        - CDF authentication must be configured
        
        **Popular Public Repositories to Try:**
        - `cognitedata/cognite-samples` - Official Cognite samples
        - `cognitedata/cog-demos` - Cognite demo projects
        - Any other public repository with Cognite configuration
        """)
    
    with st.expander("GitHub OAuth Setup"):
        st.markdown("""
        To enable private repository access, you need to set up GitHub OAuth:
        
        1. **Create a GitHub OAuth App:**
           - Go to GitHub → Settings → Developer settings → OAuth Apps
           - Click "New OAuth App"
           - Set Authorization callback URL to: `http://localhost:8501`
        
        2. **Set Environment Variables:**
           ```bash
           export GITHUB_CLIENT_ID=your_client_id
           export GITHUB_CLIENT_SECRET=your_client_secret
           export GITHUB_REDIRECT_URI=http://localhost:8501
           ```
        
        3. **Required Scopes:**
           - `repo` (Full control of private repositories)
        """)
    
    with st.expander("Troubleshooting"):
        st.markdown("""
        **Common issues:**
        
        - **"Repository not found"**: Check repository name and owner
        - **"Access denied"**: Authenticate with GitHub for private repos
        - **"Cognite toolkit not found"**: Install with `pip install cognite-toolkit`
        - **"CDF client not available"**: Set up environment variables or authentication
        - **"Build failed"**: Check if the repository contains valid Cognite configuration
        - **"Deploy failed"**: Verify CDF project permissions and configuration
        
        **Environment setup:**
        ```bash
        # Option 1: Use environment file
        source cdfenv.sh
        
        # Option 2: Set environment variables
        export CDF_PROJECT=your-project
        export CDF_CLUSTER=your-cluster
        export IDP_CLIENT_ID=your-client-id
        export IDP_CLIENT_SECRET=your-client-secret
        ```
        """)

if __name__ == "__main__":
    main()