import streamlit as st
import json
import base64
import requests
from cognite.client import CogniteClient
import time
from cryptography.fernet import Fernet
import os
import pandas as pd
from cognite.client.data_classes.data_modeling.ids import NodeId, ViewId
# import creds  # Removed - using dynamic token management instead

# --- Global Initialization and Constants ---
# Initialize CLIENT with proper error handling for local vs SaaS environments
CLIENT = None
IS_LOCAL_ENV = False

# Environment configuration constants
ENV_DATABASE = "admin_streamlit"
ENV_TABLE = "env_configs"

def initialize_cdf_client():
    """Initialize CogniteClient with proper error handling for local/SaaS environments"""
    global CLIENT, IS_LOCAL_ENV
    
    try:
CLIENT = CogniteClient()
        IS_LOCAL_ENV = False
        return True
    except Exception as e:
        # Running locally without CDF authentication
        CLIENT = None
        IS_LOCAL_ENV = True
        if st.session_state.get('debug_mode', False):
            st.warning(f"Running in LOCAL MODE: {e}")
        return False

# Try to initialize CDF client
initialize_cdf_client()

model_id = "model_id"

TOKEN_SPACE = "gtoken_space"
TOKEN_VIEW = "gtoken_view"
TOKEN_VIEW_VERSION = "v1"
TOKEN_CONTAINER = "gtoken_container"
TOKEN_NODE_ID = "gtoken"
FKEY_NODE_ID = "fkey" # For Fernet key
REPO_OWNER = "cognitedata"
WORKFLOW_FILE_NAME = "full_run.yaml"
WORKFLOW_FILE_NAME = "dynamic_deployment.yaml"

# Predefined cluster options
cluster_options = {
    "Azure": sorted([
        "az-ams-sp-002", "az-arn-001", "az-arn-003", "az-arn-dev-002",
        "az-dsm-itcaas-001", "az-dxb-001", "az-eastus-1", "az-gru-001",
        "az-pnq-gp-001", "az-power-no-northeurope", "az-sin-sp-001",
        "az-tyo-002", "az-tyo-gp-001", "bluefield", "westeurope-1",
    ]),
    "GCP": sorted([
        "asia-northeast1-1", "cognitedata-development", "cognitedata-production",
        "cognitedata-test", "europe-west1-1", "gc-dmm-002",
        "gke-cognitedata-infra", "greenfield", "omv", "pgs", "statnett",
    ]),
    "AWS": sorted([
        "aw-dub-gp-001", "aw-was-gp-001", "aws-dub-dev", "orangefield",
    ]),
}

# --- STATIC MODULE ARRAYS ---
# static_modules_set_A = [
#     "modules/common/streamlits/in-review/tradersdashboard-petrochem"
# ]

static_modules_set_A = [
    "modules/admin",  # Admin module with GitHub token management (now using dynamic deployment)
    "modules/common/in-development-streamlits"  # Deploys all 3 dashboards!
]

static_modules_set_B = [
    "modules/industry_models/offshore_og",
    "modules/in-development/valhall_dm_extension",
    "modules/in-development/simulated_data",
]

static_modules_set_C = [
    "modules/in-development/timeseries_sync",
    "modules/in-development/live_weather_data",
    "modules/in-development/custom_access_management",
]

static_modules_set_D = list(set(
    static_modules_set_A +
    static_modules_set_B +
    static_modules_set_C +
    ["common/three_d_contextualization"]
))
static_modules_set_D.sort()

# Dictionary mapping display names to their respective static arrays
module_set_options = {
    "Admin & Streamlit Apps": static_modules_set_A,
    "Industry Specific Solutions": static_modules_set_B,
    "Data Integration & Access": static_modules_set_C,
    "All Available Modules": static_modules_set_D,
}


# --- Utility Functions ---

def decode_token(encoded_token):
    return base64.b64decode(encoded_token.encode("utf-8")).decode("utf-8")

def get_stored_token(client):
    """Retrieve encrypted GitHub token from CDF Data Modeling"""
    if client is None or IS_LOCAL_ENV:
        return None
        
    try:
        res = client.data_modeling.instances.retrieve(
            nodes=NodeId(TOKEN_SPACE, TOKEN_NODE_ID),
            sources=ViewId(TOKEN_SPACE, TOKEN_VIEW, TOKEN_VIEW_VERSION),
        )
        if not res.nodes:
            return None
        
        view_id = ViewId(TOKEN_SPACE, TOKEN_VIEW, TOKEN_VIEW_VERSION)
        encrypted_token = res.nodes[0].properties[view_id].get("token")
        if not encrypted_token:
            return None
            
        # Get encryption key and decrypt
        key = get_key(client)
        if not key:
            return None
            
        fernet = Fernet(key)
        decrypted_token = fernet.decrypt(encrypted_token.encode()).decode()
        return decrypted_token
        
    except Exception as e:
        if st.session_state.get('debug_mode', False):
            st.error(f"DEBUG: Failed to retrieve stored token: {e}")
        return None

def get_token(client):
    """Get GitHub token - try stored token first, fallback to env var"""
    # First try to get stored token from CDF (if not in local mode)
    if not IS_LOCAL_ENV:
    stored_token = get_stored_token(client)
    if stored_token:
        return stored_token
    
    # Always check environment variable as fallback (both local and SaaS modes)
    env_token = os.getenv('GITHUB_TOKEN')
    if env_token:
        return env_token
    
    # No fallback - require proper token setup
    return None

def get_key(client):
    try:
        res = client.data_modeling.instances.retrieve(
            nodes=NodeId(TOKEN_SPACE, FKEY_NODE_ID),
            sources=ViewId(TOKEN_SPACE, TOKEN_VIEW, TOKEN_VIEW_VERSION),
        )
        if not res.nodes:
            # No key stored yet, return None so a new one can be created
            return None
            
        view_id = ViewId(TOKEN_SPACE, TOKEN_VIEW, TOKEN_VIEW_VERSION)
        fkey = res.nodes[0].properties[view_id]["fkey"]
        key = base64.urlsafe_b64decode(fkey.encode("utf-8"))
        return key
    except Exception as e:
        st.error(f"Failed to retrieve Fernet key from CDF: {e}")
        return None

def encrypt_json_input(json_input, key):
    if not key:
        st.error("Encryption key is not available. Cannot encrypt.")
        return None
    try:
        fernet = Fernet(key)
        encrypted = fernet.encrypt(json_input.encode('utf-8'))
        return encrypted.decode('utf-8')
    except Exception as e:
        st.error(f"Error during encryption: {e}")
        return None

def delete_github_token(client):
    """Delete stored GitHub token and encryption key"""
    try:
        # Delete both the token and encryption key nodes
        nodes_to_delete = [
            NodeId(TOKEN_SPACE, TOKEN_NODE_ID),  # Token node
            NodeId(TOKEN_SPACE, FKEY_NODE_ID)   # Encryption key node
        ]
        
        client.data_modeling.instances.delete(nodes=nodes_to_delete)
        return True
        
    except Exception as e:
        st.error(f"Failed to delete GitHub token data: {e}")
        if st.session_state.get('debug_mode', False):
            st.error(f"DEBUG: Token deletion error: {e}")
        return False

def store_github_token(client, token):
    """Store encrypted GitHub token in CDF Data Modeling"""
    try:
        # Get or create encryption key
        key = get_key(client)
        if not key:
            # Create new encryption key
            key = Fernet.generate_key()
            key_b64 = base64.urlsafe_b64encode(key).decode()
            
            # Store the key
            key_node_data = {
                "space": TOKEN_SPACE,
                "externalId": FKEY_NODE_ID,
                "instanceType": "node",
                "sources": [{
                    "source": {
                        "space": TOKEN_SPACE,
                        "externalId": TOKEN_VIEW,
                        "version": TOKEN_VIEW_VERSION,
                        "type": "view"
                    },
                    "properties": {
                        "fkey": key_b64,
                        "created_by": get_user(client),
                        "created_at": pd.Timestamp.now().isoformat()
                    }
                }]
            }
            
            if st.session_state.get('debug_mode', False):
                st.info(f"DEBUG: Creating key node with data: {key_node_data}")
            
            key_result = client.data_modeling.instances.apply(nodes=[key_node_data])
            
            if st.session_state.get('debug_mode', False):
                st.info(f"DEBUG: Key node creation result: {key_result}")
                if hasattr(key_result, 'nodes'):
                    st.info(f"DEBUG: Key nodes created: {len(key_result.nodes)}")
                else:
                    st.info(f"DEBUG: Key result type: {type(key_result)}")
        
        # Encrypt the token
        fernet = Fernet(key)
        encrypted_token = fernet.encrypt(token.encode()).decode()
        
        # Store the encrypted token
        token_node_data = {
            "space": TOKEN_SPACE,
            "externalId": TOKEN_NODE_ID,
            "instanceType": "node",
            "sources": [{
                "source": {
                    "space": TOKEN_SPACE,
                    "externalId": TOKEN_VIEW,
                    "version": TOKEN_VIEW_VERSION,
                    "type": "view"
                },
                "properties": {
                    "token": encrypted_token,
                    "created_by": get_user(client),
                    "created_at": pd.Timestamp.now().isoformat()
                }
            }]
        }
        
        if st.session_state.get('debug_mode', False):
            st.info(f"DEBUG: Creating token node with data: {token_node_data}")
        
        token_result = client.data_modeling.instances.apply(nodes=[token_node_data])
        
        if st.session_state.get('debug_mode', False):
            st.info(f"DEBUG: Token node creation result: {token_result}")
            if hasattr(token_result, 'nodes'):
                st.info(f"DEBUG: Token nodes created: {len(token_result.nodes)}")
            else:
                st.info(f"DEBUG: Token result type: {type(token_result)}")
        
        return True
        
    except Exception as e:
        st.error(f"Failed to store GitHub token: {e}")
        if st.session_state.get('debug_mode', False):
            st.error(f"DEBUG: Token storage error: {e}")
        return False

def validate_github_token(token):
    """Validate GitHub token by testing API access"""
    if not token or len(token.strip()) < 10:
        return False, "Token is too short or empty"
    
    try:
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github.v3+json",
        }
        response = requests.get("https://api.github.com/user", headers=headers)
        
        if response.status_code == 200:
            user_data = response.json()
            return True, f"Valid token for user: {user_data.get('login', 'Unknown')}"
        elif response.status_code == 401:
            return False, "Invalid token - authentication failed"
        elif response.status_code == 403:
            return False, "Token valid but insufficient permissions"
        else:
            return False, f"API error: {response.status_code}"
            
    except Exception as e:
        return False, f"Network error: {str(e)}"

def token_exists(client):
    """Check if a GitHub token exists (either in CDF storage or as environment variable in local mode)"""
    if IS_LOCAL_ENV:
        # In local mode, check for environment variable only
        env_token = os.getenv('GITHUB_TOKEN')
        return env_token is not None and len(env_token.strip()) > 0
    
    if client is None:
        return False
        
    try:
        res = client.data_modeling.instances.retrieve(
            nodes=NodeId(TOKEN_SPACE, TOKEN_NODE_ID),
            sources=ViewId(TOKEN_SPACE, TOKEN_VIEW, TOKEN_VIEW_VERSION),
        )
        if not res.nodes:
            return False
        
        view_id = ViewId(TOKEN_SPACE, TOKEN_VIEW, TOKEN_VIEW_VERSION)
        return view_id in res.nodes[0].properties and res.nodes[0].properties[view_id].get("token") is not None
    except:
        return False

def get_user(client):
    """Retrieves the display name of the current CDF user."""
    if client is None or IS_LOCAL_ENV:
        return "Local User"
        
    try:
    my_profile = client.iam.user_profiles.me()
        user_profiles = client.iam.user_profiles.list(limit=None)
    user_name = "Unknown"
    try:
        for u in user_profiles:
            if u.user_identifier == my_profile.user_identifier:
                user_name = u.display_name
                break
    except Exception as e:
        user_name = "Unknown"
    if st.session_state.get('debug_mode', False):
        st.info(f"DEBUG: Current CDF User: {user_name}")
    return user_name
    except Exception as e:
        if st.session_state.get('debug_mode', False):
            st.error(f"DEBUG: Failed to get user: {e}")
        return "Local User"


def get_github_branches(repo_owner, repo_name, github_token):
    """Fetches all branch names from a specified GitHub repository."""
    url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/branches"
    headers = {
        "Authorization": f"Bearer {github_token}",
        "Accept": "application/vnd.github.v3+json",
    }
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        branches = [branch["name"] for branch in response.json()]
        if st.session_state.get('debug_mode', False):
            st.info(f"DEBUG: Successfully fetched branches for {repo_owner}/{repo_name}.")
        return branches
    else:
        st.error(f"Failed to fetch branches: {response.status_code} - {response.text}")
        if st.session_state.get('debug_mode', False):
            st.error(f"DEBUG: Failed to fetch branches: {response.status_code} - {response.text}")
        return []

def trigger_clean_workflow(
    repo_owner,
    repo_name,
    workflow_file_name,
    branch,
    github_token,
    environment,
    modules=None,
    env_content=None,
):
    """Trigger a clean workflow to remove deployed modules"""
    try:
        url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/actions/workflows/{workflow_file_name}/dispatches"
        
        # Prepare clean workflow inputs
        inputs = {
            "environment": environment,
            "action": "clean",
            "modules": modules if modules else "",
            "dry_run": "false"  # Can be made configurable
        }
        
        # Add environment content if provided
        if env_content:
            inputs["env_content"] = env_content
        
        payload = {
            "ref": branch,
            "inputs": inputs
        }
        
        headers = {
            "Authorization": f"token {github_token}",
            "Accept": "application/vnd.github.v3+json",
            "Content-Type": "application/json",
        }
        
        if st.session_state.get('debug_mode', False):
            st.write("DEBUG: Clean workflow payload:", payload)
        
        response = requests.post(url, json=payload, headers=headers)
        
        if response.status_code == 204:
            return True
        else:
            st.error(f"Failed to trigger clean workflow. Status: {response.status_code}")
            if st.session_state.get('debug_mode', False):
                st.error(f"DEBUG: Response: {response.text}")
            return False
            
    except Exception as e:
        st.error(f"Error triggering clean workflow: {e}")
        if st.session_state.get('debug_mode', False):
            st.error(f"DEBUG: Clean workflow error: {e}")
        return False

def trigger_workflow(
    repo_owner,
    repo_name,
    workflow_file_name,
    branch,
    github_token,
    json_config_data,
    environment,
    provider,
    create_environment_flag,
    create_group_flag,
    modules,
    days_replication,
    days_replication_shift,
    model_id,
    parameters_3d,
    env_content=None,
):
    """
    Triggers a GitHub Actions workflow using the GitHub API.
    This function is used for both main deployments and GitHub config setup.
    """
    url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/actions/workflows/{workflow_file_name}/dispatches"
    headers = {
        "Authorization": f"Bearer {github_token}",
        "Accept": "application/vnd.github.v3+json",
    }

    if create_environment_flag == "yes":
        ENCRYPTION_KEY = get_key(CLIENT)
        if ENCRYPTION_KEY is None:
            st.error("Cannot proceed with encryption: Key not retrieved.")
            return None
        encrypted_json_config = encrypt_json_input(json_config_data, ENCRYPTION_KEY)
        if encrypted_json_config is None:
            st.error("Encryption failed.")
            return None
    else:
        encrypted_json_input = json_config_data
        
    # Extract cluster from environment content, fallback to default if not found
    cluster_value = "az-eastus-1"  # Default fallback
    if env_content:
        extracted_cluster = extract_env_value(env_content, 'CDF_CLUSTER')
        if extracted_cluster:
            cluster_value = extracted_cluster
        
    payload = {
        "ref": branch,
        "inputs": {
            # "config": encrypted_json_input,
            "environment": environment,
            # "provider": provider,
            # "create_environment": create_environment_flag,
            # "create_group": create_group_flag,
            "cluster": cluster_value,

            "modules": modules,
            "days_replication": days_replication,
            "days_replication_shift": days_replication_shift,
            "model_id": "model_id",
            "parameters_3d": parameters_3d,
        },
    }
    
    # Add environment content if provided
    if env_content:
        payload["inputs"]["env_content"] = env_content
    if st.session_state.get('debug_mode', False):
        st.success("DEBUG: Sending payload to GitHub:")
        st.json(payload)

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 204:
        if st.session_state.get('debug_mode', False):
            st.success("DEBUG: Workflow dispatch successful (Status 204).")
        runs_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/actions/runs?branch={branch}&event=workflow_dispatch&per_page=1"
        runs_response = requests.get(runs_url, headers=headers)
        if runs_response.status_code == 200:
            runs_data = runs_response.json()
            if "workflow_runs" in runs_data and len(runs_data["workflow_runs"]) > 0:
                latest_run = runs_data["workflow_runs"][0]
                if st.session_state.get('debug_mode', False):
                    st.success(f"DEBUG: Latest workflow run ID found: {latest_run['id']}.")
                return latest_run["id"]
        if st.session_state.get('debug_mode', False):
            st.warning("DEBUG: Could not retrieve latest workflow run ID.")
        return None
    else:
        st.error(f"Failed to trigger workflow: {response.status_code} - {response.text}")
        if st.session_state.get('debug_mode', False):
            st.error(f"DEBUG: GitHub API Error: {response.text}")
        return None

# --- Main Deployment Page ---
def main_deployment_page():
    # Prominent debug indicator at the top
    if st.session_state.get('debug_mode', False):
        st.markdown("<h3 style='color:green;'>DEBUG MODE IS ON</h3>", unsafe_allow_html=True)

    # Environment indicator - commented out for clean UI
    # if IS_LOCAL_ENV:
    #     st.info("🏠 **Running in LOCAL mode** - Limited CDF integration available")
    # else:
    #     # st.success("☁️ **Running in SaaS mode** - Full CDF integration available")  # Debug - commented out for clean UI
    #     pass

    st.title("CDF Module Deployment")
    st.markdown("Deploy CDF modules to any environment with custom configuration")
    
    # Check GitHub token status
    token_exists_result = token_exists(CLIENT)
    if not token_exists_result:
        st.error("🔐 **GitHub token not configured!**")
        if IS_LOCAL_ENV:
            st.warning("**For local mode:** Set the GITHUB_TOKEN environment variable in your shell.")
            st.code("export GITHUB_TOKEN=$(grep 'GITHUB_TOKEN=' ~/envs/.env.github | cut -d'=' -f2)")
        else:
        st.warning("A GitHub Personal Access Token is required for deployments to work.")
        col1, col2 = st.columns([1, 3])
        with col1:
            if st.button("🔧 Setup Token"):
                st.session_state['page_selection'] = "Token Settings"
                st.rerun()
        with col2:
            st.info("Go to **Token Settings** to configure your GitHub token first.")
        st.markdown("---")
    else:
        if IS_LOCAL_ENV:
            # st.success("🔐 **GitHub token found** in environment variable")  # Debug - commented out for clean UI
            pass
        else:
            # Test token validity for SaaS mode
        current_token = get_stored_token(CLIENT)
        if current_token:
            is_valid, message = validate_github_token(current_token)
            if is_valid:
                    # st.success("🔐 GitHub token configured and valid")  # Debug - commented out for clean UI
                    pass
            else:
                st.error(f"🔐 **GitHub token issue:** {message}")
                if st.button("🔧 Fix Token"):
                    st.session_state['page_selection'] = "Token Settings"
                    st.rerun()
        st.markdown("---")

    # Hardcoded repo and branch for the main deployment page (not displayed)
    repo_name_fixed = "cognite-samples"
    branch_fixed = "main"  # Use main branch with env_content support
    
    github_token_fixed = get_token(CLIENT)
    
    # GitHub token status indicator
    if github_token_fixed:
        # st.success("✅ GitHub token detected")  # Debug - commented out for clean UI
        pass
    else:
        st.error("❌ GitHub token not found - buttons will be disabled")
        st.write("**Troubleshooting:**")
        st.write("• For local mode: Ensure GITHUB_TOKEN environment variable is set")
        st.write("• For SaaS mode: Configure token in Token Settings page")

    # # CDF Project Name: label on left, input on right, with white background
    # # Removed columns for label and input to place input directly below label
    # st.markdown("CDF Project Name:") # Label is now directly rendered markdown
    # cdf_project = st.text_input(
    #     label="CDF Project Name", # Label is still needed for functionality
    #     label_visibility="hidden", # Hide the label, as we manually placed it
    #     value=st.session_state.get("main_cdf_project", ""),
    #     key="main_cdf_project",
    #     help="Name of the CDF project where modules will be deployed. The CDF Cluster will be determined by your GitHub Action configuration."
    # )
    # --- Environment Configuration Section ---
    st.header("🌍 Environment Configuration")
    
    # Environment source selection
    # Create options based on environment mode
    env_options = []
    if IS_LOCAL_ENV:
        env_options.append("Local ~/envs files")  # Only available in local mode
    env_options.append("Upload .env file")
    # env_options.append("Previously stored configs")  # Commented out - testing later
    
    env_source = st.radio(
        "Select environment source:",
        env_options,
        key="env_source",
        help="Choose where to get environment configuration from"
    )
    
    # Initialize session state for selected environment content
    if 'selected_env_content' not in st.session_state:
        st.session_state['selected_env_content'] = None
    
    selected_env_content = None
    
    if env_source == "Local ~/envs files":
        local_files = get_local_env_files()
        if local_files:
            env_options = [f"{name} ({path})" for name, path in local_files]
            selected_env = st.selectbox(
                "Choose environment file:",
                ["Select an environment..."] + env_options,
                key="local_env_selection"
            )
            
            if selected_env != "Select an environment...":
                # Extract file path from selection
                selected_path = selected_env.split(" (")[1].rstrip(")")
                selected_env_content = read_env_file(selected_path)
                if selected_env_content:
                    # Store in session state immediately
                    st.session_state['selected_env_content'] = selected_env_content
                    # st.success(f"✅ Loaded environment from: {os.path.basename(selected_path)}")  # Debug - commented out for clean UI
                    # Show non-sensitive info and set CDF project
                    project = extract_env_value(selected_env_content, 'CDF_PROJECT') or 'Unknown'
                    cluster = extract_env_value(selected_env_content, 'CDF_CLUSTER') or 'Unknown'
                    # Store CDF project in session state for button validation
                    if project != 'Unknown':
                        st.session_state["main_cdf_project"] = project
                    # st.info(f"📍 Project: {project} | 🌐 Cluster: {cluster}")  # Debug - commented out for clean UI
            else:
                # Clear session state if no environment selected
                st.session_state['selected_env_content'] = None
                if "main_cdf_project" in st.session_state:
                    del st.session_state["main_cdf_project"]
        else:
            st.warning("No .env files found in ~/envs directory")
            
    elif env_source == "Upload .env file":
        uploaded_file = st.file_uploader(
            "Upload your .env file",
            type=None,
            help="Select a .env file from your local computer (any file type allowed)",
            key="env_file_upload"
        )
        
        if uploaded_file is not None:
            selected_env_content = str(uploaded_file.read(), "utf-8")
            # Sanitize the content to remove Windows carriage returns
            selected_env_content = sanitize_env_content(selected_env_content)
            # Store in session state immediately
            st.session_state['selected_env_content'] = selected_env_content
            # st.success("✅ Environment file uploaded successfully")  # Debug - commented out for clean UI
            
            # Option to save for future use - Commented out for testing later
            # col1, col2 = st.columns([1, 2])
            # with col1:
            #     save_for_future = st.checkbox("Save for future use", key="save_env_checkbox")
            # with col2:
            #     if save_for_future:
            #         config_name = st.text_input(
            #             "Configuration name:",
            #             value=uploaded_file.name.replace('.env.', '').replace('.env', ''),
            #             key="env_config_name"
            #         )
            #         if st.button("💾 Save Configuration") and config_name:
            #             if save_env_config_to_cdf(CLIENT, config_name, selected_env_content):
            #                 st.success(f"Configuration '{config_name}' saved successfully!")
            
            # Show non-sensitive info and set CDF project
            if selected_env_content:
                project = extract_env_value(selected_env_content, 'CDF_PROJECT') or 'Unknown'
                cluster = extract_env_value(selected_env_content, 'CDF_CLUSTER') or 'Unknown'
                # Store CDF project in session state for button validation
                if project != 'Unknown':
                    st.session_state["main_cdf_project"] = project
                # st.info(f"📍 Project: {project} | 🌐 Cluster: {cluster}")  # Debug - commented out for clean UI
        else:
            # Clear session state if no file uploaded
            st.session_state['selected_env_content'] = None
            if "main_cdf_project" in st.session_state:
                del st.session_state["main_cdf_project"]
                
    # Previously stored configs section - Commented out for testing later
    # elif env_source == "Previously stored configs":
    #     stored_configs = get_stored_env_configs(CLIENT)
    #     if stored_configs:
    #         config_options = [f"{config['name']} (uploaded {config['uploaded_date'][:10]})" for config in stored_configs]
    #         selected_config = st.selectbox(
    #             "Choose stored configuration:",
    #             ["Select a configuration..."] + config_options,
    #             key="stored_config_selection"
    #         )
    #         
    #         if selected_config != "Select a configuration...":
    #             # Extract config name and load content
    #             config_name = selected_config.split(" (uploaded")[0]
    #             config_key = next(c['key'] for c in stored_configs if c['name'] == config_name)
    #             selected_env_content = load_env_config_from_cdf(CLIENT, config_key)
    #             
    #             if selected_env_content:
    #                 # Store in session state immediately
    #                 st.session_state['selected_env_content'] = selected_env_content
    #                 st.success(f"✅ Loaded stored configuration: {config_name}")
    #                 # Show non-sensitive info and set CDF project
    #                 lines = selected_env_content.split('\n')
    #                 project = next((line.split('=')[1] for line in lines if line.startswith('CDF_PROJECT=')), 'Unknown')
    #                 cluster = next((line.split('=')[1] for line in lines if line.startswith('CDF_CLUSTER=')), 'Unknown')
    #                 # Store CDF project in session state for button validation
    #                 if project != 'Unknown':
    #                     st.session_state["main_cdf_project"] = project
    #                 st.info(f"📍 Project: {project} | 🌐 Cluster: {cluster}")
    #         else:
    #             # Clear session state if no config selected
    #             st.session_state['selected_env_content'] = None
    #             if "main_cdf_project" in st.session_state:
    #                 del st.session_state["main_cdf_project"]
    #     else:
    #         st.info("No stored configurations found")
    

    
    st.markdown("---")

    # --- CDF Project Configuration (after environment setup) ---
    # Auto-populate CDF Project from environment file if available
    env_project = None
    if st.session_state.get('selected_env_content'):
        env_project = extract_env_value(st.session_state['selected_env_content'], 'CDF_PROJECT')
    
    # Only show CDF Project input if no environment file is selected AND not in local mode
    if not env_project and not IS_LOCAL_ENV:
        col1, col2 = st.columns([0.3, 0.7])
        with col1:
            st.markdown("#### CDF Project Name:")
    with col2:
        cdf_project = st.text_input(
                label="CDF Project Name",
                label_visibility="hidden",
            value=st.session_state.get("main_cdf_project", ""),
            key="main_cdf_project",
                help="Name of the CDF project where modules will be deployed. (Or select an environment file above)"
            )
    else:
        # Use project from environment file and update session state, or get from env in local mode
        if env_project:
            st.session_state["main_cdf_project"] = env_project
            cdf_project = env_project
        else:
            # In local mode, project comes from environment file selection
            cdf_project = st.session_state.get("main_cdf_project", "")
        # st.success(f"✅ **CDF Project**: {env_project} (from environment configuration)")  # Debug - commented out for clean UI
    
    st.markdown("---")

    # CDF Cluster input removed from main page (as per request)
    cdf_cluster_actual_value = "" # Pass empty string, workflow will infer from GitHub Env Vars

    # --- Optional Deployment Configurations (Commented out) ---
    # st.header("Optional Deployment Configurations")
    # 
    # # Replication Options
    # run_replication = st.checkbox(
    #     "**Enable Data Replication**",
    #     value=st.session_state.get("main_run_replication", False),
    #     help="Tick to replicate historical data points. Specify days to go back and optional time shift.",
    #     key="main_run_replication"
    # )
    # st.session_state["main_run_replication"] = run_replication
    # 
    # days_replication = 0 # Initialize as int for calculations
    # days_replication_shift = 0 # Initialize as int for calculations
    # if run_replication:
    #     with st.expander("Replication Settings", expanded=True):
    #         days_replication = st.number_input(
    #             "Number of days for replication:",
    #             value=st.session_state.get("main_days_replication", 30),
    #             min_value=1,
    #             max_value=730,
    #             help="Specify how many days to go back for historical data replication (1-730 days).",
    #             key="main_days_replication"
    #         )
    #         days_replication_shift = st.number_input(
    #             "Number of days to shift datapoints:",
    #             value=st.session_state.get("main_days_replication_shift", 7),
    #             min_value=0,
    #             max_value=7,
    #             help="Shift timedata for public datapoints (0-7 days).",
    #             key="main_days_replication_shift"
    #         )
    #     st.session_state["main_days_replication"] = days_replication
    #     st.session_state["main_days_replication_shift"] = days_replication_shift
    # 
    # days_replication_str = str(days_replication)
    # days_replication_shift_str = str(days_replication_shift)
    # 
    # # 3D Contextualization Options
    # run_3d_contextualization = st.checkbox(
    #     "**Enable 3D Contextualization**",
    #     value=st.session_state.get("main_run_3d_contextualization", False),
    #     help="Tick to run 3D contextualization. Requires a 3D model manually uploaded to CDF.",
    #     key="main_run_3d_contextualization"
    # )
    # st.session_state["main_run_3d_contextualization"] = run_3d_contextualization
    # 
    # model_id = ""
    # revision_id = ""
    # three_d_contextualization_module_path = "common/three_d_contextualization"
    # 
    # if run_3d_contextualization:
    #     st.warning(
    #         "Ensure you have uploaded a 3D model to CDF and your project is configured for Data Modeling."
    #     )
    #     with st.expander("3D Model Details", expanded=True):
    #         model_id = st.text_input(
    #             "3D Model ID (Mandatory):",
    #             value=st.session_state.get("main_model_id", ""),
    #             help="Enter the ID of the 3D model in CDF.",
    #             key="main_model_id"
    #         )
    #         revision_id = st.text_input(
    #             "3D Model Revision ID (Mandatory):",
    #             value=st.session_state.get("main_revision_id", ""),
    #             help="Enter the revision ID of the 3D model in CDF.",
    #             key="main_revision_id"
    #         )
    #     st.session_state["main_model_id"] = model_id
    #     st.session_state["main_revision_id"] = revision_id
    # else:
    #     # Clear values in session state if checkbox is unticked
    #     if "main_model_id" in st.session_state: del st.session_state["main_model_id"]
    #     if "main_revision_id" in st.session_state: del st.session_state["main_revision_id"]
    #     model_id = ""
    #     revision_id = ""
    # 
    # parameters_3d_json_str = json.dumps({"revision_id": revision_id})
    # 
    # st.markdown("---") # Separator below optional config
    # End of commented out optional configurations

    # --- Initialize optional config variables (needed for payload) ---
    days_replication_str = "0"
    days_replication_shift_str = "0"
    model_id = ""
    parameters_3d_json_str = "{}" # Empty JSON string

    # --- Common Validation for all Deploy Buttons ---
    common_validation_errors = []

    # Only validate CDF project in SaaS mode - in local mode it comes from env file
    if not IS_LOCAL_ENV and not st.session_state.get("main_cdf_project"):
        common_validation_errors.append("CDF project not set")

    if not github_token_fixed:
        common_validation_errors.append("GitHub token could not be retrieved. Check setup.")
    
    # Validation for commented out optional configurations (if they were enabled)
    # if st.session_state.get("main_run_replication", False):
    #     if st.session_state.get("main_days_replication", 0) == 0 or st.session_state.get("main_days_replication_shift", 0) == 0:
    #         common_validation_errors.append(
    #             "Replication days and shift must be greater than 0 if replication is enabled."
    #         )
    # if st.session_state.get("main_run_3d_contextualization", False):
    #     if not st.session_state.get("main_model_id") or not st.session_state.get("main_revision_id"):
    #         common_validation_errors.append(
    #             "3D Model ID and Revision ID are mandatory if 3D contextualization is enabled."
    #         )

    if common_validation_errors:
        for msg in common_validation_errors:
            st.warning(f"**Warning:** {msg}")
    
    common_inputs_are_valid = not common_validation_errors and bool(st.session_state.get("main_cdf_project"))

    # st.header("Select & Deploy Module Sets")

    user = get_user(CLIENT)
    create_environment_flag = "no"
    create_group_flag = "no"
    provider = "entra_id" # Default provider for main deployments

    json_config_data_base = json.dumps({
        "environmentName": get_sanitized_cdf_project(),
        "branchName": branch_fixed,
        "create_environment": create_environment_flag,
        "create_group": create_group_flag,
        "user": user,
        "items": [ # Minimal set for workflow to identify project
            {"name": "CDF_PROJECT", "value": get_sanitized_cdf_project()},
            {"name": "PROVIDER", "value": provider},
            # CDF_CLUSTER is removed from here and must be inferred by GitHub Action workflow
        ]
    })


    # --- Display Each Module Set with its Own Deploy Button in 2x2 Grid ---
    # Create a list of all set names to iterate through
    all_set_names = list(module_set_options.keys())
    
    # Iterate through rows and columns
    for i in range(0, len(all_set_names), 2): # Iterate by 2 for 2 columns per row
        col1, col2 = st.columns(2) # Create two columns for this row
        
        # Process first item in the row (col1)
        with col1:
            set_name = all_set_names[i]
            modules_list = module_set_options[set_name]
            
            # Create subheader with help icon
            title_col, help_col = st.columns([0.8, 0.2])
            with title_col:
            st.subheader(f"{set_name}")
            with help_col:
                # Create help text showing all modules
                help_text = f"**Modules included in '{set_name}':**\n\n"
                for module in modules_list:
                    help_text += f"• {module}  \n"  # Two spaces for line break in markdown
                st.markdown("❓", help=help_text)
            
            current_modules_to_deploy = list(modules_list) # Make a mutable copy
            # The logic for conditionally adding 3D module if enabled is commented out
            # along with optional configs, but if re-enabled, it would go here.

            modules_comma_separated_col1 = ",".join(current_modules_to_deploy)
            disable_current_button_col1 = not common_inputs_are_valid
            model_id=""
            
            # Deploy and Clean buttons in two columns
            deploy_col, clean_col = st.columns([1, 1])
            
            with deploy_col:
            if st.button(f"🚀 Deploy", disabled=disable_current_button_col1, key=f"deploy_button_{set_name}"):
                workflow_run_id = trigger_workflow(
                    REPO_OWNER,
                    repo_name_fixed,
                    WORKFLOW_FILE_NAME,
                    branch_fixed,
                    github_token_fixed,
                    json_config_data_base,
                        get_sanitized_cdf_project(), # environment
                    provider,
                    create_environment_flag,
                    create_group_flag,
                    modules_comma_separated_col1,
                    days_replication_str,
                    days_replication_shift_str,
                    model_id,
                    parameters_3d_json_str,
                        st.session_state.get('selected_env_content'), # env_content
                )

                if workflow_run_id:
                    st.success(f"Workflow for '{set_name}' triggered successfully! Monitor its progress on GitHub.")
                    st.markdown(
                        f"[View Workflow Run Here](https://github.com/{REPO_OWNER}/{repo_name_fixed}/actions/runs/{workflow_run_id})"
                    )
                    time.sleep(10)
                    st.rerun()
                else:
                    st.error(f"Failed to trigger workflow for '{set_name}'. See console for details.")
                    time.sleep(20)
                    st.rerun()

            with clean_col:
                # Clean button with confirmation
                clean_button_key = f"clean_button_{set_name}"
                confirm_key = f"confirm_clean_{set_name}"
                
                if st.button(f"🧹 Clean", disabled=disable_current_button_col1, key=clean_button_key, help="Remove deployed modules"):
                    st.session_state[confirm_key] = True
                
                # Show confirmation dialog if clean was clicked
                if st.session_state.get(confirm_key, False):
                    st.warning(f"⚠️ **Confirm Clean Operation**")
                    st.write(f"This will remove the following modules from **{st.session_state.get('main_cdf_project', '')}**:")
                    for module in current_modules_to_deploy:
                        st.write(f"• {module}")
                    
                    confirm_col, cancel_col = st.columns([1, 1])
                    
                    with confirm_col:
                        if st.button("✅ Confirm Clean", key=f"confirm_yes_{set_name}", type="primary"):
                            success = trigger_clean_workflow(
                                REPO_OWNER,
                                repo_name_fixed,
                                WORKFLOW_FILE_NAME,
                                branch_fixed,
                                github_token_fixed,
                                get_sanitized_cdf_project(),
                                modules_comma_separated_col1,
                                st.session_state.get('selected_env_content'), # env_content
                            )
                            
                            if success:
                                st.success(f"Clean operation for '{set_name}' triggered successfully!")
                                st.markdown(f"[View Progress on GitHub](https://github.com/{REPO_OWNER}/{repo_name_fixed}/actions)")
                            else:
                                st.error(f"Failed to trigger clean operation for '{set_name}'.")
                            
                            # Clear confirmation state
                            del st.session_state[confirm_key]
                            time.sleep(3)
                            st.rerun()
                    
                    with cancel_col:
                        if st.button("❌ Cancel", key=f"confirm_no_{set_name}"):
                            del st.session_state[confirm_key]
                            st.rerun()
            
            st.markdown("---") # Separator after each button block within its column

        # Process second item in the row (col2), if it exists
        if i + 1 < len(all_set_names):
            with col2:
                set_name = all_set_names[i+1]
                modules_list = module_set_options[set_name]
                
                # Create subheader with help icon
                title_col2, help_col2 = st.columns([0.8, 0.2])
                with title_col2:
                st.subheader(f"{set_name}")
                with help_col2:
                    # Create help text showing all modules
                    help_text = f"**Modules included in '{set_name}':**\n\n"
                    for module in modules_list:
                        help_text += f"• {module}  \n"  # Two spaces for line break in markdown
                    st.markdown("❓", help=help_text)
                
                current_modules_to_deploy = list(modules_list)
                # The logic for conditionally adding 3D module if enabled is commented out
                # along with optional configs, but if re-enabled, it would go here.

                modules_comma_separated_col2 = ",".join(current_modules_to_deploy)
                disable_current_button_col2 = not common_inputs_are_valid

                # Deploy and Clean buttons in two columns
                deploy_col2, clean_col2 = st.columns([1, 1])
                
                with deploy_col2:
                if st.button(f"🚀 Deploy", disabled=disable_current_button_col2, key=f"deploy_button_{set_name}"):
                    workflow_run_id = trigger_workflow(
                        REPO_OWNER,
                        repo_name_fixed,
                        WORKFLOW_FILE_NAME,
                        branch_fixed,
                        github_token_fixed,
                        json_config_data_base,
                            get_sanitized_cdf_project(),
                        provider,
                        create_environment_flag,
                        create_group_flag,
                        modules_comma_separated_col2,
                        days_replication_str,
                        days_replication_shift_str,
                        model_id,
                        parameters_3d_json_str,
                            st.session_state.get('selected_env_content'), # env_content
                    )

                    if workflow_run_id:
                        st.success(f"Workflow for '{set_name}' triggered successfully! Monitor its progress on GitHub.")
                        st.markdown(
                            f"[View Workflow Run Here](https://github.com/{REPO_OWNER}/{repo_name_fixed}/actions/runs/{workflow_run_id})"
                        )
                        time.sleep(10)
                        st.rerun()
                    else:
                        st.error(f"Failed to trigger workflow for '{set_name}'. See console for details.")
                        time.sleep(20)
                        st.rerun()

                with clean_col2:
                    # Clean button with confirmation
                    clean_button_key2 = f"clean_button2_{set_name}"
                    confirm_key2 = f"confirm_clean2_{set_name}"
                    
                    if st.button(f"🧹 Clean", disabled=disable_current_button_col2, key=clean_button_key2, help="Remove deployed modules"):
                        st.session_state[confirm_key2] = True
                    
                    # Show confirmation dialog if clean was clicked
                    if st.session_state.get(confirm_key2, False):
                        st.warning(f"⚠️ **Confirm Clean Operation**")
                        st.write(f"This will remove the following modules from **{st.session_state.get('main_cdf_project', '')}**:")
                        for module in current_modules_to_deploy:
                            st.write(f"• {module}")
                        
                        confirm_col2, cancel_col2 = st.columns([1, 1])
                        
                        with confirm_col2:
                            if st.button("✅ Confirm Clean", key=f"confirm_yes2_{set_name}", type="primary"):
                                success = trigger_clean_workflow(
                                    REPO_OWNER,
                                    repo_name_fixed,
                                    WORKFLOW_FILE_NAME,
                                    branch_fixed,
                                    github_token_fixed,
                                    get_sanitized_cdf_project(),
                                    modules_comma_separated_col2,
                                    st.session_state.get('selected_env_content'), # env_content
                                )
                                
                                if success:
                                    st.success(f"Clean operation for '{set_name}' triggered successfully!")
                                    st.markdown(f"[View Progress on GitHub](https://github.com/{REPO_OWNER}/{repo_name_fixed}/actions)")
                                else:
                                    st.error(f"Failed to trigger clean operation for '{set_name}'.")
                                
                                # Clear confirmation state
                                del st.session_state[confirm_key2]
                                time.sleep(3)
                                st.rerun()
                        
                        with cancel_col2:
                            if st.button("❌ Cancel", key=f"confirm_no2_{set_name}"):
                                del st.session_state[confirm_key2]
                                st.rerun()
                
                st.markdown("---") # Separator after each button block
    

# --- GitHub Configuration Page ---
def github_config_page():
    # Prominent debug indicator at the top
    if st.session_state.get('debug_mode', False):
        st.markdown("<h3 style='color:green;'>DEBUG MODE IS ON for GitHub Configuration Page.</h3>", unsafe_allow_html=True)

    st.title("GitHub Configuration")
    st.markdown("""
        **Note:** With the new Environment Configuration feature, most CDF credentials and settings 
        are now provided via `.env` files during deployment. This page is primarily for:
        - **Repository & Branch selection** 
        - **Initial GitHub Environment setup** (one-time)
        - **Advanced credential management** (if needed)
        
        For regular deployments, use the **Main Deployment** page with `.env` file upload.
    """)



    st.header("Repository & Branch")
    repo_name = st.selectbox(
        "Select GitHub Repository:",
        options=["cognite-samples", "uat-demo-data"],
        help="Choose the GitHub repository to configure.",
        index=0, # Default to cognite-samples
        key="config_repo_name"
    )

    github_token = get_token(CLIENT)
    branches = []
    selected_branch = None
    
    # Initialize branches cache in session state
    if 'github_branches' not in st.session_state:
        st.session_state['github_branches'] = []
    if 'branches_loaded' not in st.session_state:
        st.session_state['branches_loaded'] = False
    
    if github_token:
        col1, col2 = st.columns([2, 1])
        with col1:
            if not st.session_state['branches_loaded']:
                st.info("Click 'Load Branches' to fetch available branches from GitHub")
        with col2:
            if st.button("🔄 Load Branches", help="Fetch branches from GitHub repository"):
                with st.spinner("Loading branches..."):
        branches = get_github_branches(REPO_OWNER, repo_name, github_token)
        if branches:
                        st.session_state['github_branches'] = branches
                        st.session_state['branches_loaded'] = True
                        st.success(f"✅ Loaded {len(branches)} branches")
                    else:
                        st.error("Failed to fetch branches. Please check your GitHub token.")
        
        # Show branch selector if branches are loaded
        if st.session_state['branches_loaded'] and st.session_state['github_branches']:
            branches = st.session_state['github_branches']
            
            # Branch selector with refresh option
            col1, col2 = st.columns([3, 1])
            with col1:
                default_index = branches.index("main") if "main" in branches else 0
            selected_branch = st.selectbox(
                "Select a Branch:",
                branches,
                index=default_index,
                help="Choose the branch to associate with the GitHub Environment configuration.",
                key="config_selected_branch"
            )
            with col2:
                if st.button("🗑️ Clear", help="Clear loaded branches to fetch fresh list"):
                    st.session_state['branches_loaded'] = False
                    st.session_state['github_branches'] = []
                    st.rerun()
    else:
        st.error("GitHub token not available. Cannot fetch branches.")

    st.markdown("---")
    create_environment_flag = "no"
    
    # st.header("Environment Variables & Secrets Setup")
    # create_environment_flag = (
    #     "yes"
    #     if st.checkbox(
    #         "**Enable GitHub Environment Variables/Secrets Setup**",
    #         value=st.session_state.get('config_create_env_checkbox', True),
    #         help="Tick to configure or re-configure GitHub Environment variables and secrets. This is generally for initial setup or credential updates.",
    #         key="config_create_env_checkbox"
    #     )
    #     else "no"
    # )

    create_group_flag = "no"
   
    # create_group_flag = (
    #     "yes"
    #     if st.checkbox(
    #         "**Create/Update Toolkit Group**",
    #         value=st.session_state.get('config_create_group_checkbox', True),
    #         help="Tick if you want to create or update the group for the toolkit in CDF. This is often tied to app registration access.",
    #         key="config_create_group_checkbox"
    #     )
    #     else "no"
    # )

    # Default JSON structure for environment variables/secrets (template)
    default_json_config_template = {
        "environmentName": "", "info": "", "branchName": "",
        "items": [
            {"type": "variable", "name": "CDF_PROJECT", "info": "CDF project name", "value": "", "mandatory": True},
            {"type": "variable", "name": "IDP_TENANT_ID", "info": "Tenant ID (leave blank for CogIDP)", "value": "", "mandatory": False},
            {"type": "variable", "name": "CDF_CLUSTER", "info": "CDF cluster name", "value": "", "mandatory": True}, # CDF Cluster is collected here for GitHub Env Var
            {"type": "variable", "name": "PROVIDER", "info": "IDP provider: cdf or entra_id", "value": "cdf", "mandatory": True},
            {"type": "variable", "name": "IDP_CLIENT_ID", "info": "Toolkit client ID (app registration)", "value": "", "mandatory": True},
            {"type": "secret", "name": "IDP_CLIENT_SECRET", "info": "Toolkit client secret", "value": "", "mandatory": True},
            {"type": "variable", "name": "FUNCTION_CLIENT_ID", "info": "Optional - Function client ID", "value": "", "mandatory": False},
            {"type": "secret", "name": "FUNCTION_CLIENT_SECRET", "info": "Optional - Function client secret", "value": "", "mandatory": False},
            {"type": "variable", "name": "TRANSFORMATION_CLIENT_ID", "info": "Optional - Transformation client ID", "value": "", "mandatory": False},
            {"type": "secret", "name": "TRANSFORMATION_CLIENT_SECRET", "info": "Optional - Transformation client secret", "value": "", "mandatory": False},
            {"type": "variable", "name": "USER_IDENTIFIER", "info": "Optional - Your user identifier (for access management modules)", "value": "", "mandatory": False},
            {"type": "variable", "name": "SUPERUSER_SOURCEID_ENV", "info": "Optional - Superuser source ID from EntraID", "value": "", "mandatory": False},
            {"type": "variable", "name": "IDP_TOKEN_URL", "info": "IDP token endpoint URL", "value": "https://auth.cognite.com/oauth2/token", "mandatory": True},
            {"type": "variable", "name": "IDP_SCOPES", "info": "OAuth2 scopes for authentication", "value": "None", "mandatory": True},
            {"type": "variable", "name": "LOGIN_FLOW", "info": "OAuth2 login flow type", "value": "client_credentials", "mandatory": True},
        ],
    }

    # Initialize session state for config items values
    if 'config_items_values' not in st.session_state:
        st.session_state['config_items_values'] = {item['name']: item['value'] for item in default_json_config_template['items']}
        st.session_state['config_cdf_project_input'] = ""
        st.session_state['config_cdf_cluster_input'] = "bluefield"
        st.session_state['config_manual_cluster_input'] = ""
        st.session_state['config_provider_input'] = "cdf"
        st.session_state['config_tenant_id_input'] = ""



    
    # Simple validation - only check for branch selection
    if st.session_state.get('branches_loaded', False) and not selected_branch:
        st.warning("Please select a branch to configure.")
    elif not st.session_state.get('branches_loaded', False) and github_token:
        st.info("💡 Load branches first to continue with configuration.")

# --- Token Settings Page ---
def token_settings_page():
    """GitHub Token Management and Settings"""
    st.title("🔐 GitHub Token Settings")
    
    if st.session_state.get('debug_mode', False):
        st.markdown("<h3 style='color:green;'>DEBUG MODE IS ON</h3>", unsafe_allow_html=True)
    
    # Check current token status
    has_token = token_exists(CLIENT)
    current_token = get_stored_token(CLIENT) if has_token else None
    
    # Debug information
    if st.session_state.get('debug_mode', False):
        st.info(f"DEBUG: has_token = {has_token}")
        st.info(f"DEBUG: current_token exists = {current_token is not None}")
        if current_token:
            st.info(f"DEBUG: current_token length = {len(current_token)}")
        
        # Test raw data retrieval
        try:
            if CLIENT is not None and not IS_LOCAL_ENV:
            res = CLIENT.data_modeling.instances.retrieve(
                nodes=NodeId(TOKEN_SPACE, TOKEN_NODE_ID),
                sources=ViewId(TOKEN_SPACE, TOKEN_VIEW, TOKEN_VIEW_VERSION),
            )
            st.info(f"DEBUG: Raw node retrieval - found {len(res.nodes)} nodes")
            if res.nodes:
                view_id = ViewId(TOKEN_SPACE, TOKEN_VIEW, TOKEN_VIEW_VERSION)
                properties = res.nodes[0].properties
                st.info(f"DEBUG: Node properties keys: {list(properties.keys())}")
                if view_id in properties:
                    st.info(f"DEBUG: View properties: {list(properties[view_id].keys())}")
            else:
                st.info("DEBUG: Running in local mode - CDF data modeling not available")
        except Exception as e:
            st.error(f"DEBUG: Error retrieving raw data: {e}")
    
    # Status display
    col1, col2 = st.columns([2, 1])
    
    with col1:
        if has_token and current_token:
            st.success("✅ GitHub token is configured and stored securely")
            
            # Test current token
            if st.button("🧪 Test Current Token"):
                with st.spinner("Testing token..."):
                    is_valid, message = validate_github_token(current_token)
                    if is_valid:
                        st.success(f"✅ {message}")
                    else:
                        st.error(f"❌ {message}")
        else:
            st.warning("⚠️ No GitHub token configured")
            st.info("A GitHub Personal Access Token is required for deployment operations.")
    
    with col2:
        if has_token:
            st.metric("Token Status", "Configured", "✅")
        else:
            st.metric("Token Status", "Not Set", "❌")
    
    st.markdown("---")
    
    # Token management section
    if has_token:
        st.subheader("🔄 Update Token")
        st.info("Enter a new token to replace the existing one.")
    else:
        st.subheader("🔧 First-time Setup")
        st.info("Enter your GitHub Personal Access Token to enable deployment features.")
        
        with st.expander("📋 How to create a GitHub Personal Access Token", expanded=False):
            st.markdown("""
            1. Go to GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
            2. Click "Generate new token (classic)"
            3. Give it a descriptive name (e.g., "CDF Admin Deployment")
            4. Select expiration (recommend 90 days for security)
            5. Select scopes:
               - `repo` (Full control of private repositories)
               - `workflow` (Update GitHub Action workflows)
               - `read:org` (Read org and team membership)
            6. Click "Generate token"
            7. **Copy the token immediately** (you won't see it again!)
            """)
    
    # Token input form
    with st.form("token_form"):
        new_token = st.text_input(
            "GitHub Personal Access Token",
            type="password",
            placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            help="Your GitHub Personal Access Token with repo and workflow permissions"
        )
        
        col1, col2, col3 = st.columns([1, 1, 2])
        
        with col1:
            validate_button = st.form_submit_button("🧪 Validate Token")
        
        with col2:
            save_button = st.form_submit_button("💾 Save Token")
        
        # Handle validation
        if validate_button and new_token:
            with st.spinner("Validating token..."):
                is_valid, message = validate_github_token(new_token)
                if is_valid:
                    st.success(f"✅ {message}")
                    st.info("Token is valid! You can now save it.")
                else:
                    st.error(f"❌ {message}")
        elif validate_button:
            st.warning("Please enter a token to validate")
        
        # Handle saving
        if save_button and new_token:
            with st.spinner("Validating and saving token..."):
                # Validate first
                is_valid, message = validate_github_token(new_token)
                if is_valid:
                    # Save token
                    if store_github_token(CLIENT, new_token):
                        st.success("✅ Token saved successfully!")
                        st.info("The token is encrypted and stored securely in CDF.")
                        st.info("🔄 Refreshing page to update status...")
                        time.sleep(2)
                        st.rerun()
                    else:
                        st.error("❌ Failed to save token. Please try again.")
                else:
                    st.error(f"❌ Cannot save invalid token: {message}")
        elif save_button:
            st.warning("Please enter a token to save")
    
    # Advanced settings
    if has_token:
        st.markdown("---")
        st.subheader("⚠️ Advanced Settings")
        
        with st.expander("🗑️ Remove Token & Reset System", expanded=False):
            st.warning("This will permanently remove the stored GitHub token and encryption key.")
            st.markdown("**What will be deleted:**")
            st.markdown("- 🔑 Encrypted GitHub token")
            st.markdown("- 🔐 Encryption key")
            st.markdown("- 📊 All token metadata")
            st.markdown("")
            st.markdown("**Consequences:**")
            st.markdown("- Deployment operations will fail until reconfigured")
            st.markdown("- You'll need to set up a new token from scratch")
            st.markdown("- System will behave as if never configured")
            
            # Confirmation checkbox
            confirm_delete = st.checkbox("I understand this will completely reset the token system")
            
            if st.button("🗑️ Delete All Token Data", type="secondary", disabled=not confirm_delete):
                with st.spinner("Deleting token data..."):
                    if delete_github_token(CLIENT):
                        st.success("✅ All token data deleted successfully!")
                        st.info("🔄 System reset complete. You can now test from scratch.")
                        time.sleep(3)
                        st.rerun()
                    else:
                        st.error("❌ Failed to delete token data. Check debug info for details.")

# --- Debug Info Page ---
def debug_page():
    # Prominent debug indicator at the top
    if st.session_state.get('debug_mode', False):
        st.markdown("<h3 style='color:green;'>DEBUG MODE IS ON for Debug Info Page.</h3>", unsafe_allow_html=True)

    st.title("Debug Information")
    st.markdown("Use this page to toggle debug mode for detailed logging.")

    # Initialize debug_mode in session state if not present
    if 'debug_mode' not in st.session_state:
        st.session_state['debug_mode'] = False

    # Toggle switch for debug mode
    st.session_state['debug_mode'] = st.toggle(
        "Enable Debug Mode",
        value=st.session_state['debug_mode'],
        help="Turn on to see additional debug messages in the app and console."
    )

    if st.session_state['debug_mode']:
        st.subheader("Current Session State (for debugging):")
        st.json(st.session_state)
    else:
        st.info("Debug mode is OFF.")


# --- Main Application Entry Point ---
def app():
    st.set_page_config(
        page_title="CDF Project Deployment Dashboard",
        page_icon="🚀",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    # Custom CSS for sidebar transparency, text input background/width, and proper text contrast
    st.markdown(
        """
        <style>
        /* Main app background and text color */
        .stApp {
            background-color: #ffffff !important;
            color: #262730 !important;
        }
        
        /* Sidebar transparency and all sidebar text */
        [data-testid="stSidebar"] {
            background-color: rgba(255, 255, 255, 0.95) !important; /* White with 95% opacity */
            transition: all 0.3s ease-in-out;
            color: #262730 !important;
        }
        [data-testid="stSidebar"] > div:first-child {
            background-color: rgba(255, 255, 255, 0.95) !important;
        }
        
        /* All sidebar text elements */
        [data-testid="stSidebar"] * {
            color: #262730 !important;
        }
        
        /* Ensure all text elements have proper contrast */
        .stMarkdown, .stText, .stCaption, .stSubheader, .stHeader, .stTitle, p, span, div, label {
            color: #262730 !important;
        }
        
        /* Radio button styling - comprehensive coverage */
        .stRadio > div {
            color: #262730 !important;
        }
        .stRadio > div > label {
            color: #262730 !important;
        }
        .stRadio > div > label > div {
            color: #262730 !important;
        }
        .stRadio > div > label > div > p {
            color: #262730 !important;
        }
        .stRadio label {
            color: #262730 !important;
        }
        .stRadio span {
            color: #262730 !important;
        }
        
        /* All radio button related elements */
        [data-testid="stRadio"] * {
            color: #262730 !important;
        }
        
        /* Selectbox text and options - comprehensive coverage */
        .stSelectbox > div > div > div {
            background-color: white !important;
            color: #262730 !important;
        }
        .stSelectbox * {
            color: #262730 !important;
        }
        
        /* Selectbox dropdown options */
        [data-baseweb="select"] {
            color: #262730 !important;
        }
        [data-baseweb="select"] * {
            color: #262730 !important;
        }
        
        /* Dropdown menu options */
        [role="listbox"] {
            background-color: white !important;
        }
        [role="listbox"] * {
            color: #262730 !important;
            background-color: white !important;
        }
        [role="option"] {
            color: #262730 !important;
            background-color: white !important;
        }
        [role="option"]:hover {
            background-color: #f0f0f0 !important;
            color: #262730 !important;
        }
        
        /* Ensure all select elements are visible */
        select, option {
            color: #262730 !important;
            background-color: white !important;
        }
        
        /* Text input styling */
        div[data-testid="stTextInput"] > div[data-baseweb="input"] {
            background-color: white !important;
            border: 1px solid #ccc; /* Add a border to define the box */
            border-radius: 0.25rem; /* Match Streamlit's default border-radius */
            max-width: 20ch !important; /* Set max width for the whole visible input box to 20 characters */
            width: 100% !important; /* Ensure it takes full width of its parent */
            box-sizing: border-box !important; /* Include padding/border in width calculation */
            margin: 0 !important; 
        }
        
        /* Text input actual input element */
        div[data-testid="stTextInput"] > div[data-baseweb="input"] > input {
            background-color: white !important;
            color: #262730 !important;
            padding: 0.75rem 1rem !important;
            box-sizing: border-box !important;
        }
        
        /* Form elements */
        .stTextArea > div > div > textarea {
            background-color: white !important;
            color: #262730 !important;
        }
        
        /* Button styling */
        .stButton > button {
            background-color: #ff6b6b !important;
            color: white !important;
            border: none !important;
        }
        
        /* Clean button specific styling */
        .stButton > button[title*="Clean"], .stButton > button[aria-label*="Clean"] {
            background-color: #dc3545 !important;
            color: white !important;
            border: 1px solid #dc3545 !important;
        }
        .stButton > button[title*="Clean"]:hover, .stButton > button[aria-label*="Clean"]:hover {
            background-color: #c82333 !important;
            color: white !important;
        }
        
        /* Ensure all buttons have visible text */
        button {
            color: white !important;
        }
        button[kind="secondary"] {
            background-color: #6c757d !important;
            color: white !important;
            border: 1px solid #6c757d !important;
        }
        
        /* Alert styling */
        .stSuccess {
            background-color: #d4edda !important;
            color: #155724 !important;
        }
        .stWarning {
            background-color: #fff3cd !important;
            color: #856404 !important;
        }
        .stError {
            background-color: #f8d7da !important;
            color: #721c24 !important;
        }
        .stInfo {
            background-color: #d1ecf1 !important;
            color: #0c5460 !important;
        }
        
        /* Checkbox text */
        .stCheckbox > label > div > p {
            color: #262730 !important;
        }
        .stCheckbox * {
            color: #262730 !important;
        }
        
        /* File uploader text and button */
        .stFileUploader * {
            color: #262730 !important;
        }
        
        /* File uploader button specifically */
        .stFileUploader > div > div > button {
            background-color: #f0f0f0 !important;
            color: #262730 !important;
            border: 1px solid #ccc !important;
        }
        .stFileUploader > div > div > button:hover {
            background-color: #e0e0e0 !important;
            color: #262730 !important;
        }
        
        /* File uploader drag and drop area */
        .stFileUploader > div > div {
            background-color: white !important;
            border: 2px dashed #ccc !important;
            color: #262730 !important;
        }
        
        /* File uploader text inside the drop area */
        .stFileUploader label {
            color: #262730 !important;
        }
        .stFileUploader span {
            color: #262730 !important;
        }
        
        /* Upload button text */
        [data-testid="stFileUploader"] button {
            background-color: #f0f0f0 !important;
            color: #262730 !important;
            border: 1px solid #ccc !important;
        }
        [data-testid="stFileUploader"] button:hover {
            background-color: #e0e0e0 !important;
            color: #262730 !important;
        }
        
        /* All labels and form labels */
        [data-testid="stWidgetLabel"] {
            color: #262730 !important;
        }
        
        /* Style the stMarkdown label to remove default bottom margin */
        div[data-testid="stMarkdownContainer"] {
            margin-bottom: 0px !important;
            padding-bottom: 0px !important;
            line-height: 1.0;
            color: #262730 !important;
        }
        
        /* Target the div that contains the stMarkdown label and the stTextInput to reduce vertical spacing */
        div[data-testid="stVerticalBlock"] div[data-testid="stVerticalBlock"] {
            gap: 0rem;
        }
        
        /* Catch-all for any remaining white text */
        * {
            color: #262730 !important;
        }
        
        /* Override for elements that should stay white */
        .stButton > button, .stDownloadButton > button {
            color: white !important;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    st.sidebar.title("Navigation")
    
    # Use session state to persist sidebar selection
    if 'page_selection' not in st.session_state:
        st.session_state['page_selection'] = "Main Deployment"

    page_selection = st.sidebar.radio(
        "Go to:",
        ["Main Deployment", "GitHub Configuration", "Token Settings", "Debug Info"],
        index=["Main Deployment", "GitHub Configuration", "Token Settings", "Debug Info"].index(st.session_state['page_selection']) if st.session_state['page_selection'] in ["Main Deployment", "GitHub Configuration", "Token Settings", "Debug Info"] else 0,
        key='sidebar_radio_selection'
    )
    st.session_state['page_selection'] = page_selection


    # Route to the selected page function
    if page_selection == "Main Deployment":
        main_deployment_page()
    elif page_selection == "GitHub Configuration":
        github_config_page()
    elif page_selection == "Token Settings":
        token_settings_page()
    elif page_selection == "Debug Info":
        debug_page()

# --- Environment Configuration Functions ---

def sanitize_env_content(content):
    """
    Sanitize environment file content by removing carriage returns and normalizing line endings.
    This fixes issues with Windows-created files that contain \r characters.
    """
    if not content:
        return content
    
    # Replace Windows line endings (CRLF) with Unix line endings (LF)
    # Also strip any trailing/leading whitespace from each line
    lines = content.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    sanitized_lines = [line.rstrip() for line in lines]
    return '\n'.join(sanitized_lines)

def extract_env_value(env_content, key):
    """
    Safely extract a value from environment content, handling Windows line endings.
    Returns the value with all whitespace stripped, or None if not found.
    """
    if not env_content:
        return None
    
    # Ensure content is sanitized first
    sanitized_content = sanitize_env_content(env_content)
    lines = sanitized_content.split('\n')
    
    for line in lines:
        line = line.strip()
        if line.startswith(f'{key}='):
            value = line.split('=', 1)[1].strip()
            # Remove any quotes around the value
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            return value.strip()  # Final strip to ensure no whitespace
    
    return None

def get_sanitized_cdf_project():
    """
    Get the CDF project name from session state with proper sanitization.
    This ensures no carriage returns or extra whitespace in the project name.
    """
    project = st.session_state.get("main_cdf_project", "")
    if project:
        # Strip any whitespace or carriage returns that might have been stored
        project = project.strip().replace('\r', '').replace('\n', '')
    return project

def get_local_env_files():
    """Get list of local .env files from ~/envs directory"""
    import pathlib
    envs_dir = pathlib.Path.home() / "envs"
    if not envs_dir.exists():
        return []
    
    env_files = list(envs_dir.glob(".env.*"))
    # Return tuples of (display_name, file_path)
    return [(f.name, str(f)) for f in env_files if f.is_file()]

def read_env_file(file_path):
    """Read content of an environment file"""
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            return sanitize_env_content(content)
    except Exception as e:
        st.error(f"Failed to read env file: {e}")
        return None

# CDF storage functions - Commented out for testing later
# def save_env_config_to_cdf(client, name, content):
#     """Save environment configuration to CDF Raw"""
#     if client is None or IS_LOCAL_ENV:
#         st.error("Cannot save to CDF - running in local mode or no CDF client available")
#         return False
#         
#     try:
#         from datetime import datetime
#         
#         # Ensure database and table exist
#         try:
#             client.raw.databases.create(ENV_DATABASE)
#         except:
#             pass  # Database might already exist
#             
#         try:
#             client.raw.tables.create(ENV_DATABASE, ENV_TABLE)
#         except:
#             pass  # Table might already exist
#         
#         # Save the configuration
#         config_data = {
#             "name": name,
#             "content": content,
#             "uploaded_date": datetime.now().isoformat(),
#             "uploaded_by": get_user(client) if not IS_LOCAL_ENV else "local_user"
#         }
#         
#         client.raw.rows.insert(ENV_DATABASE, ENV_TABLE, [{"key": name, "columns": config_data}])
#         return True
#         
#     except Exception as e:
#         st.error(f"Failed to save environment config to CDF: {e}")
#         return False

# def get_stored_env_configs(client):
#     """Get list of stored environment configurations from CDF Raw"""
#     if client is None or IS_LOCAL_ENV:
#         return []
#         
#     try:
#         rows = client.raw.rows.list(ENV_DATABASE, ENV_TABLE)
#         configs = []
#         for row in rows:
#             configs.append({
#                 "name": row.columns.get("name", row.key),
#                 "key": row.key,
#                 "uploaded_date": row.columns.get("uploaded_date", "Unknown"),
#                 "uploaded_by": row.columns.get("uploaded_by", "Unknown")
#             })
#         return configs
#     except:
#         return []  # Table doesn't exist or other error

# def load_env_config_from_cdf(client, config_key):
#     """Load environment configuration content from CDF Raw"""
#     if client is None or IS_LOCAL_ENV:
#         return None
#         
#     try:
#         row = client.raw.rows.retrieve(ENV_DATABASE, ENV_TABLE, config_key)
#         return row.columns.get("content", "")
#     except Exception as e:
#         st.error(f"Failed to load environment config: {e}")
#         return None

if __name__ == "__main__":
    app()