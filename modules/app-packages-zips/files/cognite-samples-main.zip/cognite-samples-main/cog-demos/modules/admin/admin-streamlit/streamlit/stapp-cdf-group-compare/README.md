# CDF Group Access Comparison Streamlit

A comprehensive tool for comparing group access permissions between two CDF (Cognite Data Fusion) environments, with capability management and human-readable reporting.

## 🚀 Features

### Core Functionality
- **Side-by-side group comparison** between two CDF environments
- **Human-readable capability names** (150+ technical-to-readable mappings)
- **Missing group detection** with complete capability analysis
- **Group mapping interface** for cross-environment name mismatches
- **Individual & bulk capability addition** (preview mode)

### Dual Operation Modes
- **Local Mode**: Auto-loads specified .env files for development
- **SaaS Mode**: File upload interface for production deployment

### Enhanced UX
- **Auto-detection** of CDF project names and cluster info
- **Smart group mapping** with potential mismatch detection
- **Comprehensive error handling** and debugging capabilities
- **Copy-friendly JSON formatting** for manual recreation

## 📁 Usage

### Local Development Mode

```bash
# Navigate to the streamlit directory
cd cog-demos/modules/admin/admin-streamlit/streamlit/stapp-cdf-group-compare

# Run the startup script (enables local mode automatically)
./start_group_compare.sh
```

**Local Mode Features:**
- Automatically loads: `~/envs/.env.bluefield.cog-bgfast.bgfast` and `~/envs/.env.az-eastus-1.cog-demos.z-brent`
- No file upload required
- Instant environment detection
- Debug information included

### SaaS/Production Mode

```bash
# Run without local mode
streamlit run main.py --server.port 8501
```

**SaaS Mode Features:**
- File upload interface for .env files
- Works with any CDF environment
- Secure file handling
- No local file dependencies

### Manual Startup

```bash
# Set local mode manually
export STREAMLIT_LOCAL_MODE=true
streamlit run main.py --server.port 8501

# Or via URL parameter
# http://localhost:8501?local=true
```

## 🛠️ Open Tasks & Known Issues

### 🔴 **HIGH PRIORITY**

#### 1. DataFrame Serialization Errors
- **Status**: Active errors in logs
- **Issue**: `ArrowTypeError: Expected bytes, got a 'int' object` for column 'bgfast'
- **Impact**: Repeated serialization failures, though app still functions
- **Error Pattern**: 
  ```
  pyarrow.lib.ArrowTypeError: ("Expected bytes, got a 'int' object", 
  'Conversion failed for column bgfast with type object')
  ```
- **Fix Needed**: Ensure all DataFrame columns have consistent data types

#### 2. Group Mapping Dropdown Loading
- **Status**: Partially resolved, debug info added
- **Issue**: Dropdowns not consistently populating with group names
- **Debug**: Added extensive logging to identify root cause
- **Next Steps**: Review debug output to identify connection/parsing issues

### 🟡 **MEDIUM PRIORITY**

#### 3. Text Visibility Issues
- **Status**: Reported but not addressed
- **Issue**: "White text on white background in page menu and radio button options"
- **Fix Needed**: Add custom Streamlit theming/CSS for readable text contrast

#### 4. Real CDF SDK Integration
- **Status**: Currently preview/placeholder mode
- **Missing**: Actual implementation of `add_capability_to_group()` function
- **Requirements**:
  - Proper CDF SDK capability addition API calls
  - Error handling and rollback mechanisms
  - Confirmation dialogs for destructive operations
  - Group creation functionality

### 🟢 **LOW PRIORITY**

#### 5. Performance Optimization
- **Current**: Multiple sequential CDF API calls for group mapping
- **Improvements Needed**:
  - Caching mechanisms
  - Connection pooling
  - Parallel API requests
  - Session management

#### 6. Enhanced Error Handling
- **Current**: Basic error messages
- **Improvements Needed**:
  - Specific error codes
  - Retry mechanisms
  - Better connection status reporting
  - Network timeout handling

## 🔧 Technical Details

### Dependencies
- `streamlit` - Web application framework
- `cognite.client` - CDF SDK for API interactions
- `pandas` - Data manipulation and analysis
- `json` - JSON data handling

### File Structure
```
stapp-cdf-group-compare/
├── main.py                    # Main Streamlit application
├── start_group_compare.sh     # Local development startup script
└── README.md                  # This documentation
```

### Environment Variables
- `STREAMLIT_LOCAL_MODE=true` - Enables local mode with preset .env files
- Standard CDF environment variables from .env files:
  - `CDF_CLUSTER` - CDF cluster URL
  - `CDF_PROJECT` - CDF project name
  - `IDP_CLIENT_ID` - OAuth client ID
  - `IDP_CLIENT_SECRET` - OAuth client secret
  - `IDP_TENANT_ID` - Azure tenant ID

### Key Functions
- `get_readable_capability_name()` - Converts technical capability names to human-readable format
- `get_all_groups_details()` - Retrieves comprehensive group information from CDF
- `compare_all_groups()` - Performs cross-environment group comparison
- `add_capability_to_group()` - (Placeholder) Adds missing capabilities to groups

## 📊 Current Status

### ✅ **Working Features**
- Environment loading (both local and SaaS modes)
- Group retrieval and comparison
- Human-readable capability display
- Missing group detection
- Comprehensive reporting interface
- Group mapping configuration

### ⚠️ **Issues in Progress**
- DataFrame serialization warnings (non-blocking)
- Group mapping dropdown population
- Text visibility in some themes

### 🚧 **Preview Features**
- Capability addition buttons (show intended functionality)
- Bulk group creation (design complete, implementation pending)

## 🎯 Future Enhancements

1. **Real-time capability synchronization**
2. **Automated group creation workflows**
3. **Integration with CDF deployment pipelines**
4. **Historical comparison tracking**
5. **Custom capability templates**
6. **Role-based access for different user types**

## 🐛 Debugging

The application includes extensive debug information when issues occur:
- Environment variable loading status
- Connection details for both environments
- Group loading progress and errors
- Detailed error tracebacks

To enable additional debugging, check the browser console and Streamlit logs for detailed error information.

## 📝 Contributing

When working on this tool:
1. Test both local and SaaS modes
2. Verify group mapping functionality with real environments
3. Check DataFrame serialization with various data types
4. Ensure proper error handling for network issues
5. Test with different CDF cluster configurations

---

**Last Updated**: July 2, 2025  
**Status**: Merged to main branch, actively maintained 