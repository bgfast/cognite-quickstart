# 🔗 Multi-Worktree Management Guide

## 📍 Your Current Worktree Setup

| Worktree | Branch | Purpose | Color Code |
|----------|--------|---------|------------|
| `cognite-samples-1` | `main` | 🟢 Production/stable code | Green title bar |
| `cognite-samples-2` | `testing/new-feature-a` | 🔵 Feature testing | Blue title bar |
| `cognite-samples-3` | `feature/organize-pid-modules` | 🔴 PID modules development | Red title bar |

## 🎨 Visual Identification Features

### 1. **Cursor Title Bars**
Each Cursor instance now has:
- **Unique title**: Shows purpose in window title
- **Color-coded title bar**: Instant visual identification
- **Matching status bar**: Consistent color theming

### 2. **Enhanced Terminal Prompt**
Your terminal now shows:
```bash
user@machine:~/path [worktree-name:branch-name]$ 
```

### 3. **Quick Identification Command**
Run `whereami` in any terminal to see:
```
🔍 WORKTREE IDENTIFICATION
==========================
📁 Directory: /Users/you/p/cognite-samples-3
🌿 Worktree: cognite-samples-3
🔀 Branch: feature/organize-pid-modules
📋 Status: 2 uncommitted changes
🎯 Purpose:
   🔴 PID MODULES - Industry P&ID module development
==========================
```

## 🚀 Quick Start Commands

```bash
# Check which worktree you're in
whereami

# List all worktrees
git worktree list

# Switch to a specific worktree
cd /Users/brent.groom@cognitedata.com/p/cognite-samples-1  # Main
cd /Users/brent.groom@cognitedata.com/p/cognite-samples-2  # Testing  
cd /Users/brent.groom@cognitedata.com/p/cognite-samples-3  # PID Modules
```

## 💡 Best Practices

1. **Before Starting Work**: Run `whereami` to confirm you're in the right context
2. **Check Title Bar**: Look for the color-coded title bar in Cursor
3. **Terminal Prompt**: Always check the `[worktree:branch]` indicator
4. **Regular Status**: Run `git status` to see what you're working on

## 🔧 What Was Changed

### Files Modified:
- `~/.zshrc` - Enhanced terminal prompt and PATH
- `.vscode/settings.json` in each worktree - Custom titles and colors
- `~/bin/whereami` - Quick identification script

### Backup Created:
- `~/.zshrc.backup.YYYYMMDD` - Your original zsh configuration

## 🆘 Troubleshooting

### If colors don't show:
1. Restart Cursor instances
2. Reload window: `Cmd+Shift+P` → "Developer: Reload Window"

### If prompt doesn't update:
```bash
source ~/.zshrc
```

### If whereami command not found:
```bash
echo $PATH  # Should include /Users/your-username/bin
chmod +x ~/bin/whereami
```

---
**Remember**: Visual cues are your friend! 🎨
- 🟢 Green = Main/Production
- 🔵 Blue = Testing
- 🔴 Red = PID Development 