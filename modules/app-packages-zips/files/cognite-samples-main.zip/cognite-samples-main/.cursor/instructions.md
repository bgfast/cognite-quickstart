# Cursor AI Instructions for cognite-samples

## Core Development Principles

### Authentication & Environment
- **NEVER** hardcode tokens or credentials
- **ALWAYS** use `source cdfenv.sh` for CDF environment variables
- **ALWAYS** implement `IS_LOCAL_ENV` detection in streamlit apps

### Development Modes

#### Local Development Mode
Use this mode when:
- Making rapid iterative changes
- Debugging data model issues
- Testing configuration changes
- Working offline

```bash
# 1. Set environment variables
source cdfenv.sh && cdfenv your-environment

# 2. Create test config (never commit)
cp cog-demos/config.dynamic.yaml cog-demos/config.test.yaml
CDF_PROJECT=test poetry run python scripts/update_config_modules.py cog-demos/config.test.yaml "your/module"

# 3. Build and test locally
cdf clean
cdf build --env test
cdf deploy --env test

# 4. Clean up after testing
rm cog-demos/config.test.yaml
```

#### GitHub Actions Mode (Recommended)
Use this mode when:
- Deploying to shared environments
- Making production changes
- Working with secrets/variables
- Running full CI/CD pipeline

```bash
# 1. Check current branch
git branch --show-current

# 2. Trigger deployment
./scripts/trigger_dynamic_deployment.sh deploy your-env "your/module"

# 3. Monitor in GitHub Actions UI
# https://github.com/cognitedata/cognite-samples/actions
```

**⚠️ Important Rules:**
1. Never commit local test configs
2. Always clean up after local testing
3. Use GitHub Actions for final deployments
4. Local mode is for development only

### Error Handling Patterns
Common errors and solutions:
- `No ClientConfig provided` → CogniteClient initialization issue
- `No such file or directory` (config) → Missing config file creation
- `head: |: No such file or directory` → GitHub CLI failure
- `UnresolvedVariableWarning` → Missing config variables

### Development Workflow
1. **Choose development mode** based on task requirements
2. **Test locally** before any GitHub Actions changes
3. **Use proven patterns** from documentation
4. **Update documentation** with new learnings
5. **Commit changes** with clear messages

### Code Quality
- **Prefer Python scripts** over complex shell scripts for reliability
- **Use try-catch** for CogniteClient initialization
- **Implement graceful fallbacks** for authentication
- **Add clear error messages** and debugging output

### Communication Style
- **Be specific** about which documented patterns apply
- **Explain why** certain approaches are used
- **Update documentation** when discovering new patterns or solutions 