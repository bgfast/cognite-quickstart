## Introduction

Welcome to the **Field Engineering Demo Library** repository! This repository is designed to provide a common library of Cognite Data Fusion (CDF) demo modules that can be used, improved, and tailored to support different use cases and industries. Deployment from this environment does not require coding experience. The foundation of this demo environment is the **Valhall dataset** from Open Industrial Data. Additional data sources may be added as separate modules to extend or enhance the demos.

### Overview & Key Terms

- **Github Actions:** You can deploy to CDF through the Github UI using actions configured in the `Actions` tab in this repository.  You are not required to set up CDF toolkit on your own.

- **Github Environments:** All secrets and environmental variables are managed through the Github UI using a Github feature called Environments. You can access Github Environments in the `Settings` tab in this repository and then selecting `Environments`. Instructions on creating your environment are provided in the [Deployment Walkthrough](#deployment-walkthrough) section below.

- **Modules:** Each demo is organized into a "module." A module is a bundle of CDF resources, such as data models, time series, files, and Streamlit apps. While modules are not entirely self-contained, the number of inter-module dependencies should be minimized and documented. Each module should include its own `README.md` file with instructions and details.

- **Industry Models:** A key feature of this repository is the inclusion of **industry models**, located under the `cog-demo/modules/industry_models` folder. These models use the Valhall dataset as a base but modify asset and time series names to simulate demos for different industries, such as energy, chemicals, or biotech. This approach maintains compatibility with existing CDF artifacts created for the Valhall demo while offering industry-specific flexibility.

### Getting Started

To set up and deploy this demo environment, you will need to be an administrator in GitHub and have the appropriate permissions to enable deployment from a GitHub Action. 

## Multi-Worktree Development Setup

When working on multiple features simultaneously, you may want to use Git worktrees to maintain separate working directories for different branches. This is especially useful for this repository where you might be working on different modules or environments concurrently.

### The Challenge

Managing multiple Cursor/VS Code instances across different worktrees can be confusing - it's easy to lose track of which editor is working on which branch/feature, leading to mistakes and mixed-up changes.

### The Solution: Automated Visual Worktree Identification

This repository includes an **automated system** for managing color-coded worktrees! 🎨

#### 🚀 **Quick Setup (Recommended)**

**Set up all worktrees automatically:**
```bash
python scripts/setup-all-worktrees.py
```

**Or set up current worktree only:**
```bash
python scripts/setup-worktree-colors.py
```

**Check status of all worktrees:**
```bash
python scripts/worktree-status.py
```

The system automatically:
- ✅ Detects all your worktrees
- ✅ Assigns colors based on branch type (main=green, feature=red, etc.)
- ✅ Handles 1-10 worktrees intelligently
- ✅ Creates consistent color assignments
- ✅ Works for any team member who clones the repo

#### 🎨 **Auto-Assigned Color Scheme**
- 🟢 Green = Main/Production (`main`, `master`)
- 🔵 Blue = Testing/Staging (`test/*`, `staging`)
- 🔴 Red = Feature Development (`feature/*`, `feat/*`)
- 🟣 Purple = Hotfix/Urgent (`hotfix/*`, `fix/*`)
- 🟠 Orange = Experimental (`experiment/*`)
- Plus 5 more colors for additional worktrees

#### 🔧 **Manual Setup (Legacy)**

If you prefer manual setup, create a `.vscode/settings.json` file in each worktree:

```json
{
    "window.title": "PURPOSE - ${activeEditorShort}${separator}${rootName}",
    "workbench.colorCustomizations": {
        "titleBar.activeBackground": "#color-code",
        "titleBar.activeForeground": "#ffffff",
        "statusBar.background": "#color-code"
    }
}
```

#### 2. **Enhanced Terminal Identification**

Add this to your `~/.zshrc` (or `~/.bashrc`):

```bash
# Worktree identification function
show_git_worktree() {
    if git rev-parse --git-dir > /dev/null 2>&1; then
        local branch=$(git branch --show-current)
        local worktree_name=$(basename $(pwd))
        echo " [${worktree_name}:${branch}]"
    fi
}

# Enhanced prompt with worktree info
PS1='%F{cyan}%n@%m%f:%F{yellow}%~%f%F{green}$(show_git_worktree)%f$ '
```

#### 3. **Quick Identification Command**

Create a `whereami` script in `~/bin/whereami`:

```bash
#!/bin/bash
echo "🔍 WORKTREE IDENTIFICATION"
echo "=========================="
echo "📁 Directory: $(pwd)"
echo "🌿 Worktree: $(basename $(pwd))"
echo "🔀 Branch: $(git branch --show-current)"
echo "📋 Status: $(git status --porcelain | wc -l | xargs) uncommitted changes"
echo "=========================="
```

Make it executable: `chmod +x ~/bin/whereami` and add `~/bin` to your PATH.

### Usage

- **Visual**: Each Cursor instance will have a different colored title bar
- **Terminal**: Run `whereami` to see exactly which worktree and branch you're in
- **Prompt**: Your terminal prompt shows `[worktree-name:branch-name]`

### Git Worktree Quick Reference

```bash
# Create a new worktree
git worktree add ../repo-feature-name feature-branch-name

# List all worktrees  
git worktree list

# Remove a worktree
git worktree remove ../repo-feature-name
```

This setup eliminates confusion when working across multiple branches and helps prevent accidental commits to the wrong branch.

### Toolkit Documentation

If you are interested in learning more about toolkit and developing your own modules, visit the [Toolkit section](https://docs.cognite.com/cdf/deploy/cdf_toolkit/) on Cognite Docs for additional information. The [YAML reference library](https://docs.cognite.com/cdf/deploy/cdf_toolkit/references/resource_library) is particularly helpful to understand how YAML files are configured for each CDF artifact type, which will enable you to create your own modules. 

## Deployment Walkthrough
### Pre-requisites
These pre-requisites assume you are using Azure.
1. If you need to create a CDF environment, follow the steps outlined [here](https://cognitedata.atlassian.net/wiki/spaces/AP1/pages/4717740585/Creating+a+Demo+CDF) to create an internal environment. Don't create your own IdP organization if this is an internal demo (i.e. create the project directly under cog-demos).
2. In Entra ID, create an App Registration.
3. Add that App Registration to the CDF admin group for your organization, or manually create a group in CDF that gives the App Registration permissions comparable to the default `oidc-admin-group`.
4. Cognite Functions is not activated by default for a first time CDF deployment. If Cognite Functions is not activated before you try to deploy from GitHub, the deployment will fail. Go into the CDF web UI and access the Cognite Functions page to activate it. If this is a new CDF with no permissions added, you will need to manually add permissions for your user account so it has "read/write" for functions so you can access the page. You must wait for Cognite Functions to finish activating before running the GitHub action. Cognite Functions activation takes an hour or so.
5. Change the Data Modeling status of your CDF to "DATA_MODELING_ONLY" by submitting a ticket [here](https://cognitedata.atlassian.net/servicedesk/customer/portal/44/create/636). You can continue before this has been completed, but you will need to have this completed before you upload your 3D model.
6. A Github Environment with variables and secrets must be created in this repository for your CDF:
   - In this repository, go to GitHub: `Settings > Environments`.
   - Familiarize yourself with an example, like `valhall-demo`.
   - Create your environment using the same name as your CDF project.
   - Add your environment variables and secrets.  

### Deployment Steps

1. **Prepare Deployment YAML File**  
   - You can use a programming IDE (like VS Code) or the GitHub UI to create your own deployment YAML file. The steps are similar.
   - Navigate to the `cog-demos` folder.  
   - Download `config.template.yaml` to use as a template, and start customizing the parameters as needed for your environment. You will customize the modules in the next step.\
   - The `config.template.yaml` contains all modules for a basic Valhall deployment. Add additional modules if desired.
   - Name the file `config.<Your_CDF_Project>.yaml`
   - Create your own branch and check your YAML deployment file into GitHub.
   - Create a pull request and merge the branch back into `main`.

2. **Run the Deployment**  
   - Go to the GitHub Actions tab.  
   - Select the deployment action `Deploy modules to CDF project` and specify the branch (if not `main`) and the environment name corresponding to your YAML deployment file.
   - The first deployment will fail, but permissions will be created. Run the deployment a second itme. If it still fails, something else is wrong - see the troubleshooting section.

### Post-Deployment Steps for First Time Deployment
1. If you are deploying the Valhall dataset for the first time, you will need to run all three transformations, e.g. for `valhall-dm`:
   - tr_assets_to_cdm
   - tr_ts_to_cdm
   - tr_events_to_cdm
3. In your CDF's Data Management workspace, go to Configure > 3D and upload the Valhall 3D model [downloaded from here](https://drive.google.com/drive/folders/1JQdDRdlCzwn8IpFl1TPHQfgnGqrVDvx2?usp=sharing). After the model is uploaded, publish the model. NOTE: If your CDF is not set to "DATA_MODELING_ONLY", your 3D model will not be uploaded correctly. Ensure your CDF is set to "DATA_MODELING_ONLY" per the pre-requisites.
4. Go to Build Solutions > Functions and run the "Valhall 3D - Annotations" and "Valhall Files - Annotations" functions to contextualize P&IDs and the 3D model. Under the function details, you will find a data input example that tells you how to structure the input to the functions.

## Troubleshooting
- **My deployment run failed and I don't know why**: In the Github UI, click on the "workflow run" to view the log. This should give you an indication where it failed and why.
- **My deployment run failed because of an AuthorizationError**: On the first run, the deployment might fail due to insufficient permissions. Permissions are automatically added during this process. Re-run the deployment, and if everything else is correct, it should succeed. If it still doesn't work, there is a different problem and you should verify you have met the pre-requisites.
- **My deployment run was successful but the one or more functions says it failed to deploy**: Functions may fail to deploy for unknown reasons. If the deployment action succeeded but the function has a "Failed to deploy" error in the CDF UI, delete the function and re-run the deployment.
- **My deployment run was successful but the "Valhall Datapoints - OID Sync" function is timing out**:
  This is expected at first and temporary. `valhall_dm` contains a function that will backfill up to a month for each time series tag. Due to the volume of data during the initial backfill, it will time out for the initial few executions as it makes its way through the entire of list of tags. After a few timeouts, it will get caught up and succeed. 
  

## FAQ

### What is a module?
A module is a bundle of CDF resources, such as data models, time series, files, and Streamlits. A general practice is to create a module for each use case. While some dependencies between modules may exist, it is a good idea to use modules to minimize these dependencies.

### What is an industry model?
An industry model is a module under the `cog-demo/modules/industry_model` folder that applies industry-specific asset and time series names to the Valhall dataset. All external IDs remain the same, so this should make it interoperable with many CDF artifacts that were created against Valhall demo.

### Where do I go for help?
Ask for help in the `#americas-field-engineering` channel.
